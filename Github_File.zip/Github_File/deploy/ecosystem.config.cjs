// PM2 process file for VPS / cloud servers:  pm2 start deploy/ecosystem.config.cjs && pm2 save
module.exports = {
  apps: [{
    name: 'aura-isp',
    cwd: __dirname + '/../server',
    script: 'src/index.js',
    instances: 1, // scheduler runs in-process; scale horizontally with DISABLE_SCHEDULER=true on extra instances
    exec_mode: 'fork',
    max_memory_restart: '512M',
    env: { NODE_ENV: 'production' },
    autorestart: true, // required for self-updates (the app exits to restart on the new version)
    kill_timeout: 10000,
  }],
};
