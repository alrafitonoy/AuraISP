#!/usr/bin/env bash
# Renders each poster HTML to a 2160x2700 PNG (4:5, 2x for crisp text) with headless Chrome.
# Usage: bash render.sh [file.html ...]
cd "$(dirname "$0")"
CHROME="/c/Program Files/Google/Chrome/Application/chrome.exe"
mkdir -p png
for f in "${@:-*.html}"; do
  for h in $f; do
    out="png/${h%.html}.png"
    "$CHROME" --headless=new --disable-gpu --hide-scrollbars --force-device-scale-factor=2 \
      --window-size=1080,1350 --virtual-time-budget=6000 --screenshot="$(cygpath -w "$PWD/$out")" \
      "file:///$(cygpath -m "$PWD/$h")" >/dev/null 2>&1
    echo "$out"
  done
done
