// Service worker: Web Push notifications.
self.addEventListener('push', (event) => {
  let data = {};
  try { data = event.data.json(); } catch { data = { title: 'Notification', body: event.data?.text() }; }
  event.waitUntil(self.registration.showNotification(data.title || 'Notification', {
    body: data.body || '', icon: '/icon.svg', badge: '/icon.svg', data: { link: data.link || '/' },
  }));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const link = event.notification.data?.link || '/';
  const url = new URL(link.startsWith('/') ? link : '/', self.location.origin).href; // same-origin only
  event.waitUntil(clients.matchAll({ type: 'window' }).then((list) => {
    for (const c of list) if (c.url.startsWith(self.location.origin)) { c.navigate(url); return c.focus(); }
    return clients.openWindow(url);
  }));
});
