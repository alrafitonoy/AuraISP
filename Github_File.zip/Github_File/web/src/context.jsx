import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2, XCircle, Info } from 'lucide-react';
import { api, ApiError, client, handleSession, onAuthLost, refreshSession, setAccessToken, subscribe } from './lib/api.js';
import { setCurrency } from './lib/format.js';
import { appKind, getStoredToken, isNative, setStoredToken, needsServerSetup } from './lib/platform.js';

const Ctx = createContext(null);
export const useApp = () => useContext(Ctx);

function applyBrand(b) {
  const r = document.documentElement.style;
  if (b?.primary) r.setProperty('--brand-1', b.primary);
  if (b?.secondary) r.setProperty('--brand-2', b.secondary);
  if (b?.accent) r.setProperty('--brand-3', b.accent);
  if (b?.companyName) document.title = b.companyName;
  if (b?.faviconUrl) { const l = document.querySelector('link[rel=icon]'); if (l) l.href = b.faviconUrl; }
}

function resolveTheme(pref) {
  if (pref === 'light' || pref === 'dark') return pref;
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

export function AppProvider({ children }) {
  const [config, setConfig] = useState(null);
  const [user, setUser] = useState(null);
  const [booting, setBooting] = useState(true);
  const [themePref, setThemePref] = useState(() => { try { return localStorage.getItem('aura.theme') || ''; } catch { return ''; } });
  const [toasts, setToasts] = useState([]);
  const [notifications, setNotifications] = useState({ list: [], unread: 0 });
  const [liveBw, setLiveBw] = useState(null);
  const [chatTick, setChatTick] = useState(0);

  const theme = resolveTheme(themePref || config?.branding?.defaultTheme || 'system');
  useEffect(() => { document.documentElement.dataset.theme = theme; }, [theme]);
  const toggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    setThemePref(next);
    try { localStorage.setItem('aura.theme', next); } catch { /* ignore */ }
  };

  const toast = useCallback((message, kind = 'ok') => {
    const id = Math.random().toString(36).slice(2);
    setToasts((t) => [...t, { id, message, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4200);
  }, []);
  // Safety net: a button handler that awaits the API without its own try/catch used to fail silently (the spinner just
  // stopped). Any uncaught API error now shows its message. Expired sessions are handled by the auth flow instead.
  useEffect(() => {
    const onRejection = (e) => {
      const err = e.reason;
      if (!(err instanceof ApiError) || err.status === 401) return;
      e.preventDefault();
      toast(err.message || 'Something went wrong', 'bad');
    };
    window.addEventListener('unhandledrejection', onRejection);
    return () => window.removeEventListener('unhandledrejection', onRejection);
  }, [toast]);

  const loadConfig = useCallback(async () => {
    const c = await api('/public/config');
    setConfig(c); applyBrand(c.branding);
    setCurrency({ symbol: c.company.currencySymbol, code: c.company.currency });
    return c;
  }, []);

  useEffect(() => {
    if (needsServerSetup()) { setBooting(false); return; }
    (async () => {
      try { await loadConfig(); } catch { /* server unreachable */ }
      try { const s = await refreshSession(); setUser(s.user); } catch { /* not signed in */ }
      setBooting(false);
    })();
    return onAuthLost(() => setUser(null));
  }, [loadConfig]);

  const loadNotifications = useCallback(async () => {
    try { const n = await api('/notifications'); setNotifications({ list: n.notifications, unread: n.unread }); } catch { /* ignore */ }
  }, []);

  // Realtime: in-app notifications + live bandwidth.
  useEffect(() => {
    if (!user) return undefined;
    loadNotifications();
    return subscribe((ev, data) => {
      if (ev === 'notification') {
        setNotifications((n) => ({ list: [data, ...n.list].slice(0, 50), unread: n.unread + 1 }));
        toast(data.title, 'info');
      } else if (ev === 'bandwidth' || ev === 'network') setLiveBw(data);
      else if (ev === 'chat') { setChatTick((t) => t + 1); if (data?.title) toast(data.title, 'info'); }
    });
  }, [user, loadNotifications, toast]);

  const login = async (email, password) => {
    const res = await api.post('/auth/login', { email, password, client, app: appKind });
    if (res.mfaRequired) return res;
    await handleSession(res); setUser(res.user); return res;
  };
  const loginMfa = async (challenge, code) => {
    const res = await api.post('/auth/login/mfa', { challenge, code, client });
    await handleSession(res); setUser(res.user); return res;
  };
  const register = async (data) => {
    const res = await api.post('/auth/register', { ...data, client });
    await handleSession(res); setUser(res.user); return res;
  };
  const logout = async () => {
    try { await api.post('/auth/logout', isNative ? { refreshToken: await getStoredToken() } : {}); } catch { /* ignore */ }
    setAccessToken(null); await setStoredToken(null); setUser(null);
  };
  const refreshUser = async () => { const r = await api('/auth/me'); setUser(r.user); return r.user; };

  const can = useCallback((perm) => {
    if (!user) return false;
    if (user.type === 'admin') return true;
    if (user.type !== 'staff') return false;
    return user.permissions.includes('*') || user.permissions.includes(perm) || user.permissions.includes(`${String(perm).split('.')[0]}.*`);
  }, [user]);
  const moduleOn = useCallback((m) => config?.modules?.[m] !== false, [config]);

  const value = useMemo(() => ({
    config, loadConfig, user, setUser, booting, theme, toggleTheme, toast, login, loginMfa, register, logout, refreshUser, can, moduleOn,
    notifications, setNotifications, loadNotifications, liveBw, chatTick,
  }), [config, user, booting, theme, notifications, liveBw, chatTick, can, moduleOn]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <Ctx.Provider value={value}>
      {children}
      <div className="toasts" role="status" aria-live="polite">
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.div key={t.id} className={`toast ${t.kind}`} initial={{ opacity: 0, x: 60, scale: .9 }} animate={{ opacity: 1, x: 0, scale: 1 }} exit={{ opacity: 0, x: 60, scale: .9 }} transition={{ type: 'spring', stiffness: 380, damping: 28 }}>
              {t.kind === 'ok' ? <CheckCircle2 size={18} /> : t.kind === 'bad' ? <XCircle size={18} /> : <Info size={18} />}
              <div>{t.message}</div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </Ctx.Provider>
  );
}
