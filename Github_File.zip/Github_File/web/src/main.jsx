import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, HashRouter } from 'react-router-dom';
import { MotionConfig } from 'framer-motion';
import { AppProvider } from './context.jsx';
import App from './App.jsx';
import { isNative } from './lib/platform.js';
import './styles.css';

// Native shells load files from disk, so they use hash routing; the web uses clean URLs.
const Router = isNative ? HashRouter : BrowserRouter;

if ('serviceWorker' in navigator && !isNative && window.isSecureContext) {
  navigator.serviceWorker.register('/sw.js').catch(() => {});
}

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <MotionConfig reducedMotion="user">
      <Router>
        <AppProvider>
          <App />
        </AppProvider>
      </Router>
    </MotionConfig>
  </React.StrictMode>,
);
