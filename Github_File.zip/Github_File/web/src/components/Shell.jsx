import { useEffect, useRef, useState } from 'react';
import { NavLink, Outlet, useLocation, useNavigate, Link } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import {
  LayoutDashboard, Users, Package, Receipt, LifeBuoy, Activity, Router, BarChart3, ShieldBan, Wrench, MonitorSmartphone, Bell, Megaphone,
  Target, UserCog, Settings, CloudDownload, ScrollText, Menu, Sun, Moon, LogOut, Gauge, CreditCard, Baby, User, Check, Wifi,
  Network, FileBarChart, DatabaseBackup, MessagesSquare, Boxes, ClipboardList, Wallet, MapPinned, Map as MapIcon, IdCard, Globe,
} from 'lucide-react';
import { useApp } from '../context.jsx';
import { api } from '../lib/api.js';
import { ago, initials } from '../lib/format.js';
import { Button, Aurora, Avatar } from './ui.jsx';

export function Brand({ to = '/' }) {
  const { config } = useApp();
  const b = config?.branding || {};
  const name = b.companyName || 'AuraISP';
  const mode = ['both', 'logo', 'name'].includes(b.logoDisplay) ? b.logoDisplay : 'both';
  const mark = b.logoUrl ? <img src={b.logoUrl} alt={mode === 'logo' ? name : ''} /> : <span className="logo" aria-hidden={mode !== 'logo'}><Wifi size={18} /></span>;
  return (
    <Link to={to} className={`app-brand ${mode}-only`} aria-label={name} title={name}>
      {mode !== 'name' && mark}
      {mode !== 'logo' && <span className="brand-name">{name}</span>}
    </Link>
  );
}

export function ThemeToggle() {
  const { theme, toggleTheme } = useApp();
  return (
    <Button variant="ghost" onClick={toggleTheme} aria-label="Toggle theme" icon={null}>
      <AnimatePresence mode="wait" initial={false}>
        <motion.span key={theme} initial={{ rotate: -90, opacity: 0, scale: .6 }} animate={{ rotate: 0, opacity: 1, scale: 1 }} exit={{ rotate: 90, opacity: 0, scale: .6 }} transition={{ duration: .25 }} style={{ display: 'grid' }}>
          {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
        </motion.span>
      </AnimatePresence>
    </Button>
  );
}

function NotificationBell({ base }) {
  const { notifications, setNotifications } = useApp();
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const nav = useNavigate();
  useEffect(() => {
    const h = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
    document.addEventListener('mousedown', h); return () => document.removeEventListener('mousedown', h);
  }, []);
  const readAll = async () => { await api.post('/notifications/read-all'); setNotifications((n) => ({ list: n.list.map((x) => ({ ...x, read_at: x.read_at || new Date().toISOString() })), unread: 0 })); };
  const openItem = async (n) => {
    if (!n.read_at) { api.post(`/notifications/${n.id}/read`).catch(() => {}); setNotifications((s) => ({ list: s.list.map((x) => (x.id === n.id ? { ...x, read_at: new Date().toISOString() } : x)), unread: Math.max(0, s.unread - 1) })); }
    setOpen(false);
    if (n.link?.startsWith('/')) nav(n.link);
  };
  return (
    <div style={{ position: 'relative' }} ref={ref}>
      <Button variant="ghost" icon={Bell} onClick={() => setOpen((o) => !o)} aria-label="Notifications" />
      {notifications.unread > 0 && <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }} style={{ position: 'absolute', top: 4, right: 4, minWidth: 18, height: 18, borderRadius: 9, background: 'var(--grad-3)', color: '#fff', fontSize: 11, fontWeight: 700, display: 'grid', placeItems: 'center', padding: '0 4px', pointerEvents: 'none' }}>{notifications.unread > 99 ? '99+' : notifications.unread}</motion.span>}
      <AnimatePresence>
        {open && (
          <motion.div className="dropdown" initial={{ opacity: 0, y: -8, scale: .97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -8, scale: .97 }}>
            <div className="row between" style={{ padding: '14px 16px', borderBottom: '1px solid var(--border)' }}>
              <b>Notifications</b>
              <Button size="sm" variant="ghost" icon={Check} onClick={readAll}>Mark all read</Button>
            </div>
            <div style={{ maxHeight: 400, overflowY: 'auto' }}>
              {!notifications.list.length && <div className="empty">You're all caught up ✨</div>}
              {notifications.list.map((n) => (
                <button key={n.id} onClick={() => openItem(n)} style={{ all: 'unset', display: 'block', width: '100%', boxSizing: 'border-box', padding: '12px 16px', borderBottom: '1px solid var(--border)', cursor: 'pointer', background: n.read_at ? 'transparent' : 'var(--surface-2)' }}>
                  <div className="row between"><b style={{ fontSize: 14 }}>{n.title}</b><span className="faint">{ago(n.created_at)}</span></div>
                  <div className="faint" style={{ marginTop: 2, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{n.body}</div>
                </button>
              ))}
            </div>
            <Link to={base === '/admin' ? '/admin/me/notifications' : '/portal/notifications'} onClick={() => setOpen(false)} className="row" style={{ justifyContent: 'center', padding: 12, fontWeight: 600, fontSize: 14, color: 'var(--brand-1)' }}>View all</Link>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

const ADMIN_NAV = [
  { group: 'Overview' },
  { to: '/admin', icon: LayoutDashboard, label: 'Dashboard', end: true, perm: 'dashboard.view' },
  { group: 'Business' },
  { to: '/admin/customers', icon: Users, label: 'Customers', perm: 'customers.view' },
  { to: '/admin/plans', icon: Package, label: 'Plans', perm: 'plans.view' },
  { to: '/admin/billing', icon: Receipt, label: 'Billing', perm: 'billing.view', module: 'billing' },
  { to: '/admin/tickets', icon: LifeBuoy, label: 'Support', perm: 'tickets.view', module: 'support' },
  { to: '/admin/finance', icon: Wallet, label: 'Expenses & profit', perm: 'finance.view', module: 'finance' },
  { group: 'Operations' },
  { to: '/admin/jobs', icon: ClipboardList, label: 'Field jobs', perm: 'jobs.view', alt: 'jobs.work', module: 'jobs' },
  { to: '/admin/inventory', icon: Boxes, label: 'Inventory', perm: 'inventory.view', module: 'inventory' },
  { to: '/admin/map', icon: MapIcon, label: 'Network map', perm: 'network.view', module: 'network_map' },
  { to: '/admin/zones', icon: MapPinned, label: 'Zones & areas', perm: 'zones.manage', module: 'zones' },
  { to: '/admin/compliance', icon: IdCard, label: 'KYC & IP log', perm: 'kyc.view', module: 'kyc' },
  { group: 'Network' },
  { to: '/admin/network/live', icon: Activity, label: 'Live bandwidth', perm: 'network.view', module: 'bandwidth' },
  { to: '/admin/network/capacity', icon: Gauge, label: 'Core capacity', perm: 'network.view', module: 'bandwidth' },
  { to: '/admin/network/ipam', icon: Network, label: 'IP management', perm: 'network.view', module: 'ipam' },
  { to: '/admin/network/routers', icon: Router, label: 'Routers', perm: 'network.view' },
  { to: '/admin/network/traffic', icon: BarChart3, label: 'Traffic analysis', perm: 'network.view', module: 'traffic' },
  { to: '/admin/network/access', icon: ShieldBan, label: 'Access control', perm: 'network.view', module: 'access_control' },
  { to: '/admin/network/diagnostics', icon: Wrench, label: 'Device testing', perm: 'network.diagnostics', module: 'device_testing' },
  { to: '/admin/network/remote', icon: MonitorSmartphone, label: 'Remote support', perm: 'network.diagnostics', module: 'remote_support' },
  { group: 'Growth' },
  { to: '/admin/notifications', icon: Megaphone, label: 'Notifications', perm: 'notifications.send' },
  { to: '/admin/chat', icon: MessagesSquare, label: 'Live chat', perm: 'chat.handle', module: 'livechat' },
  { to: '/admin/crm', icon: Target, label: 'CRM & sales', perm: 'crm.view', module: 'crm' },
  { to: '/admin/reports', icon: FileBarChart, label: 'PDF reports', perm: 'reports.view', module: 'reports' },
  { group: 'System' },
  { to: '/admin/website', icon: Globe, label: 'Website', perm: 'settings.manage', module: 'website' },
  { to: '/admin/staff', icon: UserCog, label: 'Staff & roles', perm: 'staff.manage' },
  { to: '/admin/settings', icon: Settings, label: 'Settings', perm: 'settings.manage' },
  { to: '/admin/backups', icon: DatabaseBackup, label: 'Backups', perm: 'backups.manage' },
  { to: '/admin/updates', icon: CloudDownload, label: 'Updates', perm: 'updates.manage' },
  { to: '/admin/audit', icon: ScrollText, label: 'Audit log', perm: 'audit.view' },
];

const PORTAL_NAV = [
  { to: '/portal', icon: Gauge, label: 'Overview', end: true },
  { to: '/portal/billing', icon: CreditCard, label: 'Billing', module: 'billing' },
  { to: '/portal/plans', icon: Package, label: 'Plans', module: 'plan_sales' },
  { to: '/portal/support', icon: LifeBuoy, label: 'Support', module: 'support' },
  { to: '/portal/parental', icon: Baby, label: 'Parental controls', module: 'parental' },
  { to: '/portal/devices', icon: Wrench, label: 'Devices & tests', module: 'device_testing' },
  { to: '/portal/notifications', icon: Bell, label: 'Notifications' },
  { to: '/portal/profile', icon: User, label: 'Profile & security' },
];

export function Shell({ kind }) {
  const { user, logout, can, moduleOn } = useApp();
  const [open, setOpen] = useState(false);
  const loc = useLocation();
  useEffect(() => setOpen(false), [loc.pathname]);
  const base = kind === 'admin' ? '/admin' : '/portal';
  const items = (kind === 'admin' ? ADMIN_NAV : PORTAL_NAV).filter((i) => i.group || ((!i.perm || can(i.perm) || (i.alt && can(i.alt))) && (!i.module || moduleOn(i.module))));
  // drop empty groups
  const nav = items.filter((it, idx) => !it.group || (items[idx + 1] && !items[idx + 1].group));
  const current = nav.filter((n) => !n.group && (n.end ? loc.pathname === n.to : loc.pathname.startsWith(n.to))).sort((a, b) => b.to.length - a.to.length)[0];

  return (
    <>
      <Aurora />
      <div className="shell layer">
        <aside className={`sidebar ${open ? 'open' : ''}`}>
          <Brand to={base} />
          {nav.map((n, i) => n.group ? <div key={`g${i}`} className="nav-group">{n.group}</div> : (
            <NavLink key={n.to} to={n.to} end={n.end} className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
              {({ isActive }) => (<>{isActive && <motion.span layoutId={`pill-${kind}`} className="pill" transition={{ type: 'spring', stiffness: 400, damping: 34 }} />}<n.icon size={18} />{n.label}</>)}
            </NavLink>
          ))}
          <div className="grow" />
          <div className="card" style={{ padding: 12, marginTop: 12 }}>
            <div className="row">
              <Avatar user={user} />
              <div style={{ minWidth: 0, flex: 1 }}><div style={{ fontWeight: 600, fontSize: 14, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user?.name}</div><div className="faint">{user?.role?.name || user?.type}</div></div>
              <Button variant="ghost" size="sm" icon={LogOut} onClick={logout} aria-label="Sign out" />
            </div>
          </div>
        </aside>
        {open && <div className="scrim" onClick={() => setOpen(false)} />}
        <main className="main">
          <header className="topbar">
            <Button variant="ghost" className="mobile-only" icon={Menu} onClick={() => setOpen(true)} aria-label="Menu" />
            <h1>{current?.label || ''}</h1>
            <div className="grow" />
            {kind === 'admin' && <Link to="/admin/profile" className="btn ghost icon" aria-label="My profile"><User size={18} /></Link>}
            <ThemeToggle />
            <NotificationBell base={base} />
          </header>
          <div className="content">
            {/* No AnimatePresence "wait" and no opacity/blur: the new page mounts at once and is visible even if
                animation frames stall (previously a stuck exit animation left the content area empty). */}
            <motion.div key={loc.pathname} initial={{ y: 12 }} animate={{ y: 0 }} transition={{ duration: .28, ease: [.2, .8, .2, 1] }}>
              <Outlet />
            </motion.div>
          </div>
        </main>
      </div>
    </>
  );
}
