import { useEffect, useState } from 'react';
import { BadgeCheck, Download, Eye, FileText, ShieldCheck, Trash2, Upload, XCircle } from 'lucide-react';
import { useApp } from '../context.jsx';
import { api } from '../lib/api.js';
import { downloadFile } from '../lib/download.js';
import { dateTime } from '../lib/format.js';
import { Badge, Button, Card, Confirm, DataTable, Input, Modal, Select, Spinner, Textarea, useLoad } from './ui.jsx';

export const DOC_TYPES = {
  nid_front: 'NID (front)', nid_back: 'NID (back)', photo: 'Photo', passport: 'Passport', birth_certificate: 'Birth certificate',
  agreement: 'Service agreement', trade_license: 'Trade license', other: 'Other',
};
export const DOC_STATUS_TONE = { pending: 'warn', verified: 'ok', rejected: 'bad' };
const ACCEPT = 'image/jpeg,image/png,image/webp,application/pdf,.jpg,.jpeg,.png,.webp,.pdf';
const MAX = 5 * 1024 * 1024;

/** Image/PDF preview of a private document: fetched with the access token and shown from a blob: URL (never a public link). */
export function DocPreview({ doc, onClose }) {
  const { toast } = useApp();
  const [url, setUrl] = useState(null);
  const isImage = doc?.mime?.startsWith('image/');
  useEffect(() => {
    if (!doc) return undefined;
    let u = null; let alive = true;
    api(`/ops/documents/${doc.id}/file`, { raw: true })
      .then((r) => r.blob())
      .then((b) => { if (!alive) return; u = URL.createObjectURL(new Blob([b], { type: doc.mime || b.type })); setUrl(u); })
      .catch((e) => { toast(e.message, 'bad'); onClose(); });
    return () => { alive = false; if (u) URL.revokeObjectURL(u); };
  }, [doc?.id]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!doc) return null;
  return (
    <Modal open onClose={onClose} wide title={`${DOC_TYPES[doc.type] || doc.type}${doc.customer_name ? ` — ${doc.customer_name}` : ''}`} footer={<>
      <Button icon={Download} onClick={() => downloadFile(`/ops/documents/${doc.id}/file`, { fallbackName: `document-${doc.id}` }).catch((e) => toast(e.message, 'bad'))}>Download</Button>
      <Button onClick={onClose}>Close</Button>
    </>}>
      {!url ? <Spinner /> : isImage ? (
        <div style={{ display: 'grid', placeItems: 'center', background: 'var(--surface-2)', borderRadius: 'var(--radius-sm)', padding: 8 }}>
          <img src={url} alt={DOC_TYPES[doc.type] || 'Document'} style={{ maxWidth: '100%', maxHeight: '65vh', objectFit: 'contain', borderRadius: 8 }} />
        </div>
      ) : (
        <div className="col" style={{ alignItems: 'center', padding: 24, textAlign: 'center' }}>
          <FileText size={42} className="faint" />
          <div className="muted">PDF documents open in a new tab or can be downloaded.</div>
          <a className="btn primary" href={url} target="_blank" rel="noopener noreferrer"><Eye size={16} /> Open PDF</a>
        </div>
      )}
      {(doc.number || doc.note) && (
        <div className="row wrap mt" style={{ gap: 16 }}>
          {doc.number && <span><span className="faint">Number</span> <b>{doc.number}</b></span>}
          {doc.note && <span><span className="faint">Note</span> {doc.note}</span>}
        </div>
      )}
    </Modal>
  );
}

/** Verify / reject (with a reason) dialog. */
export function ReviewDoc({ doc, decision, onClose, onDone }) {
  const { toast } = useApp();
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  if (!doc) return null;
  const reject = decision === 'rejected';
  const submit = async () => {
    setBusy(true);
    try {
      await api.post(`/ops/documents/${doc.id}/verify`, { status: decision, note: note.trim() || null });
      toast(reject ? 'Document rejected' : 'Document verified'); onDone();
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  };
  return (
    <Modal open onClose={onClose} title={reject ? 'Reject document' : 'Verify document'} footer={<>
      <Button onClick={onClose}>Cancel</Button>
      <Button variant={reject ? 'danger' : 'primary'} icon={reject ? XCircle : BadgeCheck} loading={busy} disabled={reject && note.trim().length < 3} onClick={submit}>{reject ? 'Reject' : 'Verify'}</Button>
    </>}>
      <div className="col">
        <div className="muted">{DOC_TYPES[doc.type] || doc.type}{doc.number ? ` · ${doc.number}` : ''}{doc.customer_name ? ` · ${doc.customer_name}` : ''}</div>
        <Textarea label={reject ? 'Reason (shown to the customer)' : 'Note (optional)'} maxLength={500} value={note} onChange={(e) => setNote(e.target.value)}
          placeholder={reject ? 'e.g. Photo is blurry, please upload a clearer image' : 'e.g. Matches the original NID'} autoFocus />
      </div>
    </Modal>
  );
}

function UploadForm({ self, customerId, onDone }) {
  const { toast } = useApp();
  const [type, setType] = useState('nid_front');
  const [number, setNumber] = useState('');
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [inputKey, setInputKey] = useState(0);
  const submit = async (e) => {
    e.preventDefault();
    if (!file) { toast('Choose a file first', 'bad'); return; }
    if (file.size > MAX) { toast('File too large (max 5 MB)', 'bad'); return; }
    const form = new FormData(); form.append('type', type); if (number.trim()) form.append('number', number.trim()); form.append('file', file);
    setBusy(true);
    try {
      await api(self ? '/ops/my/documents' : `/ops/customers/${customerId}/documents`, { method: 'POST', form });
      toast(self ? 'Document uploaded — we will review it shortly' : 'Document uploaded');
      setFile(null); setNumber(''); setInputKey((k) => k + 1); onDone();
    } catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  return (
    <form className="col" onSubmit={submit} style={{ padding: 14, border: '1px dashed var(--border-strong)', borderRadius: 'var(--radius-sm)', background: 'var(--surface-2)' }}>
      <div className="grid g2">
        <Select label="Document type" value={type} onChange={(e) => setType(e.target.value)} options={Object.entries(DOC_TYPES).map(([value, l]) => ({ value, label: l }))} />
        <Input label="Document number (optional)" maxLength={64} value={number} onChange={(e) => setNumber(e.target.value)} placeholder="e.g. NID number" />
      </div>
      <div className="row wrap">
        <label className="btn" style={{ maxWidth: '100%' }}>
          <Upload size={16} /> <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 220 }}>{file ? file.name : 'Choose file'}</span>
          <input key={inputKey} type="file" accept={ACCEPT} hidden onChange={(e) => setFile(e.target.files[0] || null)} aria-label="Document file" />
        </label>
        <Button variant="primary" type="submit" icon={Upload} loading={busy} disabled={!file}>Upload</Button>
        <span className="faint">JPEG, PNG, WEBP or PDF · max 5 MB</span>
      </div>
    </form>
  );
}

/**
 * KYC documents of one customer. Staff: pass customerId (needs kyc.view; uploads with kyc.verify or customers.edit;
 * verify/reject/delete with kyc.verify). Customer portal: <KycPanel self /> lists and uploads the signed-in customer's own.
 */
export default function KycPanel({ customerId, self = false }) {
  const { toast, can, moduleOn } = useApp();
  const enabled = moduleOn('kyc') && (self || can('kyc.view'));
  const { data, loading, error, reload } = useLoad(() => (enabled ? api(self ? '/ops/my/documents' : `/ops/customers/${customerId}/documents`) : Promise.resolve({ rows: [] })), [customerId, self, enabled]);
  const [preview, setPreview] = useState(null);
  const [review, setReview] = useState(null);
  const [del, setDel] = useState(null);
  if (!enabled) return null;
  const canUpload = self || can('kyc.verify') || can('customers.edit');
  const canVerify = !self && can('kyc.verify');
  const rows = data?.rows || [];
  const verified = rows.filter((d) => d.status === 'verified').length;
  const remove = async () => {
    try { await api.del(self ? `/ops/my/documents/${del.id}` : `/ops/documents/${del.id}`); toast('Document deleted'); reload(); } catch (e) { toast(e.message, 'bad'); }
  };
  return (
    <Card title={<span className="row" style={{ gap: 8 }}><ShieldCheck size={18} /> {self ? 'My documents (KYC)' : 'KYC documents'}</span>}
      actions={rows.length > 0 && <Badge kind={verified ? 'ok' : 'warn'}>{verified} of {rows.length} verified</Badge>}>
      <div className="col">
        {self && <p className="muted" style={{ margin: 0 }}>Upload your national ID (both sides) and a photo. Your documents are stored privately and only our verification staff can see them.</p>}
        {canUpload && <UploadForm self={self} customerId={customerId} onDone={reload} />}
        {error ? <div className="alert bad">{error.message}</div> : (
          <DataTable loading={loading} rows={rows} empty="No documents uploaded yet" columns={[
            { key: 'type', title: 'Document', render: (d) => <div><b>{DOC_TYPES[d.type] || d.type}</b>{d.number && <div className="faint">{d.number}</div>}</div> },
            { key: 'status', title: 'Status', render: (d) => <div><Badge kind={DOC_STATUS_TONE[d.status]}>{d.status}</Badge>{d.note && <div className="faint" style={{ maxWidth: 240, whiteSpace: 'normal' }}>{d.note}</div>}</div> },
            { key: 'created_at', title: 'Uploaded', render: (d) => <div>{dateTime(d.created_at)}{!self && d.uploaded_by_name && <div className="faint">by {d.uploaded_by_name}</div>}</div> },
            { key: 'actions', title: '', align: 'right', render: (d) => (
              <div className="row end" style={{ gap: 6 }} onClick={(e) => e.stopPropagation()}>
                <Button size="sm" icon={Eye} onClick={() => setPreview(d)} aria-label="Preview" title="Preview" />
                <Button size="sm" icon={Download} onClick={() => downloadFile(`/ops/documents/${d.id}/file`, { fallbackName: `document-${d.id}` }).catch((e) => toast(e.message, 'bad'))} aria-label="Download" title="Download" />
                {canVerify && d.status !== 'verified' && <Button size="sm" icon={BadgeCheck} onClick={() => setReview({ doc: d, decision: 'verified' })} aria-label="Verify" title="Verify" />}
                {canVerify && d.status !== 'rejected' && <Button size="sm" icon={XCircle} onClick={() => setReview({ doc: d, decision: 'rejected' })} aria-label="Reject" title="Reject" />}
                {(canVerify || (self && d.status !== 'verified')) && <Button size="sm" variant="ghost" icon={Trash2} onClick={() => setDel(d)} aria-label="Delete" title="Delete" />}
              </div>
            ) },
          ]} />
        )}
      </div>
      {preview && <DocPreview doc={preview} onClose={() => setPreview(null)} />}
      {review && <ReviewDoc doc={review.doc} decision={review.decision} onClose={() => setReview(null)} onDone={() => { setReview(null); reload(); }} />}
      <Confirm open={!!del} onClose={() => setDel(null)} onConfirm={remove} danger confirmText="Delete" title="Delete document?">
        {del && `${DOC_TYPES[del.type] || del.type} will be permanently deleted.`}
      </Confirm>
    </Card>
  );
}
