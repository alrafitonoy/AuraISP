// Public website chrome shared by the landing page and the sign-in / sign-up / password pages.
import { Link, useLocation } from 'react-router-dom';
import { Mail, Phone, MapPin, ArrowLeft } from 'lucide-react';
import { useApp } from '../context.jsx';
import { Brand, ThemeToggle } from './Shell.jsx';

export function SiteHeader() {
  const { moduleOn, user } = useApp();
  const { pathname } = useLocation();
  const site = moduleOn('website');
  const home = site ? '/' : '/login';
  // On /site (staff preview) section links must stay on the preview page instead of bouncing to the dashboard.
  const base = pathname.startsWith('/site') ? '/site' : '/';
  const link = (hash) => (base === '/site' ? `/site${hash}` : `/${hash}`);
  return (
    <header className="site-nav">
      <div className="container">
        <Brand to={base === '/site' ? '/site' : home} />
        {site && <nav aria-label="Website"><a href={link('#plans')}>Plans</a><a href={link('#features')}>Features</a><a href={link('#coverage')}>Coverage</a><a href={link('#faq')}>FAQ</a><a href={link('#contact')}>Contact</a></nav>}
        <div className="grow" />
        <ThemeToggle />
        {user ? (
          <Link to={user.type === 'customer' ? '/portal' : '/admin'} className="btn primary nav-btn">{user.type === 'customer' ? 'My account' : 'Dashboard'}</Link>
        ) : (
          <>
            {pathname !== '/login' && <Link to="/login" className="btn ghost nav-btn">Sign in</Link>}
            {pathname !== '/register' && site && <Link to="/register" className="btn primary nav-btn"><span className="long">Get connected</span><span className="short">Join</span></Link>}
          </>
        )}
      </div>
    </header>
  );
}

export function SiteFooter() {
  const { config, moduleOn } = useApp();
  const c = config?.company || {};
  const social = config?.website?.social || {};
  const site = moduleOn('website');
  return (
    <footer className="footer site-footer">
      <div className="container footer-grid">
        <div className="col" style={{ gap: 10 }}>
          <Brand to={site ? '/' : '/login'} />
          {config?.branding?.tagline && <p className="faint" style={{ margin: 0 }}>{config.branding.tagline}</p>}
        </div>
        <div className="col" style={{ gap: 8 }}>
          <b>Contact</b>
          {c.phone && <a href={`tel:${c.phone.replace(/[^\d+]/g, '')}`} className="row"><Phone size={14} /> {c.phone}</a>}
          {c.email && <a href={`mailto:${c.email}`} className="row"><Mail size={14} /> {c.email}</a>}
          {c.address && <span className="row faint"><MapPin size={14} /> {c.address}</span>}
        </div>
        <div className="col" style={{ gap: 8 }}>
          <b>Quick links</b>
          {site && <><a href="/#plans">Internet plans</a><a href="/#coverage">Check coverage</a><a href="/#faq">Help & FAQ</a></>}
          <Link to="/login">Customer sign in</Link>
          {site && <Link to="/register">New connection</Link>}
        </div>
        {Object.values(social).some(Boolean) && (
          <div className="col" style={{ gap: 8 }}>
            <b>Follow us</b>
            <div className="row wrap">{Object.entries(social).filter(([, v]) => v).map(([k, v]) => (
              <a key={k} href={k === 'whatsapp' ? `https://wa.me/${String(v).replace(/\D/g, '')}` : v} target="_blank" rel="noopener noreferrer" className="badge">{k}</a>
            ))}</div>
          </div>
        )}
      </div>
      <div className="container footer-bottom faint">© {new Date().getFullYear()} {c.name || config?.branding?.companyName}. All rights reserved.</div>
    </footer>
  );
}

/** Banner shown to signed-in staff who are previewing the public website at /site. */
export function PreviewBar() {
  return (
    <div className="preview-bar" role="status">
      <span>You are previewing the public website as visitors see it.</span>
      <Link to="/admin/website" className="btn sm"><ArrowLeft size={14} /> Back to admin</Link>
    </div>
  );
}
