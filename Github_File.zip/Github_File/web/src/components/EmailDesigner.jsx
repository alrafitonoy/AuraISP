// Email designer: pick a modern design, customise it, see a live preview and send yourself a test.
// Used by campaigns, broadcasts, notification templates and Settings → Email (the default look).
import { useEffect, useRef, useState } from 'react';
import { Mail, Send, Sparkles } from 'lucide-react';
import { useApp } from '../context.jsx';
import { api } from '../lib/api.js';
import { Button, Input } from './ui.jsx';

const SWATCH = {
  modern: ['#f3f4fb', '#7c5cff', '#ffffff'], bold: ['#7c5cff', '#00d4ff', '#ffffff'], minimal: ['#ffffff', '#ffffff', '#7c5cff'],
  promo: ['#f6f1ff', '#ff4ecd', '#ffffff'], dark: ['#07061a', '#141134', '#7c5cff'],
};

/** value: { design, heading, preheader, buttonText, buttonUrl, imageUrl, badge, accent, footerNote } | null */
export default function EmailDesigner({ value, onChange, subject, body, title = 'Email design', allowInherit = true, hint }) {
  const { toast } = useApp();
  const [designs, setDesigns] = useState(null);
  const [html, setHtml] = useState('');
  const [testing, setTesting] = useState(false);
  const v = value || {};
  const set = (patch) => onChange({ ...v, ...patch });
  const timer = useRef();

  useEffect(() => { api('/notifications/email-designs').then((r) => setDesigns(r.designs)).catch(() => setDesigns({})); }, []);
  // Live preview (debounced) — rendered by the server with exactly the code that sends real emails.
  useEffect(() => {
    clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      api.post('/notifications/email-preview', { subject, body, email_design: clean(v) }).then((r) => setHtml(r.html)).catch(() => {});
    }, 350);
    return () => clearTimeout(timer.current);
  }, [JSON.stringify(v), subject, body]); // eslint-disable-line react-hooks/exhaustive-deps

  const test = async () => {
    setTesting(true);
    try { const r = await api.post('/notifications/email-test', { subject, body, email_design: clean(v) }); toast(`Test email sent to ${r.to}`); }
    catch (e) { toast(e.message, 'bad'); } finally { setTesting(false); }
  };
  const design = v.design || '';

  return (
    <div className="card" style={{ padding: 16 }}>
      <div className="row between wrap" style={{ marginBottom: 10 }}>
        <b className="row" style={{ gap: 8 }}><Sparkles size={16} /> {title}</b>
        <Button size="sm" icon={Send} onClick={test} loading={testing} type="button">Send test to me</Button>
      </div>
      {hint && <p className="faint" style={{ marginTop: 0 }}>{hint}</p>}
      <div className="email-designer">
        <div className="col">
          <div className="design-grid" role="radiogroup" aria-label="Email design">
            {allowInherit && (
              <button type="button" role="radio" aria-checked={!design} className={`design-card ${!design ? 'on' : ''}`} onClick={() => set({ design: undefined })}>
                <span className="design-swatch" style={{ background: 'repeating-linear-gradient(45deg,var(--surface-2),var(--surface-2) 6px,transparent 6px,transparent 12px)' }}><Mail size={16} /></span>
                <b>Default</b><span className="faint">From Settings → Email</span>
              </button>
            )}
            {Object.entries(designs || {}).map(([k, d]) => (
              <button type="button" key={k} role="radio" aria-checked={design === k} className={`design-card ${design === k ? 'on' : ''}`} onClick={() => set({ design: k })} title={d.description}>
                <span className="design-swatch" style={{ background: `linear-gradient(135deg, ${SWATCH[k]?.[0]} 0 45%, ${SWATCH[k]?.[1]} 45% 75%, ${SWATCH[k]?.[2]} 75%)` }} />
                <b>{d.label}</b><span className="faint">{d.description}</span>
              </button>
            ))}
          </div>
          <div className="grid g2">
            <Input label="Headline" placeholder="Defaults to the subject" maxLength={200} value={v.heading || ''} onChange={(e) => set({ heading: e.target.value })} />
            <Input label="Inbox preview text" placeholder="Short line shown after the subject" maxLength={200} value={v.preheader || ''} onChange={(e) => set({ preheader: e.target.value })} />
            <Input label="Button text" placeholder="e.g. Pay now" maxLength={60} value={v.buttonText || ''} onChange={(e) => set({ buttonText: e.target.value })} />
            <Input label="Button link" placeholder="/portal/billing or https://…" maxLength={500} value={v.buttonUrl || ''} onChange={(e) => set({ buttonUrl: e.target.value })} />
            <Input label="Banner image (https URL)" placeholder="https://…/banner.jpg" maxLength={500} value={v.imageUrl || ''} onChange={(e) => set({ imageUrl: e.target.value })} />
            <Input label="Badge (Promo design)" placeholder="e.g. 20% OFF" maxLength={40} value={v.badge || ''} onChange={(e) => set({ badge: e.target.value })} />
            <label className="field"><span>Accent colour</span>
              <div className="row"><input type="color" value={v.accent || '#7c5cff'} onChange={(e) => set({ accent: e.target.value })} aria-label="Accent colour" style={{ width: 44, height: 40, border: 'none', background: 'none', cursor: 'pointer' }} />
                <Button size="sm" variant="ghost" type="button" onClick={() => set({ accent: '' })}>Use brand colour</Button></div></label>
            <Input label="Footer note" maxLength={300} value={v.footerNote || ''} onChange={(e) => set({ footerNote: e.target.value })} />
          </div>
          <p className="faint" style={{ margin: 0 }}>Text fields can use the same variables as the message, e.g. {'{{name}}'}. Blank fields use the default.</p>
        </div>
        <div className="email-preview">
          <div className="faint" style={{ fontSize: 12, marginBottom: 6 }}>Live preview (sample data)</div>
          {/* sandbox="" = no scripts, no forms, no navigation: the preview is inert. */}
          <iframe title="Email preview" sandbox="" srcDoc={html} />
        </div>
      </div>
    </div>
  );
}

/** Drop empty fields so the server falls back to the defaults. Returns null when nothing is customised. */
export function clean(v) {
  const out = Object.fromEntries(Object.entries(v || {}).filter(([, x]) => x !== undefined && x !== null && x !== ''));
  return Object.keys(out).length ? out : null;
}
