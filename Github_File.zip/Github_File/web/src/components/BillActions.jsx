import { useState } from 'react';
import { Eye, Printer, FileDown, ReceiptText } from 'lucide-react';
import { downloadFile } from '../lib/download.js';
import { useApp } from '../context.jsx';
import { openInvoice, printInvoice, downloadInvoicePdf } from '../lib/invoice.js';
import { Button } from './ui.jsx';

/** View · Print · PDF — shown beside every bill for customers, staff and admins. */
export default function BillActions({ invoice, compact }) {
  const { toast } = useApp();
  const [busy, setBusy] = useState('');
  const run = (kind, fn) => async (e) => {
    e?.stopPropagation();
    setBusy(kind);
    try { await fn(); } catch (err) { toast(err.message, 'bad'); } finally { setBusy(''); }
  };
  const size = 'sm';
  return (
    <div className="row" style={{ gap: 4 }} role="group" aria-label={`Bill ${invoice.number}`}>
      <Button size={size} variant="ghost" icon={Eye} loading={busy === 'view'} onClick={run('view', () => openInvoice(invoice.id))} title="View bill" aria-label="View bill">{compact ? null : <span className="btn-label">View</span>}</Button>
      <Button size={size} variant="ghost" icon={Printer} loading={busy === 'print'} onClick={run('print', () => printInvoice(invoice.id))} title="Print bill" aria-label="Print bill">{compact ? null : <span className="btn-label">Print</span>}</Button>
      <Button size={size} variant="ghost" icon={FileDown} loading={busy === 'pdf'} onClick={run('pdf', () => downloadInvoicePdf(invoice.id, invoice.number))} title="Download PDF" aria-label="Download PDF">{compact ? null : <span className="btn-label">PDF</span>}</Button>
    </div>
  );
}

/** Download the PDF receipt of a completed payment (customers: their own; staff: billing.view). */
export function ReceiptButton({ payment }) {
  const { toast } = useApp();
  const [busy, setBusy] = useState(false);
  if (payment?.status !== 'success' || payment.method === 'balance') return null;
  const get = async () => { setBusy(true); try { await downloadFile(`/pdf/payments/${payment.id}`, { fallbackName: `receipt-${payment.id}.pdf` }); } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); } };
  return <Button size="sm" variant="ghost" icon={ReceiptText} loading={busy} onClick={get} aria-label="Download receipt">Receipt</Button>;
}
