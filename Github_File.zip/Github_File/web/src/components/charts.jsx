import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar, PieChart, Pie, Cell, Legend } from 'recharts';

const axis = { stroke: 'var(--text-3)', fontSize: 11, tickLine: false, axisLine: false };
const tip = { contentStyle: { background: 'var(--surface-solid)', border: '1px solid var(--border)', borderRadius: 12, boxShadow: 'var(--shadow)', color: 'var(--text)' }, labelStyle: { color: 'var(--text-2)' } };
export const PALETTE = ['var(--brand-1)', 'var(--brand-2)', 'var(--brand-3)', '#10b981', '#f59e0b', '#3b82f6', '#8b5cf6', '#ef4444'];

function Grad({ id, color }) {
  return <defs><linearGradient id={id} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={color} stopOpacity={0.45} /><stop offset="100%" stopColor={color} stopOpacity={0} /></linearGradient></defs>;
}

export function AreaSeries({ data, x, series, height = 260, fmtY = (v) => v, fmtX = (v) => v }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={data} margin={{ top: 10, right: 8, left: 0, bottom: 0 }}>
        {series.map((s, i) => <Grad key={s.key} id={`g-${s.key}`} color={s.color || PALETTE[i]} />)}
        <CartesianGrid stroke="var(--border)" vertical={false} />
        <XAxis dataKey={x} {...axis} tickFormatter={fmtX} minTickGap={30} />
        <YAxis {...axis} tickFormatter={fmtY} width={64} />
        <Tooltip {...tip} formatter={(v, n) => [fmtY(v), series.find((s) => s.key === n)?.label || n]} labelFormatter={fmtX} />
        {series.map((s, i) => <Area key={s.key} type="monotone" dataKey={s.key} stroke={s.color || PALETTE[i]} strokeWidth={2.2} fill={`url(#g-${s.key})`} animationDuration={1100} />)}
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function Bars({ data, x, series, height = 260, fmtY = (v) => v, fmtX = (v) => v, stacked }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 10, right: 8, left: 0, bottom: 0 }}>
        <CartesianGrid stroke="var(--border)" vertical={false} />
        <XAxis dataKey={x} {...axis} tickFormatter={fmtX} />
        <YAxis {...axis} tickFormatter={fmtY} width={64} />
        <Tooltip {...tip} cursor={{ fill: 'var(--surface-2)' }} formatter={(v, n) => [fmtY(v), series.find((s) => s.key === n)?.label || n]} labelFormatter={fmtX} />
        {series.map((s, i) => <Bar key={s.key} dataKey={s.key} stackId={stacked ? 'a' : undefined} fill={s.color || PALETTE[i]} radius={[6, 6, 0, 0]} animationDuration={900} />)}
      </BarChart>
    </ResponsiveContainer>
  );
}

export function Donut({ data, nameKey = 'name', valueKey = 'value', height = 260, fmt = (v) => v }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <PieChart>
        <Pie data={data} dataKey={valueKey} nameKey={nameKey} innerRadius="58%" outerRadius="85%" paddingAngle={3} stroke="none" animationDuration={1000}>
          {data.map((_, i) => <Cell key={i} fill={PALETTE[i % PALETTE.length]} />)}
        </Pie>
        <Tooltip {...tip} formatter={(v) => fmt(v)} />
        <Legend iconType="circle" wrapperStyle={{ fontSize: 12, color: 'var(--text-2)' }} />
      </PieChart>
    </ResponsiveContainer>
  );
}
