import { useState } from 'react';
import { motion } from 'framer-motion';
import { Phone, MessageCircle, Mail, Code2 } from 'lucide-react';
import { Modal } from './ui.jsx';

// Fixed developer credit shown on every screen (website, portal, admin, desktop & mobile apps).
export default function CreditFooter() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" className="credit-bar" onClick={() => setOpen(true)} aria-haspopup="dialog">
        Developed by: <b>S.K.M. AL RAFI</b>
      </button>
      <Modal open={open} onClose={() => setOpen(false)} title="About the developer">
        <motion.div className="credit-card" initial={{ scale: .94 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 260, damping: 22 }}>
          <div className="credit-badge"><Code2 size={26} /></div>
          <p className="muted" style={{ margin: 0 }}>This system is developed by,</p>
          <h2 className="gradient-text" style={{ margin: '4px 0' }}>S.K.M. AL RAFI</h2>
          <p style={{ fontWeight: 600 }}>Software Engineer | Cybersecurity Analyst | IT Consultant</p>
          <div className="col" style={{ gap: 8, alignItems: 'stretch', textAlign: 'left' }}>
            <a className="credit-line" href="tel:+8801717151255"><Phone size={16} /> Phone: +880 1717-151255</a>
            <a className="credit-line" href="https://wa.me/8801717151255" target="_blank" rel="noopener noreferrer"><MessageCircle size={16} /> WhatsApp: +880 1717-151255</a>
            <a className="credit-line" href="mailto:alrafitonoy@gmail.com"><Mail size={16} /> Email: alrafitonoy@gmail.com</a>
          </div>
          <p className="credit-cta">Contact for your software</p>
        </motion.div>
      </Modal>
    </>
  );
}
