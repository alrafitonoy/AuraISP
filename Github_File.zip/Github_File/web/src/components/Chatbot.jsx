// Assistant widget: answers from the FAQ, and hands off to a HUMAN agent (live chat) on request.
import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { MessageCircle, X, Send, Sparkles, UserRound, Bot, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { api } from '../lib/api.js';
import { useApp } from '../context.jsx';
import { Avatar } from './ui.jsx';

const KEY = 'aura.livechat';
const loadChat = () => { try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch { return null; } };
const saveChat = (v) => { try { v ? localStorage.setItem(KEY, JSON.stringify(v)) : localStorage.removeItem(KEY); } catch { /* private mode */ } };

export default function Chatbot() {
  const { config, moduleOn, user } = useApp();
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState(() => (loadChat() ? 'human' : 'bot'));
  const [msgs, setMsgs] = useState([]);
  const [human, setHuman] = useState({ messages: [], status: null, agent: null });
  const [chat, setChat] = useState(loadChat);
  const [form, setForm] = useState({ name: '', contact: '', website: '' });
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [unread, setUnread] = useState(0);
  const end = useRef(null);
  const lastId = useRef(0);
  const nav = useNavigate();
  const liveOn = moduleOn('livechat');

  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }); }, [msgs, human.messages.length, busy, mode]);
  useEffect(() => {
    if (open && !msgs.length) setMsgs([{ from: 'bot', text: `Hi! 👋 I'm the ${config?.branding?.companyName || ''} assistant. How can I help?`, suggestions: ['How do I pay my bill?', 'My internet is slow', 'How do I upgrade my plan?'] }]);
    if (open) setUnread(0);
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  // Live chat polling (fast while open, slow in the background for the unread badge).
  useEffect(() => {
    if (!chat) return undefined;
    let stop = false;
    const tick = async () => {
      try {
        const r = await api(`/chat/${chat.id}/messages?after=${lastId.current}`, { headers: { 'X-Chat-Token': chat.token } });
        if (r.messages.length) {
          lastId.current = r.messages[r.messages.length - 1].id;
          setHuman((h) => ({ messages: [...h.messages, ...r.messages], status: r.status, agent: r.agent }));
          if (!open) setUnread((u) => u + r.messages.filter((m) => m.sender !== 'visitor').length);
        } else setHuman((h) => ({ ...h, status: r.status, agent: r.agent }));
      } catch (e) {
        if (e.status === 404) { saveChat(null); setChat(null); }
      }
      if (!stop) timer = setTimeout(tick, open ? 2500 : 15000);
    };
    let timer = setTimeout(tick, 50);
    return () => { stop = true; clearTimeout(timer); };
  }, [chat, open]);

  if (!moduleOn('chatbot') && !liveOn) return null;

  const askBot = async (q) => {
    const message = (q ?? text).trim();
    if (!message || busy) return;
    setText('');
    setMsgs((m) => [...m, { from: 'me', text: message }]);
    setBusy(true);
    try {
      const r = await api.post('/public/chatbot', { message });
      await new Promise((res) => setTimeout(res, 350));
      setMsgs((m) => [...m, { from: 'bot', text: r.reply, suggestions: r.suggestions, actions: r.actions, offerHuman: liveOn && (!r.matched || /human|agent|person/i.test(message)) }]);
    } catch (e) {
      setMsgs((m) => [...m, { from: 'bot', text: e.message }]);
    } finally { setBusy(false); }
  };

  const startHuman = async (e) => {
    e?.preventDefault();
    const firstMsg = text.trim() || msgs.filter((m) => m.from === 'me').map((m) => m.text).slice(-1)[0] || 'Hello, I would like to talk to someone.';
    setBusy(true);
    try {
      const r = await api.post('/chat/start', { message: firstMsg, ...(user ? {} : { name: form.name, contact: form.contact, website: form.website }) });
      const c = { id: r.id, token: r.token };
      saveChat(c); lastId.current = 0; setHuman({ messages: [], status: 'waiting', agent: null }); setChat(c); setText('');
    } catch (err) { setMsgs((m) => [...m, { from: 'bot', text: err.message }]); }
    finally { setBusy(false); }
  };

  const sendHuman = async (e) => {
    e?.preventDefault();
    const body = text.trim();
    if (!body || busy) return;
    setText(''); setBusy(true);
    try { await api.post(`/chat/${chat.id}/messages`, { body }, { headers: { 'X-Chat-Token': chat.token } }); lastId.current = Math.max(lastId.current, 0); setHuman((h) => ({ ...h, messages: [...h.messages, { id: `tmp${Date.now()}`, sender: 'visitor', body, created_at: new Date().toISOString(), pending: true }] })); }
    catch (err) { setHuman((h) => ({ ...h, messages: [...h.messages, { id: `err${Date.now()}`, sender: 'system', body: err.message }] })); }
    finally { setBusy(false); }
  };

  const endHuman = async () => {
    try { await api.post(`/chat/${chat.id}/end`, {}, { headers: { 'X-Chat-Token': chat.token } }); } catch { /* ignore */ }
    saveChat(null); setChat(null); setHuman({ messages: [], status: null, agent: null }); setMode('bot');
  };

  // De-duplicate optimistic messages once the server copy arrives.
  const humanMsgs = human.messages.filter((m, i, arr) => !(m.pending && arr.slice(i + 1).some((x) => !x.pending && x.sender === 'visitor' && x.body === m.body)));

  return (
    <>
      <AnimatePresence>
        {open && (
          <motion.div className="card chat-panel" initial={{ opacity: 0, y: 30, scale: .92, transformOrigin: 'bottom right' }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 30, scale: .92 }} transition={{ type: 'spring', stiffness: 340, damping: 28 }} role="dialog" aria-label="Chat">
            <div className="row" style={{ padding: '12px 14px', background: 'var(--grad-3)', color: '#fff' }}>
              {mode === 'human' && human.agent ? <Avatar user={human.agent} size={30} /> : mode === 'human' ? <UserRound size={18} /> : <Sparkles size={18} />}
              <div className="grow" style={{ lineHeight: 1.2 }}>
                <b>{mode === 'human' ? (human.agent?.name || 'Live support') : 'Assistant'}</b>
                <div style={{ fontSize: 11, opacity: .9 }}>{mode === 'human' ? (human.status === 'closed' ? 'Chat ended' : human.agent ? 'Online now' : chat ? 'Waiting for an agent…' : 'Talk to a person') : 'Instant answers'}</div>
              </div>
              {liveOn && <button className="chat-switch" onClick={() => setMode(mode === 'bot' ? 'human' : 'bot')} aria-label={mode === 'bot' ? 'Talk to a human' : 'Back to assistant'} title={mode === 'bot' ? 'Talk to a human' : 'Back to assistant'}>{mode === 'bot' ? <UserRound size={16} /> : <Bot size={16} />}</button>}
              <button className="chat-switch" onClick={() => setOpen(false)} aria-label="Close chat"><X size={16} /></button>
            </div>

            {mode === 'bot' && (
              <>
                <div className="chat-msgs">
                  {msgs.map((m, i) => (
                    <motion.div key={i} initial={{ y: 8 }} animate={{ y: 0 }} style={{ display: 'flex', flexDirection: 'column', alignItems: m.from === 'me' ? 'flex-end' : 'flex-start', gap: 6 }}>
                      <div className={`bubble ${m.from}`}>{m.text}</div>
                      {m.actions?.length > 0 && <div className="row wrap" style={{ gap: 6 }}>{m.actions.map((a) => <button key={a.label} className="chip" onClick={() => { setOpen(false); nav(a.to.startsWith('/#') ? '/' : a.to); }}>{a.label} →</button>)}</div>}
                      {m.offerHuman && <button className="chip on" onClick={() => setMode('human')}><UserRound size={13} /> Talk to a human</button>}
                      {m.suggestions?.length > 0 && <div className="row wrap" style={{ gap: 6 }}>{m.suggestions.map((s) => <button key={s} className="chip" onClick={() => askBot(s)}>{s}</button>)}</div>}
                    </motion.div>
                  ))}
                  {busy && <div className="bubble bot typing"><span /><span /><span /></div>}
                  <div ref={end} />
                </div>
                <form className="row" style={{ padding: 12, borderTop: '1px solid var(--border)' }} onSubmit={(e) => { e.preventDefault(); askBot(); }}>
                  <input className="input" value={text} onChange={(e) => setText(e.target.value)} placeholder="Type your question…" maxLength={500} aria-label="Message" />
                  <button className="btn primary icon" type="submit" aria-label="Send"><Send size={17} /></button>
                </form>
              </>
            )}

            {mode === 'human' && !chat && (
              <form className="chat-msgs" onSubmit={startHuman}>
                <div className="bubble bot">Connect with our support & sales team. A real person will reply here — usually within a few minutes.</div>
                {!user && <>
                  <input className="input" required minLength={2} maxLength={80} placeholder="Your name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} aria-label="Your name" />
                  <input className="input" required minLength={5} maxLength={120} placeholder="Phone or email" value={form.contact} onChange={(e) => setForm({ ...form, contact: e.target.value })} aria-label="Phone or email" />
                  <input type="text" tabIndex={-1} autoComplete="off" value={form.website} onChange={(e) => setForm({ ...form, website: e.target.value })} style={{ position: 'absolute', left: '-9999px' }} aria-hidden="true" />
                </>}
                <textarea className="input" rows={3} maxLength={2000} placeholder="How can we help?" value={text} onChange={(e) => setText(e.target.value)} aria-label="Your message" />
                <button className="btn primary" type="submit" disabled={busy}>{busy ? 'Connecting…' : 'Start chat with an agent'}</button>
              </form>
            )}

            {mode === 'human' && chat && (
              <>
                <div className="chat-msgs">
                  {humanMsgs.map((m) => m.sender === 'system'
                    ? <div key={m.id} className="chat-system">{m.body}</div>
                    : (
                      <motion.div key={m.id} initial={{ y: 8 }} animate={{ y: 0 }} style={{ display: 'flex', gap: 8, alignItems: 'flex-end', flexDirection: m.sender === 'visitor' ? 'row-reverse' : 'row' }}>
                        {m.sender === 'agent' && <Avatar user={{ name: m.name, avatar: m.avatar }} size={26} />}
                        <div className={`bubble ${m.sender === 'visitor' ? 'me' : 'bot'}`} style={{ opacity: m.pending ? 0.7 : 1 }}>{m.body}</div>
                      </motion.div>
                    ))}
                  {human.status === 'waiting' && <div className="bubble bot typing"><span /><span /><span /></div>}
                  <div ref={end} />
                </div>
                {human.status === 'closed' ? (
                  <div className="row" style={{ padding: 12, borderTop: '1px solid var(--border)' }}><button className="btn primary grow" onClick={endHuman}>Start a new conversation</button></div>
                ) : (
                  <form className="row" style={{ padding: 12, borderTop: '1px solid var(--border)' }} onSubmit={sendHuman}>
                    <button type="button" className="btn ghost icon" onClick={endHuman} aria-label="End chat" title="End chat"><LogOut size={16} /></button>
                    <input className="input" value={text} onChange={(e) => setText(e.target.value)} placeholder="Write a message…" maxLength={2000} aria-label="Message" />
                    <button className="btn primary icon" type="submit" aria-label="Send"><Send size={17} /></button>
                  </form>
                )}
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
      <motion.button className="chat-fab" onClick={() => setOpen((o) => !o)} whileHover={{ scale: 1.08, rotate: -6 }} whileTap={{ scale: .92 }} aria-label={open ? 'Close chat' : 'Open chat'}>
        <AnimatePresence mode="wait" initial={false}>
          <motion.span key={open ? 'x' : 'm'} initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }} style={{ display: 'grid' }}>{open ? <X /> : <MessageCircle />}</motion.span>
        </AnimatePresence>
        {unread > 0 && !open && <span className="chat-badge">{unread}</span>}
      </motion.button>
    </>
  );
}
