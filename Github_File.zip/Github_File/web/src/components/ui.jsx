import { useCallback, useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, motion, useMotionValue, useSpring, useTransform, animate } from 'framer-motion';
import { X, Inbox, ChevronLeft, ChevronRight, ArrowUpDown } from 'lucide-react';
import { tone, label } from '../lib/format.js';
import { serverUrl } from '../lib/platform.js';

export const Aurora = () => <div className="aurora" aria-hidden="true"><span /><span /><span /></div>;

// Entry animations move content but never hide it: if the browser stalls animation frames (busy GPU, power saving,
// background tab), content must still be readable. So no opacity/blur on anything that holds page content.
export const fadeUp = { hidden: { y: 16 }, show: { y: 0, transition: { duration: .45, ease: [.2, .8, .2, 1] } } };
export const stagger = { hidden: {}, show: { transition: { staggerChildren: .06 } } };

export function Page({ title, subtitle, actions, children }) {
  return (
    <motion.div initial="hidden" animate="show" variants={stagger}>
      {(title || actions) && (
        <motion.div className="page-head" variants={fadeUp}>
          <div>{title && <h2>{title}</h2>}{subtitle && <p>{subtitle}</p>}</div>
          {actions && <div className="row wrap">{actions}</div>}
        </motion.div>
      )}
      {children}
    </motion.div>
  );
}

export function Card({ title, actions, children, className = '', hover, glow, ...rest }) {
  return (
    <motion.div variants={fadeUp} className={`card ${hover ? 'hover' : ''} ${glow ? 'glow' : ''} ${className}`} {...rest}>
      {(title || actions) && <div className="card-head"><h3>{title}</h3>{actions && <div className="row">{actions}</div>}</div>}
      {children}
    </motion.div>
  );
}

export function Button({ variant = '', size = '', loading, children, icon: Icon, className = '', ...rest }) {
  return (
    <button className={`btn ${variant} ${size} ${!children ? 'icon' : ''} ${className}`} disabled={loading || rest.disabled} {...rest}>
      {loading ? <span className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} /> : Icon && <Icon size={size === 'sm' ? 15 : 17} />}
      {children}
    </button>
  );
}

export function Field({ label: l, hint, error, children }) {
  return <label className="field">{l && <span>{l}</span>}{children}{hint && !error && <small>{hint}</small>}{error && <span className="err">{error}</span>}</label>;
}
export const Input = ({ label: l, hint, error, ...p }) => <Field label={l} hint={hint} error={error}><input className="input" {...p} /></Field>;
export const Textarea = ({ label: l, hint, ...p }) => <Field label={l} hint={hint}><textarea className="input" {...p} /></Field>;
export function Select({ label: l, hint, options, ...p }) {
  return (
    <Field label={l} hint={hint}>
      <select className="input" {...p}>
        {options.map((o) => (typeof o === 'string' ? <option key={o} value={o}>{label(o)}</option> : <option key={o.value} value={o.value}>{o.label}</option>))}
      </select>
    </Field>
  );
}

export function Toggle({ checked, onChange, label: l, hint }) {
  const id = useId();
  return (
    <div className="row between" style={{ padding: '6px 0' }}>
      {(l || hint) && <label htmlFor={id} style={{ cursor: 'pointer' }}><div style={{ fontWeight: 600 }}>{l}</div>{hint && <div className="faint">{hint}</div>}</label>}
      {/* The switch itself must be a <label>: the real checkbox is visually hidden (0×0), so a plain <span> made
          the visible switch unclickable — only the text label toggled it. */}
      <label className="toggle"><input id={id} type="checkbox" role="switch" aria-label={typeof l === 'string' ? l : undefined} checked={!!checked} onChange={(e) => onChange(e.target.checked)} /><i /></label>
    </div>
  );
}

export const Badge = ({ status, children, kind }) => <span className={`badge ${kind || tone(status)}`}>{children ?? label(status)}</span>;

export function Tabs({ tabs, value, onChange }) {
  const id = useId();
  return (
    <div className="tabs" role="tablist">
      {tabs.map((t) => {
        const v = typeof t === 'string' ? t : t.value;
        return (
          <button key={v} role="tab" aria-selected={value === v} className={`tab ${value === v ? 'on' : ''}`} onClick={() => onChange(v)}>
            {value === v && <motion.span layoutId={`tab-${id}`} className="tab-bg" transition={{ type: 'spring', stiffness: 420, damping: 34 }} />}
            {typeof t === 'string' ? label(t) : t.label}
          </button>
        );
      })}
    </div>
  );
}

export function Modal({ open, onClose, title, children, wide, footer }) {
  useEffect(() => {
    if (!open) return undefined;
    const k = (e) => e.key === 'Escape' && onClose?.();
    window.addEventListener('keydown', k);
    document.body.classList.add('modal-open');
    return () => { window.removeEventListener('keydown', k); document.body.classList.remove('modal-open'); };
  }, [open, onClose]);
  // Rendered into <body> via a portal: page transitions use CSS transforms, which would otherwise trap
  // position:fixed and let the sticky header paint over the dialog.
  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div className="overlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.15 }} onMouseDown={(e) => e.target === e.currentTarget && onClose?.()}>
          <motion.div role="dialog" aria-modal="true" aria-label={title} className={`modal ${wide ? 'wide' : ''}`} initial={{ opacity: 0, y: 24, scale: .97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 16, scale: .98 }} transition={{ type: 'spring', stiffness: 520, damping: 34, mass: .7 }}>
            <div className="row between mb"><h3 style={{ margin: 0 }}>{title}</h3><Button variant="ghost" size="sm" icon={X} onClick={onClose} aria-label="Close" /></div>
            {children}
            {footer && <div className="row end mt">{footer}</div>}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}

/** Profile picture with initials fallback. */
export function Avatar({ user, size = 36 }) {
  const [broken, setBroken] = useState(false);
  const initials = (user?.name || '?').split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase();
  const style = { width: size, height: size, fontSize: Math.round(size * 0.38) };
  const src = user?.avatar?.startsWith('/') ? `${serverUrl()}${user.avatar}` : user?.avatar; // mobile app runs on capacitor://localhost
  if (src && !broken) return <img className="avatar" src={src} alt="" style={{ ...style, objectFit: 'cover' }} onError={() => setBroken(true)} />;
  return <div className="avatar" style={style} aria-hidden="true">{initials}</div>;
}

export const Spinner = () => <div className="row" style={{ justifyContent: 'center', padding: 30 }}><div className="spinner" /></div>;
export const Empty = ({ icon: Icon = Inbox, title = 'Nothing here yet', children }) => <div className="empty"><Icon size={38} /><div style={{ fontWeight: 600, color: 'var(--text)' }}>{title}</div>{children && <div className="faint" style={{ marginTop: 6 }}>{children}</div>}</div>;

/** Animated number counter */
export function Counter({ value, format = (v) => Math.round(v).toLocaleString() }) {
  const ref = useRef(null);
  const prev = useRef(0);
  useEffect(() => {
    const ctrl = animate(prev.current, Number(value) || 0, { duration: 1.1, ease: [.2, .8, .2, 1], onUpdate: (v) => { if (ref.current) ref.current.textContent = format(v); } });
    prev.current = Number(value) || 0;
    return () => ctrl.stop();
  }, [value]); // eslint-disable-line react-hooks/exhaustive-deps
  return <span ref={ref}>{format(0)}</span>;
}

export function Stat({ icon: Icon, label: l, value, format, delta, sub }) {
  const x = useMotionValue(0); const y = useMotionValue(0);
  const rx = useSpring(useTransform(y, [-50, 50], [6, -6]), { stiffness: 200, damping: 20 });
  const ry = useSpring(useTransform(x, [-50, 50], [-6, 6]), { stiffness: 200, damping: 20 });
  return (
    <motion.div variants={fadeUp} className="card hover stat" style={{ rotateX: rx, rotateY: ry, transformPerspective: 800 }}
      onMouseMove={(e) => { const r = e.currentTarget.getBoundingClientRect(); x.set(e.clientX - r.left - r.width / 2); y.set(e.clientY - r.top - r.height / 2); }}
      onMouseLeave={() => { x.set(0); y.set(0); }}>
      <div className="row between"><div className="label">{l}</div>{Icon && <div className="ico"><Icon size={18} /></div>}</div>
      <div className="value"><Counter value={value} format={format} /></div>
      {(delta !== undefined || sub) && <div className="row" style={{ gap: 8 }}>{delta !== undefined && <span className="delta" style={{ color: delta >= 0 ? 'var(--ok)' : 'var(--bad)' }}>{delta >= 0 ? '▲' : '▼'} {Math.abs(delta).toFixed(1)}%</span>}{sub && <span className="faint">{sub}</span>}</div>}
    </motion.div>
  );
}

/** Circular speed gauge */
export function Gauge({ value, max, label: l, sub, size = 200 }) {
  const r = size / 2 - 14; const c = 2 * Math.PI * r; const arc = c * 0.75;
  const pct = Math.min(1, Math.max(0, max ? value / max : 0));
  const gid = useId().replace(/:/g, '');
  return (
    <div className="gauge" style={{ width: size, height: size }}>
      <svg width={size} height={size}>
        <defs><linearGradient id={gid} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="var(--brand-1)" /><stop offset=".6" stopColor="var(--brand-2)" /><stop offset="1" stopColor="var(--brand-3)" /></linearGradient></defs>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--border-strong)" strokeWidth="12" strokeDasharray={`${arc} ${c}`} strokeLinecap="round" />
        <motion.circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={`url(#${gid})`} strokeWidth="12" strokeLinecap="round"
          strokeDasharray={`${arc} ${c}`} initial={{ strokeDashoffset: arc }} animate={{ strokeDashoffset: arc * (1 - pct) }} transition={{ type: 'spring', stiffness: 60, damping: 18 }}
          style={{ filter: 'drop-shadow(0 0 8px color-mix(in srgb, var(--brand-1) 60%, transparent))' }} />
      </svg>
      <div className="center"><b>{l}</b><span className="faint">{sub}</span></div>
    </div>
  );
}

/** Generic data table with sorting & pagination driven by the server. */
export function DataTable({ columns, rows, onRowClick, loading, empty, sort, onSort }) {
  if (loading && !rows?.length) return <Spinner />;
  if (!rows?.length) return <Empty title={empty || 'No records found'} />;
  return (
    <div className="table-wrap">
      <table className="t">
        <thead><tr>{columns.map((c) => (
          <th key={c.key} className={c.sort ? 'th-sort' : ''} style={{ textAlign: c.align, width: c.width }} onClick={() => c.sort && onSort?.(sort === c.key ? `-${c.key}` : c.key)}>
            {c.title}{c.sort && <ArrowUpDown size={12} style={{ marginLeft: 4, verticalAlign: -1, opacity: sort?.replace('-', '') === c.key ? 1 : .35 }} />}
          </th>))}</tr></thead>
        <tbody>
          {rows.map((r, i) => (
            <motion.tr key={r.id ?? i} className={onRowClick ? 'click' : ''} onClick={() => onRowClick?.(r)} initial={{ y: 6 }} animate={{ y: 0 }} transition={{ delay: Math.min(i * 0.018, 0.4) }}>
              {columns.map((c) => <td key={c.key} style={{ textAlign: c.align }}>{c.render ? c.render(r) : r[c.key] ?? '—'}</td>)}
            </motion.tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function Pager({ page, pageSize, total, onPage }) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  if (pages <= 1) return null;
  return (
    <div className="row between" style={{ padding: '12px 16px', borderTop: '1px solid var(--border)' }}>
      <span className="faint">{(page - 1) * pageSize + 1}–{Math.min(total, page * pageSize)} of {total}</span>
      <div className="row"><Button size="sm" icon={ChevronLeft} disabled={page <= 1} onClick={() => onPage(page - 1)} aria-label="Previous" /><span className="faint">{page} / {pages}</span><Button size="sm" icon={ChevronRight} disabled={page >= pages} onClick={() => onPage(page + 1)} aria-label="Next" /></div>
    </div>
  );
}

/** useLoad(fn, deps) -> { data, loading, error, reload, setData } */
export function useLoad(fn, deps = []) {
  const [state, setState] = useState({ data: null, loading: true, error: null });
  const load = useCallback(async () => {
    setState((s) => ({ ...s, loading: true }));
    try { const data = await fn(); setState({ data, loading: false, error: null }); return data; }
    catch (error) { setState((s) => ({ ...s, loading: false, error })); return null; }
  }, deps); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { load(); }, [load]);
  return { ...state, reload: load, setData: (d) => setState((s) => ({ ...s, data: typeof d === 'function' ? d(s.data) : d })) };
}

/** Simple form state helper */
export function useForm(initial) {
  const [values, setValues] = useState(initial);
  const bind = (k, { type } = {}) => ({
    value: values[k] ?? '',
    checked: type === 'checkbox' ? !!values[k] : undefined,
    onChange: (e) => setValues((v) => ({ ...v, [k]: type === 'checkbox' ? e.target.checked : type === 'number' ? (e.target.value === '' ? '' : Number(e.target.value)) : e.target.value })),
  });
  return { values, setValues, bind, set: (k, val) => setValues((v) => ({ ...v, [k]: val })) };
}

export function Confirm({ open, onClose, onConfirm, title = 'Are you sure?', children, danger, confirmText = 'Confirm' }) {
  const [busy, setBusy] = useState(false);
  return (
    <Modal open={open} onClose={onClose} title={title} footer={<>
      <Button onClick={onClose}>Cancel</Button>
      <Button variant={danger ? 'danger' : 'primary'} loading={busy} onClick={async () => { setBusy(true); try { await onConfirm(); onClose(); } finally { setBusy(false); } }}>{confirmText}</Button>
    </>}>
      <div className="muted">{children}</div>
    </Modal>
  );
}
