import { lazy, Suspense } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { useApp } from './context.jsx';
import { Shell } from './components/Shell.jsx';
import { Spinner, Aurora } from './components/ui.jsx';
import Chatbot from './components/Chatbot.jsx';
import CreditFooter from './components/CreditFooter.jsx';
import { isDesktopApp, isMobileApp, needsServerSetup } from './lib/platform.js';

import Home from './pages/public/Home.jsx';
import { Login, Register, Forgot, ServerSetup } from './pages/public/Auth.jsx';

const Verify = lazy(() => import('./pages/public/Verify.jsx'));
const Portal = {
  Overview: lazy(() => import('./pages/portal/Overview.jsx')),
  Billing: lazy(() => import('./pages/portal/Billing.jsx')),
  Plans: lazy(() => import('./pages/portal/Plans.jsx')),
  Parental: lazy(() => import('./pages/portal/Parental.jsx')),
  Devices: lazy(() => import('./pages/portal/Devices.jsx')),
};
const Shared = {
  Support: lazy(() => import('./pages/shared/Support.jsx')),
  Notifications: lazy(() => import('./pages/shared/Notifications.jsx')),
  Profile: lazy(() => import('./pages/shared/Profile.jsx')),
};
const Admin = {
  Dashboard: lazy(() => import('./pages/admin/Dashboard.jsx')),
  Customers: lazy(() => import('./pages/admin/Customers.jsx')),
  CustomerDetail: lazy(() => import('./pages/admin/CustomerDetail.jsx')),
  Plans: lazy(() => import('./pages/admin/Plans.jsx')),
  Billing: lazy(() => import('./pages/admin/Billing.jsx')),
  Network: lazy(() => import('./pages/admin/Network.jsx')),
  Notify: lazy(() => import('./pages/admin/Notify.jsx')),
  Crm: lazy(() => import('./pages/admin/Crm.jsx')),
  Staff: lazy(() => import('./pages/admin/Staff.jsx')),
  Settings: lazy(() => import('./pages/admin/Settings.jsx')),
  Updates: lazy(() => import('./pages/admin/Updates.jsx')),
  Audit: lazy(() => import('./pages/admin/Audit.jsx')),
  Reports: lazy(() => import('./pages/admin/Reports.jsx')),
  Backups: lazy(() => import('./pages/admin/Backups.jsx')),
  LiveChat: lazy(() => import('./pages/admin/LiveChat.jsx')),
  Inventory: lazy(() => import('./pages/admin/Inventory.jsx')),
  Jobs: lazy(() => import('./pages/admin/Jobs.jsx')),
  Finance: lazy(() => import('./pages/admin/Finance.jsx')),
  Zones: lazy(() => import('./pages/admin/Zones.jsx')),
  NetworkMap: lazy(() => import('./pages/admin/NetworkMap.jsx')),
  Compliance: lazy(() => import('./pages/admin/Compliance.jsx')),
  Website: lazy(() => import('./pages/admin/Website.jsx')),
};

function Guard({ type, children }) {
  const { user, booting } = useApp();
  const loc = useLocation();
  if (booting) return <Splash />;
  if (!user) return <Navigate to="/login" replace state={{ from: loc.pathname }} />;
  if (user.mustSetup2fa && !loc.pathname.endsWith('/profile')) return <Navigate to={`${user.type === 'customer' ? '/portal' : '/admin'}/profile?setup2fa=1`} replace />;
  if (type === 'staff' && user.type === 'customer') return <Navigate to="/portal" replace />;
  if (type === 'staff' && isMobileApp) return <Navigate to="/login" replace />; // mobile app = customers only
  if (type === 'customer' && user.type !== 'customer') return <Navigate to="/admin" replace />;
  if (type === 'customer' && user.needsVerification && !loc.pathname.startsWith('/verify')) return <Navigate to="/verify" replace />;
  return children;
}

function Splash() {
  return <><Aurora /><div className="auth-wrap layer"><Spinner /></div></>;
}

export default function App() {
  const { user, booting, config, moduleOn } = useApp();
  if (needsServerSetup()) return <><ServerSetup /><CreditFooter /></>;
  if (booting) return <><Splash /><CreditFooter /></>;
  const home = user ? (user.type === 'customer' ? '/portal' : '/admin') : null;
  const websiteOn = !isDesktopApp && moduleOn('website');

  return (
    <Suspense fallback={<Splash />}>
      <Routes>
        <Route path="/" element={home ? <Navigate to={home} replace /> : websiteOn ? <Home /> : <Navigate to="/login" replace />} />
        <Route path="/plans" element={websiteOn ? <Home scrollTo="plans" /> : <Navigate to="/login" replace />} />
        {/* The public website as visitors see it, also for signed-in staff (who are otherwise sent to their dashboard). */}
        <Route path="/site" element={<Home preview={!!user && user.type !== 'customer' && window.top === window.self} />} />
        <Route path="/login" element={home ? <Navigate to={home} replace /> : <Login />} />
        <Route path="/register" element={home ? <Navigate to={home} replace /> : isDesktopApp ? <Navigate to="/login" /> : <Register />} />
        <Route path="/forgot" element={<Forgot />} />
        <Route path="/verify" element={<Guard type="customer"><Verify /></Guard>} />

        <Route path="/portal" element={<Guard type="customer"><Shell kind="portal" /></Guard>}>
          <Route index element={<Portal.Overview />} />
          <Route path="billing" element={<Portal.Billing />} />
          <Route path="plans" element={<Portal.Plans />} />
          <Route path="support" element={<Shared.Support />} />
          <Route path="support/:id" element={<Shared.Support />} />
          <Route path="parental" element={<Portal.Parental />} />
          <Route path="devices" element={<Portal.Devices />} />
          <Route path="notifications" element={<Shared.Notifications />} />
          <Route path="profile" element={<Shared.Profile />} />
        </Route>

        <Route path="/admin" element={<Guard type="staff"><Shell kind="admin" /></Guard>}>
          <Route index element={<Admin.Dashboard />} />
          <Route path="customers" element={<Admin.Customers />} />
          <Route path="customers/:id" element={<Admin.CustomerDetail />} />
          <Route path="plans" element={<Admin.Plans />} />
          <Route path="billing" element={<Admin.Billing />} />
          <Route path="tickets" element={<Shared.Support />} />
          <Route path="tickets/:id" element={<Shared.Support />} />
          <Route path="network/:section" element={<Admin.Network />} />
          <Route path="notifications" element={<Admin.Notify />} />
          <Route path="crm" element={<Admin.Crm />} />
          <Route path="staff" element={<Admin.Staff />} />
          <Route path="settings" element={<Admin.Settings />} />
          <Route path="updates" element={<Admin.Updates />} />
          <Route path="audit" element={<Admin.Audit />} />
          <Route path="reports" element={<Admin.Reports />} />
          <Route path="backups" element={<Admin.Backups />} />
          <Route path="chat" element={<Admin.LiveChat />} />
          <Route path="inventory" element={<Admin.Inventory />} />
          <Route path="jobs" element={<Admin.Jobs />} />
          <Route path="finance" element={<Admin.Finance />} />
          <Route path="zones" element={<Admin.Zones />} />
          <Route path="map" element={<Admin.NetworkMap />} />
          <Route path="compliance" element={<Admin.Compliance />} />
          <Route path="website" element={<Admin.Website />} />
          <Route path="profile" element={<Shared.Profile />} />
          <Route path="me/notifications" element={<Shared.Notifications />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      {config && !isDesktopApp && (!user || user.type === 'customer') && <Chatbot />}
      <CreditFooter />
    </Suspense>
  );
}
