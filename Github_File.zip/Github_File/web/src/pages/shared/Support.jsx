// Ticketing — used by customers (/portal/support) and staff (/admin/tickets).
import { useEffect, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Plus, Send, Lock, ArrowLeft, MonitorSmartphone, ClipboardList } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { ago, dateTime, initials, label } from '../../lib/format.js';
import { Avatar, Badge, Button, Card, DataTable, Input, Modal, Page, Pager, Select, Spinner, Tabs, Textarea, useLoad } from '../../components/ui.jsx';

const CATS = ['general', 'billing', 'technical', 'connection', 'speed', 'installation', 'plan', 'other'];
const STATUSES = ['open', 'in_progress', 'awaiting_customer', 'resolved', 'closed'];

function NewTicket({ open, onClose, onCreated, staff }) {
  const { toast } = useApp();
  const [f, setF] = useState({ subject: '', body: '', category: 'general', priority: 'normal', customer_id: '' });
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault(); setBusy(true);
    try { const r = await api.post('/tickets', { ...f, customer_id: f.customer_id ? Number(f.customer_id) : undefined }); toast(`Ticket ${r.number} created`); onCreated(r.id); }
    catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  return (
    <Modal open={open} onClose={onClose} title="New support ticket">
      <form className="col" onSubmit={submit}>
        {staff && <Input label="Customer ID (optional)" type="number" value={f.customer_id} onChange={(e) => setF({ ...f, customer_id: e.target.value })} />}
        <Input label="Subject" required minLength={3} maxLength={200} value={f.subject} onChange={(e) => setF({ ...f, subject: e.target.value })} />
        <div className="grid g2">
          <Select label="Category" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} options={CATS} />
          <Select label="Priority" value={f.priority} onChange={(e) => setF({ ...f, priority: e.target.value })} options={['low', 'normal', 'high', 'urgent']} />
        </div>
        <Textarea label="Describe the issue" required minLength={3} rows={5} value={f.body} onChange={(e) => setF({ ...f, body: e.target.value })} />
        <Button variant="primary" type="submit" loading={busy}>Submit ticket</Button>
      </form>
    </Modal>
  );
}

function Thread({ id, staff, base }) {
  const { user, toast, can, moduleOn } = useApp();
  const nav = useNavigate();
  const { data, reload } = useLoad(() => api(`/tickets/${id}`), [id]);
  const staffList = useLoad(() => (staff && can('staff.manage') ? api('/staff') : Promise.resolve({ users: [] })));
  const [body, setBody] = useState('');
  const [internal, setInternal] = useState(false);
  const [busy, setBusy] = useState(false);
  const end = useRef(null);
  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }); }, [data?.messages?.length]);
  useEffect(() => { const t = setInterval(reload, 20000); return () => clearInterval(t); }, [reload]);
  if (!data) return <Spinner />;
  const t = data.ticket;
  const send = async (e) => {
    e.preventDefault(); if (!body.trim()) return; setBusy(true);
    try { await api.post(`/tickets/${id}/messages`, { body, internal }); setBody(''); reload(); } catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  const patch = async (p) => { try { await api.patch(`/tickets/${id}`, p); reload(); toast('Ticket updated'); } catch (err) { toast(err.message, 'bad'); } };
  const remote = async () => { try { await api.post('/network/remote-sessions', { customer_id: t.customer_id, ticket_id: t.id }); toast('Remote support request sent to customer'); } catch (err) { toast(err.message, 'bad'); } };

  return (
    <Page title={t.subject} subtitle={`${t.number} · ${label(t.category)} · opened ${ago(t.created_at)}${staff && t.customer_name ? ` · ${t.customer_name} (${t.customer_code})` : ''}`}
      actions={<><Button icon={ArrowLeft} onClick={() => nav(base)}>Back</Button>{!staff && !['closed', 'resolved'].includes(t.status) && <Button onClick={() => patch({ status: 'resolved' })}>Mark resolved</Button>}</>}>
      <div className="grid" style={{ gridTemplateColumns: staff ? 'minmax(0,1fr) 280px' : '1fr' }}>
        <Card>
          <div className="col" style={{ gap: 16, maxHeight: '60vh', overflowY: 'auto', paddingRight: 6 }}>
            {data.messages.map((m) => {
              const mine = m.user_id === user.id;
              return (
                <motion.div key={m.id} initial={{ y: 10 }} animate={{ y: 0 }} className="row" style={{ alignItems: 'flex-start', flexDirection: mine ? 'row-reverse' : 'row' }}>
                  <Avatar user={m} />
                  <div style={{ maxWidth: '78%' }}>
                    <div className="faint" style={{ textAlign: mine ? 'right' : 'left' }}>{m.name} · {dateTime(m.created_at)} {m.internal ? <span className="badge warn" style={{ marginLeft: 6 }}><Lock size={10} /> internal</span> : null}</div>
                    <div className={`bubble ${mine ? 'me' : 'bot'}`} style={{ maxWidth: '100%', marginTop: 4, ...(m.internal ? { background: 'color-mix(in srgb, var(--warn) 15%, transparent)', color: 'var(--text)' } : {}) }}>{m.body}</div>
                  </div>
                </motion.div>
              );
            })}
            <div ref={end} />
          </div>
          {t.status !== 'closed' && (
            <form onSubmit={send} className="col mt">
              <textarea className="input" rows={3} placeholder="Write a reply…" value={body} onChange={(e) => setBody(e.target.value)} maxLength={10000} aria-label="Reply" />
              <div className="row between">
                {staff ? <label className="check"><input type="checkbox" checked={internal} onChange={(e) => setInternal(e.target.checked)} /> Internal note (hidden from customer)</label> : <span />}
                <Button variant="primary" type="submit" icon={Send} loading={busy}>Send</Button>
              </div>
            </form>
          )}
        </Card>
        {staff && (
          <Card title="Details">
            <div className="col">
              <Select label="Status" value={t.status} onChange={(e) => patch({ status: e.target.value })} options={STATUSES} />
              <Select label="Priority" value={t.priority} onChange={(e) => patch({ priority: e.target.value })} options={['low', 'normal', 'high', 'urgent']} />
              {can('staff.manage') ? (
                <Select label="Assignee" value={t.assigned_to || ''} onChange={(e) => patch({ assigned_to: e.target.value ? Number(e.target.value) : null })} options={[{ value: '', label: 'Unassigned' }, ...(staffList.data?.users || []).map((u) => ({ value: u.id, label: u.name }))]} />
              ) : <Button onClick={() => patch({ assigned_to: user.id })}>{t.assigned_to === user.id ? 'Assigned to you' : 'Assign to me'}</Button>}
              {t.customer_id && <Button onClick={() => nav(`/admin/customers/${t.customer_id}`)}>Open customer</Button>}
              {t.customer_id && can('network.diagnostics') && <Button icon={MonitorSmartphone} onClick={remote}>Request remote support</Button>}
              {can('jobs.manage') && moduleOn('jobs') && <Link className="btn" to={`/admin/jobs?fromTicket=${t.id}`}><ClipboardList size={16} /> Create field job</Link>}
            </div>
          </Card>
        )}
      </div>
    </Page>
  );
}

export default function Support() {
  const { user } = useApp();
  const staff = user.type !== 'customer';
  const base = staff ? '/admin/tickets' : '/portal/support';
  const { id } = useParams();
  const nav = useNavigate();
  const [status, setStatus] = useState('');
  const [assigned, setAssigned] = useState('');
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const [creating, setCreating] = useState(false);
  const list = useLoad(() => api(`/tickets?page=${page}&pageSize=25&status=${status}&assigned=${assigned}&q=${encodeURIComponent(q)}`), [page, status, assigned, q]);
  if (id) return <Thread id={id} staff={staff} base={base} />;
  return (
    <Page title={staff ? 'Support desk' : 'Support'} subtitle={staff ? 'All customer queries in one place' : 'We usually reply within an hour'} actions={<Button variant="primary" icon={Plus} onClick={() => setCreating(true)}>New ticket</Button>}>
      <div className="row wrap mb">
        <Tabs tabs={[{ value: '', label: 'All' }, ...STATUSES.map((s) => ({ value: s, label: label(s) }))]} value={status} onChange={(v) => { setStatus(v); setPage(1); }} />
        {staff && <Tabs tabs={[{ value: '', label: 'Anyone' }, { value: 'me', label: 'Mine' }, { value: 'none', label: 'Unassigned' }]} value={assigned} onChange={(v) => { setAssigned(v); setPage(1); }} />}
        <div className="grow" />
        <input className="input" style={{ maxWidth: 260 }} placeholder="Search tickets…" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} aria-label="Search" />
      </div>
      <Card className="flush">
        <DataTable loading={list.loading} rows={list.data?.rows} onRowClick={(r) => nav(`${base}/${r.id}`)} empty="No tickets" columns={[
          { key: 'number', title: '#', render: (r) => <span className="mono">{r.number}</span> },
          { key: 'subject', title: 'Subject', render: (r) => <b>{r.subject}</b> },
          ...(staff ? [{ key: 'customer_name', title: 'Customer' }, { key: 'assignee_name', title: 'Assignee', render: (r) => r.assignee_name || <span className="faint">—</span> }] : []),
          { key: 'priority', title: 'Priority', render: (r) => <Badge status={r.priority} /> },
          { key: 'status', title: 'Status', render: (r) => <Badge status={r.status} /> },
          { key: 'updated_at', title: 'Updated', render: (r) => ago(r.updated_at) },
        ]} />
        {list.data && <Pager page={list.data.page} pageSize={list.data.pageSize} total={list.data.total} onPage={setPage} />}
      </Card>
      <NewTicket open={creating} staff={staff} onClose={() => setCreating(false)} onCreated={(tid) => { setCreating(false); nav(`${base}/${tid}`); }} />
    </Page>
  );
}
