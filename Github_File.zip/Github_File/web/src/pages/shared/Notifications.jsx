import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Bell, BellRing, Check } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { ago } from '../../lib/format.js';
import { enablePush } from '../../lib/push.js';
import { Button, Card, Empty, Page, fadeUp } from '../../components/ui.jsx';

export default function Notifications() {
  const { notifications, setNotifications, toast, config } = useApp();
  const nav = useNavigate();
  const [busy, setBusy] = useState(false);
  const readAll = async () => { await api.post('/notifications/read-all'); setNotifications((n) => ({ list: n.list.map((x) => ({ ...x, read_at: x.read_at || new Date().toISOString() })), unread: 0 })); };
  const push = async () => { setBusy(true); try { await enablePush(config?.vapidPublicKey); toast('Push notifications enabled on this device'); } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); } };
  return (
    <Page title="Notifications" actions={<><Button icon={BellRing} onClick={push} loading={busy}>Enable push on this device</Button><Button icon={Check} onClick={readAll}>Mark all read</Button></>}>
      <Card>
        {!notifications.list.length && <Empty icon={Bell} title="No notifications yet" />}
        {notifications.list.map((n) => (
          <motion.div key={n.id} variants={fadeUp} className="list-item" style={{ cursor: n.link ? 'pointer' : 'default' }} onClick={() => { if (!n.read_at) { api.post(`/notifications/${n.id}/read`).catch(() => {}); setNotifications((s) => ({ list: s.list.map((x) => (x.id === n.id ? { ...x, read_at: new Date().toISOString() } : x)), unread: Math.max(0, s.unread - 1) })); } if (n.link?.startsWith('/')) nav(n.link); }}>
            <div className="avatar" style={{ background: n.read_at ? 'var(--surface-2)' : undefined, color: n.read_at ? 'var(--text-3)' : undefined }}><Bell size={16} /></div>
            <div className="grow"><b>{n.title}</b><div className="muted" style={{ whiteSpace: 'pre-wrap', fontSize: 14 }}>{n.body}</div></div>
            <span className="faint">{ago(n.created_at)}</span>
          </motion.div>
        ))}
      </Card>
    </Page>
  );
}
