import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShieldCheck, KeyRound, Smartphone, Monitor, Copy, ShieldOff, LogOut, MailCheck, AlertTriangle, Camera, Trash2 } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api, client, handleSession } from '../../lib/api.js';
import { ago, date } from '../../lib/format.js';
import { Avatar, Badge, Button, Card, Input, Modal, Page, useLoad } from '../../components/ui.jsx';
import KycPanel from '../../components/KycPanel.jsx';

function TwoFactor() {
  const { user, refreshUser, toast } = useApp();
  const [setup, setSetup] = useState(null);
  const [code, setCode] = useState('');
  const [codes, setCodes] = useState(null);
  const [disable, setDisable] = useState(false);
  const [pw, setPw] = useState('');
  const [busy, setBusy] = useState(false);
  const start = async () => { setBusy(true); try { setSetup(await api.post('/auth/2fa/setup')); } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); } };
  const enable = async (e) => {
    e.preventDefault(); setBusy(true);
    try { const r = await api.post('/auth/2fa/enable', { code }); setCodes(r.backupCodes); setSetup(null); setCode(''); await refreshUser(); toast('Two-factor authentication enabled'); }
    catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  const off = async (e) => {
    e.preventDefault(); setBusy(true);
    try { await api.post('/auth/2fa/disable', { password: pw, code }); setDisable(false); setPw(''); setCode(''); await refreshUser(); toast('Two-factor authentication disabled', 'info'); }
    catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  const regen = async () => {
    const c = window.prompt('Enter a current 6-digit code from your authenticator app');
    if (!c) return;
    try { setCodes((await api.post('/auth/2fa/backup-codes', { code: c.trim() })).backupCodes); } catch (e) { toast(e.message, 'bad'); }
  };
  return (
    <Card title="Two-factor authentication" actions={<Badge kind={user.twoFactor ? 'ok' : 'warn'}>{user.twoFactor ? 'Enabled' : 'Off'}</Badge>}>
      <p className="muted">Protect your account with a 6-digit code from Google Authenticator, Microsoft Authenticator, Authy or 1Password.</p>
      {!user.twoFactor && !setup && <Button variant="primary" icon={ShieldCheck} loading={busy} onClick={start}>Enable 2FA</Button>}
      {setup && (
        <motion.form initial={{ y: 10 }} animate={{ y: 0 }} onSubmit={enable} className="col">
          <div className="row wrap" style={{ alignItems: 'flex-start' }}>
            <img src={setup.qr} alt="2FA QR code" width={180} height={180} style={{ borderRadius: 14, background: '#fff', padding: 8 }} />
            <div className="col grow">
              <div className="faint">Scan the QR code, or enter this key manually:</div>
              <div className="row"><code className="kbd" style={{ wordBreak: 'break-all' }}>{setup.secret}</code><Button size="sm" variant="ghost" icon={Copy} type="button" onClick={() => navigator.clipboard?.writeText(setup.secret)} aria-label="Copy key" /></div>
              <input className="input otp" inputMode="numeric" maxLength={6} required value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} placeholder="000000" aria-label="Code" />
              <Button variant="primary" type="submit" loading={busy}>Verify & enable</Button>
            </div>
          </div>
        </motion.form>
      )}
      {user.twoFactor && <div className="row"><Button icon={KeyRound} onClick={regen}>New backup codes</Button><Button variant="danger" icon={ShieldOff} onClick={() => setDisable(true)}>Disable</Button></div>}
      <Modal open={!!codes} onClose={() => setCodes(null)} title="Save your backup codes">
        <div className="alert warn mb"><AlertTriangle size={18} /><div>Each code works once. Store them somewhere safe — they are shown only now.</div></div>
        <div className="grid g2">{codes?.map((c) => <code key={c} className="kbd" style={{ fontSize: 15, textAlign: 'center', padding: 8 }}>{c}</code>)}</div>
        <div className="row end mt"><Button icon={Copy} onClick={() => navigator.clipboard?.writeText(codes.join('\n'))}>Copy all</Button><Button variant="primary" onClick={() => setCodes(null)}>I've saved them</Button></div>
      </Modal>
      <Modal open={disable} onClose={() => setDisable(false)} title="Disable two-factor authentication">
        <form className="col" onSubmit={off}>
          <Input label="Password" type="password" required value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="current-password" />
          <Input label="Authenticator or backup code" required value={code} onChange={(e) => setCode(e.target.value)} />
          <Button variant="danger" type="submit" loading={busy}>Disable 2FA</Button>
        </form>
      </Modal>
    </Card>
  );
}

function ProfilePicture() {
  const { user, setUser, toast } = useApp();
  const [busy, setBusy] = useState(false);
  const upload = async (file) => {
    if (!file) return;
    if (file.size > 1024 * 1024) { toast('Image must be 1 MB or smaller', 'bad'); return; }
    const form = new FormData(); form.append('file', file);
    setBusy(true);
    try { const r = await api('/auth/me/avatar', { method: 'POST', form }); setUser(r.user); toast('Profile picture updated'); }
    catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  };
  const remove = async () => { const r = await api.del('/auth/me/avatar'); setUser(r.user); toast('Profile picture removed', 'info'); };
  return (
    <Card title="Profile picture">
      <div className="row wrap" style={{ gap: 18 }}>
        <motion.div whileHover={{ scale: 1.04 }}><Avatar user={user} size={96} /></motion.div>
        <div className="col">
          <label className={`btn primary ${busy ? 'disabled' : ''}`}><Camera size={16} /> {user.avatar ? 'Change picture' : 'Upload picture'}
            <input type="file" accept="image/png,image/jpeg,image/webp" hidden onChange={(e) => upload(e.target.files[0])} disabled={busy} />
          </label>
          {user.avatar && <Button variant="ghost" icon={Trash2} onClick={remove}>Remove</Button>}
          <span className="faint">PNG, JPG or WEBP · max 1 MB · square images look best</span>
        </div>
      </div>
    </Card>
  );
}

export default function Profile() {
  const { user, refreshUser, toast, logout } = useApp();
  const [params] = useSearchParams();
  const [name, setName] = useState(user.name);
  const [pw, setPw] = useState({ current: '', password: '' });
  const [busy, setBusy] = useState('');
  const sessions = useLoad(() => api('/auth/sessions'));

  const saveName = async (e) => { e.preventDefault(); setBusy('name'); try { await api.patch('/auth/me', { name }); await refreshUser(); toast('Profile updated'); } catch (err) { toast(err.message, 'bad'); } finally { setBusy(''); } };
  const changePw = async (e) => {
    e.preventDefault(); setBusy('pw');
    try { const r = await api.post('/auth/password/change', { ...pw, client }); await handleSession(r); setPw({ current: '', password: '' }); toast('Password changed. Other sessions were signed out.'); sessions.reload(); }
    catch (err) { toast(err.message, 'bad'); } finally { setBusy(''); }
  };
  const revoke = async (id) => { await api.del(`/auth/sessions/${id}`); sessions.reload(); };
  const revokeAll = async () => { await api.post('/auth/sessions/revoke-all'); await logout(); };

  return (
    <Page title="Profile & security">
      {params.get('setup2fa') && user.mustSetup2fa && <div className="alert warn mb"><AlertTriangle size={18} /><div>Your organisation requires two-factor authentication for staff accounts. Enable it below to continue.</div></div>}
      <div className="grid g2">
        <ProfilePicture />
        {user.type === 'customer' && <KycPanel self />}
        <Card title="Account">
          <form className="col" onSubmit={saveName}>
            <Input label="Name" value={name} onChange={(e) => setName(e.target.value)} minLength={2} maxLength={120} required />
            <div className="row"><MailCheck size={16} className="muted" /> {user.email} <Badge kind={user.emailVerified ? 'ok' : 'warn'}>{user.emailVerified ? 'verified' : 'unverified'}</Badge></div>
            {user.phone && <div className="row"><Smartphone size={16} className="muted" /> {user.phone} <Badge kind={user.phoneVerified ? 'ok' : 'warn'}>{user.phoneVerified ? 'verified' : 'unverified'}</Badge></div>}
            <Button type="submit" loading={busy === 'name'} style={{ alignSelf: 'flex-start' }}>Save</Button>
          </form>
        </Card>
        <Card title="Change password">
          <form className="col" onSubmit={changePw}>
            <Input label="Current password" type="password" required value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} autoComplete="current-password" />
            <Input label="New password" type="password" required minLength={10} value={pw.password} onChange={(e) => setPw({ ...pw, password: e.target.value })} autoComplete="new-password" hint="10+ characters with upper-case, lower-case and a number" />
            <Button type="submit" variant="primary" loading={busy === 'pw'} style={{ alignSelf: 'flex-start' }}>Update password</Button>
          </form>
        </Card>
        <TwoFactor />
        <Card title="Active sessions" actions={<Button size="sm" variant="danger" icon={LogOut} onClick={revokeAll}>Sign out everywhere</Button>}>
          {(sessions.data?.sessions || []).map((s) => (
            <div key={s.id} className="list-item">
              {/mobile|android|iphone/i.test(s.user_agent) ? <Smartphone size={18} className="muted" /> : <Monitor size={18} className="muted" />}
              <div className="grow" style={{ minWidth: 0 }}><div style={{ fontSize: 13, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.user_agent || 'Unknown device'}</div><div className="faint">{s.ip} · active {ago(s.last_used_at)} · expires {date(s.expires_at)}</div></div>
              <Button size="sm" variant="ghost" onClick={() => revoke(s.id)}>Revoke</Button>
            </div>
          ))}
        </Card>
      </div>
    </Page>
  );
}
