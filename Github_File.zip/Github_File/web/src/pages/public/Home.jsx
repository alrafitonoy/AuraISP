import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Check, ArrowRight, MapPin, Sparkles, ChevronDown, Phone, Mail, Zap, ShieldCheck, Headphones, Gauge, Wifi, Globe, Rocket, Clock, Heart, Star, Tv, Gamepad2, Router, Lock, Smartphone, Users } from 'lucide-react';

// Icons selectable for website feature cards (Settings → Website).
const Icons = { Zap, ShieldCheck, Headphones, Gauge, Wifi, Globe, Rocket, Clock, Heart, Star, Tv, Gamepad2, Router, Lock, Smartphone, Users, MapPin, Sparkles };
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { money, speed } from '../../lib/format.js';
import { Aurora, Button, fadeUp, stagger, Input, Textarea } from '../../components/ui.jsx';
import { SiteHeader, SiteFooter, PreviewBar } from '../../components/Site.jsx';


function SpeedOrb({ plans }) {
  const top = plans.reduce((m, p) => Math.max(m, p.download_kbps), 0);
  const [v, setV] = useState(0);
  useEffect(() => {
    let raf; const t0 = performance.now();
    const tick = (t) => { const k = Math.min(1, (t - t0) / 1800); setV(Math.round(top * (1 - Math.pow(1 - k, 3)))); if (k < 1) raf = requestAnimationFrame(tick); };
    raf = requestAnimationFrame(tick); return () => cancelAnimationFrame(raf);
  }, [top]);
  return (
    <motion.div className="speed-orb" initial={{ scale: .7 }} animate={{ scale: 1 }} transition={{ delay: .4, type: 'spring', stiffness: 80 }}>
      <div><div style={{ font: '700 56px var(--font-display)', letterSpacing: '-.04em' }} className="gradient-text">{speed(v).split(' ')[0]}</div><div className="muted">{speed(v).split(' ')[1] || 'Mbps'} max speed</div></div>
    </motion.div>
  );
}

export default function Home({ scrollTo, preview = false }) {
  const { config, toast } = useApp();
  const [plans, setPlans] = useState([]);
  const [faqs, setFaqs] = useState([]);
  const [openFaq, setOpenFaq] = useState(0);
  const [area, setArea] = useState('');
  const [coverage, setCoverage] = useState(null);
  const [lead, setLead] = useState({ name: '', phone: '', email: '', address: '', message: '', website: '' });
  const [sending, setSending] = useState(false);
  const nav = useNavigate();
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const heroY = useTransform(scrollYProgress, [0, 1], [0, 160]);
  const heroOpacity = useTransform(scrollYProgress, [0, .8], [1, 0]);

  useEffect(() => {
    api('/public/plans').then((r) => setPlans(r.plans)).catch(() => {});
    api('/public/faqs').then((r) => setFaqs(r.faqs)).catch(() => {});
  }, []);
  useEffect(() => { if (scrollTo) setTimeout(() => document.getElementById(scrollTo)?.scrollIntoView({ behavior: 'smooth' }), 300); }, [scrollTo, plans.length]);

  const w = config?.website || {};
  const b = config?.branding || {};

  const checkCoverage = async (e) => {
    e.preventDefault();
    try { setCoverage(await api.post('/public/coverage', { area })); } catch (err) { toast(err.message, 'bad'); }
  };
  const submitLead = async (e) => {
    e.preventDefault(); setSending(true);
    try { await api.post('/public/contact', lead); toast('Thanks! Our team will call you shortly.'); setLead({ name: '', phone: '', email: '', address: '', message: '', website: '' }); }
    catch (err) { toast(err.message, 'bad'); } finally { setSending(false); }
  };

  return (
    <>
      <Aurora />
      <div className="layer">
        {w.announcement && <div style={{ background: 'var(--grad-3)', color: '#fff', textAlign: 'center', padding: '8px 16px', fontSize: 14, fontWeight: 600 }}>{w.announcement}</div>}
        {preview && <PreviewBar />}
        <SiteHeader />

        <section className="hero" ref={heroRef}>
          <motion.div className="container" style={{ y: heroY, opacity: heroOpacity }} initial="hidden" animate="show" variants={stagger}>
            <motion.div variants={fadeUp} className="eyebrow"><Sparkles size={14} /> {b.tagline}</motion.div>
            <motion.h1 variants={fadeUp}>{(w.hero?.title || '').split(' ').map((word, i, arr) => <span key={i} className={i >= arr.length - 2 ? 'gradient-text' : ''}>{word} </span>)}</motion.h1>
            <motion.p variants={fadeUp} className="lead">{w.hero?.subtitle}</motion.p>
            <motion.div variants={fadeUp} className="row" style={{ justifyContent: 'center', flexWrap: 'wrap' }}>
              <a href="#plans" className="btn primary lg">{w.hero?.cta || 'See plans'} <ArrowRight size={18} /></a>
              <a href="#coverage" className="btn lg"><MapPin size={18} /> Check coverage</a>
            </motion.div>
            {plans.length > 0 && <SpeedOrb plans={plans} />}
          </motion.div>
        </section>

        <section className="section" id="features">
          <div className="container">
            <motion.div className="grid g4" initial="hidden" whileInView="show" viewport={{ once: true, margin: '-80px' }} variants={stagger}>
              {(w.features || []).map((f) => {
                const Icon = Icons[f.icon] || Icons.Zap;
                return (
                  <motion.div key={f.title} variants={fadeUp} className="card hover" whileHover={{ y: -6 }}>
                    <div className="stat"><div className="ico" style={{ marginBottom: 10 }}><Icon size={18} /></div></div>
                    <h3>{f.title}</h3><p className="muted" style={{ margin: 0 }}>{f.text}</p>
                  </motion.div>
                );
              })}
            </motion.div>
          </div>
        </section>

        <section className="section" id="plans">
          <div className="container">
            <div className="section-title"><h2>Pick your <span className="gradient-text">speed</span></h2><p>No data caps. No hidden fees. Upgrade or downgrade any time from the app.</p></div>
            <motion.div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(230px, 1fr))' }} initial="hidden" whileInView="show" viewport={{ once: true, margin: '-60px' }} variants={stagger}>
              {plans.map((p) => (
                <motion.div key={p.id} variants={fadeUp} whileHover={{ y: -8 }} className={`card plan-card ${p.is_featured ? 'featured glow' : 'hover'}`}>
                  {p.is_featured && <span className="badge brand ribbon">Most popular</span>}
                  <h3>{p.name}</h3>
                  <div className="gradient-text" style={{ font: '700 26px var(--font-display)' }}>{speed(p.download_kbps)}</div>
                  <div className="price">{money(p.price_cents)}<small> /{p.billing_cycle === 'monthly' ? 'mo' : p.billing_cycle}</small></div>
                  <ul>{p.features.map((f) => <li key={f}><Check size={16} />{f}</li>)}</ul>
                  <div className="grow" />
                  <Button variant={p.is_featured ? 'primary' : ''} onClick={() => nav(`/register?plan=${p.id}`)}>Choose {p.name}</Button>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        <section className="section" id="coverage">
          <div className="container">
            <motion.div className="card glow" style={{ padding: 36, textAlign: 'center' }} initial={{ y: 30 }} whileInView={{ y: 0 }} viewport={{ once: true }}>
              <h2>Are we in your area?</h2>
              <p className="muted">We currently serve {(w.coverageAreas || []).slice(0, 6).join(', ')}{(w.coverageAreas || []).length > 6 ? ' and more' : ''}.</p>
              <form onSubmit={checkCoverage} className="row" style={{ maxWidth: 520, margin: '20px auto 0' }}>
                <input className="input" value={area} onChange={(e) => setArea(e.target.value)} placeholder="Enter your area, e.g. Gulshan" required minLength={2} maxLength={80} aria-label="Area" />
                <Button variant="primary" type="submit" icon={MapPin}>Check</Button>
              </form>
              {coverage && (
                <motion.div initial={{ scale: .9 }} animate={{ scale: 1 }} className={`alert ${coverage.covered ? 'ok' : 'warn'}`} style={{ maxWidth: 520, margin: '16px auto 0', justifyContent: 'center' }}>
                  <div>{coverage.covered ? `Great news — ${coverage.area} is covered! ` : "We're not there yet — leave your details below and we'll notify you."}{coverage.covered && <Link to="/register" style={{ fontWeight: 700, color: 'var(--brand-1)' }}>Sign up now →</Link>}</div>
                </motion.div>
              )}
            </motion.div>
          </div>
        </section>

        {faqs.length > 0 && (
          <section className="section" id="faq">
            <div className="container" style={{ maxWidth: 820 }}>
              <div className="section-title"><h2>Questions? <span className="gradient-text">Answered.</span></h2></div>
              {faqs.map((f, i) => (
                <motion.div key={f.id} className="card" style={{ marginBottom: 12, padding: 0, overflow: 'hidden' }} initial={{ y: 16 }} whileInView={{ y: 0 }} viewport={{ once: true }}>
                  <button onClick={() => setOpenFaq(openFaq === i ? -1 : i)} className="row between" style={{ all: 'unset', display: 'flex', width: '100%', boxSizing: 'border-box', padding: '18px 22px', cursor: 'pointer', fontWeight: 600, justifyContent: 'space-between' }} aria-expanded={openFaq === i}>
                    {f.question}<motion.span animate={{ rotate: openFaq === i ? 180 : 0 }}><ChevronDown size={18} /></motion.span>
                  </button>
                  <motion.div initial={false} animate={{ height: openFaq === i ? 'auto' : 0, opacity: openFaq === i ? 1 : 0 }} style={{ overflow: 'hidden' }}>
                    <p className="muted" style={{ padding: '0 22px 18px', margin: 0 }}>{f.answer}</p>
                  </motion.div>
                </motion.div>
              ))}
            </div>
          </section>
        )}

        <section className="section" id="contact">
          <div className="container grid g2" style={{ alignItems: 'center' }}>
            <div>
              <h2>Talk to <span className="gradient-text">a human</span></h2>
              <p className="muted">Leave your number and our sales team will call you back within the hour during business hours.</p>
              <div className="col" style={{ marginTop: 20 }}>
                <div className="row"><Phone size={18} className="muted" /> {config?.company?.phone}</div>
                <div className="row"><Mail size={18} className="muted" /> {config?.company?.email}</div>
                <div className="row"><MapPin size={18} className="muted" /> {config?.company?.address}</div>
              </div>
            </div>
            <form className="card col" onSubmit={submitLead}>
              <div className="grid g2">
                <Input label="Name" required minLength={2} maxLength={120} value={lead.name} onChange={(e) => setLead({ ...lead, name: e.target.value })} />
                <Input label="Phone" required minLength={6} maxLength={20} value={lead.phone} onChange={(e) => setLead({ ...lead, phone: e.target.value })} />
              </div>
              <Input label="Email (optional)" type="email" value={lead.email} onChange={(e) => setLead({ ...lead, email: e.target.value })} />
              <Input label="Address" value={lead.address} onChange={(e) => setLead({ ...lead, address: e.target.value })} />
              <Textarea label="Message" value={lead.message} onChange={(e) => setLead({ ...lead, message: e.target.value })} maxLength={2000} />
              <input type="text" name="website" tabIndex={-1} autoComplete="off" value={lead.website} onChange={(e) => setLead({ ...lead, website: e.target.value })} style={{ position: 'absolute', left: '-9999px' }} aria-hidden="true" />
              <Button variant="primary" type="submit" loading={sending}>Request a call back</Button>
            </form>
          </div>
        </section>

        <SiteFooter />
      </div>
    </>
  );
}
