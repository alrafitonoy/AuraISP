import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MailCheck, Smartphone, LogOut } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { Aurora, Button } from '../../components/ui.jsx';
import { Brand } from '../../components/Shell.jsx';

function CodeStep({ channel, target, onDone }) {
  const { toast } = useApp();
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(channel === 'email');
  const send = async () => { setBusy(true); try { await api.post(`/auth/verify/${channel}/send`); setSent(true); toast('Code sent'); } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); } };
  const confirm = async (e) => {
    e.preventDefault(); setBusy(true);
    try { const r = await api.post(`/auth/verify/${channel}/confirm`, { code }); onDone(r.user); } catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  return (
    <form className="col" onSubmit={confirm}>
      <div className="row">{channel === 'email' ? <MailCheck /> : <Smartphone />}<div><b>Verify your {channel}</b><div className="faint">{target}</div></div></div>
      {sent && <input className="input otp" inputMode="numeric" maxLength={6} required value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} placeholder="000000" aria-label="Verification code" />}
      <div className="row">
        {sent && <Button variant="primary" type="submit" loading={busy} className="grow">Verify</Button>}
        <Button type="button" onClick={send} loading={busy && !sent}>{sent ? 'Resend' : 'Send code'}</Button>
      </div>
    </form>
  );
}

export default function Verify() {
  const { user, setUser, logout } = useApp();
  const nav = useNavigate();
  const onDone = (u) => { setUser(u); if (!u.needsVerification) nav('/portal'); };
  return (
    <>
      <Aurora />
      <div className="auth-wrap layer">
        <motion.div className="card glow auth-card col" initial={{ y: 30 }} animate={{ y: 0 }}>
          <div style={{ display: 'flex', justifyContent: 'center' }}><Brand /></div>
          <h2 style={{ textAlign: 'center' }}>Confirm it's you</h2>
          <p className="muted" style={{ textAlign: 'center' }}>For your security we need to verify your contact details before you can use the portal.</p>
          {!user.emailVerified && <CodeStep channel="email" target={user.email} onDone={onDone} />}
          {user.emailVerified && !user.phoneVerified && <CodeStep channel="phone" target={user.phone} onDone={onDone} />}
          <Button variant="ghost" icon={LogOut} onClick={logout}>Sign out</Button>
        </motion.div>
      </div>
    </>
  );
}
