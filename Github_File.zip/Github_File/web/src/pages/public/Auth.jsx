import { useState } from 'react';
import { Link, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldCheck, LogIn, UserPlus, KeyRound, Server, Eye, EyeOff } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { Aurora, Button, Field, Input, Select } from '../../components/ui.jsx';
import { SiteHeader, SiteFooter } from '../../components/Site.jsx';
import { Brand, ThemeToggle } from '../../components/Shell.jsx';
import { isDesktopApp, isMobileApp, setServerUrl } from '../../lib/platform.js';

function AuthLayout({ title, subtitle, children }) {
  const web = !isDesktopApp && !isMobileApp;
  return (
    <div className={web ? 'auth-page' : undefined}>
      <Aurora />
      {web && <div className="layer"><SiteHeader /></div>}
      <div className="auth-wrap layer">
        {!web && <div style={{ position: 'fixed', top: 16, right: 16 }}><ThemeToggle /></div>}
        <motion.div className="card glow auth-card" initial={{ y: 30, scale: .96 }} animate={{ y: 0, scale: 1 }} transition={{ type: 'spring', stiffness: 160, damping: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'center' }}><Brand /></div>
          <h2 style={{ textAlign: 'center', marginTop: 8 }}>{title}</h2>
          {subtitle && <p className="muted" style={{ textAlign: 'center' }}>{subtitle}</p>}
          {children}
        </motion.div>
      </div>
      {web && <div className="layer"><SiteFooter /></div>}
    </div>
  );
}

// The eye sits inside the input box itself (not the whole field), so a hint or error under the input can't push it out.
function PasswordInput({ label: l, hint, error, ...props }) {
  const [show, setShow] = useState(false);
  return (
    <Field label={l} hint={hint} error={error}>
      <div className="pw-wrap">
        <input className="input" type={show ? 'text' : 'password'} {...props} />
        <button type="button" className="pw-eye" onClick={() => setShow((s) => !s)} aria-label={show ? 'Hide password' : 'Show password'} aria-pressed={show}>{show ? <EyeOff size={18} /> : <Eye size={18} />}</button>
      </div>
    </Field>
  );
}

export function Login() {
  const { login, loginMfa, toast } = useApp();
  const nav = useNavigate();
  const loc = useLocation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [challenge, setChallenge] = useState(null);
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const done = (u) => nav(loc.state?.from && !loc.state.from.startsWith('/login') ? loc.state.from : u.type === 'customer' ? '/portal' : '/admin', { replace: true });

  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setError('');
    try {
      const r = await login(email, password);
      if (r.mfaRequired) setChallenge(r.challenge); else done(r.user);
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  };
  const submitMfa = async (e) => {
    e.preventDefault(); setBusy(true); setError('');
    try { const r = await loginMfa(challenge, code); toast(`Welcome back, ${r.user.name.split(' ')[0]}!`); done(r.user); }
    catch (err) { setError(err.message); if (err.status === 401 && /expired/i.test(err.message)) setChallenge(null); }
    finally { setBusy(false); }
  };

  return (
    <AuthLayout title={challenge ? 'Two-factor authentication' : 'Welcome back'} subtitle={challenge ? 'Enter the 6-digit code from your authenticator app, or a backup code.' : isDesktopApp ? 'Staff & administrator sign in' : isMobileApp ? 'Customer sign in' : 'Sign in to your account'}>
      <AnimatePresence mode="wait">
        {!challenge ? (
          <motion.form key="pw" className="col" onSubmit={submit} initial={{ x: -20 }} animate={{ x: 0 }} exit={{ opacity: 0, x: 20 }}>
            <Input label="Email" type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} />
            <PasswordInput label="Password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
            {error && <div className="alert bad"><div>{error}</div></div>}
            <Button variant="primary" size="lg" type="submit" loading={busy} icon={LogIn}>Sign in</Button>
            <div className="row between"><Link to="/forgot" className="faint">Forgot password?</Link>{!isDesktopApp && <Link to="/register" className="faint">Create account</Link>}</div>
          </motion.form>
        ) : (
          <motion.form key="mfa" className="col" onSubmit={submitMfa} initial={{ x: 20 }} animate={{ x: 0 }} exit={{ opacity: 0, x: -20 }}>
            <input className="input otp" inputMode="text" autoComplete="one-time-code" autoFocus required maxLength={11} value={code} onChange={(e) => setCode(e.target.value.trim())} placeholder="000000" aria-label="Authentication code" />
            {error && <div className="alert bad"><div>{error}</div></div>}
            <Button variant="primary" size="lg" type="submit" loading={busy} icon={ShieldCheck}>Verify</Button>
            <Button variant="ghost" type="button" onClick={() => { setChallenge(null); setCode(''); }}>Back</Button>
          </motion.form>
        )}
      </AnimatePresence>
    </AuthLayout>
  );
}

export function Register() {
  const { register, config } = useApp();
  const nav = useNavigate();
  const [params] = useSearchParams();
  const [plans, setPlans] = useState(null);
  const [f, setF] = useState({ name: '', email: '', phone: '', password: '', address: '', area: '', planId: params.get('plan') || '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  if (plans === null) { setPlans([]); api('/public/plans').then((r) => setPlans(r.plans)).catch(() => {}); }
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setError('');
    try { const r = await register({ ...f, planId: f.planId || undefined }); nav(r?.user?.needsVerification ? '/verify' : '/portal'); }
    catch (err) { setError(err.details?.fieldErrors ? Object.values(err.details.fieldErrors).flat()[0] : err.message); }
    finally { setBusy(false); }
  };
  const strength = [/[a-z]/, /[A-Z]/, /\d/, /[^A-Za-z0-9]/, /.{12,}/].filter((r) => r.test(f.password)).length;

  return (
    <AuthLayout title="Get connected" subtitle={`Create your ${config?.branding?.companyName || ''} account`}>
      <form className="col" onSubmit={submit}>
        <Input label="Full name" required minLength={2} maxLength={120} value={f.name} onChange={set('name')} autoComplete="name" />
        <div className="grid g2">
          <Input label="Email" type="email" required value={f.email} onChange={set('email')} autoComplete="email" />
          <Input label="Mobile" type="tel" required value={f.phone} onChange={set('phone')} placeholder="+8801…" autoComplete="tel" />
        </div>
        <PasswordInput label="Password" required minLength={10} value={f.password} onChange={set('password')} autoComplete="new-password" hint="10+ characters with upper-case, lower-case and a number" />
        <div className="progress" aria-hidden="true"><i style={{ width: `${strength * 20}%`, background: strength < 3 ? 'var(--bad)' : strength < 4 ? 'var(--warn)' : undefined }} /></div>
        <div className="grid g2">
          <Input label="Area" value={f.area} onChange={set('area')} />
          <Select label="Plan" value={f.planId} onChange={set('planId')} options={[{ value: '', label: 'Decide later' }, ...(plans || []).map((p) => ({ value: p.id, label: p.name }))]} />
        </div>
        <Input label="Address" value={f.address} onChange={set('address')} autoComplete="street-address" />
        {error && <div className="alert bad"><div>{error}</div></div>}
        <Button variant="primary" size="lg" type="submit" loading={busy} icon={UserPlus}>Create account</Button>
        <div className="faint" style={{ textAlign: 'center' }}>Already a customer? <Link to="/login" style={{ color: 'var(--brand-1)', fontWeight: 600 }}>Sign in</Link></div>
      </form>
    </AuthLayout>
  );
}

export function Forgot() {
  const { toast } = useApp();
  const nav = useNavigate();
  const [step, setStep] = useState(1);
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const send = async (e) => {
    e.preventDefault(); setBusy(true); setError('');
    try { await api.post('/auth/password/forgot', { email }); setStep(2); } catch (err) { setError(err.message); } finally { setBusy(false); }
  };
  const reset = async (e) => {
    e.preventDefault(); setBusy(true); setError('');
    try { await api.post('/auth/password/reset', { email, code, password }); toast('Password updated — please sign in'); nav('/login'); }
    catch (err) { setError(err.message); } finally { setBusy(false); }
  };
  return (
    <AuthLayout title="Reset password" subtitle={step === 1 ? "We'll email you a 6-digit code." : `Enter the code sent to ${email}.`}>
      {step === 1 ? (
        <form className="col" onSubmit={send}>
          <Input label="Email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          {error && <div className="alert bad"><div>{error}</div></div>}
          <Button variant="primary" size="lg" loading={busy} type="submit" icon={KeyRound}>Send code</Button>
          <Link to="/login" className="faint" style={{ textAlign: 'center' }}>Back to sign in</Link>
        </form>
      ) : (
        <form className="col" onSubmit={reset}>
          <input className="input otp" inputMode="numeric" maxLength={6} required value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} placeholder="000000" aria-label="Code" />
          <PasswordInput label="New password" required minLength={10} value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" />
          {error && <div className="alert bad"><div>{error}</div></div>}
          <Button variant="primary" size="lg" loading={busy} type="submit">Update password</Button>
        </form>
      )}
    </AuthLayout>
  );
}

/** First launch of the mobile app: which server should it connect to? */
export function ServerSetup() {
  const [url, setUrl] = useState('https://');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const save = async (e) => {
    e.preventDefault(); setBusy(true); setError('');
    try {
      const clean = url.trim().replace(/\/$/, '');
      if (!/^https:\/\//.test(clean) && !/^http:\/\/(localhost|127\.0\.0\.1|10\.|192\.168\.)/.test(clean)) throw new Error('Use an https:// address');
      const res = await fetch(`${clean}/api/health`);
      if (!res.ok) throw new Error('Server did not respond');
      setServerUrl(clean);
      window.location.reload();
    } catch (err) { setError(err.message || 'Could not reach the server'); } finally { setBusy(false); }
  };
  return (
    <AuthLayout title="Connect to your provider" subtitle="Enter the address your internet provider gave you.">
      <form className="col" onSubmit={save}>
        <Input label="Server address" type="url" required value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://portal.example.com" />
        {error && <div className="alert bad"><div>{error}</div></div>}
        <Button variant="primary" size="lg" type="submit" loading={busy} icon={Server}>Connect</Button>
      </form>
    </AuthLayout>
  );
}
