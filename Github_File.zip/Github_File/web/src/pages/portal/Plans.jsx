import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Check, Rocket, ArrowDownCircle } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { money, speed } from '../../lib/format.js';
import { Badge, Button, Confirm, Page, Spinner, useLoad, fadeUp, stagger } from '../../components/ui.jsx';

export default function Plans() {
  const { toast } = useApp();
  const nav = useNavigate();
  const { data, reload } = useLoad(() => api('/portal/plans'));
  const [choice, setChoice] = useState(null);
  if (!data) return <Spinner />;
  const current = data.plans.find((p) => p.id === data.currentPlanId);

  const change = async () => {
    try {
      const r = await api.post('/portal/plans/change', { planId: choice.id });
      if (r.invoice) { toast('Invoice created — complete payment to activate your new plan'); nav('/portal/billing'); }
      else { toast(`You're now on ${choice.name}`); reload(); }
    } catch (e) { toast(e.message, 'bad'); }
  };

  return (
    <Page title="Plans" subtitle={current ? `You're on ${current.name} · ${speed(current.download_kbps)}` : 'Choose a plan to get started'}>
      {data.pending && <div className="alert warn mb"><div>A plan change is waiting for payment. <a href="#/" onClick={(e) => { e.preventDefault(); nav('/portal/billing'); }} style={{ fontWeight: 700 }}>Pay invoice →</a></div></div>}
      <motion.div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))' }} variants={stagger} initial="hidden" animate="show">
        {data.plans.map((p) => {
          const isCurrent = p.id === data.currentPlanId;
          const up = !current || p.price_cents > current.price_cents;
          return (
            <motion.div key={p.id} variants={fadeUp} whileHover={{ y: -6 }} className={`card plan-card ${isCurrent ? 'glow' : 'hover'}`}>
              {isCurrent && <span className="ribbon"><Badge kind="ok">Current</Badge></span>}
              <h3>{p.name}</h3>
              <div className="gradient-text" style={{ font: '700 26px var(--font-display)' }}>{speed(p.download_kbps)}</div>
              <div className="price">{money(p.price_cents)}<small> /{p.billing_cycle === 'monthly' ? 'mo' : p.billing_cycle}</small></div>
              <ul>{p.features.map((f) => <li key={f}><Check size={16} />{f}</li>)}</ul>
              <div className="grow" />
              {!isCurrent && p.quote && current && <div className="faint">{up ? `Pay ${money(p.quote.chargeCents)} today (prorated)` : 'Applies immediately'}</div>}
              {!isCurrent && <Button variant={up ? 'primary' : ''} icon={up ? Rocket : ArrowDownCircle} onClick={() => setChoice(p)}>{!current ? 'Choose' : up ? 'Upgrade' : 'Downgrade'}</Button>}
            </motion.div>
          );
        })}
      </motion.div>
      <Confirm open={!!choice} onClose={() => setChoice(null)} onConfirm={change} title={`Switch to ${choice?.name}?`} confirmText="Confirm">
        {choice?.quote && current && choice.price_cents > current.price_cents
          ? <>You'll receive credit for unused days on {current.name}. Amount payable now: <b>{money(choice.quote.chargeCents)}</b>. Your new speed applies as soon as payment completes.</>
          : current ? <>Your plan will change immediately to {choice?.name}. The new price applies from your next invoice.</>
          : <>An invoice for {money(choice?.price_cents)} will be created. Your connection is activated after payment.</>}
      </Confirm>
    </Page>
  );
}
