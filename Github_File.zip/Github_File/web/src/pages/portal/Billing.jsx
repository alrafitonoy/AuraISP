import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { CreditCard, FileText, Wallet } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { date, dateTime, money, label } from '../../lib/format.js';
import BillActions, { ReceiptButton } from '../../components/BillActions.jsx';
import { isMobileApp } from '../../lib/platform.js';
import { downloadFile } from '../../lib/download.js';
import { FileDown } from 'lucide-react';
import { Badge, Button, Card, DataTable, Modal, Page, Stat, Tabs, useLoad } from '../../components/ui.jsx';

const GW = { bkash: 'bKash', sslcommerz: 'SSLCommerz (cards, mobile banking)', stripe: 'Card (Stripe)' };

export default function Billing() {
  const { toast, moduleOn } = useApp();
  const [tab, setTab] = useState('invoices');
  const [params, setParams] = useSearchParams();
  const invoices = useLoad(() => api('/billing/invoices?pageSize=100'));
  const payments = useLoad(() => api('/billing/payments?pageSize=100'));
  const gateways = useLoad(() => api('/billing/gateways'));
  const [paying, setPaying] = useState(null);
  const [busy, setBusy] = useState('');

  useEffect(() => {
    const p = params.get('payment');
    if (!p) return;
    if (p === 'success') toast('Payment successful — thank you!');
    else if (p === 'failed') toast('Payment failed or was declined', 'bad');
    else if (p === 'cancelled') toast('Payment cancelled', 'info');
    else if (p === 'pending') { toast('Payment is being confirmed — your invoice will update shortly', 'info'); setTimeout(() => { invoices.reload(); payments.reload(); }, 5000); }
    setParams({}, { replace: true });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const due = (invoices.data?.rows || []).filter((i) => ['unpaid', 'overdue', 'partial'].includes(i.status));
  const totalDue = due.reduce((s, i) => s + i.total_cents - i.paid_cents, 0);
  const online = (gateways.data?.gateways || []).filter((g) => g.id !== 'manual');
  const manual = (gateways.data?.gateways || []).find((g) => g.id === 'manual');

  const pay = async (gateway) => {
    setBusy(gateway);
    try {
      const r = await api.post(`/billing/invoices/${paying.id}/pay`, { gateway });
      if (!/^https:\/\//.test(r.redirectUrl)) throw new Error('Unexpected payment URL');
      const Browser = isMobileApp && window.Capacitor?.Plugins?.Browser;
      if (Browser) {
        // Mobile app: pay in the system browser (gateway apps & 3-D Secure work there), then refresh.
        const h = await Browser.addListener('browserFinished', () => { h.remove(); setPaying(null); setBusy(''); invoices.reload(); payments.reload(); });
        await Browser.open({ url: r.redirectUrl });
      } else {
        window.location.assign(r.redirectUrl);
      }
    } catch (e) { toast(e.message, 'bad'); setBusy(''); }
  };

  return (
    <Page title="Billing" subtitle="Invoices, payments and receipts"
      actions={<Button icon={FileDown} onClick={() => downloadFile(`/pdf/reports/customer?from=${new Date(Date.now() - 365 * 86400000).toISOString().slice(0, 10)}`, { fallbackName: 'statement.pdf' }).catch((e) => toast(e.message, 'bad'))}>Statement (PDF)</Button>}>
      <div className="grid g3 mb">
        <Stat icon={Wallet} label="Outstanding" value={totalDue} format={money} sub={`${due.length} invoice(s)`} />
        <Stat icon={FileText} label="Invoices" value={invoices.data?.total || 0} />
        <Stat icon={CreditCard} label="Payments made" value={(payments.data?.rows || []).filter((p) => p.status === 'success').length} />
      </div>
      <div className="mb"><Tabs tabs={['invoices', 'payments']} value={tab} onChange={setTab} /></div>
      <Card className="flush">
        {tab === 'invoices' ? (
          <DataTable loading={invoices.loading} rows={invoices.data?.rows} columns={[
            { key: 'number', title: 'Invoice', render: (r) => <b>{r.number}</b> },
            { key: 'issued_at', title: 'Issued', render: (r) => date(r.issued_at) },
            { key: 'due_date', title: 'Due', render: (r) => date(r.due_date) },
            { key: 'total_cents', title: 'Amount', align: 'right', render: (r) => money(r.total_cents) },
            { key: 'status', title: 'Status', render: (r) => <Badge status={r.status} /> },
            { key: 'a', title: '', align: 'right', render: (r) => (
              <div className="row end">
                <BillActions invoice={r} />
                {['unpaid', 'overdue', 'partial'].includes(r.status) && <Button size="sm" variant="primary" onClick={() => setPaying(r)}>Pay now</Button>}
              </div>) },
          ]} />
        ) : (
          <DataTable loading={payments.loading} rows={payments.data?.rows} columns={[
            { key: 'created_at', title: 'Date', render: (r) => dateTime(r.completed_at || r.created_at) },
            { key: 'invoice_number', title: 'Invoice' },
            { key: 'method', title: 'Method', render: (r) => label(r.method) },
            { key: 'amount_cents', title: 'Amount', align: 'right', render: (r) => money(r.amount_cents) },
            { key: 'status', title: 'Status', render: (r) => <Badge status={r.status} /> },
            { key: 'receipt', title: '', align: 'right', render: (r) => <ReceiptButton payment={r} /> },
          ]} />
        )}
      </Card>

      <Modal open={!!paying} onClose={() => setPaying(null)} title={`Pay ${paying?.number || ''}`}>
        {paying && (
          <div className="col">
            <div className="card glow" style={{ textAlign: 'center' }}><div className="faint">Amount</div><div style={{ font: '700 34px var(--font-display)' }} className="gradient-text">{money(paying.total_cents - paying.paid_cents)}</div></div>
            {moduleOn('payments_online') && online.map((g) => <Button key={g.id} size="lg" onClick={() => pay(g.id)} loading={busy === g.id} disabled={!!busy}>{GW[g.id] || g.id}</Button>)}
            {(!moduleOn('payments_online') || !online.length) && <div className="alert info"><div>Online payments are not available right now.</div></div>}
            {manual && <div className="alert info"><div><b>Pay offline:</b> {manual.instructions}</div></div>}
            <div className="faint" style={{ textAlign: 'center' }}>You'll be redirected to the secure payment page. Card details never touch our servers.</div>
          </div>
        )}
      </Modal>
    </Page>
  );
}
