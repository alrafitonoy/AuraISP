import { useState } from 'react';
import { motion } from 'framer-motion';
import { Gauge as GaugeIcon, Play, Router as RouterIcon, ShieldCheck, ShieldX, MonitorSmartphone } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { dateTime, label } from '../../lib/format.js';
import { Badge, Button, Card, Empty, Gauge, Page, useLoad } from '../../components/ui.jsx';

/** Browser-based speed test against our own server: latency, download and upload. */
export function SpeedTest({ onResult }) {
  const [phase, setPhase] = useState('idle');
  const [live, setLive] = useState(0);
  const [res, setRes] = useState(null);
  const run = async () => {
    setRes(null);
    try {
      setPhase('ping');
      const pings = [];
      for (let i = 0; i < 5; i++) { const t = performance.now(); await api('/speedtest/ping'); pings.push(performance.now() - t); }
      const pingMs = +Math.min(...pings).toFixed(1);
      setPhase('download');
      const t0 = performance.now();
      const r = await api('/speedtest/download?mb=20', { raw: true });
      const reader = r.body.getReader(); let got = 0;
      for (;;) { const { done, value } = await reader.read(); if (done) break; got += value.length; const s = (performance.now() - t0) / 1000; setLive((got * 8) / s / 1e6); }
      const downMbps = +((got * 8) / ((performance.now() - t0) / 1000) / 1e6).toFixed(1);
      setPhase('upload');
      const blob = new Uint8Array(8 * 1024 * 1024); crypto.getRandomValues(blob.subarray(0, 65536));
      const t1 = performance.now();
      await api('/speedtest/upload', { method: 'POST', form: new Blob([blob], { type: 'application/octet-stream' }) });
      const upMbps = +((blob.length * 8) / ((performance.now() - t1) / 1000) / 1e6).toFixed(1);
      const out = { pingMs, downMbps, upMbps };
      setRes(out); setPhase('done'); setLive(downMbps);
      onResult?.(out);
    } catch { setPhase('error'); }
  };
  return (
    <div className="col" style={{ alignItems: 'center' }}>
      <Gauge value={live} max={Math.max(100, live * 1.2)} label={live.toFixed(1)} sub={phase === 'idle' ? 'Mbps' : phase === 'done' ? 'Mbps download' : phase === 'error' ? 'Test failed' : `Testing ${phase}…`} size={220} />
      {res && (
        <motion.div className="grid g3" style={{ width: '100%', textAlign: 'center' }} initial={{ y: 10 }} animate={{ y: 0 }}>
          <div><div className="faint">Ping</div><b style={{ fontSize: 20 }}>{res.pingMs} ms</b></div>
          <div><div className="faint">Download</div><b style={{ fontSize: 20 }}>{res.downMbps} Mbps</b></div>
          <div><div className="faint">Upload</div><b style={{ fontSize: 20 }}>{res.upMbps} Mbps</b></div>
        </motion.div>
      )}
      <Button variant="primary" size="lg" icon={Play} onClick={run} loading={!['idle', 'done', 'error'].includes(phase)}>{phase === 'done' ? 'Run again' : 'Start speed test'}</Button>
      <div className="faint">Measures your connection to our network. For best results use a wired connection.</div>
    </div>
  );
}

export default function Devices() {
  const { toast, moduleOn } = useApp();
  const { data, reload } = useLoad(() => api('/portal/devices'));
  const sessions = useLoad(() => (moduleOn('remote_support') ? api('/portal/remote-sessions') : Promise.resolve({ sessions: [] })));
  const decide = async (id, decision) => {
    try { await api.post(`/portal/remote-sessions/${id}/${decision}`); toast(decision === 'approve' ? 'Remote support approved' : 'Request denied'); sessions.reload(); } catch (e) { toast(e.message, 'bad'); }
  };
  const pending = (sessions.data?.sessions || []).filter((s) => s.status === 'requested');
  return (
    <Page title="Devices & tests" subtitle="Test your connection and manage remote support">
      {pending.map((s) => (
        <motion.div key={s.id} className="alert warn mb" initial={{ y: -10 }} animate={{ y: 0 }}>
          <MonitorSmartphone size={18} />
          <div className="grow"><b>{s.staff_name}</b> from support is requesting permission to run remote diagnostics on your connection (status checks, ping tests, reconnecting your session).</div>
          <div className="row"><Button size="sm" variant="primary" icon={ShieldCheck} onClick={() => decide(s.id, 'approve')}>Approve</Button><Button size="sm" icon={ShieldX} onClick={() => decide(s.id, 'deny')}>Deny</Button></div>
        </motion.div>
      ))}
      <div className="grid g2">
        <Card title="Speed test" actions={<GaugeIcon size={18} className="muted" />}><SpeedTest onResult={(r) => api.post('/portal/speedtest-result', r).then(reload).catch(() => {})} /></Card>
        <div className="col">
          <Card title="My equipment">
            {!data?.devices?.length ? <Empty icon={RouterIcon} title="No registered devices" /> : data.devices.map((d) => (
              <div key={d.id} className="list-item"><RouterIcon size={20} className="muted" /><div className="grow"><b>{d.name}</b><div className="faint">{d.model} · {d.ip_address || 'no IP'}</div></div><Badge status={d.status} /></div>
            ))}
          </Card>
          <Card title="Recent tests">
            {!data?.tests?.length ? <Empty title="No tests yet" /> : data.tests.slice(0, 8).map((t) => (
              <div key={t.id} className="list-item"><div className="grow"><b>{label(t.test)}</b><div className="faint">{dateTime(t.created_at)}</div></div>
                <span className="mono faint">{t.result?.downMbps ? `${t.result.downMbps}↓ ${t.result.upMbps}↑ ${t.result.pingMs}ms` : t.result?.avgMs ? `${t.result.avgMs} ms` : ''}</span></div>
            ))}
          </Card>
          {sessions.data?.sessions?.length > 0 && (
            <Card title="Remote support history">
              {sessions.data.sessions.map((s) => <div key={s.id} className="list-item"><div className="grow"><b>{s.staff_name}</b><div className="faint">{dateTime(s.created_at)} · {s.actions.length} action(s)</div></div><Badge status={s.status} /></div>)}
            </Card>
          )}
        </div>
      </div>
    </Page>
  );
}
