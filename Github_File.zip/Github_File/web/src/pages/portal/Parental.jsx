import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldCheck, Plus, Trash2, Moon, Gamepad2, Users, Tv, Dice5, EyeOff, Globe } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { Button, Card, Page, Spinner, Toggle, useLoad } from '../../components/ui.jsx';

const CAT = { social: { icon: Users, label: 'Social media' }, gaming: { icon: Gamepad2, label: 'Gaming' }, streaming: { icon: Tv, label: 'Video streaming' }, gambling: { icon: Dice5, label: 'Gambling' }, adult: { icon: EyeOff, label: 'Adult content' } };
const DAYS = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];

export function ParentalEditor({ value, onChange, categories }) {
  const [domain, setDomain] = useState('');
  const v = value;
  const set = (patch) => onChange({ ...v, ...patch });
  const toggleCat = (c) => set({ blockedCategories: v.blockedCategories.includes(c) ? v.blockedCategories.filter((x) => x !== c) : [...v.blockedCategories, c] });
  const addDomain = (e) => {
    e.preventDefault();
    const d = domain.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    if (!/^(?!-)[a-z0-9-]{1,63}(\.[a-z0-9-]{1,63})+$/.test(d)) return;
    if (!v.blockedDomains.includes(d)) set({ blockedDomains: [...v.blockedDomains, d] });
    setDomain('');
  };
  return (
    <div className="col">
      <Toggle checked={v.enabled} onChange={(enabled) => set({ enabled })} label="Enable parental controls" hint="Rules apply to every device on this connection" />
      <motion.div animate={{ opacity: v.enabled ? 1 : .45 }} style={{ pointerEvents: v.enabled ? 'auto' : 'none' }} className="col">
        <Toggle checked={v.safeSearch} onChange={(safeSearch) => set({ safeSearch })} label="Family-safe DNS & SafeSearch" hint="Filters adult and malicious sites on Google, Bing and YouTube" />
        <div className="divider" />
        <b>Block categories</b>
        <div className="grid g3">
          {categories.map((c) => {
            const meta = CAT[c] || { icon: Globe, label: c };
            const on = v.blockedCategories.includes(c);
            return (
              <motion.button key={c} type="button" whileTap={{ scale: .96 }} onClick={() => toggleCat(c)} className={`card ${on ? 'glow' : 'hover'}`} style={{ textAlign: 'left', cursor: 'pointer', font: 'inherit', color: 'inherit' }} aria-pressed={on}>
                <div className="row"><meta.icon size={20} style={{ color: on ? 'var(--bad)' : 'var(--text-3)' }} /><b>{meta.label}</b></div>
                <div className="faint" style={{ marginTop: 6 }}>{on ? 'Blocked' : 'Allowed'}</div>
              </motion.button>
            );
          })}
        </div>
        <div className="divider" />
        <b>Blocked websites</b>
        <form onSubmit={addDomain} className="row"><input className="input" placeholder="e.g. example.com" value={domain} onChange={(e) => setDomain(e.target.value)} aria-label="Domain to block" /><Button type="submit" icon={Plus}>Add</Button></form>
        <div className="row wrap">
          <AnimatePresence>{v.blockedDomains.map((d) => (
            <motion.span key={d} layout initial={{ opacity: 0, scale: .8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: .8 }} className="chip">{d}<button type="button" onClick={() => set({ blockedDomains: v.blockedDomains.filter((x) => x !== d) })} style={{ all: 'unset', cursor: 'pointer', display: 'grid' }} aria-label={`Unblock ${d}`}><Trash2 size={13} /></button></motion.span>
          ))}</AnimatePresence>
          {!v.blockedDomains.length && <span className="faint">No websites blocked</span>}
        </div>
        <div className="divider" />
        <div className="row between"><b>Internet pause schedules</b><Button size="sm" icon={Plus} onClick={() => set({ schedules: [...v.schedules, { label: 'Bedtime', from: '22:00', to: '23:59', days: [...DAYS] }] })}>Add schedule</Button></div>
        {v.schedules.map((s, i) => (
          <motion.div key={i} layout className="card" style={{ padding: 14 }}>
            <div className="row wrap">
              <Moon size={18} className="muted" />
              <input className="input" style={{ width: 140 }} value={s.label || ''} maxLength={40} onChange={(e) => set({ schedules: v.schedules.map((x, j) => (j === i ? { ...x, label: e.target.value } : x)) })} aria-label="Schedule name" />
              <input className="input" type="time" style={{ width: 130 }} value={s.from} onChange={(e) => set({ schedules: v.schedules.map((x, j) => (j === i ? { ...x, from: e.target.value } : x)) })} aria-label="From" />
              <span className="faint">to</span>
              <input className="input" type="time" style={{ width: 130 }} value={s.to} onChange={(e) => set({ schedules: v.schedules.map((x, j) => (j === i ? { ...x, to: e.target.value } : x)) })} aria-label="To" />
              <div className="grow" />
              <Button size="sm" variant="ghost" icon={Trash2} onClick={() => set({ schedules: v.schedules.filter((_, j) => j !== i) })} aria-label="Remove schedule" />
            </div>
            <div className="row wrap" style={{ marginTop: 10, gap: 6 }}>
              {DAYS.map((d) => <button key={d} type="button" className={`chip ${s.days.includes(d) ? 'on' : ''}`} onClick={() => set({ schedules: v.schedules.map((x, j) => (j === i ? { ...x, days: x.days.includes(d) ? x.days.filter((y) => y !== d) : [...x.days, d] } : x)) })}>{d}</button>)}
            </div>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}

export default function Parental() {
  const { toast } = useApp();
  const { data } = useLoad(() => api('/portal/parental'));
  const [value, setValue] = useState(null);
  const [saving, setSaving] = useState(false);
  useEffect(() => {
    if (data) setValue({ ...data.parental, blockedCategories: data.parental.blockedCategories || [], blockedDomains: data.parental.blockedDomains || [], schedules: (data.parental.schedules || []).map((s) => ({ ...s, from: s.fromLabel || s.from, to: s.toLabel || s.to })) });
  }, [data]);
  if (!value) return <Spinner />;
  const save = async () => {
    setSaving(true);
    try {
      const r = await api.put('/portal/parental', {
        enabled: !!value.enabled, safeSearch: !!value.safeSearch, blockedCategories: value.blockedCategories, blockedDomains: value.blockedDomains,
        schedules: value.schedules.filter((s) => s.days.length).map((s) => ({ label: s.label, from: s.from, to: s.to, days: s.days })),
      });
      toast(r.sync?.ok === false ? `Saved, but the router could not be updated yet: ${r.sync.error}` : 'Parental controls applied', r.sync?.ok === false ? 'info' : 'ok');
    } catch (e) { toast(e.message, 'bad'); } finally { setSaving(false); }
  };
  return (
    <Page title="Parental controls" subtitle="Keep your family safe online" actions={<Button variant="primary" icon={ShieldCheck} loading={saving} onClick={save}>Save & apply</Button>}>
      <Card><ParentalEditor value={value} onChange={setValue} categories={data.categories} /></Card>
    </Page>
  );
}
