import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowDown, ArrowUp, CreditCard, LifeBuoy, Package, Wifi, AlertTriangle, Database } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { bps, bytes, date, money, speed } from '../../lib/format.js';
import { Badge, Card, Gauge, Page, Spinner, Stat, useLoad, fadeUp } from '../../components/ui.jsx';
import { AreaSeries } from '../../components/charts.jsx';

export default function Overview() {
  const { user, liveBw, moduleOn } = useApp();
  const { data } = useLoad(() => api('/portal/overview'));
  const usage = useLoad(() => (moduleOn('bandwidth') ? api('/portal/usage?hours=24') : Promise.resolve(null)));
  if (!data) return <Spinner />;
  const c = data.customer;
  const live = liveBw?.rx_bps !== undefined ? liveBw : data.live;
  const capBytes = c.data_cap_mb ? c.data_cap_mb * 1024 * 1024 : 0;

  return (
    <Page title={`Hi, ${user.name.split(' ')[0]} 👋`} subtitle={`Account ${c.code} · ${c.area || ''}`}>
      {c.status !== 'active' && (
        <motion.div variants={fadeUp} className={`alert ${c.status === 'suspended' ? 'bad' : 'warn'} mb`}>
          <AlertTriangle size={18} />
          <div>{c.status === 'suspended' ? (c.suspended_reason === 'data_cap' ? 'Your service is paused because this month\'s data allowance is used up. It resumes on the 1st, or upgrade now.' : c.suspended_reason === 'manual' ? 'Your service has been suspended by our team. Please contact support.' : 'Your service is suspended. Pay outstanding invoices to restore it instantly.') : c.plan_id ? 'Your connection is being prepared. Our team will contact you to schedule installation.' : 'Choose a plan to activate your connection.'}{' '}
            <Link to={c.plan_id ? '/portal/billing' : '/portal/plans'} style={{ fontWeight: 700, color: 'var(--brand-1)' }}>{c.plan_id ? 'Go to billing →' : 'Choose a plan →'}</Link></div>
        </motion.div>
      )}
      <div className="grid g3">
        <Card className="span2" title="Live bandwidth" actions={live?.online ? <span className="row faint"><span className="pulse-dot" /> Online</span> : <Badge status="offline" />}>
          <div className="row wrap" style={{ justifyContent: 'space-around', gap: 24 }}>
            <Gauge value={(live?.rx_bps || 0) / 1000} max={c.bandwidth.downKbps} label={bps(live?.rx_bps || 0).split(' ')[0]} sub={<><ArrowDown size={12} /> {bps(live?.rx_bps || 0).split(' ')[1]} download</>} />
            <Gauge value={(live?.tx_bps || 0) / 1000} max={c.bandwidth.upKbps} label={bps(live?.tx_bps || 0).split(' ')[0]} sub={<><ArrowUp size={12} /> {bps(live?.tx_bps || 0).split(' ')[1]} upload</>} size={170} />
            <div className="col" style={{ minWidth: 180 }}>
              <div><div className="faint">Your plan</div><div style={{ font: '700 22px var(--font-display)' }}>{c.plan_name || 'No plan'}</div></div>
              <div><div className="faint">Speed</div><b>{speed(c.bandwidth.downKbps)} ↓ / {speed(c.bandwidth.upKbps)} ↑</b></div>
              <div><div className="faint">Status</div><Badge status={c.status} /></div>
            </div>
          </div>
        </Card>
        <div className="col">
          <Stat icon={CreditCard} label="Amount due" value={data.dueCents} format={(v) => money(v)} sub={data.nextDueDate ? `Due ${date(data.nextDueDate)}` : 'All paid up 🎉'} />
          <Stat icon={Database} label="Data this month" value={data.monthUsageBytes} format={(v) => bytes(v)} sub={capBytes ? `of ${bytes(capBytes)}` : 'Unlimited'} />
        </div>
      </div>
      {c.cap_exceeded && (
        <motion.div variants={fadeUp} className="alert warn mt">
          <AlertTriangle size={18} />
          <div>You've used this month's data allowance, so your speed is limited until the 1st. <Link to="/portal/plans" style={{ fontWeight: 700, color: 'var(--brand-1)' }}>Upgrade for full speed →</Link></div>
        </motion.div>
      )}
      {capBytes > 0 && <Card className="mt" title="Data cap"><div className="progress"><i style={{ width: `${Math.min(100, (data.monthUsageBytes / capBytes) * 100)}%` }} /></div></Card>}
      {usage.data && (
        <Card className="mt" title="Last 24 hours">
          <AreaSeries data={usage.data.samples} x="ts" fmtX={(v) => new Date(v).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} fmtY={bps}
            series={[{ key: 'rx_bps', label: 'Download' }, { key: 'tx_bps', label: 'Upload' }]} />
        </Card>
      )}
      <div className="grid g3 mt">
        {[
          { to: '/portal/billing', icon: CreditCard, t: 'Pay a bill', d: 'Invoices & payment history' },
          { to: '/portal/plans', icon: Package, t: 'Upgrade speed', d: 'Prorated, applied instantly' },
          { to: '/portal/support', icon: LifeBuoy, t: 'Get help', d: `${data.openTickets} open ticket(s)` },
        ].map((q) => (
          <motion.div key={q.to} variants={fadeUp} whileHover={{ y: -4 }}>
            <Link to={q.to} className="card hover row" style={{ display: 'flex' }}><div className="stat"><div className="ico"><q.icon size={18} /></div></div><div><b>{q.t}</b><div className="faint">{q.d}</div></div></Link>
          </motion.div>
        ))}
      </div>
      {c.ip_address && <div className="faint mt row"><Wifi size={14} /> {c.connection_type?.toUpperCase()} · {c.ip_address}</div>}
    </Page>
  );
}
