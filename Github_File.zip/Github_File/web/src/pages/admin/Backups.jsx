import { useState } from 'react';
import { motion } from 'framer-motion';
import { Database, Layers, HardDrive, Download, RotateCcw, Trash2, Upload, Lock, ShieldCheck, AlertTriangle } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { downloadFile } from '../../lib/download.js';
import { bytes, dateTime } from '../../lib/format.js';
import { Badge, Button, Card, DataTable, Input, Modal, Page, Select, Toggle, useLoad, fadeUp, stagger } from '../../components/ui.jsx';

const KINDS = {
  database: { icon: Database, title: 'Database', text: 'All data: customers, billing, network, settings. Portable — restores into SQLite or MySQL.' },
  ui_db: { icon: Layers, title: 'UI + database', text: 'Database plus the built web app and uploaded branding (logo, favicon).' },
  full: { icon: HardDrive, title: 'Entire system', text: 'Database, web app, uploads and server code. Optionally the .env master key (encrypted).' },
};

export default function Backups() {
  const { toast, user } = useApp();
  const { data, reload } = useLoad(() => api('/backups'));
  const [create, setCreate] = useState(null);
  const [action, setAction] = useState(null); // { kind: 'download'|'restore'|'delete', backup }
  const [busy, setBusy] = useState(false);
  const [sched, setSched] = useState(null);
  if (data && !sched) setSched(data.settings);

  const doCreate = async (e) => {
    e.preventDefault(); setBusy(true);
    try { const r = await api.post('/backups', { kind: create.kind, includeEnv: create.includeEnv, passphrase: create.passphrase || undefined }); toast(`Backup created (${bytes(r.size)})`); setCreate(null); reload(); }
    catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  const doAction = async (e) => {
    e.preventDefault(); setBusy(true);
    const { kind, backup, password, passphrase, restoreFiles, restoreEnv } = action;
    try {
      if (kind === 'download') { await downloadFile(`/backups/${backup.id}/download`, { method: 'POST', body: { password }, fallbackName: backup.file }); toast('Download started'); }
      if (kind === 'delete') { await api.del(`/backups/${backup.id}`, { body: { password } }); toast('Backup deleted'); }
      if (kind === 'restore') {
        const r = await api.post(`/backups/${backup.id}/restore`, { password, passphrase: passphrase || undefined, restoreFiles, restoreEnv });
        toast(`Restored: ${r.restored.join(', ')}. Safety backup: ${r.safetyBackup}`);
        setTimeout(() => window.location.assign('/login'), r.restarting ? 8000 : 1500);
      }
      setAction(null); reload();
    } catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  const upload = async (file) => {
    if (!file) return;
    const form = new FormData(); form.append('file', file);
    try { await api('/backups/upload', { method: 'POST', form }); toast('Backup uploaded — you can restore it now'); reload(); } catch (e) { toast(e.message, 'bad'); }
  };
  const saveSched = async () => { try { await api.put('/backups/settings', sched); toast('Schedule saved'); } catch (e) { toast(e.message, 'bad'); } };

  return (
    <Page title="Backups" subtitle="Database, UI + database, or the entire system — on demand or on a schedule"
      actions={user.type === 'admin' && <label className="btn"><Upload size={16} /> Upload backup<input type="file" hidden accept=".gz,.enc" onChange={(e) => upload(e.target.files[0])} /></label>}>
      <motion.div className="grid g3 mb" variants={stagger} initial="hidden" animate="show">
        {Object.entries(KINDS).map(([k, m]) => (
          <motion.div key={k} variants={fadeUp} whileHover={{ y: -4 }} className="card hover col">
            <div className="row"><div className="stat"><div className="ico"><m.icon size={18} /></div></div><h3 style={{ margin: 0 }}>{m.title}</h3></div>
            <p className="muted" style={{ margin: 0 }}>{m.text}</p>
            <Button variant="primary" onClick={() => setCreate({ kind: k, passphrase: '', includeEnv: false })} style={{ alignSelf: 'flex-start' }}>Back up now</Button>
          </motion.div>
        ))}
      </motion.div>
      <div className="grid g3">
        <Card className="span2 flush" title="">
          <div style={{ padding: '16px 20px 0' }}><h3>Stored backups</h3></div>
          <DataTable rows={data?.backups} loading={!data} empty="No backups yet" columns={[
            { key: 'created_at', title: 'Created', render: (r) => dateTime(r.created_at) },
            { key: 'kind', title: 'Type', render: (r) => <Badge kind="brand">{KINDS[r.kind]?.title || r.kind}</Badge> },
            { key: 'size', title: 'Size', render: (r) => bytes(r.size) },
            { key: 'enc', title: '', render: (r) => r.encrypted ? <Lock size={15} title="Encrypted" /> : null },
            { key: 'trigger_by', title: 'By', render: (r) => <span className="faint">{String(r.trigger_by).replace('manual:', '')}</span> },
            { key: 'x', title: '', align: 'right', render: (r) => r.exists ? (
              <div className="row end">
                <Button size="sm" variant="ghost" icon={Download} onClick={() => setAction({ kind: 'download', backup: r, password: '' })} aria-label="Download" />
                {user.type === 'admin' && <Button size="sm" icon={RotateCcw} onClick={() => setAction({ kind: 'restore', backup: r, password: '', passphrase: '', restoreFiles: true, restoreEnv: false })}>Restore</Button>}
                <Button size="sm" variant="ghost" icon={Trash2} onClick={() => setAction({ kind: 'delete', backup: r, password: '' })} aria-label="Delete" />
              </div>) : <Badge kind="bad">file missing</Badge> },
          ]} />
        </Card>
        <Card title="Automatic backups">
          {sched && <div className="col">
            <Toggle checked={sched.auto} onChange={(auto) => setSched({ ...sched, auto })} label="Daily automatic backup" />
            <Select label="What to back up" value={sched.kind} onChange={(e) => setSched({ ...sched, kind: e.target.value })} options={Object.entries(KINDS).map(([v, m]) => ({ value: v, label: m.title }))} />
            <Input label="Hour (server time, 0–23)" type="number" min={0} max={23} value={sched.hour} onChange={(e) => setSched({ ...sched, hour: Number(e.target.value) })} />
            <Input label="Keep the newest" type="number" min={1} max={365} value={sched.keep} onChange={(e) => setSched({ ...sched, keep: Number(e.target.value) })} hint="Older backups are deleted automatically" />
            <Button onClick={saveSched}>Save schedule</Button>
            <div className="divider" />
            <div className="row"><ShieldCheck size={16} color="var(--ok)" /> <span className="faint">Checksums verified before every restore; a safety backup is taken first.</span></div>
            <div className="row"><AlertTriangle size={16} color="var(--warn)" /> <span className="faint">Copy backups off this server regularly (download them).</span></div>
          </div>}
        </Card>
      </div>

      <Modal open={!!create} onClose={() => setCreate(null)} title={`Back up: ${KINDS[create?.kind]?.title || ''}`}>
        {create && <form className="col" onSubmit={doCreate}>
          <Input label="Encryption passphrase (optional, 12+ characters)" type="password" minLength={create.passphrase ? 12 : undefined} value={create.passphrase} onChange={(e) => setCreate({ ...create, passphrase: e.target.value })} hint="AES-256 encrypted. Without the passphrase the backup cannot be restored — store it safely." autoComplete="new-password" />
          {create.kind === 'full' && user.type === 'admin' && <Toggle checked={create.includeEnv} onChange={(includeEnv) => setCreate({ ...create, includeEnv })} label="Include .env (master key & database credentials)" hint="Needed to move to a new server. Requires a passphrase." />}
          <Button variant="primary" type="submit" loading={busy} disabled={create.includeEnv && create.passphrase.length < 12}>Create backup</Button>
        </form>}
      </Modal>

      <Modal open={!!action} onClose={() => setAction(null)} title={action ? `${action.kind[0].toUpperCase()}${action.kind.slice(1)} backup` : ''}>
        {action && <form className="col" onSubmit={doAction}>
          <div className="faint mono">{action.backup.file}</div>
          {action.kind === 'restore' && <div className="alert warn"><AlertTriangle size={18} /><div>All current data will be replaced by this backup. A safety backup is created first, and everyone will need to sign in again.</div></div>}
          {action.kind === 'restore' && action.backup.encrypted && <Input label="Backup passphrase" type="password" required value={action.passphrase} onChange={(e) => setAction({ ...action, passphrase: e.target.value })} />}
          {action.kind === 'restore' && action.backup.kind !== 'database' && <Toggle checked={action.restoreFiles} onChange={(restoreFiles) => setAction({ ...action, restoreFiles })} label="Also restore files (web app, uploads, code)" />}
          {action.kind === 'restore' && action.backup.kind === 'full' && <Toggle checked={action.restoreEnv} onChange={(restoreEnv) => setAction({ ...action, restoreEnv })} label="Restore .env too (if included)" hint="Only when moving to a new server" />}
          <Input label="Your password (confirmation)" type="password" required value={action.password} onChange={(e) => setAction({ ...action, password: e.target.value })} autoComplete="current-password" />
          <Button variant={action.kind === 'download' ? 'primary' : 'danger'} type="submit" loading={busy}>{action.kind === 'restore' ? 'Restore now' : action.kind === 'delete' ? 'Delete permanently' : 'Download'}</Button>
        </form>}
      </Modal>
    </Page>
  );
}
