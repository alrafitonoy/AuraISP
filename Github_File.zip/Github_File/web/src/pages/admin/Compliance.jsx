import { useState } from 'react';
import { Link } from 'react-router-dom';
import { BadgeCheck, Download, Eye, Search, ShieldCheck, Trash2, XCircle, Network as NetIcon, RotateCcw } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { downloadFile } from '../../lib/download.js';
import { bytes, dateTime } from '../../lib/format.js';
import { Badge, Button, Card, Confirm, DataTable, Empty, Input, Page, Pager, Select, Tabs, useLoad } from '../../components/ui.jsx';
import { DOC_STATUS_TONE, DOC_TYPES, DocPreview, ReviewDoc } from '../../components/KycPanel.jsx';

// <input type="datetime-local"> is in the browser's local time; the API compares UTC ISO strings.
const toIso = (local) => (local ? new Date(local).toISOString() : '');
const qs = (o) => Object.entries(o).filter(([, v]) => v !== '' && v !== null && v !== undefined).map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&');

function KycQueue() {
  const { toast, can } = useApp();
  const [status, setStatus] = useState('pending');
  const [type, setType] = useState('');
  const [q, setQ] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const { data, loading, error, reload } = useLoad(() => api(`/ops/documents?${qs({ status, type, q: search, page, pageSize: 25 })}`), [status, type, search, page]);
  const [preview, setPreview] = useState(null);
  const [review, setReview] = useState(null);
  const [del, setDel] = useState(null);
  const canVerify = can('kyc.verify');
  const counts = data?.counts || {};
  const remove = async () => {
    try { await api.del(`/ops/documents/${del.id}`); toast('Document deleted'); reload(); } catch (e) { toast(e.message, 'bad'); }
  };
  return (
    <Card>
      <div className="row between wrap mb" style={{ gap: 10 }}>
        <Tabs value={status} onChange={(v) => { setStatus(v); setPage(1); }} tabs={['pending', 'verified', 'rejected'].map((s) => ({ value: s, label: <span>{s[0].toUpperCase() + s.slice(1)} <span className="faint">{counts[s] ?? 0}</span></span> }))} />
        <form className="row wrap" style={{ gap: 8 }} onSubmit={(e) => { e.preventDefault(); setSearch(q.trim()); setPage(1); }}>
          <div style={{ minWidth: 150 }}><Select aria-label="Document type" value={type} onChange={(e) => { setType(e.target.value); setPage(1); }} options={[{ value: '', label: 'All types' }, ...Object.entries(DOC_TYPES).map(([value, l]) => ({ value, label: l }))]} /></div>
          <div style={{ minWidth: 180 }}><Input aria-label="Search customer or number" placeholder="Customer, code, number…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
          <Button type="submit" icon={Search} aria-label="Search" />
        </form>
      </div>
      {error ? <div className="alert bad">{error.message}</div> : (
        <DataTable loading={loading} rows={data?.rows} empty={status === 'pending' ? 'No documents waiting for review' : `No ${status} documents`} columns={[
          { key: 'customer', title: 'Customer', render: (d) => <div><Link to={`/admin/customers/${d.customer_id}`}><b>{d.customer_name}</b></Link><div className="faint">{d.customer_code}{d.customer_phone ? ` · ${d.customer_phone}` : ''}</div></div> },
          { key: 'type', title: 'Document', render: (d) => <div>{DOC_TYPES[d.type] || d.type}{d.number && <div className="faint">{d.number}</div>}</div> },
          { key: 'created_at', title: 'Uploaded', render: (d) => dateTime(d.created_at) },
          { key: 'status', title: 'Status', render: (d) => <div><Badge kind={DOC_STATUS_TONE[d.status]}>{d.status}</Badge>{d.verified_by_name && <div className="faint">by {d.verified_by_name} · {dateTime(d.verified_at)}</div>}{d.note && <div className="faint" style={{ maxWidth: 260, whiteSpace: 'normal' }}>{d.note}</div>}</div> },
          { key: 'actions', title: '', align: 'right', render: (d) => (
            <div className="row end" style={{ gap: 6 }}>
              <Button size="sm" icon={Eye} onClick={() => setPreview(d)} aria-label="Preview" title="Preview" />
              <Button size="sm" icon={Download} onClick={() => downloadFile(`/ops/documents/${d.id}/file`, { fallbackName: `document-${d.id}` }).catch((e) => toast(e.message, 'bad'))} aria-label="Download" title="Download" />
              {canVerify && d.status !== 'verified' && <Button size="sm" variant="primary" icon={BadgeCheck} onClick={() => setReview({ doc: d, decision: 'verified' })}>Verify</Button>}
              {canVerify && d.status !== 'rejected' && <Button size="sm" icon={XCircle} onClick={() => setReview({ doc: d, decision: 'rejected' })}>Reject</Button>}
              {canVerify && d.status !== 'pending' && <Button size="sm" variant="ghost" icon={RotateCcw} onClick={() => api.post(`/ops/documents/${d.id}/verify`, { status: 'pending' }).then(() => { toast('Moved back to pending'); reload(); }).catch((e) => toast(e.message, 'bad'))} aria-label="Back to pending" title="Back to pending" />}
              {canVerify && <Button size="sm" variant="ghost" icon={Trash2} onClick={() => setDel(d)} aria-label="Delete" title="Delete" />}
            </div>
          ) },
        ]} />
      )}
      {data && <Pager page={data.page} pageSize={data.pageSize} total={data.total} onPage={setPage} />}
      {preview && <DocPreview doc={preview} onClose={() => setPreview(null)} />}
      {review && <ReviewDoc doc={review.doc} decision={review.decision} onClose={() => setReview(null)} onDone={() => { setReview(null); reload(); }} />}
      <Confirm open={!!del} onClose={() => setDel(null)} onConfirm={remove} danger confirmText="Delete" title="Delete document?">
        {del && `${DOC_TYPES[del.type] || del.type} of ${del.customer_name} will be permanently deleted. This cannot be undone.`}
      </Confirm>
    </Card>
  );
}

function SessionLog() {
  const { toast } = useApp();
  const [form, setForm] = useState({ ip: '', q: '', mode: 'at', at: '', from: '', to: '', open: false });
  const [filters, setFilters] = useState(null);
  const [page, setPage] = useState(1);
  const [busy, setBusy] = useState(false);
  const params = filters ? { ...filters, page, pageSize: 50 } : null;
  const { data, loading, error } = useLoad(() => (params ? api(`/ops/sessions?${qs(params)}`) : api('/ops/sessions?pageSize=50&open=1')), [JSON.stringify(params)]);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }));
  const submit = (e) => {
    e.preventDefault();
    if (form.mode === 'range' && form.from && form.to && new Date(form.from) > new Date(form.to)) { toast('"From" must be before "To"', 'bad'); return; }
    setFilters({
      ip: form.ip.trim(), q: form.q.trim(),
      ...(form.mode === 'at' ? { at: toIso(form.at) } : { from: toIso(form.from), to: toIso(form.to) }),
      open: form.open ? '1' : '',
    });
    setPage(1);
  };
  const reset = () => { setForm({ ip: '', q: '', mode: 'at', at: '', from: '', to: '', open: false }); setFilters(null); setPage(1); };
  const exportCsv = async () => {
    setBusy(true);
    try { await downloadFile(`/ops/sessions.csv?${qs(filters || { open: '1' })}`, { fallbackName: 'session-log.csv' }); toast('Session log exported'); }
    catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  };
  return (
    <>
      <Card className="mb">
        <form className="col" onSubmit={submit}>
          <p className="muted" style={{ margin: 0 }}>Find who used an IP address at a given moment (BTRC requests), or every session in a period. A session matches when it started before the moment and had not ended yet.</p>
          <div className="grid g3">
            <Input label="IP address" placeholder="e.g. 103.112.10.25" value={form.ip} onChange={set('ip')} inputMode="decimal" />
            <Select label="Time" value={form.mode} onChange={set('mode')} options={[{ value: 'at', label: 'At a moment' }, { value: 'range', label: 'During a period' }]} />
            {form.mode === 'at'
              ? <Input label="Date & time" type="datetime-local" step="1" value={form.at} onChange={set('at')} hint="Your local time" />
              : <div className="grid g2" style={{ gap: 10 }}>
                  <Input label="From" type="datetime-local" value={form.from} onChange={set('from')} />
                  <Input label="To" type="datetime-local" value={form.to} onChange={set('to')} />
                </div>}
          </div>
          <div className="row wrap between" style={{ gap: 10 }}>
            <div className="row wrap" style={{ gap: 10 }}>
              <div style={{ minWidth: 220 }}><Input aria-label="Customer, username or MAC" placeholder="Customer, PPPoE username or MAC" value={form.q} onChange={set('q')} /></div>
              <label className="row" style={{ gap: 6, cursor: 'pointer' }}><input type="checkbox" checked={form.open} onChange={set('open')} /> Only sessions online now</label>
            </div>
            <div className="row wrap">
              <Button type="button" onClick={reset}>Reset</Button>
              <Button type="button" icon={Download} onClick={exportCsv} loading={busy}>Export CSV</Button>
              <Button variant="primary" type="submit" icon={Search}>Search</Button>
            </div>
          </div>
        </form>
      </Card>
      <Card title={filters ? `Results${data ? ` · ${data.total}` : ''}` : `Online now${data ? ` · ${data.total}` : ''}`}>
        {error ? <div className="alert bad">{error.message}</div> : (
          <DataTable loading={loading} rows={data?.rows} empty={filters ? 'No session matches this search' : 'No open sessions. Sessions are recorded every minute from the live network poll.'} columns={[
            { key: 'ip', title: 'IP', render: (s) => <b style={{ fontFamily: 'ui-monospace, monospace' }}>{s.ip || '—'}</b> },
            { key: 'customer', title: 'Customer', render: (s) => (s.customer_id ? <div><Link to={`/admin/customers/${s.customer_id}`}><b>{s.customer_name || `#${s.customer_id}`}</b></Link><div className="faint">{s.customer_code}{s.customer_phone ? ` · ${s.customer_phone}` : ''}</div></div> : <span className="faint">deleted</span>) },
            { key: 'username', title: 'Username / MAC', render: (s) => <div>{s.username || '—'}{s.mac && <div className="faint" style={{ fontFamily: 'ui-monospace, monospace' }}>{s.mac}</div>}</div> },
            { key: 'started_at', title: 'Started', render: (s) => dateTime(s.started_at) },
            { key: 'ended_at', title: 'Ended', render: (s) => (s.ended_at ? <div>{dateTime(s.ended_at)}<div className="faint">last seen {dateTime(s.last_seen_at)}</div></div> : <Badge kind="ok">online</Badge>) },
            { key: 'traffic', title: 'Traffic ↓/↑', align: 'right', render: (s) => <span className="faint">{bytes(s.bytes_in)} / {bytes(s.bytes_out)}</span> },
            { key: 'router', title: 'Router', render: (s) => s.router_name || '—' },
          ]} />
        )}
        {data && <Pager page={data.page} pageSize={data.pageSize} total={data.total} onPage={setPage} />}
      </Card>
    </>
  );
}

export default function Compliance() {
  const { can, moduleOn } = useApp();
  const tabs = [
    moduleOn('kyc') && can('kyc.view') && { value: 'kyc', label: <span className="row" style={{ gap: 6 }}><ShieldCheck size={15} /> KYC queue</span> },
    moduleOn('session_log') && can('kyc.view') && { value: 'sessions', label: <span className="row" style={{ gap: 6 }}><NetIcon size={15} /> Session &amp; IP log</span> },
  ].filter(Boolean);
  const [tab, setTab] = useState(tabs[0]?.value);
  const current = tabs.some((t) => t.value === tab) ? tab : tabs[0]?.value;
  return (
    <Page title="Compliance" subtitle="KYC verification and the BTRC session / IP log">
      {!tabs.length ? (
        <Card><Empty title="Nothing to show">The KYC and Session log modules are switched off, or you do not have permission to view them.</Empty></Card>
      ) : (
        <>
          {tabs.length > 1 && <div className="mb"><Tabs tabs={tabs} value={current} onChange={setTab} /></div>}
          {current === 'kyc' ? <KycQueue /> : <SessionLog />}
        </>
      )}
    </Page>
  );
}
