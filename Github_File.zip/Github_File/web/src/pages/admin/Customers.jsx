import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserPlus, Search } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { bps, date, money, speed } from '../../lib/format.js';
import { Badge, Button, Card, DataTable, Input, Modal, Page, Pager, Select, Tabs, Toggle, useLoad } from '../../components/ui.jsx';

export function CustomerForm({ initial = {}, onSubmit, submitText = 'Save', create }) {
  const plans = useLoad(() => api('/plans'));
  const routers = useLoad(() => api('/network/routers').catch(() => ({ routers: [] })));
  const { moduleOn } = useApp();
  const zones = useLoad(() => (moduleOn('zones') ? api('/zones?lite=1').catch(() => ({ zones: [] })) : Promise.resolve({ zones: [] })));
  const [f, setF] = useState({ connection_type: 'pppoe', createInvoice: true, ...initial });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault(); setBusy(true);
    const payload = { ...f };
    for (const k of ['plan_id', 'router_id', 'zone_id', 'custom_download_kbps', 'custom_upload_kbps', 'billing_day']) payload[k] = payload[k] === '' || payload[k] == null ? null : Number(payload[k]);
    if (!payload.billing_day) delete payload.billing_day;
    if (!payload.password) delete payload.password;
    if (!payload.pppoe_password) delete payload.pppoe_password;
    for (const k of ['id', 'user_id', 'code', 'created_at', 'updated_at', 'plan_name', 'download_kbps', 'upload_kbps', 'live', 'has_pppoe_password', 'parental', 'balance_cents', 'data_cap_mb', 'email_verified_at', 'pppoe_password_enc', 'zone_name']) delete payload[k];
    if (!create) { delete payload.email; delete payload.createInvoice; delete payload.password; }
    try { await onSubmit(payload); } finally { setBusy(false); }
  };
  return (
    <form className="col" onSubmit={submit}>
      <div className="grid g2">
        <Input label="Full name" required value={f.name || ''} onChange={set('name')} />
        <Input label="Email" type="email" required={create} disabled={!create} value={f.email || ''} onChange={set('email')} />
        <Input label="Phone" value={f.phone || ''} onChange={set('phone')} />
        <Input label="National ID" value={f.national_id || ''} onChange={set('national_id')} />
        <Input label="Area" value={f.area || ''} onChange={set('area')} />
        {zones.data?.zones?.length > 0 && <Select label="Zone" value={f.zone_id ?? ''} onChange={set('zone_id')} options={[{ value: '', label: '— none —' }, ...zones.data.zones.map((z) => ({ value: z.id, label: z.name }))]} />}
        <Input label="Address" value={f.address || ''} onChange={set('address')} />
        <Select label="Plan" value={f.plan_id ?? ''} onChange={set('plan_id')} options={[{ value: '', label: '— none —' }, ...(plans.data?.plans || []).map((p) => ({ value: p.id, label: `${p.name} · ${speed(p.download_kbps)} · ${money(p.price_cents)}` }))]} />
        <Select label="Router / NAS" value={f.router_id ?? ''} onChange={set('router_id')} options={[{ value: '', label: '— virtual —' }, ...(routers.data?.routers || []).map((r) => ({ value: r.id, label: r.name }))]} />
        <Select label="Connection type" value={f.connection_type} onChange={set('connection_type')} options={['pppoe', 'static', 'dhcp', 'hotspot']} />
        <Input label="PPPoE username" value={f.pppoe_username || ''} onChange={set('pppoe_username')} />
        <Input label={create ? 'PPPoE password' : 'New PPPoE password'} type="password" value={f.pppoe_password || ''} onChange={set('pppoe_password')} hint={!create && f.has_pppoe_password ? 'Leave blank to keep the current one' : undefined} autoComplete="new-password" />
        <Input label="IP address" value={f.ip_address || ''} onChange={set('ip_address')} placeholder="10.20.0.15" />
        <Input label="MAC address" value={f.mac_address || ''} onChange={set('mac_address')} placeholder="AA:BB:CC:DD:EE:FF" />
        <Input label="Billing day (1-28)" type="number" min={1} max={28} value={f.billing_day ?? ''} onChange={set('billing_day')} />
        {!create && <Select label="Status" value={f.status} onChange={set('status')} options={['pending', 'active', 'suspended', 'terminated']} />}
      </div>
      {create && <Input label="Portal password (optional)" type="password" value={f.password || ''} onChange={set('password')} hint="Leave blank to generate one and email it to the customer" autoComplete="new-password" />}
      {create && <Toggle checked={f.createInvoice} onChange={(v) => setF({ ...f, createInvoice: v })} label="Create first invoice" hint="Bills the first period plus any setup fee" />}
      <Button variant="primary" type="submit" loading={busy}>{submitText}</Button>
    </form>
  );
}

export default function Customers() {
  const { toast, can, moduleOn } = useApp();
  const nav = useNavigate();
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('');
  const [zone, setZone] = useState('');
  const zones = useLoad(() => (moduleOn('zones') ? api('/zones?lite=1').catch(() => ({ zones: [] })) : Promise.resolve({ zones: [] })));
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState('');
  const [creating, setCreating] = useState(false);
  const list = useLoad(() => api(`/customers?page=${page}&pageSize=25&q=${encodeURIComponent(q)}&status=${status}&sort=${sort}&zone_id=${zone}`), [page, q, status, sort, zone]);

  const create = async (payload) => {
    try {
      const r = await api.post('/customers', payload);
      if (r.tempPassword) window.prompt('Customer created. Temporary portal password (shown once — copy it now; it was also emailed if SMTP is configured):', r.tempPassword);
      toast(r.sync?.ok === false ? `Customer created; router sync failed: ${r.sync.error}` : 'Customer created and provisioned', r.sync?.ok === false ? 'info' : 'ok'); setCreating(false); nav(`/admin/customers/${r.id}`); }
    catch (e) { toast(e.message, 'bad'); }
  };

  return (
    <Page title="Customers" subtitle={`${list.data?.total ?? '…'} subscribers`} actions={can('customers.create') && <Button variant="primary" icon={UserPlus} onClick={() => setCreating(true)}>Add customer</Button>}>
      <div className="row wrap mb">
        <Tabs tabs={[{ value: '', label: 'All' }, 'active', 'pending', 'suspended', 'terminated']} value={status} onChange={(v) => { setStatus(v); setPage(1); }} />
        <div className="grow" />
        {zones.data?.zones?.length > 0 && <select className="input" style={{ width: 180 }} value={zone} onChange={(e) => { setZone(e.target.value); setPage(1); }} aria-label="Filter by zone"><option value="">All zones</option><option value="none">No zone</option>{zones.data.zones.map((z) => <option key={z.id} value={z.id}>{z.name}</option>)}</select>}
        <div style={{ position: 'relative', width: 300, maxWidth: '100%' }}>
          <Search size={16} style={{ position: 'absolute', left: 12, top: 13, color: 'var(--text-3)' }} />
          <input className="input" style={{ paddingLeft: 36 }} placeholder="Name, phone, code, IP, PPPoE…" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} aria-label="Search customers" />
        </div>
      </div>
      <Card className="flush">
        <DataTable loading={list.loading} rows={list.data?.rows} onRowClick={(r) => nav(`/admin/customers/${r.id}`)} sort={sort} onSort={setSort} columns={[
          { key: 'code', title: 'Code', sort: true, render: (r) => <span className="mono">{r.code}</span> },
          { key: 'name', title: 'Customer', sort: true, render: (r) => <div><b>{r.name}</b><div className="faint">{r.phone || r.email}</div></div> },
          { key: 'plan_name', title: 'Plan', render: (r) => r.plan_name ? <div>{r.plan_name}<div className="faint">{speed(r.custom_download_kbps || r.download_kbps)}</div></div> : <span className="faint">—</span> },
          { key: 'area', title: 'Area' },
          { key: 'live', title: 'Live', render: (r) => r.live?.online ? <span className="row" style={{ gap: 6 }}><span className="pulse-dot" /><span className="mono">{bps(r.live.rx_bps)}</span></span> : <span className="faint">offline</span> },
          { key: 'next_due_date', title: 'Next due', sort: true, render: (r) => date(r.next_due_date) },
          { key: 'status', title: 'Status', sort: true, render: (r) => <Badge status={r.status} /> },
        ]} />
        {list.data && <Pager page={list.data.page} pageSize={list.data.pageSize} total={list.data.total} onPage={setPage} />}
      </Card>
      <Modal wide open={creating} onClose={() => setCreating(false)} title="New customer"><CustomerForm create onSubmit={create} submitText="Create customer" /></Modal>
    </Page>
  );
}
