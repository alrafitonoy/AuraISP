import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Gauge as GaugeIcon, Pause, Play, RefreshCw, Trash2, Eye, Receipt, Wrench, ShieldCheck } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { bps, date, dateTime, label, money, speed } from '../../lib/format.js';
import BillActions, { ReceiptButton } from '../../components/BillActions.jsx';
import { Badge, Button, Card, Confirm, DataTable, Gauge, Input, Modal, Page, Spinner, Stat, Tabs, useLoad } from '../../components/ui.jsx';
import { AreaSeries } from '../../components/charts.jsx';
import { CustomerForm } from './Customers.jsx';
import { ParentalEditor } from '../portal/Parental.jsx';
import { RecordPayment, NewInvoice } from './Billing.jsx';
import { KIND_META } from './NetworkCore.jsx';
import { CustomerEquipment } from './Inventory.jsx';
import KycPanel from '../../components/KycPanel.jsx';
import { MapPin, ClipboardList } from 'lucide-react';
import { downloadFile } from '../../lib/download.js';
import { FileDown } from 'lucide-react';
import { Select } from '../../components/ui.jsx';

function Bandwidth({ c, onSaved }) {
  const { toast } = useApp();
  const [down, setDown] = useState(c.custom_download_kbps ? c.custom_download_kbps / 1000 : '');
  const [up, setUp] = useState(c.custom_upload_kbps ? c.custom_upload_kbps / 1000 : '');
  const [busy, setBusy] = useState(false);
  const save = async (reset) => {
    setBusy(true);
    try {
      const r = await api.post(`/customers/${c.id}/bandwidth`, reset ? { download_kbps: null, upload_kbps: null } : { download_kbps: down ? Math.round(down * 1000) : null, upload_kbps: up ? Math.round(up * 1000) : null });
      toast(r.ok ? 'Bandwidth applied on the router' : `Saved, but router sync failed: ${r.sync.error}`, r.ok ? 'ok' : 'info');
      if (reset) { setDown(''); setUp(''); }
      onSaved();
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  };
  return (
    <Card title="Bandwidth control" actions={<GaugeIcon size={18} className="muted" />}>
      <p className="muted">Plan speed: <b>{speed(c.download_kbps)} ↓ / {speed(c.upload_kbps)} ↑</b>. Set a custom limit to override it for this customer.</p>
      <div className="grid g2">
        <Input label="Download (Mbps)" type="number" min={0} step="0.1" value={down} onChange={(e) => setDown(e.target.value)} placeholder={String((c.download_kbps || 0) / 1000)} />
        <Input label="Upload (Mbps)" type="number" min={0} step="0.1" value={up} onChange={(e) => setUp(e.target.value)} placeholder={String((c.upload_kbps || 0) / 1000)} />
      </div>
      <div className="row mt"><Button variant="primary" loading={busy} onClick={() => save(false)}>Apply limit</Button><Button onClick={() => save(true)} disabled={busy}>Reset to plan</Button></div>
    </Card>
  );
}

const REASONS = { overdue: 'overdue invoices (automatic)', manual: 'manually by staff', data_cap: 'data allowance used up' };

function RulesCard({ c, onSaved }) {
  const { toast, can } = useApp();
  const active = c.billing_override === 'never_suspend' && (!c.override_until || c.override_until > new Date().toISOString());
  const [f, setF] = useState({ until: c.override_until ? c.override_until.slice(0, 10) : '', reason: c.override_reason || '', reactivate: true });
  const [busy, setBusy] = useState(false);
  if (!can('billing.manage') && !can('customers.edit')) return null;
  const save = async (mode) => {
    setBusy(true);
    try {
      await api.post(`/customers/${c.id}/override`, { mode, until: mode === 'none' || !f.until ? null : new Date(`${f.until}T23:59:59Z`).toISOString(), reason: mode === 'none' ? null : f.reason, reactivate: f.reactivate });
      toast(mode === 'none' ? 'Override removed — normal invoicing rules apply' : 'Override saved — auto-suspension is paused for this customer');
      onSaved();
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  };
  return (
    <Card title="Billing rules & manual override" actions={active ? <Badge kind="warn">override on</Badge> : <Badge kind="ok">rules apply</Badge>}>
      {c.status === 'suspended' && <div className="alert warn mb"><div>Suspended: <b>{REASONS[c.suspended_reason] || 'reason not recorded'}</b></div></div>}
      {Number(c.cap_exceeded) === 1 && <div className="alert info mb"><div>Monthly data allowance used up — speed limited until next month.</div></div>}
      <p className="faint" style={{ marginTop: 0 }}>Service is stopped automatically according to Settings → Billing (overdue invoices, amount and grace days). An override keeps this customer connected anyway.</p>
      {active && <div className="faint mb">Active{c.override_until ? ` until ${date(c.override_until)}` : ' indefinitely'} · reason: {c.override_reason}</div>}
      <div className="grid g2">
        <Input label="Keep connected until (optional)" type="date" value={f.until} onChange={(e) => setF({ ...f, until: e.target.value })} />
        <Input label="Reason (required)" value={f.reason} maxLength={250} onChange={(e) => setF({ ...f, reason: e.target.value })} placeholder="e.g. payment promised on 15th" />
      </div>
      {c.status === 'suspended' && <label className="check mt"><input type="checkbox" checked={f.reactivate} onChange={(e) => setF({ ...f, reactivate: e.target.checked })} /> Reactivate service now</label>}
      <div className="row mt"><Button variant="primary" loading={busy} onClick={() => save('never_suspend')}>{active ? 'Update override' : 'Pause auto-suspension'}</Button>{active && <Button onClick={() => save('none')} disabled={busy}>Remove override</Button>}</div>
      {Number(c.speed_violations) > 0 && <div className="faint mt">Speed-limit violations auto-corrected: {c.speed_violations}</div>}
    </Card>
  );
}

function IpCard({ c, onSaved }) {
  const { toast, can, moduleOn } = useApp();
  const [kind, setKind] = useState(c.ip_type || 'shared');
  const [address, setAddress] = useState('');
  const [busy, setBusy] = useState(false);
  if (!moduleOn('ipam')) return null;
  const meta = KIND_META[c.ip_type];
  const assign = async () => {
    setBusy(true);
    try { const r = await api.post('/network/ipam/assign', { customer_id: c.id, kind: address ? undefined : kind, address: address || undefined }); toast(`Assigned ${r.address}${r.monthlyCents ? ` (+${money(r.monthlyCents)}/mo)` : ''}${r.sync.ok ? '' : ` — router: ${r.sync.error}`}`, r.sync.ok ? 'ok' : 'info'); setAddress(''); onSaved(); }
    catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  };
  const release = async () => { if (!window.confirm('Release this IP from the customer?')) return; await api.post('/network/ipam/release', { customer_id: c.id }); toast('IP released'); onSaved(); };
  const provision = async () => { const r = await api.post(`/network/customers/${c.id}/provision`); toast(r.sync.ok ? 'Speed and IP pushed to router' : `Router: ${r.sync.error}`, r.sync.ok ? 'ok' : 'bad'); };
  return (
    <Card title="IP address" actions={meta && <Badge kind="brand">{meta.label}</Badge>}>
      <div className="row between"><span className="faint">Current</span><b className="mono">{c.ip_address || 'none'}</b></div>
      {Number(c.ip_addon_cents) > 0 && <div className="row between"><span className="faint">IP charge</span><b>{money(c.ip_addon_cents)}/mo</b></div>}
      {(can('network.manage') || can('customers.edit')) && <>
        <div className="divider" />
        <div className="grid g2">
          <Select label="Type" value={kind} onChange={(e) => setKind(e.target.value)} options={Object.entries(KIND_META).map(([v, m]) => ({ value: v, label: m.label }))} />
          <Input label="Specific IP (optional)" value={address} onChange={(e) => setAddress(e.target.value)} placeholder="next free" />
        </div>
        <div className="faint" style={{ margin: '6px 0' }}>{KIND_META[kind]?.hint}</div>
        <div className="row wrap"><Button variant="primary" loading={busy} onClick={assign}>{c.ip_address ? 'Change IP' : 'Assign IP'}</Button>{c.ip_address && <Button onClick={release}>Release</Button>}{can('network.manage') && <Button onClick={provision}>Push speed + IP to router</Button>}</div>
      </>}
    </Card>
  );
}


// Access methods and what each IP type needs from them.
const ACCESS = {
  pppoe: { label: 'PPPoE', hint: 'Customer router dials in with a username/password; the router hands out the assigned IP.' },
  static: { label: 'Static IP', hint: 'IP, mask, gateway and DNS are typed into the customer router. Needs an assigned IP.' },
  dhcp: { label: 'DHCP (IPoE)', hint: 'Address is leased automatically, usually bound to the MAC address.' },
  hotspot: { label: 'Hotspot', hint: 'Captive-portal login on a shared Wi-Fi network.' },
};

/** Connection details shaped by the customer's IP type (shared CGNAT vs real/dedicated public) and access method. */
function ConnectionCard({ c, conn, onSaved, pppoe, reveal }) {
  const { toast, can } = useApp();
  const [edit, setEdit] = useState(null);
  const routers = useLoad(() => (edit && can('network.view') ? api('/network/routers') : Promise.resolve(null)), [!!edit]);
  const type = conn?.ipType;
  const meta = KIND_META[type];
  const pool = conn?.pool;
  const access = c.connection_type || 'pppoe';
  // Things that don't fit together are shown as warnings instead of being silently wrong.
  const warnings = [];
  if (access === 'static' && !c.ip_address) warnings.push('Static access needs an IP address — assign one in the IP address card.');
  if (access === 'pppoe' && !c.pppoe_username) warnings.push('PPPoE access needs a PPPoE username.');
  if (access === 'dhcp' && !c.mac_address) warnings.push('DHCP access is normally bound to the router MAC address — add it.');
  if (type === 'dedicated' && access === 'dhcp') warnings.push('A dedicated IP should be fixed: use Static or PPPoE so the address never changes.');
  if (!c.router_id) warnings.push('No router (NAS) selected — speed limits and suspensions cannot be applied.');
  if (c.ip_address && !conn?.managedByIpam) warnings.push(`${c.ip_address} was entered by hand and isn't tracked in IP management, so its type, gateway and DNS are unknown. Run Reconcile in IP management (if it belongs to a pool) or pick a type and press Change IP.`);
  const Row = ({ k, v, mono }) => <div className="row between" style={{ gap: 12 }}><span className="faint">{k}</span>{typeof v === 'string' || typeof v === 'number' ? <span className={mono ? 'mono' : undefined} style={{ textAlign: 'right', wordBreak: 'break-all' }}>{v}</span> : v}</div>;
  const save = async (e) => {
    e.preventDefault();
    try {
      await api.put(`/customers/${c.id}`, { connection_type: edit.connection_type, pppoe_username: edit.pppoe_username || null, ...(edit.pppoe_password ? { pppoe_password: edit.pppoe_password } : {}), mac_address: edit.mac_address || null, router_id: edit.router_id ? Number(edit.router_id) : null });
      toast('Connection saved and pushed to the router'); setEdit(null); onSaved();
    } catch (err) { toast(err.message, 'bad'); }
  };
  return (
    <Card title="Connection" actions={<div className="row">{meta && <Badge kind="brand">{meta.label}</Badge>}<Badge kind="info">{ACCESS[access]?.label || access}</Badge>{can('customers.edit') && <Button size="sm" variant="ghost" onClick={() => setEdit({ connection_type: access, pppoe_username: c.pppoe_username || '', pppoe_password: '', mac_address: c.mac_address || '', router_id: c.router_id || '' })}>Edit</Button>}</div>}>
      <div className="col" style={{ gap: 8 }}>
        <Row k="Access method" v={ACCESS[access]?.label || access} />
        <Row k="IP type" v={meta ? meta.label : 'Not assigned'} />
        {type === 'shared' ? <>
          <Row k="Private IP (CGNAT)" v={c.ip_address || '—'} mono />
          <Row k="Shows on the internet as" v={pool?.natAddress || 'pool NAT address not set'} mono />
        </> : <>
          <Row k={type ? 'Public IP' : 'IP'} v={c.ip_address || '—'} mono />
          {pool?.ptr && <Row k="Reverse DNS (PTR)" v={pool.ptr} mono />}
        </>}
        {pool && <>
          {(access === 'static' || type !== 'shared') && pool.netmask && <Row k="Subnet mask" v={`${pool.netmask} (/${pool.cidr.split('/')[1]})`} mono />}
          <Row k="Gateway" v={pool.gateway || '—'} mono />
          <Row k="DNS" v={pool.dns || 'router default'} mono />
          <Row k="IP pool" v={`${pool.name} · ${pool.cidr}`} />
        </>}
        {(access === 'pppoe' || c.pppoe_username) && <>
          <Row k="PPPoE user" v={c.pppoe_username || '—'} mono />
          {c.has_pppoe_password && can('customers.edit') && <Row k="PPPoE password" v={pppoe ? <span className="mono">{pppoe}</span> : <Button size="sm" variant="ghost" icon={Eye} onClick={reveal}>Reveal</Button>} />}
        </>}
        <Row k="MAC" v={c.mac_address || '—'} mono />
        <Row k="Router (NAS)" v={conn?.router ? <span>{conn.router.name} <Badge status={conn.router.status} /></span> : '—'} />
        <Row k="Address" v={[c.address, c.area].filter(Boolean).join(', ') || '—'} />
        <Row k="Customer since" v={date(c.created_at)} />
        {type === 'shared' && <div className="faint" style={{ fontSize: 13 }}>Shared IP: incoming connections (CCTV, servers, port forwarding) won't reach this customer. Switch to a Real or Dedicated IP for that.</div>}
        {warnings.map((w) => <div key={w} className="alert warn" style={{ margin: 0 }}><div>{w}</div></div>)}
      </div>
      <Modal open={!!edit} onClose={() => setEdit(null)} title="Edit connection">
        {edit && <form className="col" onSubmit={save}>
          <Select label="Access method" value={edit.connection_type} onChange={(e) => setEdit({ ...edit, connection_type: e.target.value })} options={Object.entries(ACCESS).map(([v, m]) => ({ value: v, label: m.label }))} hint={ACCESS[edit.connection_type]?.hint} />
          {(edit.connection_type === 'pppoe' || edit.pppoe_username) && <div className="grid g2">
            <Input label="PPPoE username" value={edit.pppoe_username} onChange={(e) => setEdit({ ...edit, pppoe_username: e.target.value })} pattern="[A-Za-z0-9_.@\-]*" title="Letters, numbers and _ . @ -" maxLength={64} required={edit.connection_type === 'pppoe'} />
            <Input label="PPPoE password" type="password" autoComplete="new-password" value={edit.pppoe_password} onChange={(e) => setEdit({ ...edit, pppoe_password: e.target.value })} placeholder={c.has_pppoe_password ? 'unchanged' : ''} maxLength={64} />
          </div>}
          <Input label="MAC address" value={edit.mac_address} onChange={(e) => setEdit({ ...edit, mac_address: e.target.value })} placeholder="AA:BB:CC:DD:EE:FF" pattern="^$|^([0-9A-Fa-f]{2}[:\-]){5}[0-9A-Fa-f]{2}$" title="Format AA:BB:CC:DD:EE:FF" />
          <Select label="Router (NAS)" value={String(edit.router_id || '')} onChange={(e) => setEdit({ ...edit, router_id: e.target.value })} options={[{ value: '', label: '— none —' }, ...((routers.data?.routers) || []).map((r) => ({ value: String(r.id), label: `${r.name}${r.role ? ` (${r.role})` : ''}` }))]} />
          {edit.connection_type === 'static' && !c.ip_address && <div className="alert warn" style={{ margin: 0 }}><div>Assign an IP in the IP address card first — static customers need a fixed address.</div></div>}
          <Button variant="primary" type="submit">Save connection</Button>
        </form>}
      </Modal>
    </Card>
  );
}

export default function CustomerDetail() {
  const { id } = useParams();
  const nav = useNavigate();
  const { toast, can, liveBw, moduleOn } = useApp();
  const { data, reload } = useLoad(() => api(`/customers/${id}`), [id]);
  const usage = useLoad(() => api(`/customers/${id}/usage?hours=24`), [id]);
  const [tab, setTab] = useState('overview');
  const [edit, setEdit] = useState(false);
  const [confirm, setConfirm] = useState(null);
  const [paying, setPaying] = useState(null);
  const [invoicing, setInvoicing] = useState(false);
  const [parental, setParental] = useState(null);
  const [pppoe, setPppoe] = useState(null);
  useEffect(() => {
    if (data?.customer) {
      const p = data.customer.parental || { enabled: false, safeSearch: false, blockedCategories: [], blockedDomains: [], schedules: [] };
      setParental({ ...p, blockedCategories: p.blockedCategories || [], blockedDomains: p.blockedDomains || [], schedules: (p.schedules || []).map((s) => ({ ...s, from: s.fromLabel || s.from, to: s.toLabel || s.to })) });
    }
  }, [data]);
  if (!data) return <Spinner />;
  const c = data.customer;
  const live = c.live;
  const due = data.invoices.filter((i) => ['unpaid', 'overdue', 'partial'].includes(i.status)).reduce((s, i) => s + i.total_cents - i.paid_cents, 0);

  const setStatus = async (status) => { const r = await api.post(`/customers/${id}/status`, { status }); toast(`Customer ${status}${r.sync?.ok === false ? ` (router: ${r.sync.error})` : ''}`); reload(); };
  const reconnect = async () => { try { const r = await api.post(`/customers/${id}/reconnect`); toast(`Session reset (${r.disconnected} disconnected)`); } catch (e) { toast(e.message, 'bad'); } };
  const save = async (payload) => { try { const r = await api.put(`/customers/${id}`, payload); toast(r.sync?.ok === false ? `Saved; router sync failed: ${r.sync.error}` : 'Customer updated'); setEdit(false); reload(); } catch (e) { toast(e.message, 'bad'); } };
  const del = async () => { await api.del(`/customers/${id}?force=true`); toast('Customer deleted'); nav('/admin/customers'); };
  const saveParental = async () => {
    const p = {
      enabled: !!parental.enabled, safeSearch: !!parental.safeSearch, blockedCategories: parental.blockedCategories, blockedDomains: parental.blockedDomains,
      schedules: parental.schedules.filter((s) => s.days.length).map((s) => ({ label: s.label, from: s.from, to: s.to, days: s.days })),
    };
    try { const r = await api.put(`/network/customers/${id}/parental`, { parental: p }); toast(r.sync?.ok === false ? `Saved; router: ${r.sync.error}` : 'Parental controls applied'); } catch (e) { toast(e.message, 'bad'); }
  };
  const reveal = async () => { try { setPppoe((await api(`/customers/${id}/pppoe-password`)).password || '(none)'); } catch (e) { toast(e.message, 'bad'); } };

  return (
    <Page title={c.name} subtitle={`${c.code} · ${c.email} · ${c.phone || ''}`}
      actions={<>
        <Button icon={ArrowLeft} onClick={() => nav('/admin/customers')}>Back</Button>
        {can('customers.edit') && <Button onClick={() => setEdit(true)}>Edit</Button>}
        {can('customers.edit') && (c.status === 'active' ? <Button icon={Pause} onClick={() => setConfirm('suspend')}>Suspend</Button> : <Button variant="primary" icon={Play} onClick={() => setStatus('active')}>Activate</Button>)}
        {(can('network.manage') || can('network.diagnostics')) && c.pppoe_username && <Button icon={RefreshCw} onClick={reconnect}>Reconnect</Button>}
        {moduleOn('network_map') && can('customers.edit') && <Button icon={MapPin} onClick={() => nav(`/admin/map?place=${c.id}`)}>Location</Button>}
        {moduleOn('jobs') && can('jobs.manage') && <Button icon={ClipboardList} onClick={() => nav(`/admin/jobs?customer=${c.id}&new=1`)}>New job</Button>}
        {can('customers.delete') && <Button variant="danger" icon={Trash2} onClick={() => setConfirm('delete')} aria-label="Delete" />}
      </>}>
      <div className="grid g4 mb">
        <Stat label="Status" value={0} format={() => label(c.status)} sub={<Badge status={c.status} />} />
        <Stat label="Plan" value={0} format={() => c.plan_name || '—'} sub={`${speed(c.custom_download_kbps || c.download_kbps)} ${c.custom_download_kbps ? '(custom)' : ''}`} />
        <Stat label="Outstanding" value={due} format={money} sub={`Next due ${date(c.next_due_date)}`} />
        <Stat label="Live" value={(live?.rx_bps || 0)} format={bps} sub={live?.online ? 'online' : 'offline'} />
      </div>
      <div className="mb"><Tabs tabs={['overview', 'billing', 'support', ...(can('network.manage') ? ['parental'] : [])]} value={tab} onChange={setTab} /></div>

      {tab === 'overview' && (
        <div className="grid g2">
          <Card title="Usage — last 24h" className="span-all">
            {usage.data?.samples?.length ? <AreaSeries data={usage.data.samples} x="ts" fmtX={(v) => new Date(v).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} fmtY={bps} series={[{ key: 'rx_bps', label: 'Download' }, { key: 'tx_bps', label: 'Upload' }]} /> : <div className="faint">No usage samples yet</div>}
          </Card>
          {(can('network.manage') || can('customers.edit')) && <Bandwidth c={c} onSaved={reload} />}
          <IpCard c={c} onSaved={reload} />
          <RulesCard c={c} onSaved={reload} />
          <CustomerEquipment customerId={c.id} />
          <KycPanel customerId={c.id} />
          <ConnectionCard c={c} conn={data.connection} onSaved={reload} pppoe={pppoe} reveal={reveal} />
          {data.devices.length > 0 && <Card title="Devices">{data.devices.map((d) => <div key={d.id} className="list-item"><Wrench size={16} className="muted" /><div className="grow">{d.name}<div className="faint">{d.model} · {d.ip_address}</div></div><Badge status={d.status} /></div>)}</Card>}
        </div>
      )}

      {tab === 'billing' && (
        <div className="col">
          <div className="row">{can('billing.manage') && <Button icon={Receipt} onClick={() => setInvoicing(true)}>New invoice</Button>}<Button icon={FileDown} onClick={() => downloadFile(`/pdf/reports/customer?customer_id=${c.id}&from=${new Date(Date.now() - 365 * 86400000).toISOString().slice(0, 10)}`, { fallbackName: 'statement.pdf' }).catch((e) => toast(e.message, 'bad'))}>Customer report (PDF)</Button></div>
          <Card title="Invoices" className="flush" style={{ padding: 0 }}>
            <DataTable rows={data.invoices} columns={[
              { key: 'number', title: 'Invoice', render: (r) => <b>{r.number}</b> },
              { key: 'issued_at', title: 'Issued', render: (r) => date(r.issued_at) },
              { key: 'due_date', title: 'Due', render: (r) => date(r.due_date) },
              { key: 'total_cents', title: 'Total', align: 'right', render: (r) => money(r.total_cents) },
              { key: 'paid_cents', title: 'Paid', align: 'right', render: (r) => money(r.paid_cents) },
              { key: 'status', title: 'Status', render: (r) => <Badge status={r.status} /> },
              { key: 'x', title: '', align: 'right', render: (r) => <div className="row end"><BillActions invoice={r} compact />{can('billing.collect') && ['unpaid', 'overdue', 'partial'].includes(r.status) && <Button size="sm" variant="primary" onClick={() => setPaying(r)}>Collect</Button>}</div> },
            ]} />
          </Card>
          <Card title="Payments" className="flush">
            <DataTable rows={data.payments} columns={[
              { key: 'created_at', title: 'Date', render: (r) => dateTime(r.completed_at || r.created_at) },
              { key: 'method', title: 'Method', render: (r) => label(r.method) },
              { key: 'amount_cents', title: 'Amount', align: 'right', render: (r) => money(r.amount_cents) },
              { key: 'status', title: 'Status', render: (r) => <Badge status={r.status} /> },
              { key: 'receipt', title: '', align: 'right', render: (r) => <ReceiptButton payment={r} /> },
            ]} />
          </Card>
        </div>
      )}

      {tab === 'support' && (
        <Card className="flush"><DataTable rows={data.tickets} onRowClick={(t) => nav(`/admin/tickets/${t.id}`)} columns={[
          { key: 'number', title: '#' }, { key: 'subject', title: 'Subject' }, { key: 'priority', title: 'Priority', render: (r) => <Badge status={r.priority} /> }, { key: 'status', title: 'Status', render: (r) => <Badge status={r.status} /> }, { key: 'created_at', title: 'Opened', render: (r) => date(r.created_at) },
        ]} /></Card>
      )}

      {tab === 'parental' && parental && (
        <Card title="Parental controls" actions={<Button variant="primary" icon={ShieldCheck} onClick={saveParental}>Save & apply</Button>}>
          <ParentalEditor value={parental} onChange={setParental} categories={['social', 'gaming', 'streaming', 'gambling', 'adult']} />
        </Card>
      )}

      <Modal wide open={edit} onClose={() => setEdit(false)} title="Edit customer"><CustomerForm initial={c} onSubmit={save} /></Modal>
      <Confirm open={confirm === 'suspend'} onClose={() => setConfirm(null)} onConfirm={() => setStatus('suspended')} title="Suspend service?" danger confirmText="Suspend">The customer's internet access will be cut off on the router and they will be notified.</Confirm>
      <Confirm open={confirm === 'delete'} onClose={() => setConfirm(null)} onConfirm={del} title="Delete customer permanently?" danger confirmText="Delete">This removes the customer account, invoices and history. This cannot be undone. Consider terminating instead.</Confirm>
      {paying && <RecordPayment invoice={paying} onClose={() => setPaying(null)} onDone={() => { setPaying(null); reload(); }} />}
      {invoicing && <NewInvoice customerId={c.id} onClose={() => setInvoicing(false)} onDone={() => { setInvoicing(false); reload(); }} />}
    </Page>
  );
}
