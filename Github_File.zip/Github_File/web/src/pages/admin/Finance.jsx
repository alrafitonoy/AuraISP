import { useState } from 'react';
import { Plus, Pencil, Trash2, Download, Upload, Paperclip, Wallet, Receipt, TrendingUp, UserCheck, Search, Tags, FileX } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { downloadFile } from '../../lib/download.js';
import { date, label, money, moneyShort, toCents } from '../../lib/format.js';
import { Badge, Button, Card, Confirm, DataTable, Empty, Input, Modal, Page, Pager, Select, Spinner, Stat, Tabs, Textarea, useLoad } from '../../components/ui.jsx';
import { Bars, Donut } from '../../components/charts.jsx';

const METHODS = ['cash', 'bank', 'bkash', 'nagad', 'card', 'other'];
const RECEIPT_ACCEPT = 'application/pdf,image/png,image/jpeg,image/webp';
const RECEIPT_MAX = 5 * 1024 * 1024;
const todayIso = () => new Date().toISOString().slice(0, 10);
const yearAgoIso = () => { const d = new Date(); d.setUTCDate(1); d.setUTCMonth(d.getUTCMonth() - 11); return d.toISOString().slice(0, 10); };
const monthLabel = (m) => (/^\d{4}-\d{2}$/.test(m) ? new Date(`${m}-01T00:00:00Z`).toLocaleDateString('en-GB', { month: 'short', year: '2-digit', timeZone: 'UTC' }) : m);
const pct = (v) => (v == null ? '—' : `${v}%`);
const qs = (o) => new URLSearchParams(Object.entries(o).filter(([, v]) => v !== '' && v != null)).toString();

/** Shared lookups: categories and (when the zones module is on) zones. */
function useLookups() {
  const { moduleOn } = useApp();
  const cats = useLoad(() => api('/finance/categories'));
  const zones = useLoad(() => (moduleOn('zones') ? api('/zones?lite=1').catch(() => ({ zones: [] })) : Promise.resolve({ zones: [] })), []);
  return { cats, categories: cats.data?.categories || [], zones: zones.data?.zones || [] };
}

// ------------------------------------------------------------------ overview: KPIs, chart, P&L table
function Overview({ range, kpis, pnl, group, setGroup }) {
  if (!pnl) return <Spinner />;
  const chart = pnl.periods.map((p) => ({ label: p.label, income: p.income_cents, expense: p.expense_cents, profit: p.profit_cents }));
  const empty = !pnl.totals.income_cents && !pnl.totals.expense_cents;
  return (
    <>
      <div className="grid g3 mb">
        <Card title={`Income vs expenses${group === 'zone' ? ' by zone' : ''}`} className="span2">
          {empty ? <Empty icon={TrendingUp} title="No income or expenses in this period">Record expenses or collect payments to see the trend.</Empty>
            : <Bars data={chart} x="label" fmtX={group === 'month' ? monthLabel : (v) => v} fmtY={moneyShort} series={[{ key: 'income', label: 'Income', color: '#10b981' }, { key: 'expense', label: 'Expenses', color: '#ef4444' }]} />}
        </Card>
        <Card title="Expenses by category">
          {pnl.by_category.length ? <Donut data={pnl.by_category.map((c) => ({ name: c.name, value: c.amount_cents }))} fmt={money} />
            : <Empty icon={Tags} title="No expenses in this period" />}
        </Card>
      </div>
      <Card title={`Profit & loss · ${date(range.from)} – ${date(range.to)}`} actions={
        <Tabs tabs={[{ value: 'month', label: 'By month' }, { value: 'zone', label: 'By zone' }]} value={group} onChange={setGroup} />
      }>
        <div className="table-wrap">
          <table className="t">
            <thead><tr><th>{group === 'zone' ? 'Zone' : 'Month'}</th><th style={{ textAlign: 'right' }}>Income</th><th style={{ textAlign: 'right' }}>Expenses</th><th style={{ textAlign: 'right' }}>Profit</th><th style={{ textAlign: 'right' }}>Margin</th></tr></thead>
            <tbody>
              {pnl.periods.map((p) => (
                <tr key={p.key}>
                  <td>{group === 'month' ? monthLabel(p.label) : p.label}</td>
                  <td style={{ textAlign: 'right' }}>{money(p.income_cents)}</td>
                  <td style={{ textAlign: 'right' }}>{money(p.expense_cents)}</td>
                  <td style={{ textAlign: 'right', color: p.profit_cents < 0 ? 'var(--bad)' : undefined, fontWeight: 600 }}>{money(p.profit_cents)}</td>
                  <td style={{ textAlign: 'right' }}>{pct(p.margin)}</td>
                </tr>
              ))}
              <tr style={{ fontWeight: 700 }}>
                <td>Total</td>
                <td style={{ textAlign: 'right' }}>{money(pnl.totals.income_cents)}</td>
                <td style={{ textAlign: 'right' }}>{money(pnl.totals.expense_cents)}</td>
                <td style={{ textAlign: 'right', color: pnl.totals.profit_cents < 0 ? 'var(--bad)' : 'var(--ok)' }}>{money(pnl.totals.profit_cents)}</td>
                <td style={{ textAlign: 'right' }}>{pct(pnl.totals.margin)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </Card>
      {pnl.by_category.length > 0 && (
        <Card className="mt" title="Expense breakdown">
          <DataTable rows={pnl.by_category.map((c) => ({ ...c, id: c.category_id ?? 'none' }))} columns={[
            { key: 'name', title: 'Category', render: (c) => <b>{c.name}</b> },
            { key: 'count', title: 'Entries', align: 'right' },
            { key: 'amount_cents', title: 'Amount', align: 'right', render: (c) => money(c.amount_cents) },
            { key: 'share', title: 'Share', align: 'right', render: (c) => `${c.share}%` },
          ]} />
        </Card>
      )}
      {kpis && <p className="faint mt">Income counts completed payments only; prepaid balance applied to invoices is not counted twice. ARPU uses this month’s income ÷ {kpis.active_customers} active customer(s).</p>}
    </>
  );
}

// ------------------------------------------------------------------ expense editor
function ExpenseModal({ expense, categories, zones, onClose, onSaved }) {
  const { toast } = useApp();
  const [f, setF] = useState(() => ({
    amount: expense.id ? (expense.amount_cents / 100).toFixed(2) : '', spent_on: expense.spent_on || todayIso(),
    category_id: expense.category_id ?? '', zone_id: expense.zone_id ?? '', vendor: expense.vendor || '', method: expense.method || 'cash',
    reference: expense.reference || '', notes: expense.notes || '',
  }));
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [hasReceipt, setHasReceipt] = useState(!!expense.has_receipt);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const pick = (e) => {
    const x = e.target.files?.[0] || null; e.target.value = '';
    if (x && x.size > RECEIPT_MAX) { toast('Receipts must be 5 MB or smaller', 'bad'); return; }
    if (x && !RECEIPT_ACCEPT.split(',').includes(x.type)) { toast('Use a PDF, PNG, JPG or WEBP file', 'bad'); return; }
    setFile(x);
  };

  const save = async (e) => {
    e.preventDefault();
    const amount_cents = toCents(f.amount);
    if (amount_cents <= 0) { toast('Enter an amount greater than zero', 'bad'); return; }
    const body = {
      amount_cents, spent_on: f.spent_on, category_id: f.category_id ? Number(f.category_id) : null, zone_id: f.zone_id ? Number(f.zone_id) : null,
      vendor: f.vendor || null, method: f.method || null, reference: f.reference || null, notes: f.notes || null,
    };
    setBusy(true);
    try {
      const id = expense.id || (await api.post('/finance/expenses', body)).id;
      if (expense.id) await api.put(`/finance/expenses/${id}`, body);
      if (file) {
        const form = new FormData(); form.append('file', file);
        try { await api(`/finance/expenses/${id}/receipt`, { method: 'POST', form }); }
        catch (err) { toast(`Expense saved, but the receipt was not uploaded: ${err.message}`, 'bad'); onSaved(); onClose(); return; }
      }
      toast(expense.id ? 'Expense updated' : 'Expense recorded');
      onSaved(); onClose();
    } catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };

  const removeReceipt = async () => {
    try { await api.del(`/finance/expenses/${expense.id}/receipt`); setHasReceipt(false); toast('Receipt removed'); onSaved(); }
    catch (err) { toast(err.message, 'bad'); }
  };

  return (
    <Modal open onClose={onClose} title={expense.id ? 'Edit expense' : 'Record expense'} wide>
      <form className="col" onSubmit={save}>
        <div className="grid g2">
          <Input label="Amount" type="number" inputMode="decimal" min="0.01" step="0.01" required value={f.amount} onChange={set('amount')} autoFocus />
          <Input label="Date" type="date" required max="9999-12-31" value={f.spent_on} onChange={set('spent_on')} />
          <Select label="Category" value={f.category_id} onChange={set('category_id')} options={[{ value: '', label: '— Uncategorised —' }, ...categories.map((c) => ({ value: c.id, label: c.name }))]} />
          <Select label="Zone" value={f.zone_id} onChange={set('zone_id')} options={[{ value: '', label: '— Company-wide —' }, ...zones.map((z) => ({ value: z.id, label: z.name }))]} />
          <Input label="Vendor / paid to" maxLength={190} value={f.vendor} onChange={set('vendor')} placeholder="e.g. Summit Communications" />
          <Select label="Payment method" value={f.method} onChange={set('method')} options={METHODS.map((m) => ({ value: m, label: m === 'bkash' ? 'bKash' : m === 'nagad' ? 'Nagad' : label(m).replace(/^./, (c) => c.toUpperCase()) }))} />
          <Input label="Reference" maxLength={64} value={f.reference} onChange={set('reference')} placeholder="Bill / transaction no." />
        </div>
        <Textarea label="Notes" maxLength={250} value={f.notes} onChange={set('notes')} />
        <div className="row wrap">
          <label className="btn sm"><Upload size={14} /> {file ? file.name : hasReceipt ? 'Replace receipt' : 'Attach receipt'}<input type="file" accept={RECEIPT_ACCEPT} hidden onChange={pick} aria-label="Receipt file" /></label>
          {file && <Button type="button" size="sm" variant="ghost" onClick={() => setFile(null)}>Clear</Button>}
          {hasReceipt && !file && <>
            <Button type="button" size="sm" icon={Download} onClick={() => downloadFile(`/finance/expenses/${expense.id}/receipt`, { fallbackName: `receipt-${expense.id}` }).catch((err) => toast(err.message, 'bad'))}>Download receipt</Button>
            <Button type="button" size="sm" variant="ghost" icon={FileX} onClick={removeReceipt}>Remove</Button>
          </>}
          <span className="faint">PDF or image, up to 5 MB. Stored privately.</span>
        </div>
        <div className="row end"><Button type="button" onClick={onClose}>Cancel</Button><Button variant="primary" type="submit" loading={busy}>{expense.id ? 'Save changes' : 'Record expense'}</Button></div>
      </form>
    </Modal>
  );
}

// ------------------------------------------------------------------ expenses list
function Expenses({ lookups, onChanged }) {
  const { toast, can } = useApp();
  const manage = can('finance.manage');
  const [flt, setFlt] = useState({ from: '', to: '', category_id: '', zone_id: '', method: '', q: '' });
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState('');
  const [edit, setEdit] = useState(null);
  const [del, setDel] = useState(null);
  const query = qs({ ...flt, page, pageSize: 25, sort });
  const list = useLoad(() => api(`/finance/expenses?${query}`), [query]);
  const setF = (k) => (e) => { setFlt({ ...flt, [k]: e.target.value }); setPage(1); };
  const refresh = () => { list.reload(); lookups.cats.reload(); onChanged?.(); };
  const { categories, zones } = lookups;

  return (
    <>
      <Card className="mb">
        <div className="grid g4" style={{ gap: 12 }}>
          <Input label="From" type="date" value={flt.from} onChange={setF('from')} />
          <Input label="To" type="date" value={flt.to} onChange={setF('to')} />
          <Select label="Category" value={flt.category_id} onChange={setF('category_id')} options={[{ value: '', label: 'All categories' }, { value: 'none', label: 'Uncategorised' }, ...categories.map((c) => ({ value: c.id, label: c.name }))]} />
          {zones.length > 0
            ? <Select label="Zone" value={flt.zone_id} onChange={setF('zone_id')} options={[{ value: '', label: 'All zones' }, { value: 'none', label: 'Company-wide' }, ...zones.map((z) => ({ value: z.id, label: z.name }))]} />
            : <Select label="Method" value={flt.method} onChange={setF('method')} options={[{ value: '', label: 'Any method' }, ...METHODS]} />}
        </div>
        <div className="row wrap mt">
          {zones.length > 0 && <div style={{ width: 180 }}><Select aria-label="Payment method" value={flt.method} onChange={setF('method')} options={[{ value: '', label: 'Any method' }, ...METHODS]} /></div>}
          <div style={{ position: 'relative', flex: '1 1 220px', maxWidth: 360 }}>
            <Search size={16} style={{ position: 'absolute', left: 12, top: 13, color: 'var(--text-3)' }} />
            <input className="input" style={{ paddingLeft: 36 }} placeholder="Vendor, reference, notes…" value={flt.q} onChange={setF('q')} aria-label="Search expenses" />
          </div>
          <div className="grow" />
          {list.data && <span className="muted">{list.data.totals.count} expense(s) · <b style={{ color: 'var(--text)' }}>{money(list.data.totals.amount_cents)}</b></span>}
          {manage && <Button variant="primary" icon={Plus} onClick={() => setEdit({})}>Record expense</Button>}
        </div>
      </Card>
      <Card className="flush">
        <DataTable loading={list.loading} rows={list.data?.rows} sort={sort} onSort={setSort} empty="No expenses match these filters" onRowClick={manage ? (r) => setEdit(r) : undefined} columns={[
          { key: 'spent_on', title: 'Date', sort: true, render: (r) => date(`${r.spent_on}T00:00:00Z`) },
          { key: 'category_name', title: 'Category', render: (r) => r.category_name ? <Badge kind="brand">{r.category_name}</Badge> : <span className="faint">Uncategorised</span> },
          { key: 'vendor', title: 'Vendor', sort: true, render: (r) => <div><b>{r.vendor || '—'}</b>{(r.reference || r.notes) && <div className="faint">{[r.reference, r.notes].filter(Boolean).join(' · ')}</div>}</div> },
          ...(zones.length ? [{ key: 'zone_name', title: 'Zone', render: (r) => r.zone_name || <span className="faint">—</span> }] : []),
          { key: 'method', title: 'Method', render: (r) => (r.method ? label(r.method) : '—') },
          { key: 'amount_cents', title: 'Amount', sort: true, align: 'right', render: (r) => <b>{money(r.amount_cents)}</b> },
          { key: 'actions', title: '', align: 'right', render: (r) => (
            <div className="row end" style={{ gap: 4 }} onClick={(e) => e.stopPropagation()}>
              {r.has_receipt && <Button size="sm" variant="ghost" icon={Paperclip} aria-label="Download receipt" title="Download receipt" onClick={() => downloadFile(`/finance/expenses/${r.id}/receipt`, { fallbackName: `receipt-${r.id}` }).catch((e) => toast(e.message, 'bad'))} />}
              {manage && <Button size="sm" variant="ghost" icon={Pencil} aria-label="Edit expense" onClick={() => setEdit(r)} />}
              {manage && <Button size="sm" variant="ghost" icon={Trash2} aria-label="Delete expense" onClick={() => setDel(r)} />}
            </div>
          ) },
        ]} />
        {list.data && <Pager page={list.data.page} pageSize={list.data.pageSize} total={list.data.total} onPage={setPage} />}
      </Card>
      {edit && <ExpenseModal expense={edit} categories={categories} zones={zones} onClose={() => setEdit(null)} onSaved={refresh} />}
      <Confirm open={!!del} danger title="Delete expense?" confirmText="Delete" onClose={() => setDel(null)} onConfirm={async () => {
        try { await api.del(`/finance/expenses/${del.id}`); toast('Expense deleted'); refresh(); } catch (e) { toast(e.message, 'bad'); }
      }}>
        {del && <>This permanently removes the {money(del.amount_cents)} expense{del.vendor ? ` to ${del.vendor}` : ''} on {date(`${del.spent_on}T00:00:00Z`)}{del.has_receipt ? ' and its receipt' : ''}.</>}
      </Confirm>
    </>
  );
}

// ------------------------------------------------------------------ categories
function Categories({ lookups, onChanged }) {
  const { toast, can } = useApp();
  const manage = can('finance.manage');
  const [edit, setEdit] = useState(null);
  const [del, setDel] = useState(null);
  const [busy, setBusy] = useState(false);
  const save = async (e) => {
    e.preventDefault(); setBusy(true);
    try {
      if (edit.id) await api.put(`/finance/categories/${edit.id}`, { name: edit.name });
      else await api.post('/finance/categories', { name: edit.name });
      toast(edit.id ? 'Category renamed' : 'Category added'); setEdit(null); lookups.cats.reload(); onChanged?.();
    } catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  return (
    <>
      {manage && <div className="row end mb"><Button variant="primary" icon={Plus} onClick={() => setEdit({ name: '' })}>Add category</Button></div>}
      <Card className="flush">
        <DataTable loading={lookups.cats.loading} rows={lookups.categories} empty="No categories" columns={[
          { key: 'name', title: 'Category', render: (c) => <b>{c.name}</b> },
          { key: 'expense_count', title: 'Expenses', align: 'right' },
          { key: 'total_cents', title: 'All-time total', align: 'right', render: (c) => money(c.total_cents) },
          ...(manage ? [{ key: 'actions', title: '', align: 'right', render: (c) => (
            <div className="row end" style={{ gap: 4 }}>
              <Button size="sm" variant="ghost" icon={Pencil} aria-label={`Rename ${c.name}`} onClick={() => setEdit({ id: c.id, name: c.name })} />
              <Button size="sm" variant="ghost" icon={Trash2} aria-label={`Delete ${c.name}`} onClick={() => setDel(c)} />
            </div>
          ) }] : []),
        ]} />
      </Card>
      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? 'Rename category' : 'New category'}>
        {edit && <form className="col" onSubmit={save}>
          <Input label="Name" required minLength={2} maxLength={80} autoFocus value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
          <div className="row end"><Button type="button" onClick={() => setEdit(null)}>Cancel</Button><Button variant="primary" type="submit" loading={busy}>Save</Button></div>
        </form>}
      </Modal>
      <Confirm open={!!del} danger title="Delete category?" confirmText="Delete" onClose={() => setDel(null)} onConfirm={async () => {
        try { const r = await api.del(`/finance/categories/${del.id}`); toast(r.uncategorised ? `Category deleted; ${r.uncategorised} expense(s) are now uncategorised` : 'Category deleted'); lookups.cats.reload(); }
        catch (e) { toast(e.message, 'bad'); }
      }}>
        {del && <>“{del.name}” will be removed. {del.expense_count ? `Its ${del.expense_count} expense(s) are kept and become uncategorised.` : 'It has no expenses.'}</>}
      </Confirm>
    </>
  );
}

// ------------------------------------------------------------------ page
export default function Finance() {
  const { toast } = useApp();
  const [tab, setTab] = useState('overview');
  const [range, setRange] = useState({ from: yearAgoIso(), to: todayIso() });
  const [group, setGroup] = useState('month');
  const lookups = useLookups();
  const validRange = range.from && range.to && range.from <= range.to;
  const pnl = useLoad(() => (validRange ? api(`/finance/pnl?${qs({ ...range, group })}`) : Promise.resolve(null)), [range.from, range.to, group]);
  const k = pnl.data?.kpis;
  const profitDelta = k && k.previous.profit_cents ? ((k.profit_cents - k.previous.profit_cents) / Math.abs(k.previous.profit_cents)) * 100 : undefined;
  const incomeDelta = k && k.previous.income_cents ? ((k.income_cents - k.previous.income_cents) / k.previous.income_cents) * 100 : undefined;
  const expenseDelta = k && k.previous.expense_cents ? ((k.expense_cents - k.previous.expense_cents) / k.previous.expense_cents) * 100 : undefined;

  const exportCsv = () => downloadFile(`/finance/pnl.csv?${qs({ ...range, group })}`, { fallbackName: 'profit-loss.csv' })
    .then(() => toast('P&L exported')).catch((e) => toast(e.message, 'bad'));

  return (
    <Page title="Expenses & profit" subtitle="Track spending, see where money goes and what the business actually earns" actions={<>
      <Input aria-label="From date" type="date" value={range.from} max={range.to} onChange={(e) => setRange({ ...range, from: e.target.value })} />
      <Input aria-label="To date" type="date" value={range.to} min={range.from} onChange={(e) => setRange({ ...range, to: e.target.value })} />
      <Button icon={Download} onClick={exportCsv} disabled={!validRange}>Export P&amp;L</Button>
    </>}>
      {!validRange && <div className="alert warn mb">Choose a start date on or before the end date.</div>}
      {pnl.error && <div className="alert bad mb">{pnl.error.message}</div>}
      <div className="grid g4 mb">
        <Stat icon={Wallet} label="Income this month" value={k?.income_cents || 0} format={moneyShort} delta={incomeDelta} sub="vs last month" />
        <Stat icon={Receipt} label="Expenses this month" value={k?.expense_cents || 0} format={moneyShort} delta={expenseDelta} sub="vs last month" />
        <Stat icon={TrendingUp} label="Profit this month" value={k?.profit_cents || 0} format={moneyShort} delta={profitDelta} sub={k?.margin != null ? `${k.margin}% margin` : 'vs last month'} />
        <Stat icon={UserCheck} label="ARPU" value={k?.arpu_cents || 0} format={money} sub={k ? `${k.active_customers} active` : ''} />
      </div>
      <div className="row mb" style={{ overflowX: 'auto' }}>
        <Tabs tabs={[{ value: 'overview', label: 'Profit & loss' }, { value: 'expenses', label: 'Expenses' }, { value: 'categories', label: 'Categories' }]} value={tab} onChange={setTab} />
      </div>
      {tab === 'overview' && <Overview range={range} kpis={k} pnl={pnl.data} group={group} setGroup={setGroup} />}
      {tab === 'expenses' && <Expenses lookups={lookups} onChanged={pnl.reload} />}
      {tab === 'categories' && <Categories lookups={lookups} onChanged={pnl.reload} />}
    </Page>
  );
}
