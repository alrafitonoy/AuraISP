import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Plus, RefreshCw, Plug, Trash2, Pencil, Play, MonitorSmartphone, X, Router as RouterIcon, ShieldBan, Activity, Radar } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { ago, bps, bytes, dateTime, label } from '../../lib/format.js';
import { Badge, Button, Card, DataTable, Empty, Input, Modal, Page, Select, Spinner, Stat, Tabs, Toggle, useLoad } from '../../components/ui.jsx';
import { AreaSeries, Bars, Donut } from '../../components/charts.jsx';
import { Ipam, Capacity, DiscoverModal, PinCertificate } from './NetworkCore.jsx';

// ------------------------------------------------------------------ live
function Live() {
  const { liveBw } = useApp();
  const nav = useNavigate();
  const { data, reload } = useLoad(() => api('/network/live'));
  const [polling, setPolling] = useState(false);
  if (!data) return <Spinner />;
  const t = liveBw?.rx_bps !== undefined && liveBw?.online !== undefined ? liveBw : data.totals;
  const poll = async () => { setPolling(true); try { await api.post('/network/poll'); await reload(); } finally { setPolling(false); } };
  return (
    <Page title="Live bandwidth" subtitle={`Updated ${ago(data.at)} · refreshes every minute`} actions={<Button icon={RefreshCw} loading={polling} onClick={poll}>Poll now</Button>}>
      <div className="grid g3 mb">
        <Stat icon={Activity} label="Total download" value={t.rx_bps} format={bps} />
        <Stat icon={Activity} label="Total upload" value={t.tx_bps} format={bps} />
        <Stat icon={RouterIcon} label="Online sessions" value={t.online} />
      </div>
      <Card className="flush">
        <DataTable rows={data.customers} onRowClick={(r) => nav(`/admin/customers/${r.id}`)} columns={[
          { key: 'name', title: 'Customer', render: (r) => <div><b>{r.name}</b><div className="faint">{r.code}</div></div> },
          { key: 'plan_name', title: 'Plan' },
          { key: 'online', title: 'State', render: (r) => r.online ? <span className="row" style={{ gap: 6 }}><span className="pulse-dot" />online</span> : <Badge status="offline" /> },
          { key: 'rx_bps', title: 'Download', align: 'right', render: (r) => <span className="mono">{bps(r.rx_bps)}</span> },
          { key: 'tx_bps', title: 'Upload', align: 'right', render: (r) => <span className="mono">{bps(r.tx_bps)}</span> },
          { key: 'bar', title: '', width: 160, render: (r) => <div className="progress"><motion.i initial={{ width: 0 }} animate={{ width: `${Math.min(100, (r.rx_bps / Math.max(1, data.customers[0]?.rx_bps)) * 100)}%` }} /></div> },
        ]} />
      </Card>
    </Page>
  );
}

// ------------------------------------------------------------------ routers
function RouterForm({ initial, onSubmit }) {
  const [f, setF] = useState({ name: '', driver: 'mikrotik', role: 'nas', host: '', port: 443, username: 'aura-api', password: '', use_tls: true, verify_tls: true, location: '', ...initial, password: '' });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return (
    <form className="col" onSubmit={async (e) => { e.preventDefault(); setBusy(true); try { await onSubmit({ name: f.name, driver: f.driver, role: f.role, host: f.host || null, port: f.port ? Number(f.port) : null, username: f.username || null, ...(f.password ? { password: f.password } : {}), use_tls: f.use_tls, verify_tls: f.verify_tls, location: f.location || null }); } finally { setBusy(false); } }}>
      <div className="grid g2">
        <Input label="Name" required value={f.name} onChange={set('name')} />
        <Select label="Driver" value={f.driver} onChange={set('driver')} options={[{ value: 'mikrotik', label: 'MikroTik RouterOS v7 (REST)' }, { value: 'simulator', label: 'Simulator (demo)' }]} />
        <Input label="Host / IP" value={f.host || ''} onChange={set('host')} disabled={f.driver === 'simulator'} />
        <Input label="Port" type="number" value={f.port || ''} onChange={set('port')} disabled={f.driver === 'simulator'} />
        <Input label="API username" value={f.username || ''} onChange={set('username')} disabled={f.driver === 'simulator'} />
        <Input label="API password" type="password" value={f.password} onChange={set('password')} disabled={f.driver === 'simulator'} hint={initial?.has_password ? 'Leave blank to keep' : 'Stored encrypted (AES-256-GCM)'} autoComplete="new-password" />
        <Input label="Location" value={f.location || ''} onChange={set('location')} />
        <Select label="Role" value={f.role} onChange={set('role')} options={[{ value: 'core', label: 'Core / border (upstream internet)' }, { value: 'nas', label: 'NAS / BRAS (customer sessions)' }, { value: 'edge', label: 'Edge / distribution' }]} />
      </div>
      {f.driver === 'mikrotik' && <>
        <Toggle checked={f.use_tls} onChange={(v) => setF({ ...f, use_tls: v })} label="Use HTTPS (www-ssl)" hint="Strongly recommended" />
        <Toggle checked={!f.verify_tls} onChange={(v) => setF({ ...f, verify_tls: !v })} label="Router uses a self-signed certificate" hint="You will pin its exact certificate fingerprint after saving — verification is never simply turned off" />
      </>}
      <Button variant="primary" type="submit" loading={busy}>Save router</Button>
    </form>
  );
}

function Routers() {
  const { toast, can } = useApp();
  const { data, reload } = useLoad(() => api('/network/routers'));
  const [editing, setEditing] = useState(null);
  const [busy, setBusy] = useState('');
  const [discover, setDiscover] = useState(null);
  const [pinning, setPinning] = useState(null);
  const test = async (r) => { setBusy(`t${r.id}`); try { const out = await api.post(`/network/routers/${r.id}/test`); toast(out.ok ? `Connected · RouterOS ${out.info.version}` : `Failed: ${out.error}`, out.ok ? 'ok' : 'bad'); reload(); } finally { setBusy(''); } };
  const sync = async (r) => { setBusy(`s${r.id}`); try { const out = await api.post(`/network/routers/${r.id}/sync`); toast(`${out.synced} customer(s) synced${out.failed.length ? `, ${out.failed.length} failed` : ''}`, out.failed.length ? 'info' : 'ok'); } finally { setBusy(''); } };
  const save = async (p) => { try { if (editing.id) await api.put(`/network/routers/${editing.id}`, p); else await api.post('/network/routers', p); toast('Router saved'); setEditing(null); reload(); } catch (e) { toast(e.message, 'bad'); } };
  const del = async (r) => { if (!window.confirm(`Delete router ${r.name}?`)) return; await api.del(`/network/routers/${r.id}`); reload(); };
  return (
    <Page title="Routers & NAS" subtitle="Bandwidth limits, suspensions and site rules are pushed to these devices" actions={can('network.manage') && <Button variant="primary" icon={Plus} onClick={() => setEditing({})}>Add router</Button>}>
      {!data ? <Spinner /> : !data.routers.length ? <Card><Empty icon={RouterIcon} title="No routers yet">Add a MikroTik router (RouterOS 7.1+ with REST API enabled) or a simulator for testing.</Empty></Card> : (
        <div className="grid g3">
          {data.routers.map((r) => (
            <Card key={r.id} hover>
              <div className="row between"><div className="row"><RouterIcon size={20} /><h3 style={{ margin: 0 }}>{r.name}</h3>{r.role === 'core' && <Badge kind="brand">core</Badge>}</div><Badge status={r.status} /></div>
              {r.driver === 'mikrotik' && r.use_tls && !r.verify_tls && (
                r.tls_fingerprint ? <div className="faint" style={{ marginTop: 6 }}>🔒 Certificate pinned · <span className="mono">{r.tls_fingerprint.slice(0, 16)}…</span></div>
                  : <div className="alert warn" style={{ marginTop: 8 }}><div style={{ fontSize: 13 }}>Self-signed certificate not pinned yet — connections are blocked. {can('network.manage') && <a style={{ cursor: 'pointer', fontWeight: 700 }} onClick={() => setPinning(r)}>Pin now →</a>}</div></div>
              )}
              <div className="col mt" style={{ gap: 6 }}>
                <div className="row between"><span className="faint">Driver</span><span>{r.driver}</span></div>
                {r.host && <div className="row between"><span className="faint">Host</span><span className="mono">{r.host}:{r.port}</span></div>}
                <div className="row between"><span className="faint">Customers</span><b>{r.customers}</b></div>
                <div className="row between"><span className="faint">Last seen</span><span>{ago(r.last_seen_at)}</span></div>
                {r.info?.version && <div className="row between"><span className="faint">Version</span><span>{r.info.version} · {r.info.board}</span></div>}
                {r.info?.error && <div className="alert bad"><div style={{ fontSize: 13 }}>{r.info.error}</div></div>}
              </div>
              <div className="row wrap mt">
                <Button size="sm" icon={Plug} loading={busy === `t${r.id}`} onClick={() => test(r)}>Test</Button>
                {can('network.manage') && <><Button size="sm" icon={Radar} onClick={() => setDiscover(r)}>Discover & import</Button><Button size="sm" icon={RefreshCw} loading={busy === `s${r.id}`} onClick={() => sync(r)}>Sync all</Button><Button size="sm" variant="ghost" icon={Pencil} onClick={() => setEditing(r)} aria-label="Edit" /><Button size="sm" variant="ghost" icon={Trash2} onClick={() => del(r)} aria-label="Delete" /></>}
              </div>
            </Card>
          ))}
        </div>
      )}
      <Modal wide open={!!editing} onClose={() => setEditing(null)} title={editing?.id ? 'Edit router' : 'Add router'}>{editing && <RouterForm initial={editing.id ? editing : undefined} onSubmit={save} />}</Modal>
      {discover && <DiscoverModal router={discover} onClose={(changed) => { setDiscover(null); if (changed) reload(); }} />}
      <Modal open={!!pinning} onClose={() => setPinning(null)} title={`Pin certificate · ${pinning?.name || ''}`}>{pinning && <PinCertificate router={pinning} onDone={() => { setPinning(null); reload(); }} />}</Modal>
    </Page>
  );
}

// ------------------------------------------------------------------ traffic
function Traffic() {
  const [days, setDays] = useState(30);
  const { data } = useLoad(() => api(`/network/traffic?days=${days}`), [days]);
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const max = data ? Math.max(1, ...data.heatmap.flat()) : 1;
  return (
    <Page title="Traffic analysis" actions={<Tabs tabs={[{ value: 7, label: '7d' }, { value: 30, label: '30d' }, { value: 90, label: '90d' }]} value={days} onChange={setDays} />}>
      {!data ? <Spinner /> : (
        <div className="grid g3">
          <Card className="span2" title="Daily volume"><AreaSeries data={data.daily.map((d) => ({ ...d, bytes: Number(d.bytes) }))} x="day" fmtY={bytes} series={[{ key: 'bytes', label: 'Traffic' }]} /></Card>
          <Card title="By category" actions={data.categoriesEstimated && <span className="faint" title="Enable DNS/NetFlow integration for exact categories">estimated</span>}><Donut data={data.categories.map((c) => ({ name: label(c.category), value: Number(c.bytes) }))} fmt={bytes} /></Card>
          <Card className="span2" title="Peak hours (avg throughput, UTC)">
            <div className="heat">
              <span />{Array.from({ length: 24 }, (_, h) => <span key={h} style={{ textAlign: 'center' }}>{h % 3 === 0 ? h : ''}</span>)}
              {data.heatmap.map((row, d) => [<span key={`l${d}`}>{dayNames[d]}</span>, ...row.map((v, h) => <motion.i key={`${d}-${h}`} title={`${dayNames[d]} ${h}:00 · ${bps(v)}`} initial={{ scale: .5 }} animate={{ scale: 1 }} transition={{ delay: (d * 24 + h) * 0.002 }} style={{ background: `color-mix(in srgb, var(--brand-1) ${Math.round((v / max) * 100)}%, var(--surface-2))` }} />)])}
            </div>
          </Card>
          <Card title="By plan"><Bars data={data.byPlan.map((p) => ({ plan: p.plan || 'No plan', bytes: Number(p.bytes) }))} x="plan" fmtY={bytes} series={[{ key: 'bytes', label: 'Traffic' }]} height={240} /></Card>
          <Card className="span-all" title="Top consumers">
            <DataTable rows={data.top} columns={[{ key: 'name', title: 'Customer' }, { key: 'code', title: 'Code' }, { key: 'bytes', title: 'Volume', align: 'right', render: (r) => bytes(r.bytes) }]} />
          </Card>
        </div>
      )}
    </Page>
  );
}

// ------------------------------------------------------------------ access control
function Access() {
  const { toast, can } = useApp();
  const { data, reload } = useLoad(() => api('/network/site-rules'));
  const [f, setF] = useState({ scope: 'global', action: 'block', domain: '', category: '', customer_id: '', time: '', reason: '' });
  const [open, setOpen] = useState(false);
  const add = async (e) => {
    e.preventDefault();
    try {
      await api.post('/network/site-rules', { scope: f.scope, action: f.action, domain: f.domain || null, category: f.category || null, customer_id: f.scope === 'customer' ? Number(f.customer_id) : null, schedule: f.time ? { time: f.time } : null, reason: f.reason || null });
      toast('Rule added and pushed to routers'); setOpen(false); reload();
    } catch (err) { toast(err.message, 'bad'); }
  };
  return (
    <Page title="Access control & site restrictions" subtitle="Block or allow domains and categories network-wide or per customer" actions={can('network.manage') && <Button variant="primary" icon={Plus} onClick={() => setOpen(true)}>Add rule</Button>}>
      <Card className="flush">
        <DataTable rows={data?.rules} loading={!data} empty="No rules yet" columns={[
          { key: 'action', title: 'Action', render: (r) => <Badge kind={r.action === 'block' ? 'bad' : 'ok'}>{r.action}</Badge> },
          { key: 'target', title: 'Target', render: (r) => r.domain ? <span className="mono">{r.domain}</span> : <Badge kind="brand">{r.category}</Badge> },
          { key: 'scope', title: 'Scope', render: (r) => r.scope === 'global' ? 'Everyone' : r.customer_name },
          { key: 'schedule', title: 'Schedule', render: (r) => r.schedule?.time ? <span className="mono">{r.schedule.time}</span> : 'Always' },
          { key: 'reason', title: 'Reason' },
          { key: 'active', title: 'Active', render: (r) => <label className="toggle" style={{ display: 'inline-block' }}><input type="checkbox" checked={r.active} disabled={!can('network.manage')} onChange={async (e) => { await api.patch(`/network/site-rules/${r.id}`, { active: e.target.checked }); reload(); }} aria-label="Active" /><i /></label> },
          { key: 'x', title: '', render: (r) => can('network.manage') && <Button size="sm" variant="ghost" icon={Trash2} onClick={async () => { await api.del(`/network/site-rules/${r.id}`); reload(); }} aria-label="Delete" /> },
        ]} />
      </Card>
      <Modal open={open} onClose={() => setOpen(false)} title="New site rule">
        <form className="col" onSubmit={add}>
          <div className="grid g2">
            <Select label="Action" value={f.action} onChange={(e) => setF({ ...f, action: e.target.value })} options={['block', 'allow']} />
            <Select label="Scope" value={f.scope} onChange={(e) => setF({ ...f, scope: e.target.value })} options={[{ value: 'global', label: 'Everyone' }, { value: 'customer', label: 'One customer' }]} />
          </div>
          {f.scope === 'customer' && <Input label="Customer ID" type="number" required value={f.customer_id} onChange={(e) => setF({ ...f, customer_id: e.target.value })} />}
          <Input label="Domain" placeholder="example.com" value={f.domain} onChange={(e) => setF({ ...f, domain: e.target.value })} />
          <Select label="…or category" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} options={[{ value: '', label: '—' }, ...(data?.categories || []).map((c) => ({ value: c, label: label(c) }))]} />
          <Input label="Schedule (RouterOS time, optional)" placeholder="8h-17h,mon,tue,wed,thu,fri" value={f.time} onChange={(e) => setF({ ...f, time: e.target.value })} />
          <Input label="Reason" value={f.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} />
          <Button variant="primary" type="submit" icon={ShieldBan}>Add & apply</Button>
        </form>
      </Modal>
    </Page>
  );
}

// ------------------------------------------------------------------ device testing / diagnostics
function Diagnostics() {
  const { toast, can } = useApp();
  const [f, setF] = useState({ test: 'ping', target: '8.8.8.8', customer_id: '' });
  const [result, setResult] = useState(null);
  const [busy, setBusy] = useState(false);
  const history = useLoad(() => api('/network/diagnostics/history'));
  const devices = useLoad(() => api('/network/devices'));
  const [dev, setDev] = useState(null);
  const run = async (e) => {
    e?.preventDefault(); setBusy(true); setResult(null);
    try { setResult(await api.post('/network/diagnostics', { test: f.test, target: f.target, customer_id: f.customer_id ? Number(f.customer_id) : undefined })); history.reload(); }
    catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  const testDevice = async (d) => { try { const r = await api.post('/network/diagnostics', { test: 'ping', target: d.ip_address, customer_id: d.customer_id || undefined, device_id: d.id }); toast(r.ok ? `${d.name} reachable (${r.result.avgMs} ms)` : `${d.name} unreachable`, r.ok ? 'ok' : 'bad'); devices.reload(); } catch (e) { toast(e.message, 'bad'); } };
  const saveDev = async (e) => {
    e.preventDefault();
    try { const p = { ...dev, customer_id: dev.customer_id ? Number(dev.customer_id) : null }; delete p.id; delete p.last_test; delete p.customer_name; delete p.status; delete p.created_at; if (dev.id) await api.put(`/network/devices/${dev.id}`, p); else await api.post('/network/devices', p); setDev(null); devices.reload(); }
    catch (err) { toast(err.message, 'bad'); }
  };
  return (
    <Page title="Router & device testing">
      <div className="grid g2">
        <Card title="Run a test">
          <form className="col" onSubmit={run}>
            <div className="grid g2">
              <Select label="Test" value={f.test} onChange={(e) => setF({ ...f, test: e.target.value })} options={[{ value: 'ping', label: 'Ping' }, { value: 'traceroute', label: 'Traceroute' }, { value: 'dns', label: 'DNS lookup' }, { value: 'port', label: 'TCP port (host:port)' }]} />
              <Input label="Run from customer's router (ID)" type="number" value={f.customer_id} onChange={(e) => setF({ ...f, customer_id: e.target.value })} hint="Optional" />
            </div>
            <Input label="Target" required value={f.target} onChange={(e) => setF({ ...f, target: e.target.value })} placeholder={f.test === 'port' ? 'host:443' : '8.8.8.8 or example.com'} />
            <Button variant="primary" type="submit" icon={Play} loading={busy}>Run</Button>
          </form>
          {result && <motion.div initial={{ y: 8 }} animate={{ y: 0 }} className="mt"><div className="row mb"><Badge kind={result.ok ? 'ok' : 'bad'}>{result.ok ? 'pass' : 'fail'}</Badge>{result.result.avgMs != null && <b>{result.result.avgMs} ms avg · {result.result.loss}% loss</b>}</div>
            {result.result.hops ? <DataTable rows={result.result.hops.map((h) => ({ ...h, id: h.hop }))} columns={[{ key: 'hop', title: '#' }, { key: 'address', title: 'Address' }, { key: 'ms', title: 'ms', align: 'right' }]} /> : <pre className="code">{JSON.stringify(result.result, null, 2)}</pre>}</motion.div>}
        </Card>
        <Card title="Devices" actions={can('network.manage') && <Button size="sm" icon={Plus} onClick={() => setDev({ name: '', kind: 'router', ip_address: '', model: '', customer_id: '' })}>Add</Button>}>
          {!devices.data?.devices?.length ? <Empty title="No devices registered" /> : devices.data.devices.map((d) => (
            <div key={d.id} className="list-item"><RouterIcon size={18} className="muted" /><div className="grow"><b>{d.name}</b><div className="faint">{label(d.kind)} · {d.ip_address || 'no IP'} {d.customer_name ? `· ${d.customer_name}` : ''}</div></div><Badge status={d.status} />
              {d.ip_address && <Button size="sm" icon={Play} onClick={() => testDevice(d)}>Test</Button>}
              {can('network.manage') && <Button size="sm" variant="ghost" icon={Pencil} onClick={() => setDev(d)} aria-label="Edit" />}</div>
          ))}
        </Card>
        <Card className="span-all flush" title="">
          <div style={{ padding: '16px 20px 0' }}><h3>Test history</h3></div>
          <DataTable rows={history.data?.tests} columns={[
            { key: 'created_at', title: 'When', render: (r) => dateTime(r.created_at) },
            { key: 'test', title: 'Test', render: (r) => label(r.test) },
            { key: 'target', title: 'Target', render: (r) => <span className="mono">{r.target}</span> },
            { key: 'run_by_name', title: 'By' },
            { key: 'ok', title: 'Result', render: (r) => <Badge kind={r.ok ? 'ok' : 'bad'}>{r.ok ? 'pass' : 'fail'}</Badge> },
          ]} />
        </Card>
      </div>
      <Modal open={!!dev} onClose={() => setDev(null)} title={dev?.id ? 'Edit device' : 'Add device'}>
        {dev && <form className="col" onSubmit={saveDev}>
          <Input label="Name" required value={dev.name} onChange={(e) => setDev({ ...dev, name: e.target.value })} />
          <div className="grid g2">
            <Select label="Kind" value={dev.kind} onChange={(e) => setDev({ ...dev, kind: e.target.value })} options={['router', 'onu', 'switch', 'ap', 'olt', 'cpe', 'other']} />
            <Input label="Customer ID" type="number" value={dev.customer_id || ''} onChange={(e) => setDev({ ...dev, customer_id: e.target.value })} />
            <Input label="IP address" value={dev.ip_address || ''} onChange={(e) => setDev({ ...dev, ip_address: e.target.value })} />
            <Input label="MAC" value={dev.mac_address || ''} onChange={(e) => setDev({ ...dev, mac_address: e.target.value })} />
            <Input label="Model" value={dev.model || ''} onChange={(e) => setDev({ ...dev, model: e.target.value })} />
            <Input label="Firmware" value={dev.firmware || ''} onChange={(e) => setDev({ ...dev, firmware: e.target.value })} />
          </div>
          <Button variant="primary" type="submit">Save</Button>
        </form>}
      </Modal>
    </Page>
  );
}

// ------------------------------------------------------------------ remote support
const ACTIONS = [['status', 'Connection status'], ['ping_gateway', 'Ping customer gateway'], ['ping_internet', 'Ping internet (8.8.8.8)'], ['dns_check', 'DNS check'], ['speed_profile_check', 'Verify speed profile'], ['resync_profile', 'Re-push router config'], ['reconnect', 'Reconnect PPPoE session']];

function Remote() {
  const { toast } = useApp();
  const { data, reload } = useLoad(() => api('/network/remote-sessions'));
  const [active, setActive] = useState(null);
  const [cid, setCid] = useState('');
  const [busy, setBusy] = useState('');
  const request = async (e) => { e.preventDefault(); try { await api.post('/network/remote-sessions', { customer_id: Number(cid) }); toast('Request sent — waiting for customer approval'); setCid(''); reload(); } catch (err) { toast(err.message, 'bad'); } };
  const act = async (a) => {
    setBusy(a);
    try { await api.post(`/network/remote-sessions/${active.id}/action`, { action: a }); const d = await reload(); setActive(d.sessions.find((s) => s.id === active.id)); }
    catch (e) { toast(e.message, 'bad'); } finally { setBusy(''); }
  };
  const close = async (s) => { await api.post(`/network/remote-sessions/${s.id}/close`); setActive(null); reload(); };
  return (
    <Page title="Remote support" subtitle="Consent-based remote diagnostics — every action is logged and visible to the customer">
      <Card className="mb"><form className="row" onSubmit={request}><input className="input" style={{ maxWidth: 220 }} type="number" placeholder="Customer ID" required value={cid} onChange={(e) => setCid(e.target.value)} aria-label="Customer ID" /><Button variant="primary" type="submit" icon={MonitorSmartphone}>Request session</Button><span className="faint">The customer must approve in their app before you can act.</span></form></Card>
      <Card className="flush">
        <DataTable rows={data?.sessions} loading={!data} onRowClick={(s) => setActive(s)} columns={[
          { key: 'customer_name', title: 'Customer', render: (r) => <div><b>{r.customer_name}</b><div className="faint">{r.code}</div></div> },
          { key: 'staff_name', title: 'Agent' },
          { key: 'status', title: 'Status', render: (r) => <Badge status={r.status} /> },
          { key: 'actions', title: 'Actions', render: (r) => r.actions.length },
          { key: 'created_at', title: 'Requested', render: (r) => ago(r.created_at) },
        ]} />
      </Card>
      <Modal wide open={!!active} onClose={() => setActive(null)} title={`Remote session · ${active?.customer_name || ''}`}>
        {active && (
          <div className="col">
            <div className="row"><Badge status={active.status} />{active.consent_at && <span className="faint">Approved {ago(active.consent_at)}</span>}<div className="grow" />{active.status === 'active' && <Button size="sm" variant="danger" icon={X} onClick={() => close(active)}>End session</Button>}</div>
            {active.status === 'requested' && <div className="alert warn"><div>Waiting for the customer to approve this session in their app.</div></div>}
            {active.status === 'active' && <div className="row wrap">{ACTIONS.map(([k, l]) => <Button key={k} size="sm" loading={busy === k} disabled={!!busy} onClick={() => act(k)}>{l}</Button>)}</div>}
            <div className="col" style={{ maxHeight: 360, overflowY: 'auto' }}>
              {[...active.actions].reverse().map((a, i) => <div key={i} className="card" style={{ padding: 12 }}><div className="row between"><b>{label(a.action)}</b><span className="faint">{a.by} · {dateTime(a.at)}</span></div><pre className="code" style={{ marginTop: 8 }}>{JSON.stringify(a.result, null, 2)}</pre></div>)}
            </div>
          </div>
        )}
      </Modal>
    </Page>
  );
}

export default function Network() {
  const { section } = useParams();
  const map = { live: Live, routers: Routers, traffic: Traffic, access: Access, diagnostics: Diagnostics, remote: Remote, ipam: Ipam, capacity: Capacity };
  const C = map[section] || Live;
  return <C />;
}
