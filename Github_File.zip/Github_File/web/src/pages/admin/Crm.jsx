import { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Send, Trash2, Pencil, Facebook, Users, TrendingUp, Target, Upload, Download, FileSpreadsheet } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { downloadFile } from '../../lib/download.js';
import EmailDesigner, { clean } from '../../components/EmailDesigner.jsx';
import { ago, dateTime, label, money, moneyShort, toCents } from '../../lib/format.js';
import { Badge, Button, Card, DataTable, Input, Modal, Page, Select, Stat, Tabs, Textarea, Toggle, useLoad } from '../../components/ui.jsx';
import { Bars, Donut } from '../../components/charts.jsx';
import { ChannelPicker, AudiencePicker } from './Notify.jsx';

// <input type="datetime-local"> works in the browser's local time; the API stores UTC ISO strings.
const toLocalInput = (iso) => { const d = new Date(iso); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16); };

const STAGES = ['new', 'contacted', 'qualified', 'proposal', 'won', 'lost'];

/** Bulk lead import from CSV: pick a file → preview (nothing saved) → import. */
function ImportLeads({ onClose, onDone }) {
  const { toast } = useApp();
  const [file, setFile] = useState(null);
  const [mode, setMode] = useState('skip');
  const [preview, setPreview] = useState(null);
  const [busy, setBusy] = useState('');
  const send = async (dryRun) => {
    const form = new FormData(); form.append('file', file); form.append('dryRun', String(dryRun)); form.append('onDuplicate', mode);
    return api('/crm/leads/import', { method: 'POST', form });
  };
  const check = async () => { setBusy('check'); try { setPreview(await send(true)); } catch (e) { toast(e.message, 'bad'); setPreview(null); } finally { setBusy(''); } };
  const run = async () => {
    setBusy('run');
    try { const r = await send(false); toast(`Imported: ${r.created} new, ${r.updated} updated, ${r.skipped} skipped${r.errors.length ? `, ${r.errors.length} with errors` : ''}`); onDone(); onClose(); }
    catch (e) { toast(e.message, 'bad'); } finally { setBusy(''); }
  };
  const ready = preview && (preview.created + preview.updated) > 0;
  return (
    <Modal open onClose={onClose} title="Import leads from CSV" wide footer={<>
      <Button onClick={onClose}>Cancel</Button>
      <Button icon={FileSpreadsheet} onClick={check} loading={busy === 'check'} disabled={!file || !!busy}>Preview</Button>
      <Button variant="primary" icon={Upload} onClick={run} loading={busy === 'run'} disabled={!ready || !!busy}>Import {ready ? preview.created + preview.updated : ''} lead(s)</Button>
    </>}>
      <div className="col">
        <p className="muted" style={{ margin: 0 }}>Columns: <b>name</b> (required), <b>email</b> and/or <b>phone</b>, and optionally address, source, status, plan, assigned_to (staff email), value, notes. Common header names (e.g. "Full name", "Mobile") are recognised. Up to 5,000 rows, 2 MB.</p>
        <div className="row wrap">
          <Button size="sm" icon={Download} onClick={() => downloadFile('/crm/leads/template.csv', { fallbackName: 'leads-template.csv' }).catch((e) => toast(e.message, 'bad'))}>Download template</Button>
          <label className="btn sm"><Upload size={14} /> {file ? file.name : 'Choose .csv file'}<input type="file" accept=".csv,text/csv" hidden onChange={(e) => { setFile(e.target.files[0] || null); setPreview(null); }} /></label>
        </div>
        <Select label="When a lead with the same email or phone already exists" value={mode} onChange={(e) => { setMode(e.target.value); setPreview(null); }}
          options={[{ value: 'skip', label: 'Skip it (keep the existing lead)' }, { value: 'update', label: 'Update the existing lead with the file data' }]} />
        {preview && (
          <div className="col">
            <div className="row wrap">
              <Badge kind="ok">{preview.created} new</Badge><Badge kind="info">{preview.updated} to update</Badge>
              <Badge kind="brand">{preview.skipped} skipped (duplicates)</Badge><Badge kind={preview.errors.length ? 'bad' : 'brand'}>{preview.errors.length} with errors</Badge>
              <span className="faint">{preview.total} row(s) in file · nothing saved yet</span>
            </div>
            {preview.errors.length > 0 && (
              <div className="alert warn" style={{ maxHeight: 180, overflow: 'auto', display: 'block' }}>
                <b>These rows will not be imported:</b>
                {preview.errors.slice(0, 50).map((e) => <div key={e.row}>Row {e.row}{e.name ? ` (${e.name})` : ''}: {e.error}</div>)}
              </div>
            )}
            {preview.preview.length > 0 && (
              <DataTable rows={preview.preview.map((p) => ({ ...p, id: p.row }))} columns={[
                { key: 'row', title: 'Row' }, { key: 'action', title: '', render: (p) => <Badge kind={p.action === 'create' ? 'ok' : 'info'}>{p.action}</Badge> },
                { key: 'name', title: 'Name' }, { key: 'email', title: 'Email' }, { key: 'phone', title: 'Phone' }, { key: 'status', title: 'Stage' },
              ]} />
            )}
          </div>
        )}
      </div>
    </Modal>
  );
}

function Leads() {
  const { toast, can } = useApp();
  const { data, reload, setData } = useLoad(() => api('/crm/leads?pageSize=200'));
  const plans = useLoad(() => api('/plans'));
  const [edit, setEdit] = useState(null);
  const [over, setOver] = useState(null);
  const [importing, setImporting] = useState(false);
  const move = async (id, status) => {
    setData((d) => ({ ...d, rows: d.rows.map((l) => (l.id === id ? { ...l, status } : l)) }));
    try { await api.put(`/crm/leads/${id}`, { status }); if (status === 'won') toast('Deal won 🎉 — recorded as a sale'); } catch (e) { toast(e.message, 'bad'); reload(); }
  };
  const save = async (e) => {
    e.preventDefault();
    const p = { name: edit.name, email: edit.email || null, phone: edit.phone || null, address: edit.address || null, source: edit.source, status: edit.status, plan_id: edit.plan_id ? Number(edit.plan_id) : null, value_cents: toCents(edit.value || 0), notes: edit.notes || null };
    try { if (edit.id) await api.put(`/crm/leads/${edit.id}`, p); else await api.post('/crm/leads', p); setEdit(null); reload(); } catch (err) { toast(err.message, 'bad'); }
  };
  const rows = data?.rows || [];
  return (
    <>
      <div className="row end mb wrap">
        <Button icon={Download} onClick={() => downloadFile('/crm/leads/export.csv', { fallbackName: 'leads.csv' }).then(() => toast('Leads exported')).catch((e) => toast(e.message, 'bad'))}>Export CSV</Button>
        {can('crm.manage') && <Button icon={Upload} onClick={() => setImporting(true)}>Import CSV</Button>}
        {can('crm.manage') && <Button variant="primary" icon={Plus} onClick={() => setEdit({ name: '', source: 'phone', status: 'new', value: '' })}>New lead</Button>}
      </div>
      {importing && <ImportLeads onClose={() => setImporting(false)} onDone={reload} />}
      <div className="kanban">
        {STAGES.map((s) => {
          const items = rows.filter((l) => l.status === s);
          return (
            <div key={s} className={`kanban-col ${over === s ? 'over' : ''}`} onDragOver={(e) => { e.preventDefault(); setOver(s); }} onDragLeave={() => setOver(null)} onDrop={(e) => { e.preventDefault(); setOver(null); const id = Number(e.dataTransfer.getData('text/plain')); if (id && can('crm.manage')) move(id, s); }}>
              <div className="row between mb"><Badge status={s} /><span className="faint">{items.length} · {moneyShort(items.reduce((a, l) => a + Number(l.value_cents || 0), 0))}</span></div>
              {items.map((l) => (
                <motion.div layout key={l.id} className="card kanban-card hover" draggable={can('crm.manage')} onDragStart={(e) => e.dataTransfer.setData('text/plain', String(l.id))} onClick={() => setEdit({ ...l, value: l.value_cents / 100 })}>
                  <b style={{ fontSize: 14 }}>{l.name}</b>
                  <div className="faint">{l.phone || l.email}</div>
                  <div className="row between" style={{ marginTop: 6 }}><span className="faint">{label(l.source)}</span>{l.plan_name && <Badge kind="brand">{l.plan_name}</Badge>}</div>
                </motion.div>
              ))}
            </div>
          );
        })}
      </div>
      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? 'Edit lead' : 'New lead'}>
        {edit && <form className="col" onSubmit={save}>
          <Input label="Name" required value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
          <div className="grid g2">
            <Input label="Phone" value={edit.phone || ''} onChange={(e) => setEdit({ ...edit, phone: e.target.value })} />
            <Input label="Email" type="email" value={edit.email || ''} onChange={(e) => setEdit({ ...edit, email: e.target.value })} />
            <Select label="Source" value={edit.source} onChange={(e) => setEdit({ ...edit, source: e.target.value })} options={['website', 'signup', 'chatbot', 'referral', 'facebook', 'whatsapp', 'walk_in', 'phone', 'other']} />
            <Select label="Stage" value={edit.status} onChange={(e) => setEdit({ ...edit, status: e.target.value })} options={STAGES} />
            <Select label="Interested plan" value={edit.plan_id || ''} onChange={(e) => setEdit({ ...edit, plan_id: e.target.value })} options={[{ value: '', label: '—' }, ...(plans.data?.plans || []).map((p) => ({ value: p.id, label: p.name }))]} />
            <Input label="Deal value" type="number" min={0} step="0.01" value={edit.value} onChange={(e) => setEdit({ ...edit, value: e.target.value })} />
          </div>
          <Input label="Address" value={edit.address || ''} onChange={(e) => setEdit({ ...edit, address: e.target.value })} />
          <Textarea label="Notes" value={edit.notes || ''} onChange={(e) => setEdit({ ...edit, notes: e.target.value })} />
          <div className="row">{can('crm.manage') && <Button variant="primary" type="submit" className="grow">Save</Button>}{edit.id && can('crm.manage') && <Button type="button" variant="danger" icon={Trash2} onClick={async () => { await api.del(`/crm/leads/${edit.id}`); setEdit(null); reload(); }} aria-label="Delete" />}</div>
        </form>}
      </Modal>
    </>
  );
}

function Campaigns() {
  const { toast, can } = useApp();
  const { data, reload } = useLoad(() => api('/crm/campaigns'));
  const plans = useLoad(() => api('/plans'));
  const [edit, setEdit] = useState(null);
  const save = async (e) => {
    e.preventDefault();
    const p = { name: edit.name, channels: edit.channels, audience: { ...edit.audience, value: edit.audience.value || undefined }, subject: edit.subject || null, body: edit.body, social_post: edit.social_post || null, scheduled_at: edit.scheduled_at ? new Date(edit.scheduled_at).toISOString() : null, email_design: clean(edit.email_design) };
    try { if (edit.id) await api.put(`/crm/campaigns/${edit.id}`, p); else await api.post('/crm/campaigns', p); toast('Campaign saved'); setEdit(null); reload(); } catch (err) { toast(err.message, 'bad'); }
  };
  const send = async (c) => {
    try { const { size } = await api.post(`/crm/campaigns/${c.id}/audience-size`); if (!window.confirm(`Send "${c.name}" to ${size} recipient(s) now?`)) return; await api.post(`/crm/campaigns/${c.id}/send`); toast('Campaign is sending'); setTimeout(reload, 1500); }
    catch (e) { toast(e.message, 'bad'); }
  };
  return (
    <>
      <div className="row end mb">{can('crm.manage') && <Button variant="primary" icon={Plus} onClick={() => setEdit({ name: '', channels: ['email', 'inapp'], audience: { type: 'all_customers', value: '' }, subject: '', body: '', social_post: '', scheduled_at: '' })}>New campaign</Button>}</div>
      <Card className="flush">
        <DataTable rows={data?.campaigns} loading={!data} empty="No campaigns yet" columns={[
          { key: 'name', title: 'Campaign', render: (r) => <div><b>{r.name}</b><div className="faint">{label(r.audience.type)}</div></div> },
          { key: 'channels', title: 'Channels', render: (r) => <div className="row wrap" style={{ gap: 4 }}>{r.channels.map((c) => <Badge key={c} kind="brand">{c}</Badge>)}</div> },
          { key: 'status', title: 'Status', render: (r) => <Badge status={r.status} /> },
          { key: 'when', title: 'When', render: (r) => r.sent_at ? `Sent ${ago(r.sent_at)}` : r.scheduled_at ? dateTime(r.scheduled_at) : '—' },
          { key: 'stats', title: 'Delivered', render: (r) => r.stats ? `${r.stats.sent}/${r.stats.recipients}${r.stats.failed ? ` (${r.stats.failed} failed)` : ''}` : '—' },
          { key: 'x', title: '', align: 'right', render: (r) => can('crm.manage') && !['sent', 'sending'].includes(r.status) && <div className="row end"><Button size="sm" variant="ghost" icon={Pencil} onClick={() => setEdit({ ...r, scheduled_at: r.scheduled_at ? toLocalInput(r.scheduled_at) : '' })} aria-label="Edit" /><Button size="sm" variant="primary" icon={Send} onClick={() => send(r)}>Send</Button></div> },
        ]} />
      </Card>
      <Modal wide open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? 'Edit campaign' : 'New campaign'}>
        {edit && <form className="col" onSubmit={save}>
          <Input label="Campaign name" required value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
          <AudiencePicker value={edit.audience} onChange={(audience) => setEdit({ ...edit, audience })} plans={plans.data?.plans} />
          <ChannelPicker value={edit.channels} onChange={(channels) => setEdit({ ...edit, channels })} extra={[{ value: 'facebook', label: 'Facebook page', icon: Facebook }]} />
          <Input label="Subject" value={edit.subject || ''} onChange={(e) => setEdit({ ...edit, subject: e.target.value })} />
          <Textarea label="Message" required rows={5} value={edit.body} onChange={(e) => setEdit({ ...edit, body: e.target.value })} hint="{{user.name}} and {{company}} are replaced per recipient" />
          {edit.channels.includes('facebook') && <Textarea label="Social post (optional — defaults to the message)" rows={3} value={edit.social_post || ''} onChange={(e) => setEdit({ ...edit, social_post: e.target.value })} />}
          {edit.channels.includes('email') && <EmailDesigner value={edit.email_design} onChange={(email_design) => setEdit({ ...edit, email_design })} subject={edit.subject || edit.name} body={edit.body} hint="How this campaign looks in the inbox. Promo and Bold work best for offers." />}
          <Input label="Schedule (optional)" type="datetime-local" value={edit.scheduled_at || ''} onChange={(e) => setEdit({ ...edit, scheduled_at: e.target.value })} />
          <Button variant="primary" type="submit" disabled={!edit.channels.length}>Save campaign</Button>
        </form>}
      </Modal>
    </>
  );
}

function Sales() {
  const [days, setDays] = useState(90);
  const { data } = useLoad(() => api(`/crm/sales?days=${days}`), [days]);
  const total = (data?.byKind || []).reduce((s, k) => s + Number(k.amount || 0), 0);
  const count = (data?.byKind || []).reduce((s, k) => s + Number(k.n || 0), 0);
  const won = Number(data?.funnel?.find((f) => f.status === 'won')?.n || 0);
  const allLeads = (data?.funnel || []).reduce((s, f) => s + Number(f.n), 0);
  return (
    <>
      <div className="row end mb"><Tabs tabs={[{ value: 30, label: '30d' }, { value: 90, label: '90d' }, { value: 365, label: '1y' }]} value={days} onChange={setDays} /></div>
      <div className="grid g3 mb">
        <Stat icon={TrendingUp} label="Sales value" value={total} format={money} />
        <Stat icon={Users} label="Deals" value={count} />
        <Stat icon={Target} label="Lead conversion" value={allLeads ? (won / allLeads) * 100 : 0} format={(v) => `${v.toFixed(1)}%`} />
      </div>
      <div className="grid g3">
        <Card className="span2" title="Sales by month"><Bars data={(data?.byMonth || []).map((m) => ({ ...m, amount: Number(m.amount) }))} x="month" fmtY={moneyShort} series={[{ key: 'amount', label: 'Value' }]} /></Card>
        <Card title="By type"><Donut data={(data?.byKind || []).map((k) => ({ name: label(k.kind), value: Number(k.amount) }))} fmt={money} /></Card>
        <Card title="Leaderboard">{(data?.byStaff || []).map((s, i) => <div key={i} className="list-item"><span className="faint">{i + 1}</span><div className="grow"><b>{s.staff || 'Self-service'}</b><div className="faint">{s.n} deals</div></div><b>{moneyShort(s.amount)}</b></div>)}</Card>
        <Card className="span2 flush" title="">
          <div style={{ padding: '16px 20px 0' }}><h3>Recent sales</h3></div>
          <DataTable rows={data?.recent} columns={[{ key: 'created_at', title: 'Date', render: (r) => dateTime(r.created_at) }, { key: 'customer_name', title: 'Customer' }, { key: 'plan_name', title: 'Plan' }, { key: 'kind', title: 'Type', render: (r) => <Badge kind="brand">{r.kind}</Badge> }, { key: 'staff_name', title: 'By' }, { key: 'amount_cents', title: 'Value', align: 'right', render: (r) => money(r.amount_cents) }]} />
        </Card>
      </div>
    </>
  );
}

function Faq() {
  const { toast, can } = useApp();
  const { data, reload } = useLoad(() => api('/crm/faqs'));
  const [edit, setEdit] = useState(null);
  const [testQ, setTestQ] = useState('');
  const [testA, setTestA] = useState(null);
  const save = async (e) => {
    e.preventDefault();
    const p = { question: edit.question, answer: edit.answer, category: edit.category || 'general', keywords: edit.keywords || null, sort: Number(edit.sort) || 0, active: !!edit.active };
    try { if (edit.id) await api.put(`/crm/faqs/${edit.id}`, p); else await api.post('/crm/faqs', p); setEdit(null); reload(); } catch (err) { toast(err.message, 'bad'); }
  };
  return (
    <div className="grid g3">
      <Card className="span2 flush" title="">
        <div className="row between" style={{ padding: '16px 20px 0' }}><h3>FAQ knowledge base</h3>{can('crm.manage') && <Button size="sm" variant="primary" icon={Plus} onClick={() => setEdit({ question: '', answer: '', category: 'general', keywords: '', active: true })}>Add</Button>}</div>
        <DataTable rows={data?.faqs} onRowClick={(f) => setEdit({ ...f, active: !!f.active })} columns={[{ key: 'question', title: 'Question', render: (r) => <b>{r.question}</b> }, { key: 'category', title: 'Category' }, { key: 'active', title: '', render: (r) => <Badge kind={r.active ? 'ok' : 'info'}>{r.active ? 'live' : 'hidden'}</Badge> }]} />
      </Card>
      <Card title="Test the chatbot">
        <form className="col" onSubmit={async (e) => { e.preventDefault(); setTestA(await api.post('/public/chatbot', { message: testQ })); }}>
          <Input value={testQ} onChange={(e) => setTestQ(e.target.value)} placeholder="Ask something…" required />
          <Button type="submit">Ask</Button>
        </form>
        {testA && <div className="bubble bot mt" style={{ maxWidth: '100%' }}>{testA.reply}{testA.matched && <div className="faint" style={{ marginTop: 6 }}>Matched: {testA.matched}</div>}</div>}
      </Card>
      <Modal wide open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? 'Edit FAQ' : 'New FAQ'}>
        {edit && <form className="col" onSubmit={save}>
          <Input label="Question" required value={edit.question} onChange={(e) => setEdit({ ...edit, question: e.target.value })} />
          <Textarea label="Answer" required rows={5} value={edit.answer} onChange={(e) => setEdit({ ...edit, answer: e.target.value })} />
          <div className="grid g2">
            <Input label="Category" value={edit.category} onChange={(e) => setEdit({ ...edit, category: e.target.value })} />
            <Input label="Keywords (help the chatbot match)" value={edit.keywords || ''} onChange={(e) => setEdit({ ...edit, keywords: e.target.value })} />
          </div>
          <Toggle checked={edit.active} onChange={(active) => setEdit({ ...edit, active })} label="Published" />
          <div className="row">{can('crm.manage') && <Button variant="primary" type="submit" className="grow">Save</Button>}{edit.id && can('crm.manage') && <Button type="button" variant="danger" icon={Trash2} onClick={async () => { await api.del(`/crm/faqs/${edit.id}`); setEdit(null); reload(); }} aria-label="Delete" />}</div>
        </form>}
      </Modal>
    </div>
  );
}

export default function Crm() {
  const [tab, setTab] = useState('pipeline');
  return (
    <Page title="CRM & sales" subtitle="Leads, multi-channel marketing, sales tracking and chatbot knowledge">
      <div className="mb"><Tabs tabs={['pipeline', 'campaigns', 'sales', 'faq_&_chatbot']} value={tab} onChange={setTab} /></div>
      {tab === 'pipeline' && <Leads />}
      {tab === 'campaigns' && <Campaigns />}
      {tab === 'sales' && <Sales />}
      {tab === 'faq_&_chatbot' && <Faq />}
    </Page>
  );
}
