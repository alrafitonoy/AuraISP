import { useState } from 'react';
import { motion } from 'framer-motion';
import { CloudDownload, RefreshCw, RotateCcw, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { ago, bytes, dateTime } from '../../lib/format.js';
import { Badge, Button, Card, Confirm, DataTable, Page, Spinner, Toggle, useLoad } from '../../components/ui.jsx';

export default function Updates() {
  const { toast, user } = useApp();
  const { data, reload } = useLoad(() => api('/updates'));
  const [check, setCheck] = useState(null);
  const [busy, setBusy] = useState('');
  const [confirm, setConfirm] = useState(null);
  if (!data) return <Spinner />;
  const info = check || data.settings.latest;
  const doCheck = async () => { setBusy('check'); try { setCheck(await api.post('/updates/check')); } catch (e) { toast(e.message, 'bad'); } finally { setBusy(''); } };
  const apply = async () => { try { const r = await api.post('/updates/apply'); toast(r.updated ? `Updated to ${r.to}. Restarting…` : r.message); if (r.restarting) setTimeout(() => window.location.reload(), 8000); reload(); } catch (e) { toast(e.message, 'bad'); } };
  const rollback = async (file) => { try { await api.post('/updates/rollback', { file }); toast('Rolling back. Restarting…'); setTimeout(() => window.location.reload(), 8000); } catch (e) { toast(e.message, 'bad'); } };
  const setAuto = async (auto) => { await api.put('/updates/settings', { auto }); reload(); toast(auto ? 'Automatic updates enabled' : 'Automatic updates disabled', 'info'); };

  return (
    <Page title="Software updates" subtitle={`Installed version ${data.current}`}>
      <div className="grid g2">
        <Card glow>
          <div className="row"><motion.div animate={{ rotate: busy === 'check' ? 360 : 0 }} transition={{ repeat: busy === 'check' ? Infinity : 0, duration: 1, ease: 'linear' }}><CloudDownload size={40} color="var(--brand-1)" /></motion.div>
            <div className="grow">
              {info?.available ? <><h3 style={{ margin: 0 }}>Version {info.latest} is available</h3><div className="faint">Published {ago(info.publishedAt)}</div></>
                : info?.configured === false ? <><h3 style={{ margin: 0 }}>Updates not configured</h3><div className="faint">Set UPDATE_REPO and UPDATE_PUBLIC_KEY in the server .env</div></>
                : <><h3 style={{ margin: 0 }} className="row"><CheckCircle2 size={20} color="var(--ok)" /> You're up to date</h3><div className="faint">Last checked {ago(data.settings.lastCheckAt)}</div></>}
            </div>
          </div>
          {info?.notes && <pre className="code mt" style={{ whiteSpace: 'pre-wrap' }}>{info.notes}</pre>}
          <div className="row mt">
            <Button icon={RefreshCw} loading={busy === 'check'} onClick={doCheck}>Check now</Button>
            {info?.available && user.type === 'admin' && <Button variant="primary" icon={CloudDownload} onClick={() => setConfirm('apply')}>Install {info.latest}</Button>}
          </div>
        </Card>
        <Card title="Update policy">
          <Toggle checked={data.settings.auto} onChange={setAuto} label="Install stable updates automatically" hint="Checked nightly at 03:20. Only signed, non-prerelease versions are installed." />
          <div className="divider" />
          <div className="col" style={{ gap: 8 }}>
            <div className="row"><ShieldCheck size={16} color="var(--ok)" /> Ed25519 signature verified before install</div>
            <div className="row"><ShieldCheck size={16} color="var(--ok)" /> Pre-releases, drafts, -beta / -rc tags are ignored</div>
            <div className="row"><ShieldCheck size={16} color="var(--ok)" /> Automatic backup before every update (last 5 kept)</div>
            <div className="row"><ShieldCheck size={16} color="var(--ok)" /> Database migrations run on restart</div>
          </div>
        </Card>
        <Card title="History" className="flush">
          <DataTable rows={data.history} empty="No updates yet" columns={[{ key: 'created_at', title: 'When', render: (r) => dateTime(r.created_at) }, { key: 'v', title: 'Version', render: (r) => `${r.from_version} → ${r.to_version || '—'}` }, { key: 'status', title: 'Result', render: (r) => <Badge status={r.status === 'rollback' ? 'pending' : r.status}>{r.status}</Badge> }, { key: 'triggered_by', title: 'By' }, { key: 'message', title: 'Details', render: (r) => <span className="faint">{r.message}</span> }]} />
        </Card>
        <Card title="Backups" className="flush">
          <DataTable rows={data.backups.map((b) => ({ ...b, id: b.file }))} empty="No backups yet" columns={[{ key: 'file', title: 'File', render: (r) => <span className="mono">{r.file}</span> }, { key: 'size', title: 'Size', render: (r) => bytes(r.size) }, { key: 'x', title: '', render: (r) => user.type === 'admin' && <Button size="sm" icon={RotateCcw} onClick={() => setConfirm(r.file)}>Restore</Button> }]} />
        </Card>
      </div>
      <Confirm open={!!confirm} onClose={() => setConfirm(null)} onConfirm={() => (confirm === 'apply' ? apply() : rollback(confirm))} title={confirm === 'apply' ? `Install version ${info?.latest}?` : 'Restore this backup?'} confirmText={confirm === 'apply' ? 'Install & restart' : 'Restore & restart'}>
        The server will restart. Users may see a short interruption (usually under a minute).
      </Confirm>
    </Page>
  );
}
