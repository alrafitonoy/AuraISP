import { useEffect, useRef, useState } from 'react';
import { Send, Plus, Pencil, Trash2, Mail, MessageSquare, Smartphone, Bell, AppWindow, X, Search } from 'lucide-react';
import { useApp } from '../../context.jsx';
import EmailDesigner, { clean } from '../../components/EmailDesigner.jsx';
import { api } from '../../lib/api.js';
import { dateTime, label } from '../../lib/format.js';
import { Badge, Button, Card, DataTable, Input, Modal, Page, Pager, Select, Tabs, Textarea, Toggle, useLoad } from '../../components/ui.jsx';

export const CHANNELS = [
  { value: 'email', label: 'Email', icon: Mail },
  { value: 'sms', label: 'SMS', icon: Smartphone },
  { value: 'whatsapp', label: 'WhatsApp', icon: MessageSquare },
  { value: 'push', label: 'Push', icon: Bell },
  { value: 'inapp', label: 'In-app', icon: AppWindow },
];

export function ChannelPicker({ value, onChange, extra = [] }) {
  return (
    <div className="row wrap" style={{ gap: 8 }}>
      {[...CHANNELS, ...extra].map((c) => {
        const on = value.includes(c.value);
        return <button type="button" key={c.value} className={`chip ${on ? 'on' : ''}`} onClick={() => onChange(on ? value.filter((x) => x !== c.value) : [...value, c.value])} aria-pressed={on}>{c.icon && <c.icon size={14} />}{c.label}</button>;
      })}
    </div>
  );
}

/** Search customers by name / code / phone / email / PPPoE and pick them as chips (value = array of customer ids). */
function CustomerPicker({ value, onChange }) {
  const ids = Array.isArray(value) ? value : [];
  const [q, setQ] = useState('');
  const [hits, setHits] = useState([]);
  const [names, setNames] = useState({}); // id -> label for chips
  const [open, setOpen] = useState(false);
  const t = useRef();
  useEffect(() => {
    clearTimeout(t.current);
    const term = q.trim();
    if (!term || /^[\d,\s]+$/.test(term)) { setHits([]); return undefined; }
    t.current = setTimeout(() => api(`/customers?q=${encodeURIComponent(term)}&pageSize=8`).then((r) => { setHits(r.rows || []); setOpen(true); }).catch(() => setHits([])), 250);
    return () => clearTimeout(t.current);
  }, [q]);
  const add = (c) => { if (!ids.includes(c.id)) onChange([...ids, c.id]); setNames((n) => ({ ...n, [c.id]: `${c.name} · ${c.code}` })); setQ(''); setHits([]); setOpen(false); };
  // Typing plain IDs ("12, 15 18") and pressing Enter or comma adds them directly.
  const addTypedIds = () => {
    const typed = q.split(/[\s,;]+/).map((x) => Number(x)).filter((n) => Number.isInteger(n) && n > 0);
    if (typed.length) { onChange([...new Set([...ids, ...typed])]); setQ(''); }
  };
  return (
    <div className="picker">
      <label className="field"><span>Customers</span>
        <div className="pw-wrap">
          <input className="input" value={q} placeholder="Search name, code, phone, email — or type IDs and press Enter" aria-label="Find customers"
            onChange={(e) => setQ(e.target.value)} onFocus={() => hits.length && setOpen(true)} onBlur={() => setTimeout(() => setOpen(false), 150)}
            onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); if (hits.length && !/^[\d,\s]+$/.test(q)) add(hits[0]); else addTypedIds(); } }} />
          <span className="pw-eye" aria-hidden="true"><Search size={16} /></span>
        </div>
      </label>
      {open && hits.length > 0 && (
        <div className="picker-menu" role="listbox">
          {hits.map((c) => <button type="button" role="option" aria-selected={ids.includes(c.id)} key={c.id} onMouseDown={(e) => e.preventDefault()} onClick={() => add(c)}><span>{c.name} <span className="faint">· {c.code}</span></span><span className="faint">{c.phone || c.email}</span></button>)}
        </div>
      )}
      {ids.length > 0 && <div className="picker-chips">{ids.map((id) => <span key={id} className="picker-chip">{names[id] || `Customer #${id}`}<button type="button" aria-label={`Remove ${names[id] || id}`} onClick={() => onChange(ids.filter((x) => x !== id))}><X size={12} /></button></span>)}</div>}
      <small className="faint">{ids.length ? `${ids.length} customer(s) selected` : 'No customers selected yet'}</small>
    </div>
  );
}

/** Free-form email addresses (one per line or comma separated) for people who are not customers. */
function EmailListInput({ value, onChange }) {
  const [text, setText] = useState(Array.isArray(value) ? value.join(', ') : '');
  const parse = (t) => [...new Set(t.split(/[\s,;]+/).map((x) => x.trim().toLowerCase()).filter((x) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(x)))];
  const valid = parse(text);
  return <Textarea label="Email addresses" rows={3} value={text} placeholder="partner@example.com, someone@company.com" hint={`${valid.length} valid address(es) — one per line or comma separated (max 500). Only the Email channel applies to plain addresses.`}
    onChange={(e) => { setText(e.target.value); onChange(parse(e.target.value)); }} />;
}

export function AudiencePicker({ value, onChange, plans, external = true }) {
  return (
    <div className="col">
      <div className="grid g2">
        <Select label="Audience" value={value.type} onChange={(e) => onChange({ type: e.target.value, value: '' })} options={[
          { value: 'all_customers', label: 'All customers' }, { value: 'status', label: 'Customers by status' }, { value: 'plan', label: 'Customers by plan' },
          { value: 'area', label: 'Customers by area' }, { value: 'overdue', label: 'Customers with overdue invoices' }, { value: 'customers', label: 'Pick specific customers' },
          ...(external ? [{ value: 'staff', label: 'All staff & admins' }, { value: 'leads', label: 'CRM leads (not yet customers)' }, { value: 'emails', label: 'Any email addresses' }] : []),
        ]} />
        {value.type === 'status' && <Select label="Status" value={value.value} onChange={(e) => onChange({ ...value, value: e.target.value })} options={[{ value: '', label: 'Choose…' }, 'active', 'pending', 'suspended']} />}
        {value.type === 'plan' && <Select label="Plan" value={value.value} onChange={(e) => onChange({ ...value, value: e.target.value })} options={[{ value: '', label: 'Choose…' }, ...(plans || []).map((p) => ({ value: String(p.id), label: p.name }))]} />}
        {value.type === 'area' && <Input label="Area" value={value.value} onChange={(e) => onChange({ ...value, value: e.target.value })} />}
        {value.type === 'leads' && <Select label="Lead stage" value={value.value} onChange={(e) => onChange({ ...value, value: e.target.value })} options={[{ value: '', label: 'All open leads (not won/lost)' }, 'new', 'contacted', 'qualified', 'proposal', 'won', 'lost']} />}
      </div>
      {value.type === 'customers' && <CustomerPicker value={value.value} onChange={(v) => onChange({ ...value, value: v })} />}
      {value.type === 'emails' && <EmailListInput value={value.value} onChange={(v) => onChange({ ...value, value: v })} />}
      {['leads', 'emails'].includes(value.type) && <div className="alert info" style={{ margin: 0 }}><div>Leads and email addresses have no app account, so only <b>Email</b> (and SMS/WhatsApp for leads with a phone) are delivered.</div></div>}
    </div>
  );
}

function Compose() {
  const { toast } = useApp();
  const plans = useLoad(() => api('/plans'));
  const [audience, setAudience] = useState({ type: 'all_customers', value: '' });
  const [channels, setChannels] = useState(['inapp', 'push']);
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [design, setDesign] = useState(null);
  const [busy, setBusy] = useState(false);
  const send = async (e) => {
    e.preventDefault(); setBusy(true);
    try { const r = await api.post('/notifications/send', { audience: { ...audience, value: audience.value || undefined }, channels, subject, body, email_design: channels.includes('email') ? clean(design) : undefined }); toast(`Sending to ${r.queued} recipient(s)`); setSubject(''); setBody(''); }
    catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  return (
    <Card title="Send a custom notification">
      <form className="col" onSubmit={send}>
        <AudiencePicker value={audience} onChange={setAudience} plans={plans.data?.plans} />
        <div><div className="faint mb" style={{ marginBottom: 8, fontWeight: 600 }}>Channels</div><ChannelPicker value={channels} onChange={setChannels} /></div>
        <Input label="Title / subject" required maxLength={200} value={subject} onChange={(e) => setSubject(e.target.value)} />
        <Textarea label="Message" required rows={5} maxLength={5000} value={body} onChange={(e) => setBody(e.target.value)} hint="Use {{user.name}} and {{company}} for personalisation" />
        {channels.includes('email') && <EmailDesigner value={design} onChange={setDesign} subject={subject} body={body} />}
        <Button variant="primary" type="submit" icon={Send} loading={busy} disabled={!channels.length}>Send now</Button>
      </form>
    </Card>
  );
}

function Templates() {
  const { toast } = useApp();
  const { data, reload } = useLoad(() => api('/notifications/templates'));
  const [edit, setEdit] = useState(null);
  const save = async (e) => {
    e.preventDefault();
    try { const { id, template_key, updated_at, ...rest } = edit; await api.put(`/notifications/templates/${id}`, { ...rest, email_design: clean(rest.email_design) }); toast('Template saved'); setEdit(null); reload(); } catch (err) { toast(err.message, 'bad'); }
  };
  return (
    <>
      <Card className="flush">
        <DataTable rows={data?.templates} loading={!data} onRowClick={setEdit} columns={[
          { key: 'name', title: 'Template', render: (r) => <div><b>{r.name}</b><div className="faint mono">{r.template_key}</div></div> },
          { key: 'subject', title: 'Subject' },
          { key: 'channels', title: 'Channels', render: (r) => <div className="row wrap" style={{ gap: 4 }}>{r.channels.map((c) => <Badge key={c} kind="brand">{c}</Badge>)}</div> },
          { key: 'active', title: 'Active', render: (r) => <Badge kind={r.active ? 'ok' : 'info'}>{r.active ? 'on' : 'off'}</Badge> },
        ]} />
      </Card>
      <Modal wide open={!!edit} onClose={() => setEdit(null)} title={`Edit template · ${edit?.name || ''}`}>
        {edit && <form className="col" onSubmit={save}>
          <Input label="Name" value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
          <Input label="Subject" value={edit.subject || ''} onChange={(e) => setEdit({ ...edit, subject: e.target.value })} />
          <Textarea label="Body (email / in-app / WhatsApp)" rows={7} value={edit.body} onChange={(e) => setEdit({ ...edit, body: e.target.value })} />
          <Textarea label="Short text (SMS / push, max 640)" rows={2} maxLength={640} value={edit.sms_body || ''} onChange={(e) => setEdit({ ...edit, sms_body: e.target.value })} />
          <div><div className="faint" style={{ marginBottom: 8, fontWeight: 600 }}>Default channels</div><ChannelPicker value={edit.channels} onChange={(channels) => setEdit({ ...edit, channels })} /></div>
          <Toggle checked={edit.active} onChange={(active) => setEdit({ ...edit, active })} label="Active" />
          {edit.channels.includes('email') && <EmailDesigner value={edit.email_design} onChange={(email_design) => setEdit({ ...edit, email_design })} subject={edit.subject} body={edit.body} hint="Used every time this automatic email is sent (e.g. a Pay now button on invoice emails)." />}
          <div className="faint">Variables: {'{{user.name}} {{company}} {{invoice}} {{amount}} {{due_date}} {{plan}} {{ticket}} {{days}}'}</div>
          <Button variant="primary" type="submit">Save</Button>
        </form>}
      </Modal>
    </>
  );
}

function Reminders() {
  const { toast } = useApp();
  const { data, reload } = useLoad(() => api('/notifications/reminders'));
  const tpls = useLoad(() => api('/notifications/templates'));
  const [edit, setEdit] = useState(null);
  const save = async (e) => {
    e.preventDefault();
    const { id, created_at, ...rest } = edit;
    const p = { ...rest, offset_days: Number(rest.offset_days) };
    try { if (id) await api.put(`/notifications/reminders/${id}`, p); else await api.post('/notifications/reminders', p); toast('Reminder saved'); setEdit(null); reload(); } catch (err) { toast(err.message, 'bad'); }
  };
  return (
    <>
      <div className="row end mb"><Button variant="primary" icon={Plus} onClick={() => setEdit({ name: '', trigger_event: 'invoice_due', offset_days: 3, template_key: 'invoice_due', channels: ['email', 'inapp'], active: true })}>New reminder</Button></div>
      <Card className="flush">
        <DataTable rows={data?.rules} loading={!data} columns={[
          { key: 'name', title: 'Rule', render: (r) => <b>{r.name}</b> },
          { key: 'trigger_event', title: 'Trigger', render: (r) => `${label(r.trigger_event)} · ${r.offset_days} day(s) ${r.trigger_event === 'invoice_overdue' ? 'after' : 'before'}` },
          { key: 'template_key', title: 'Template', render: (r) => <span className="mono">{r.template_key}</span> },
          { key: 'channels', title: 'Channels', render: (r) => r.channels.join(', ') },
          { key: 'active', title: 'Active', render: (r) => <Badge kind={r.active ? 'ok' : 'info'}>{r.active ? 'on' : 'off'}</Badge> },
          { key: 'x', title: '', render: (r) => <div className="row"><Button size="sm" variant="ghost" icon={Pencil} onClick={() => setEdit(r)} aria-label="Edit" /><Button size="sm" variant="ghost" icon={Trash2} onClick={async () => { await api.del(`/notifications/reminders/${r.id}`); reload(); }} aria-label="Delete" /></div> },
        ]} />
      </Card>
      <Modal open={!!edit} onClose={() => setEdit(null)} title="Reminder rule">
        {edit && <form className="col" onSubmit={save}>
          <Input label="Name" required value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
          <div className="grid g2">
            <Select label="Trigger" value={edit.trigger_event} onChange={(e) => setEdit({ ...edit, trigger_event: e.target.value })} options={['invoice_due', 'invoice_overdue', 'plan_expiry']} />
            <Input label="Days" type="number" min={0} max={60} value={edit.offset_days} onChange={(e) => setEdit({ ...edit, offset_days: e.target.value })} />
          </div>
          <Select label="Template" value={edit.template_key} onChange={(e) => setEdit({ ...edit, template_key: e.target.value })} options={(tpls.data?.templates || []).map((t) => ({ value: t.template_key, label: t.name }))} />
          <ChannelPicker value={edit.channels} onChange={(channels) => setEdit({ ...edit, channels })} />
          <Toggle checked={edit.active} onChange={(active) => setEdit({ ...edit, active })} label="Active" />
          {edit.channels.includes('email') && <EmailDesigner value={edit.email_design} onChange={(email_design) => setEdit({ ...edit, email_design })} subject={edit.subject} body={edit.body} hint="Used every time this automatic email is sent (e.g. a Pay now button on invoice emails)." />}
          <Button variant="primary" type="submit">Save</Button>
        </form>}
      </Modal>
    </>
  );
}

function Log() {
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState('');
  const { data } = useLoad(() => api(`/notifications/log?page=${page}&status=${status}`), [page, status]);
  return (
    <>
      <div className="mb"><Tabs tabs={[{ value: '', label: 'All' }, 'sent', 'failed']} value={status} onChange={(v) => { setStatus(v); setPage(1); }} /></div>
      <Card className="flush">
        <DataTable rows={data?.rows} loading={!data} columns={[
          { key: 'created_at', title: 'When', render: (r) => dateTime(r.created_at) },
          { key: 'name', title: 'User' },
          { key: 'channel', title: 'Channel', render: (r) => <Badge kind="brand">{r.channel}</Badge> },
          { key: 'subject', title: 'Subject' },
          { key: 'status', title: 'Status', render: (r) => <Badge status={r.status} /> },
          { key: 'error', title: 'Error', render: (r) => <span className="faint">{r.error}</span> },
        ]} />
        {data && <Pager page={data.page} pageSize={data.pageSize} total={data.total} onPage={setPage} />}
      </Card>
    </>
  );
}

export default function Notify() {
  const { can, moduleOn } = useApp();
  const tabs = [moduleOn('notifications') && 'compose', can('notifications.manage') && 'templates', can('notifications.manage') && moduleOn('reminders') && 'reminders', can('notifications.manage') && 'delivery_log'].filter(Boolean);
  const [tab, setTab] = useState(tabs[0]);
  return (
    <Page title="Notifications" subtitle="Email, SMS, WhatsApp, push and in-app messaging">
      <div className="mb"><Tabs tabs={tabs} value={tab} onChange={setTab} /></div>
      {tab === 'compose' && <Compose />}
      {tab === 'templates' && <Templates />}
      {tab === 'reminders' && <Reminders />}
      {tab === 'delivery_log' && <Log />}
    </Page>
  );
}
