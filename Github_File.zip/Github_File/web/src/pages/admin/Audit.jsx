import { useState } from 'react';
import { api } from '../../lib/api.js';
import { dateTime } from '../../lib/format.js';
import { Badge, Card, DataTable, Page, Pager, useLoad } from '../../components/ui.jsx';

export default function Audit() {
  const [page, setPage] = useState(1);
  const [action, setAction] = useState('');
  const { data, loading } = useLoad(() => api(`/audit?page=${page}&pageSize=50&action=${encodeURIComponent(action)}`), [page, action]);
  return (
    <Page title="Audit log" subtitle="Every security-relevant action, who did it and from where">
      <div className="row mb"><input className="input" style={{ maxWidth: 280 }} placeholder="Filter by action prefix, e.g. auth. or customer." value={action} onChange={(e) => { setAction(e.target.value); setPage(1); }} aria-label="Filter" /></div>
      <Card className="flush">
        <DataTable loading={loading} rows={data?.rows} columns={[
          { key: 'created_at', title: 'When', render: (r) => dateTime(r.created_at) },
          { key: 'user_name', title: 'User', render: (r) => r.user_name ? <div>{r.user_name}<div className="faint">{r.user_email}</div></div> : <span className="faint">system</span> },
          { key: 'action', title: 'Action', render: (r) => <Badge kind={/fail|locked|reuse|delete/.test(r.action) ? 'bad' : 'brand'}>{r.action}</Badge> },
          { key: 'entity', title: 'Target', render: (r) => r.entity ? `${r.entity} #${r.entity_id}` : '—' },
          { key: 'ip', title: 'IP', render: (r) => <span className="mono">{r.ip}</span> },
          { key: 'meta', title: 'Details', render: (r) => r.meta ? <span className="faint mono" style={{ fontSize: 11 }}>{JSON.stringify(r.meta).slice(0, 120)}</span> : '' },
        ]} />
        {data && <Pager page={data.page} pageSize={data.pageSize} total={data.total} onPage={setPage} />}
      </Card>
    </Page>
  );
}
