import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Crosshair, MapPin, Maximize2, Plus, RefreshCw, Trash2, X } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { ago, label } from '../../lib/format.js';
import { Badge, Button, Card, Input, Modal, Page, Select, Spinner, Textarea, useLoad } from '../../components/ui.jsx';

const DHAKA = [23.8103, 90.4125];
const SITE_TYPES = ['pop', 'tower', 'box', 'splitter', 'olt', 'office'];
const SITE_ICON = { pop: 'P', tower: 'T', box: 'B', splitter: 'S', olt: 'O', office: 'H' };
const CATS = {
  online: { label: 'Online', color: 'var(--ok)', hex: '#10b981' },
  offline: { label: 'Offline', color: 'var(--text-3)', hex: '#8a87a6' },
  suspended: { label: 'Suspended', color: 'var(--bad)', hex: '#ef4444' },
  overdue: { label: 'Overdue', color: 'var(--warn)', hex: '#f59e0b' },
};
// Suspended wins over overdue (service already stopped), overdue over online/offline (needs attention).
const category = (c) => (c.status === 'suspended' ? 'suspended' : c.overdue ? 'overdue' : c.online ? 'online' : 'offline');

// Map chrome that has to follow the Aura theme (Leaflet ships light-only styles). Dark mode dims/inverts the OSM tiles.
const MAP_CSS = `
.nm-wrap { position: relative; border-radius: var(--radius-sm); overflow: hidden; border: 1px solid var(--border); }
.nm-map { height: calc(100vh - 290px); min-height: 440px; width: 100%; background: var(--bg-2); z-index: 0; }
@media (max-width: 720px) { .nm-map { height: 62vh; min-height: 360px; } }
[data-theme='dark'] .nm-map .leaflet-tile-pane { filter: invert(1) hue-rotate(180deg) brightness(.85) contrast(.9) saturate(.6); }
.nm-map .leaflet-popup-content-wrapper, .nm-map .leaflet-popup-tip { background: var(--surface-solid); color: var(--text); box-shadow: var(--shadow); }
.nm-map .leaflet-popup-content { margin: 12px 14px; font: 13px/1.45 var(--font); min-width: 180px; }
.nm-map .leaflet-popup-close-button { color: var(--text-3) !important; }
.nm-map .leaflet-control-zoom a, .nm-map .leaflet-bar a { background: var(--surface-solid); color: var(--text); border-color: var(--border); }
.nm-map .leaflet-control-attribution { background: color-mix(in srgb, var(--surface-solid) 80%, transparent); color: var(--text-2); }
.nm-map .leaflet-control-attribution a { color: var(--brand-1); }
.nm-map.picking { cursor: crosshair; }
.nm-map.picking .leaflet-interactive { cursor: crosshair; }
.nm-pop b { display: block; font-size: 14px; margin-bottom: 2px; }
.nm-pop .faint { color: var(--text-3); }
.nm-pop .nm-row { display: flex; gap: 6px; margin-top: 8px; flex-wrap: wrap; }
.nm-pop button, .nm-pop a.nm-btn { font: 600 12px var(--font); padding: 5px 10px; border-radius: 8px; border: 1px solid var(--border); background: var(--surface-2); color: var(--text); cursor: pointer; text-decoration: none; }
.nm-pop button.danger { color: var(--bad); }
.nm-site { display: grid; place-items: center; width: 26px; height: 26px; border-radius: 8px; background: var(--grad); color: #fff; font: 700 12px var(--font); border: 2px solid #fff; box-shadow: 0 2px 8px rgba(0,0,0,.35); }
.nm-site.olt, .nm-site.pop { border-radius: 50%; }
.nm-banner { position: absolute; z-index: 500; left: 50%; top: 12px; transform: translateX(-50%); max-width: calc(100% - 24px); display: flex; align-items: center; gap: 10px;
  padding: 8px 12px; border-radius: 12px; background: var(--surface-solid); border: 1px solid var(--border-strong); box-shadow: var(--shadow); font-size: 13px; font-weight: 600; }
.nm-legend { display: flex; flex-wrap: wrap; gap: 8px; }
.nm-dot { width: 10px; height: 10px; border-radius: 50%; display: inline-block; }
.nm-results { max-height: 240px; overflow: auto; border: 1px solid var(--border); border-radius: var(--radius-sm); }
.nm-results button { display: flex; width: 100%; justify-content: space-between; gap: 10px; padding: 9px 12px; background: none; border: 0; border-bottom: 1px solid var(--border); color: var(--text); text-align: left; cursor: pointer; font: inherit; }
.nm-results button:hover, .nm-results button:focus-visible { background: var(--surface-2); outline: none; }
`;

const el = (tag, props = {}, ...kids) => {
  const n = document.createElement(tag);
  Object.assign(n, props);
  kids.filter((k) => k !== null && k !== undefined && k !== false).forEach((k) => n.append(k instanceof Node ? k : document.createTextNode(String(k))));
  return n;
};

function SiteForm({ site, zones, onClose, onSaved }) {
  const { toast } = useApp();
  const [f, setF] = useState(site);
  const [busy, setBusy] = useState(false);
  const save = async (e) => {
    e.preventDefault(); setBusy(true);
    const body = { name: f.name, type: f.type, lat: Number(f.lat), lng: Number(f.lng), zone_id: f.zone_id ? Number(f.zone_id) : null, notes: f.notes || null };
    try {
      if (f.id) await api.put(`/ops/sites/${f.id}`, body); else await api.post('/ops/sites', body);
      toast(f.id ? 'Site updated' : 'Site added'); onSaved();
    } catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  return (
    <Modal open onClose={onClose} title={f.id ? 'Edit site' : 'New network site'}>
      <form className="col" onSubmit={save}>
        <Input label="Name" required maxLength={120} value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} autoFocus />
        <div className="grid g2">
          <Select label="Type" value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })} options={SITE_TYPES.map((t) => ({ value: t, label: t === 'olt' || t === 'pop' ? t.toUpperCase() : label(t).replace(/^./, (c) => c.toUpperCase()) }))} />
          <Select label="Zone" value={f.zone_id || ''} onChange={(e) => setF({ ...f, zone_id: e.target.value })} options={[{ value: '', label: '—' }, ...zones.map((z) => ({ value: z.id, label: z.name }))]} />
          <Input label="Latitude" type="number" step="any" min={-90} max={90} required value={f.lat} onChange={(e) => setF({ ...f, lat: e.target.value })} />
          <Input label="Longitude" type="number" step="any" min={-180} max={180} required value={f.lng} onChange={(e) => setF({ ...f, lng: e.target.value })} />
        </div>
        <Textarea label="Notes" maxLength={1000} value={f.notes || ''} onChange={(e) => setF({ ...f, notes: e.target.value })} />
        <div className="row end"><Button type="button" onClick={onClose}>Cancel</Button><Button variant="primary" type="submit" loading={busy}>Save</Button></div>
      </form>
    </Modal>
  );
}

/** Search a customer to place on the map. */
function CustomerPicker({ onPick, onClose }) {
  const [q, setQ] = useState('');
  const [rows, setRows] = useState(null);
  useEffect(() => {
    let alive = true;
    const t = setTimeout(async () => {
      try { const d = await api(`/customers?pageSize=15&q=${encodeURIComponent(q.trim())}`); if (alive) setRows(d.rows || []); } catch { if (alive) setRows([]); }
    }, 250);
    return () => { alive = false; clearTimeout(t); };
  }, [q]);
  return (
    <Modal open onClose={onClose} title="Place a customer on the map">
      <div className="col">
        <Input label="Find customer" placeholder="Name, code, phone, IP…" value={q} onChange={(e) => setQ(e.target.value)} autoFocus />
        {rows === null ? <Spinner /> : rows.length === 0 ? <div className="faint">No customers match.</div> : (
          <div className="nm-results" role="listbox" aria-label="Customers">
            {rows.map((c) => (
              <button key={c.id} type="button" role="option" aria-selected="false" onClick={() => onPick({ id: c.id, name: c.name, code: c.code })}>
                <span><b>{c.name}</b> <span className="faint">{c.code}</span></span>
                <span className="faint">{c.lat && c.lng ? 'placed' : 'not placed'}</span>
              </button>
            ))}
          </div>
        )}
        <p className="faint" style={{ margin: 0 }}>After choosing, click (or tap) the customer's location on the map.</p>
      </div>
    </Modal>
  );
}

export default function NetworkMap() {
  const { toast, can, moduleOn } = useApp();
  const nav = useNavigate();
  const [params, setParams] = useSearchParams();
  const { data, loading, error, reload } = useLoad(() => api('/ops/map'));
  const zones = useLoad(() => (moduleOn('zones') && (can('zones.manage') || can('customers.view')) ? api('/zones?lite=1').catch(() => ({ zones: [] })) : Promise.resolve({ zones: [] })));
  const [show, setShow] = useState({ online: true, offline: true, suspended: true, overdue: true, sites: true });
  const [mode, setMode] = useState(null); // null | { kind: 'site' } | { kind: 'place', customer }
  const [picking, setPicking] = useState(false);
  const [siteForm, setSiteForm] = useState(null);
  const [delSite, setDelSite] = useState(null);
  const mapEl = useRef(null); const map = useRef(null); const layers = useRef(null);
  const modeRef = useRef(mode); modeRef.current = mode;
  const fitted = useRef(false);
  const canSites = can('network.manage'); const canPlace = can('customers.edit');

  // ?place=<customerId> (from the customer page) starts "place customer" mode directly.
  useEffect(() => {
    const id = Number(params.get('place'));
    if (!id || !canPlace) return;
    api(`/customers/${id}`).then((d) => setMode({ kind: 'place', customer: { id, name: d.customer.name, code: d.customer.code } }))
      .catch((e) => toast(e.message, 'bad'));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const counts = useMemo(() => {
    const out = { online: 0, offline: 0, suspended: 0, overdue: 0 };
    (data?.customers || []).forEach((c) => { out[category(c)]++; });
    return out;
  }, [data]);

  // Create the map once.
  useEffect(() => {
    if (!mapEl.current || map.current) return undefined;
    const m = L.map(mapEl.current, { center: DHAKA, zoom: 12, worldCopyJump: true, preferCanvas: true });
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19, subdomains: 'abc', attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> contributors',
    }).addTo(m);
    layers.current = { customers: L.layerGroup().addTo(m), sites: L.layerGroup().addTo(m) };
    m.on('click', (e) => onMapClick(e.latlng));
    map.current = m;
    // The container can change size (sidebar, orientation): keep tiles aligned.
    const ro = new ResizeObserver(() => m.invalidateSize());
    ro.observe(mapEl.current);
    return () => { ro.disconnect(); m.remove(); map.current = null; layers.current = null; };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  async function onMapClick({ lat, lng }) {
    const md = modeRef.current;
    if (!md) return;
    const la = Math.round(lat * 1e6) / 1e6; const ln = Math.round(L.Util.wrapNum(lng, [-180, 180], true) * 1e6) / 1e6;
    if (md.kind === 'site') { setSiteForm({ name: '', type: 'pop', lat: la, lng: ln, zone_id: '', notes: '' }); setMode(null); return; }
    if (md.kind === 'place') {
      try {
        await api.put(`/ops/customers/${md.customer.id}/location`, { lat: la, lng: ln });
        toast(`${md.customer.name} placed on the map`);
        setMode(null);
        if (params.get('place')) { params.delete('place'); setParams(params, { replace: true }); }
        reload();
      } catch (e) { toast(e.message, 'bad'); }
    }
  }

  const removeLocation = async (c) => {
    try { await api.put(`/ops/customers/${c.id}/location`, { lat: null, lng: null }); toast('Location removed'); reload(); } catch (e) { toast(e.message, 'bad'); }
  };

  // Draw markers whenever data or layer toggles change.
  useEffect(() => {
    const m = map.current; const g = layers.current;
    if (!m || !g || !data) return;
    g.customers.clearLayers(); g.sites.clearLayers();
    for (const c of data.customers) {
      const cat = category(c);
      if (!show[cat]) continue;
      const mk = L.circleMarker([c.lat, c.lng], { radius: 7, color: '#fff', weight: 2, fillColor: CATS[cat].hex, fillOpacity: 0.95 });
      mk.bindTooltip(`${c.name} · ${c.code}`, { direction: 'top', offset: [0, -6] });
      mk.bindPopup(() => {
        const open = el('a', { href: `/admin/customers/${c.id}`, className: 'nm-btn', textContent: 'Open customer' });
        open.addEventListener('click', (e) => { e.preventDefault(); nav(`/admin/customers/${c.id}`); });
        const row = el('div', { className: 'nm-row' }, open);
        if (canPlace) {
          const move = el('button', { type: 'button', textContent: 'Move' });
          move.addEventListener('click', () => { m.closePopup(); setMode({ kind: 'place', customer: { id: c.id, name: c.name, code: c.code } }); });
          const clear = el('button', { type: 'button', className: 'danger', textContent: 'Remove pin' });
          clear.addEventListener('click', () => { m.closePopup(); removeLocation(c); });
          row.append(move, clear);
        }
        return el('div', { className: 'nm-pop' },
          el('b', {}, c.name),
          el('div', { className: 'faint' }, `${c.code}${c.plan_name ? ` · ${c.plan_name}` : ''}`),
          el('div', {}, `${CATS[cat].label}${c.status !== 'active' && cat !== 'suspended' ? ` · ${label(c.status)}` : ''}${c.ip_address ? ` · ${c.ip_address}` : ''}`),
          c.address ? el('div', { className: 'faint' }, c.address) : null,
          c.phone ? el('div', { className: 'faint' }, c.phone) : null,
          row);
      });
      mk.addTo(g.customers);
    }
    if (show.sites) {
      for (const s of data.sites) {
        const icon = L.divIcon({ className: '', html: `<div class="nm-site ${s.type}">${SITE_ICON[s.type] || '•'}</div>`, iconSize: [26, 26], iconAnchor: [13, 13], popupAnchor: [0, -12] });
        const mk = L.marker([s.lat, s.lng], { icon, keyboard: true, title: s.name, riseOnHover: true });
        mk.bindPopup(() => {
          const row = el('div', { className: 'nm-row' });
          if (canSites) {
            const edit = el('button', { type: 'button', textContent: 'Edit' });
            edit.addEventListener('click', () => { m.closePopup(); setSiteForm({ ...s, zone_id: s.zone_id || '' }); });
            const del = el('button', { type: 'button', className: 'danger', textContent: 'Delete' });
            del.addEventListener('click', () => { m.closePopup(); setDelSite(s); });
            row.append(edit, del);
          }
          return el('div', { className: 'nm-pop' },
            el('b', {}, s.name),
            el('div', { className: 'faint' }, `${s.type.toUpperCase()} · ${s.lat.toFixed(5)}, ${s.lng.toFixed(5)}`),
            s.notes ? el('div', {}, s.notes) : null,
            canSites ? row : null);
        });
        mk.addTo(g.sites);
      }
    }
    if (!fitted.current) { fitted.current = true; fitAll(); }
  }, [data, show]); // eslint-disable-line react-hooks/exhaustive-deps

  function fitAll() {
    const m = map.current; if (!m || !data) return;
    const pts = [...data.customers.filter((c) => show[category(c)]).map((c) => [c.lat, c.lng]), ...(show.sites ? data.sites.map((s) => [s.lat, s.lng]) : [])];
    if (!pts.length) { m.setView(DHAKA, 12); return; }
    if (pts.length === 1) { m.setView(pts[0], 16); return; }
    m.fitBounds(L.latLngBounds(pts), { padding: [40, 40], maxZoom: 17 });
  }

  const locateMe = () => {
    if (!navigator.geolocation) { toast('Location is not available on this device', 'bad'); return; }
    navigator.geolocation.getCurrentPosition((p) => map.current?.setView([p.coords.latitude, p.coords.longitude], 17),
      () => toast('Could not get your location', 'bad'), { enableHighAccuracy: true, timeout: 10000 });
  };

  const toggle = (k) => setShow((s) => ({ ...s, [k]: !s[k] }));
  const deleteSite = async () => {
    try { await api.del(`/ops/sites/${delSite.id}`); toast('Site deleted'); setDelSite(null); reload(); } catch (e) { toast(e.message, 'bad'); }
  };

  return (
    <Page title="Network map" subtitle={data ? `${data.customers.length} customers on the map · ${data.sites.length} sites${data.unplaced ? ` · ${data.unplaced} without a location` : ''}${data.liveAt ? ` · live ${ago(data.liveAt)}` : ''}` : 'Customers and network sites'}
      actions={<>
        <Button icon={RefreshCw} onClick={reload} loading={loading && !!data}>Refresh</Button>
        {canPlace && <Button icon={MapPin} onClick={() => setPicking(true)}>Place customer</Button>}
        {canSites && <Button variant="primary" icon={Plus} onClick={() => setMode({ kind: 'site' })}>Add site</Button>}
      </>}>
      <style>{MAP_CSS}</style>
      {error && <div className="alert bad mb">Could not load the map: {error.message}</div>}
      <Card>
        <div className="row between wrap mb" style={{ gap: 10 }}>
          <div className="nm-legend" role="group" aria-label="Map layers">
            {Object.entries(CATS).map(([k, c]) => (
              <button key={k} type="button" className={`chip ${show[k] ? '' : 'off'}`} aria-pressed={show[k]} onClick={() => toggle(k)} style={{ opacity: show[k] ? 1 : 0.5 }}>
                <span className="nm-dot" style={{ background: c.color }} /> {c.label} <span className="faint">{counts[k]}</span>
              </button>
            ))}
            <button type="button" className="chip" aria-pressed={show.sites} onClick={() => toggle('sites')} style={{ opacity: show.sites ? 1 : 0.5 }}>
              <span className="nm-dot" style={{ background: 'var(--brand-1)', borderRadius: 3 }} /> Sites <span className="faint">{data?.sites.length ?? 0}</span>
            </button>
          </div>
          <div className="row">
            <Button size="sm" icon={Crosshair} onClick={locateMe} aria-label="Go to my location" title="My location" />
            <Button size="sm" icon={Maximize2} onClick={fitAll}>Fit all</Button>
          </div>
        </div>
        <div className="nm-wrap">
          {mode && (
            <div className="nm-banner" role="status">
              {mode.kind === 'site' ? <Plus size={16} /> : <MapPin size={16} />}
              <span>{mode.kind === 'site' ? 'Click the map where the new site is' : `Click the location of ${mode.customer.name} (${mode.customer.code})`}</span>
              <Button size="sm" variant="ghost" icon={X} onClick={() => setMode(null)} aria-label="Cancel" />
            </div>
          )}
          <div ref={mapEl} className={`nm-map ${mode ? 'picking' : ''}`} role="application" aria-label="Network map" />
        </div>
        <div className="row wrap mt faint" style={{ gap: 14 }}>
          {SITE_TYPES.map((t) => <span key={t} className="row" style={{ gap: 6 }}><span className={`nm-site ${t}`} style={{ width: 20, height: 20, fontSize: 10, borderWidth: 1 }}>{SITE_ICON[t]}</span>{t === 'olt' || t === 'pop' ? t.toUpperCase() : label(t)}</span>)}
          {data && !data.customers.length && <Badge kind="info">No customer has a location yet — use “Place customer”.</Badge>}
        </div>
      </Card>
      {picking && <CustomerPicker onClose={() => setPicking(false)} onPick={(customer) => { setPicking(false); setMode({ kind: 'place', customer }); }} />}
      {siteForm && <SiteForm site={siteForm} zones={zones.data?.zones || []} onClose={() => setSiteForm(null)} onSaved={() => { setSiteForm(null); reload(); }} />}
      <Modal open={!!delSite} onClose={() => setDelSite(null)} title="Delete site?" footer={<>
        <Button onClick={() => setDelSite(null)}>Cancel</Button><Button variant="danger" icon={Trash2} onClick={deleteSite}>Delete</Button>
      </>}>
        <div className="muted">“{delSite?.name}” will be removed from the map.</div>
      </Modal>
    </Page>
  );
}
