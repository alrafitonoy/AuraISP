import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { useSearchParams } from 'react-router-dom';
import { Save, Upload, Send, Plus, Trash2 } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { Button, Card, Input, Page, Select, Spinner, Tabs, Textarea, Toggle, useLoad } from '../../components/ui.jsx';
import EmailDesigner from '../../components/EmailDesigner.jsx';

const MASK = '••••••••';

function Section({ title, children, hint }) {
  return <Card title={title} className="mb">{hint && <p className="faint" style={{ marginTop: -6 }}>{hint}</p>}<div className="col">{children}</div></Card>;
}
// A stored secret is shown as a mask. Focusing the field clears it so new input REPLACES the secret (typing after the
// mask used to save "••••••••newkey" as the key); leaving it empty puts the mask back = keep the stored value.
function Secret({ value, onChange, ...p }) {
  const stored = useRef(false); // is a secret saved on the server? (true whenever the server has shown us its mask)
  if (value === MASK) stored.current = true;
  const emit = (e, v) => onChange({ ...e, target: { ...e.target, value: v } });
  return (
    <Input type="password" autoComplete="new-password" placeholder={stored.current ? 'unchanged' : ''} value={value} onChange={onChange} {...p}
      onFocus={(e) => { if (value === MASK) emit(e, ''); }}
      onBlur={(e) => { if (stored.current && e.target.value === '') emit(e, MASK); }} />
  );
}

function Branding({ v, set }) {
  const { toast } = useApp();
  const upload = async (key, file) => {
    if (!file) return;
    const form = new FormData(); form.append('file', file);
    try { const r = await api('/settings/upload', { method: 'POST', form }); set({ [key]: r.url }); toast('Uploaded — remember to save'); } catch (e) { toast(e.message, 'bad'); }
  };
  return (
    <>
      <Section title="Identity">
        <div className="grid g2">
          <Input label="Company name" value={v.companyName} onChange={(e) => set({ companyName: e.target.value })} />
          <Input label="Tagline" value={v.tagline} onChange={(e) => set({ tagline: e.target.value })} />
        </div>
        <div className="grid g2">
          {[['logoUrl', 'Logo'], ['faviconUrl', 'Favicon']].map(([k, l]) => (
            <div key={k} className="col">
              <Input label={`${l} URL`} value={v[k]} onChange={(e) => set({ [k]: e.target.value })} hint="https:// URL or upload a PNG/JPG/WEBP/ICO (max 2 MB)" />
              <div className="row">{v[k] && <img src={v[k]} alt="" style={{ height: 40, maxWidth: 160, objectFit: 'contain', background: 'var(--surface-2)', borderRadius: 8, padding: 4 }} />}<label className="btn sm"><Upload size={14} /> Upload<input type="file" accept="image/png,image/jpeg,image/webp,image/x-icon" hidden onChange={(e) => upload(k, e.target.files[0])} /></label></div>
            </div>
          ))}
        </div>
      </Section>
      <Section title="Colours & theme" hint="The Aura theme derives gradients, glows and charts from these three colours.">
        <div className="grid g3">
          {[['primary', 'Primary'], ['secondary', 'Secondary'], ['accent', 'Accent']].map(([k, l]) => (
            <label key={k} className="field"><span>{l}</span><div className="row"><input type="color" value={v[k]} onChange={(e) => set({ [k]: e.target.value })} style={{ width: 48, height: 42, border: 'none', background: 'none', cursor: 'pointer' }} aria-label={l} /><input className="input mono" value={v[k]} onChange={(e) => set({ [k]: e.target.value })} maxLength={7} /></div></label>
          ))}
        </div>
        <motion.div className="card" style={{ background: `linear-gradient(120deg, ${v.primary}, ${v.secondary} 55%, ${v.accent})`, color: '#fff', textAlign: 'center', padding: 28 }} layout>
          <b style={{ fontSize: 22, fontFamily: 'var(--font-display)' }}>{v.companyName}</b><div style={{ opacity: .9 }}>{v.tagline}</div>
        </motion.div>
        <Select label="Default theme for visitors" value={v.defaultTheme} onChange={(e) => set({ defaultTheme: e.target.value })} options={['system', 'light', 'dark']} />
        <Select label="Show in the header, website and emails" value={v.logoDisplay || 'both'} onChange={(e) => set({ logoDisplay: e.target.value })}
          hint="Without an uploaded logo, a default icon is used for “Logo only”, and the name for emails."
          options={[{ value: 'both', label: 'Logo and company name' }, { value: 'logo', label: 'Logo only' }, { value: 'name', label: 'Company name only' }]} />
      </Section>
    </>
  );
}

function Company({ v, set }) {
  return (
    <Section title="Company & invoicing">
      <div className="grid g2">
        <Input label="Legal name" value={v.legalName} onChange={(e) => set({ legalName: e.target.value })} />
        <Input label="Support email" type="email" value={v.email} onChange={(e) => set({ email: e.target.value })} />
        <Input label="Phone" value={v.phone} onChange={(e) => set({ phone: e.target.value })} />
        <Input label="Website" value={v.website} onChange={(e) => set({ website: e.target.value })} />
        <Input label="Address" value={v.address} onChange={(e) => set({ address: e.target.value })} />
        <Input label="Tax / BIN number" value={v.taxId} onChange={(e) => set({ taxId: e.target.value })} />
        <Input label="Currency code" value={v.currency} maxLength={3} onChange={(e) => set({ currency: e.target.value.toUpperCase() })} />
        <Input label="Currency symbol" value={v.currencySymbol} maxLength={5} onChange={(e) => set({ currencySymbol: e.target.value })} />
        <Input label="Tax / VAT %" type="number" min={0} max={100} step="0.01" value={v.taxPercent} onChange={(e) => set({ taxPercent: Number(e.target.value) })} />
        <Input label="Invoice prefix" value={v.invoicePrefix} onChange={(e) => set({ invoicePrefix: e.target.value.toUpperCase() })} />
        <Input label="Timezone" value={v.timezone} onChange={(e) => set({ timezone: e.target.value })} />
        <Input label="Locale" value={v.locale} onChange={(e) => set({ locale: e.target.value })} />
      </div>
    </Section>
  );
}

function Modules({ v, set, catalog }) {
  return (
    <Section title="Modules" hint="Turn features on or off. Disabled modules disappear from every app and their APIs are blocked.">
      <div className="grid g2">
        {Object.entries(catalog).map(([k, m]) => <div key={k} className="card" style={{ padding: '10px 16px' }}><Toggle checked={v[k] !== false} onChange={(on) => set({ [k]: on })} label={m.label} hint={m.description} /></div>)}
      </div>
    </Section>
  );
}

function BillingCfg({ v, set }) {
  return (
    <Section title="Billing automation">
      <div className="grid g2">
        <Input label="Generate invoices N days before renewal" type="number" min={0} max={30} value={v.generateDaysBefore} onChange={(e) => set({ generateDaysBefore: Number(e.target.value) })} />
        <Input label="Payment due after (days) for manual invoices" type="number" min={0} max={90} value={v.dueDays} onChange={(e) => set({ dueDays: Number(e.target.value) })} />
        <Input label="Grace period before suspension (days)" type="number" min={0} max={90} value={v.graceDays} onChange={(e) => set({ graceDays: Number(e.target.value) })} />
      </div>
      <Toggle checked={v.autoSuspend} onChange={(x) => set({ autoSuspend: x })} label="Auto-suspend overdue customers" hint="Service resumes automatically when they pay" />
      <Toggle checked={v.prorate} onChange={(x) => set({ prorate: x })} label="Prorate mid-cycle upgrades" />
      <Toggle checked={v.emailPdf !== false} onChange={(x) => set({ emailPdf: x })} label="Attach PDF invoice / receipt to billing emails" hint="New-invoice emails carry the invoice PDF; payment emails carry a receipt PDF." />
      <h3 className="mt">Subscription stop rules</h3>
      <p className="faint" style={{ marginTop: 0 }}>Service is suspended only when ALL of these are true (after the grace period). Individual customers can be exempted with a manual override on their page.</p>
      <div className="grid g2">
        <Input label="Minimum overdue invoices" type="number" min={1} max={24} value={v.suspendMinOverdueInvoices} onChange={(e) => set({ suspendMinOverdueInvoices: Number(e.target.value) })} />
        <Input label="Minimum overdue amount (0 = any)" type="number" min={0} step="0.01" value={(v.suspendMinOverdueCents || 0) / 100} onChange={(e) => set({ suspendMinOverdueCents: Math.round(Number(e.target.value) * 100) })} />
        <Input label="Warn customers N days before suspension" type="number" min={0} max={30} value={v.warnBeforeSuspendDays} onChange={(e) => set({ warnBeforeSuspendDays: Number(e.target.value) })} />
        <Input label="Auto-terminate after N days overdue (0 = never)" type="number" min={0} max={365} value={v.terminateAfterDays} onChange={(e) => set({ terminateAfterDays: Number(e.target.value) })} />
      </div>
    </Section>
  );
}

function Enforcement({ v, set }) {
  return (
    <Section title="Bandwidth & data enforcement" hint="Guarantees that no customer uses more speed or data than their package or the limit you set.">
      <Toggle checked={v.strictSpeed} onChange={(x) => set({ strictSpeed: x })} label="Strict speed enforcement" hint="Every minute live speeds are compared with each customer's limit; anyone above it gets the router limit re-applied immediately (logged)." />
      <Input label="Measurement tolerance (%)" type="number" min={0} max={50} value={v.speedTolerancePct} onChange={(e) => set({ speedTolerancePct: Number(e.target.value) })} hint="Small allowance for counter jitter before something counts as a violation" />
      <Select label="When a monthly data cap is used up" value={v.dataCapAction} onChange={(e) => set({ dataCapAction: e.target.value })} options={[{ value: 'throttle', label: 'Throttle speed until next month (fair usage)' }, { value: 'suspend', label: 'Pause service until next month' }]} />
      {v.dataCapAction === 'throttle' && <Input label="Throttled speed (Kbps)" type="number" min={64} value={v.throttleKbps} onChange={(e) => set({ throttleKbps: Number(e.target.value) })} />}
      <p className="faint">Data caps are set per plan (Plans → Data cap). Router queues are created without burst, so the package speed is a hard ceiling.</p>
    </Section>
  );
}

function Security({ v, set }) {
  return (
    <Section title="Security policy">
      <div className="grid g2">
        <Input label="Minimum password length" type="number" min={8} max={64} value={v.passwordMinLength} onChange={(e) => set({ passwordMinLength: Number(e.target.value) })} />
        <Input label="Failed logins before lock" type="number" min={3} max={20} value={v.maxLoginAttempts} onChange={(e) => set({ maxLoginAttempts: Number(e.target.value) })} />
        <Input label="Lock duration (minutes)" type="number" min={1} max={1440} value={v.lockMinutes} onChange={(e) => set({ lockMinutes: Number(e.target.value) })} />
        <Input label="Session lifetime (days)" type="number" min={1} max={365} value={v.sessionDays} onChange={(e) => set({ sessionDays: Number(e.target.value) })} />
      </div>
      <Toggle checked={v.requireEmailVerification} onChange={(x) => set({ requireEmailVerification: x })} label="Require email verification for customers" />
      <Toggle checked={v.requirePhoneVerification} onChange={(x) => set({ requirePhoneVerification: x })} label="Require phone (SMS) verification for customers" />
      <Toggle checked={v.require2faForStaff} onChange={(x) => set({ require2faForStaff: x })} label="Require two-factor authentication for all staff" />
    </Section>
  );
}

function Integrations({ v, set }) {
  const { toast } = useApp();
  const sub = (k) => (patch) => set({ [k]: { ...v[k], ...patch } });
  const pay = (k) => (patch) => set({ payments: { ...v.payments, [k]: { ...v.payments[k], ...patch } } });
  const test = async (channel) => { try { const r = await api.post('/notifications/test', { channel }); toast(r.status === 'sent' ? `Test ${channel} sent to you` : `Failed: ${r.error}`, r.status === 'sent' ? 'ok' : 'bad'); } catch (e) { toast(e.message, 'bad'); } };
  const s = v.smtp; const sms = v.sms; const w = v.whatsapp; const p = v.payments;
  return (
    <>
      <Section title="Email (SMTP)" hint="Save first, then send a test to your own address.">
        <div className="grid g3">
          <Input label="Host" value={s.host} onChange={(e) => sub('smtp')({ host: e.target.value })} placeholder="smtp.gmail.com" />
          <Input label="Port" type="number" value={s.port} onChange={(e) => sub('smtp')({ port: Number(e.target.value) })} />
          <Input label="From" value={s.from} onChange={(e) => sub('smtp')({ from: e.target.value })} placeholder="AuraNet <billing@example.com>" />
          <Input label="Username" value={s.user} onChange={(e) => sub('smtp')({ user: e.target.value })} />
          <Secret label="Password" value={s.pass} onChange={(e) => sub('smtp')({ pass: e.target.value })} />
          <div className="field"><span>&nbsp;</span><Toggle checked={s.secure} onChange={(x) => sub('smtp')({ secure: x })} label="SSL/TLS (port 465)" /></div>
        </div>
        <Button size="sm" icon={Send} onClick={() => test('email')} style={{ alignSelf: 'flex-start' }}>Send test email</Button>
      </Section>
      <Section title="SMS">
        <Select label="Provider" value={sms.provider} onChange={(e) => sub('sms')({ provider: e.target.value })} options={[{ value: 'none', label: 'Disabled' }, { value: 'twilio', label: 'Twilio' }, { value: 'http', label: 'Generic HTTP gateway (local bulk-SMS providers)' }]} />
        {sms.provider === 'twilio' && <div className="grid g3"><Input label="Account SID" value={sms.twilioSid} onChange={(e) => sub('sms')({ twilioSid: e.target.value })} /><Secret label="Auth token" value={sms.twilioToken} onChange={(e) => sub('sms')({ twilioToken: e.target.value })} /><Input label="From number" value={sms.from} onChange={(e) => sub('sms')({ from: e.target.value })} /></div>}
        {sms.provider === 'http' && <>
          <div className="grid g2"><Select label="Method" value={sms.httpMethod} onChange={(e) => sub('sms')({ httpMethod: e.target.value })} options={['GET', 'POST']} /><Secret label="API key" value={sms.httpApiKey} onChange={(e) => sub('sms')({ httpApiKey: e.target.value })} /></div>
          <Input label="URL" value={sms.httpUrl} onChange={(e) => sub('sms')({ httpUrl: e.target.value })} placeholder="https://api.provider.com/send?api_key={apikey}&to={to}&msg={message}&sender={from}" hint="Placeholders: {to} {message} {from} {apikey}" />
          {sms.httpMethod === 'POST' && <Textarea label="JSON body" value={sms.httpBody} onChange={(e) => sub('sms')({ httpBody: e.target.value })} placeholder='{"to":"{to}","text":"{message}","key":"{apikey}"}' />}
          <Input label="Sender ID" value={sms.from} onChange={(e) => sub('sms')({ from: e.target.value })} />
        </>}
        <Button size="sm" icon={Send} onClick={() => test('sms')} style={{ alignSelf: 'flex-start' }}>Send test SMS</Button>
      </Section>
      <Section title="WhatsApp">
        <Select label="Provider" value={w.provider} onChange={(e) => sub('whatsapp')({ provider: e.target.value })} options={[{ value: 'none', label: 'Disabled' }, { value: 'meta', label: 'Meta WhatsApp Cloud API' }, { value: 'twilio', label: 'Twilio WhatsApp' }]} />
        {w.provider === 'meta' && <div className="grid g2"><Input label="Phone number ID" value={w.metaPhoneId} onChange={(e) => sub('whatsapp')({ metaPhoneId: e.target.value })} /><Secret label="Access token" value={w.metaToken} onChange={(e) => sub('whatsapp')({ metaToken: e.target.value })} /></div>}
        {w.provider === 'twilio' && <div className="grid g3"><Input label="Account SID" value={w.twilioSid} onChange={(e) => sub('whatsapp')({ twilioSid: e.target.value })} /><Secret label="Auth token" value={w.twilioToken} onChange={(e) => sub('whatsapp')({ twilioToken: e.target.value })} /><Input label="WhatsApp number" value={w.from} onChange={(e) => sub('whatsapp')({ from: e.target.value })} /></div>}
        <Button size="sm" icon={Send} onClick={() => test('whatsapp')} style={{ alignSelf: 'flex-start' }}>Send test WhatsApp</Button>
      </Section>
      <Section title="Push notifications" hint="Web push uses VAPID keys generated at setup. For the mobile app, paste your Firebase service-account JSON.">
        <Textarea label="Firebase service account JSON" rows={4} value={v.push.fcmServiceAccount} onChange={(e) => sub('push')({ fcmServiceAccount: e.target.value })} placeholder={v.push.fcmServiceAccount === MASK ? 'configured (hidden)' : '{ "type": "service_account", ... }'} />
        <Button size="sm" icon={Send} onClick={() => test('push')} style={{ alignSelf: 'flex-start' }}>Send test push</Button>
      </Section>
      <Section title="Online payments">
        <Card><Toggle checked={p.bkash.enabled} onChange={(x) => pay('bkash')({ enabled: x })} label="bKash (Tokenized Checkout)" />
          {p.bkash.enabled && <div className="grid g2 mt"><Input label="App key" value={p.bkash.appKey} onChange={(e) => pay('bkash')({ appKey: e.target.value })} /><Secret label="App secret" value={p.bkash.appSecret} onChange={(e) => pay('bkash')({ appSecret: e.target.value })} /><Input label="Username" value={p.bkash.username} onChange={(e) => pay('bkash')({ username: e.target.value })} /><Secret label="Password" value={p.bkash.password} onChange={(e) => pay('bkash')({ password: e.target.value })} /><Toggle checked={p.bkash.sandbox} onChange={(x) => pay('bkash')({ sandbox: x })} label="Sandbox mode" /></div>}
        </Card>
        <Card><Toggle checked={p.sslcommerz.enabled} onChange={(x) => pay('sslcommerz')({ enabled: x })} label="SSLCommerz (cards, mobile banking, net banking)" />
          {p.sslcommerz.enabled && <div className="grid g2 mt"><Input label="Store ID" value={p.sslcommerz.storeId} onChange={(e) => pay('sslcommerz')({ storeId: e.target.value })} /><Secret label="Store password" value={p.sslcommerz.storePassword} onChange={(e) => pay('sslcommerz')({ storePassword: e.target.value })} /><Toggle checked={p.sslcommerz.sandbox} onChange={(x) => pay('sslcommerz')({ sandbox: x })} label="Sandbox mode" /></div>}
        </Card>
        <Card><Toggle checked={p.stripe.enabled} onChange={(x) => pay('stripe')({ enabled: x })} label="Stripe Checkout (international cards)" />
          {p.stripe.enabled && <div className="grid g3 mt"><Input label="Publishable key" value={p.stripe.publishableKey} onChange={(e) => pay('stripe')({ publishableKey: e.target.value })} /><Secret label="Secret key" value={p.stripe.secretKey} onChange={(e) => pay('stripe')({ secretKey: e.target.value })} /><Secret label="Webhook signing secret" value={p.stripe.webhookSecret} onChange={(e) => pay('stripe')({ webhookSecret: e.target.value })} /></div>}
          {p.stripe.enabled && <div className="faint mt">Webhook URL: <span className="mono">{window.location.origin}/api/billing/webhooks/stripe</span> (event: checkout.session.completed)</div>}
        </Card>
        <Card><Toggle checked={p.manual.enabled} onChange={(x) => pay('manual')({ enabled: x })} label="Offline payment instructions" />
          {p.manual.enabled && <Textarea label="Instructions shown to customers" value={p.manual.instructions} onChange={(e) => pay('manual')({ instructions: e.target.value })} />}
        </Card>
      </Section>
      <Section title="Social media" hint="Used by CRM campaigns to publish posts to your Facebook page.">
        <div className="grid g2"><Input label="Facebook page ID" value={v.social.facebookPageId} onChange={(e) => sub('social')({ facebookPageId: e.target.value })} /><Secret label="Page access token" value={v.social.facebookToken} onChange={(e) => sub('social')({ facebookToken: e.target.value })} /></div>
      </Section>
    </>
  );
}

function Website({ v, set }) {
  return (
    <>
      <Section title="Hero">
        <Input label="Headline" value={v.hero.title} onChange={(e) => set({ hero: { ...v.hero, title: e.target.value } })} />
        <Textarea label="Sub-headline" value={v.hero.subtitle} onChange={(e) => set({ hero: { ...v.hero, subtitle: e.target.value } })} />
        <div className="grid g2"><Input label="Button text" value={v.hero.cta} onChange={(e) => set({ hero: { ...v.hero, cta: e.target.value } })} /><Input label="Announcement bar" value={v.announcement} onChange={(e) => set({ announcement: e.target.value })} /></div>
      </Section>
      <Section title="Feature highlights" hint="Icon names come from lucide.dev (e.g. Zap, ShieldCheck, Headphones, Gauge, Wifi).">
        {v.features.map((f, i) => (
          <div key={i} className="row" style={{ alignItems: 'flex-end' }}>
            <div style={{ width: 140 }}><Input label={i === 0 ? 'Icon' : undefined} value={f.icon} onChange={(e) => set({ features: v.features.map((x, j) => (j === i ? { ...x, icon: e.target.value } : x)) })} /></div>
            <div style={{ width: 200 }}><Input label={i === 0 ? 'Title' : undefined} value={f.title} onChange={(e) => set({ features: v.features.map((x, j) => (j === i ? { ...x, title: e.target.value } : x)) })} /></div>
            <div className="grow"><Input label={i === 0 ? 'Text' : undefined} value={f.text} onChange={(e) => set({ features: v.features.map((x, j) => (j === i ? { ...x, text: e.target.value } : x)) })} /></div>
            <Button variant="ghost" icon={Trash2} onClick={() => set({ features: v.features.filter((_, j) => j !== i) })} aria-label="Remove" />
          </div>
        ))}
        <Button size="sm" icon={Plus} onClick={() => set({ features: [...v.features, { icon: 'Zap', title: '', text: '' }] })} style={{ alignSelf: 'flex-start' }}>Add feature</Button>
      </Section>
      <Section title="Coverage areas">
        <Textarea label="One area per line" rows={6} value={v.coverageAreas.join('\n')} onChange={(e) => set({ coverageAreas: e.target.value.split('\n').map((s) => s.trim()).filter(Boolean) })} />
      </Section>
      <Section title="Social links">
        <div className="grid g2">{['facebook', 'instagram', 'youtube', 'whatsapp'].map((k) => <Input key={k} label={k} value={v.social[k] || ''} onChange={(e) => set({ social: { ...v.social, [k]: e.target.value } })} />)}</div>
      </Section>
    </>
  );
}

// Default look of every email the platform sends; campaigns, broadcasts and templates can pick their own.
const EmailDefaults = ({ v, set }) => (
  <EmailDesigner title="Default email design" allowInherit={false} value={v} onChange={(d) => set({ ...d })}
    subject="Invoice INV-2026-00042 is ready" body={'Hi {{name}},\n\nYour invoice for **৳1,200** is ready and due on 2026-12-01.\n\nThank you for staying with us!'}
    hint="Your logo and brand colours (Branding tab) are applied automatically. SMTP must be set up (Integrations tab) to send." />
);

const TABS = { branding: Branding, company: Company, modules: Modules, billing: BillingCfg, enforcement: Enforcement, security: Security, integrations: Integrations, website: Website, email: EmailDefaults };

export default function Settings() {
  const { toast, loadConfig } = useApp();
  const { data, reload } = useLoad(() => api('/settings'));
  const [params] = useSearchParams();
  const [tab, setTab] = useState(() => (TABS[params.get('tab')] ? params.get('tab') : 'branding')); // e.g. ?tab=website from Admin → Website
  const [draft, setDraft] = useState(null);
  const [saving, setSaving] = useState(false);
  // First load fills every tab; after saving one tab only that tab is refreshed, so unsaved edits elsewhere survive.
  useEffect(() => {
    if (!data) return;
    setDraft((d) => (d ? { ...d, [tab]: structuredClone(data.settings[tab]) } : structuredClone(data.settings)));
  }, [data]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!draft) return <Spinner />;
  const C = TABS[tab];
  const set = (patch) => setDraft((d) => ({ ...d, [tab]: { ...d[tab], ...patch } }));
  const save = async () => {
    setSaving(true);
    try { await api.put(`/settings/${tab}`, draft[tab]); toast('Settings saved'); await reload(); await loadConfig(); }
    catch (e) { toast(e.details?.fieldErrors ? `${Object.keys(e.details.fieldErrors)[0]}: ${Object.values(e.details.fieldErrors)[0][0]}` : e.message, 'bad'); }
    finally { setSaving(false); }
  };
  return (
    <Page title="Settings" subtitle="Configure every module of your platform" actions={<Button variant="primary" icon={Save} loading={saving} onClick={save}>Save {tab}</Button>}>
      <div className="mb"><Tabs tabs={Object.keys(TABS)} value={tab} onChange={setTab} /></div>
      <motion.div key={tab} initial={{ y: 10 }} animate={{ y: 0 }}>
        <C v={draft[tab]} set={set} catalog={data.modulesCatalog} />
      </motion.div>
    </Page>
  );
}
