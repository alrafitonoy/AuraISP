// Website: live preview of the public site (desktop / tablet / phone) with quick links to visit it and edit its content.
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ExternalLink, Monitor, Tablet, Smartphone, Pencil, RefreshCw } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { Button, Card, Page } from '../../components/ui.jsx';

const SIZES = { desktop: { w: '100%', label: 'Desktop', icon: Monitor }, tablet: { w: 820, label: 'Tablet', icon: Tablet }, phone: { w: 390, label: 'Phone', icon: Smartphone } };

export default function Website() {
  const { config, moduleOn } = useApp();
  const [size, setSize] = useState('desktop');
  const [key, setKey] = useState(0);
  const url = `${window.location.origin}/`;
  const enabled = moduleOn('website');
  return (
    <Page title="Website" subtitle="See your public website exactly as visitors do"
      actions={<>
        <Link to="/admin/settings?tab=website" className="btn"><Pencil size={16} /> Edit content</Link>
        <a href="/site" target="_blank" rel="noopener" className="btn primary"><ExternalLink size={16} /> Visit website</a>
      </>}>
      {!enabled && <div className="alert warn mb"><div>The public website module is switched off, so visitors are sent straight to the sign-in page. Turn it on in Settings → Modules.</div></div>}
      <Card className="mb">
        <div className="row between wrap" style={{ gap: 12 }}>
          <div className="col" style={{ gap: 2 }}>
            <b>{config?.branding?.companyName}</b>
            <a href={url} target="_blank" rel="noopener" className="faint mono" style={{ wordBreak: 'break-all' }}>{url}</a>
          </div>
          <div className="row wrap" role="group" aria-label="Preview size">
            {Object.entries(SIZES).map(([k, s]) => (
              <button type="button" key={k} className={`chip ${size === k ? 'on' : ''}`} aria-pressed={size === k} onClick={() => setSize(k)}><s.icon size={14} />{s.label}</button>
            ))}
            <Button size="sm" variant="ghost" icon={RefreshCw} onClick={() => setKey((x) => x + 1)} aria-label="Reload preview" />
          </div>
        </div>
      </Card>
      <div className="site-preview">
        <iframe key={key} title="Website preview" src="/site" style={{ width: SIZES[size].w, maxWidth: '100%' }} />
      </div>
    </Page>
  );
}
