import { useState } from 'react';
import { Plus, Wallet, AlertCircle, TrendingUp, PlayCircle, Trash2, FileText } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { date, dateTime, label, money, toCents } from '../../lib/format.js';
import BillActions, { ReceiptButton } from '../../components/BillActions.jsx';
import { Badge, Button, Card, DataTable, Input, Modal, Page, Pager, Select, Stat, Tabs, useLoad } from '../../components/ui.jsx';
import { Donut } from '../../components/charts.jsx';

export function RecordPayment({ invoice, onClose, onDone }) {
  const { toast } = useApp();
  const remaining = invoice.total_cents - invoice.paid_cents;
  const [amount, setAmount] = useState(remaining / 100);
  const [method, setMethod] = useState('cash');
  const [reference, setReference] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault(); setBusy(true);
    try { await api.post(`/billing/invoices/${invoice.id}/record-payment`, { amount_cents: toCents(amount), method, reference: reference || undefined }); toast('Payment recorded'); onDone(); }
    catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  return (
    <Modal open onClose={onClose} title={`Collect payment · ${invoice.number}`}>
      <form className="col" onSubmit={submit}>
        <div className="faint">Outstanding: <b>{money(remaining)}</b></div>
        <Input label="Amount" type="number" step="0.01" min={0.01} max={remaining / 100} required value={amount} onChange={(e) => setAmount(e.target.value)} />
        <Select label="Method" value={method} onChange={(e) => setMethod(e.target.value)} options={['cash', 'bank', 'bkash_manual', 'nagad', 'rocket', 'card_pos', 'other']} />
        <Input label="Reference / transaction ID" value={reference} onChange={(e) => setReference(e.target.value)} maxLength={120} />
        <Button variant="primary" type="submit" loading={busy}>Record payment</Button>
      </form>
    </Modal>
  );
}

export function NewInvoice({ customerId, onClose, onDone }) {
  const { toast } = useApp();
  const [cid, setCid] = useState(customerId || '');
  const [items, setItems] = useState([{ description: '', quantity: 1, price: '' }]);
  const [discount, setDiscount] = useState(0);
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState(false);
  const total = items.reduce((s, i) => s + toCents(i.price) * (Number(i.quantity) || 1), 0) - toCents(discount);
  const submit = async (e) => {
    e.preventDefault(); setBusy(true);
    try {
      await api.post('/billing/invoices', { customer_id: Number(cid), items: items.map((i) => ({ description: i.description, quantity: Number(i.quantity) || 1, unit_cents: toCents(i.price) })), discount_cents: toCents(discount), notes: notes || undefined });
      toast('Invoice created'); onDone();
    } catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  return (
    <Modal open wide onClose={onClose} title="New invoice">
      <form className="col" onSubmit={submit}>
        {!customerId && <Input label="Customer ID" type="number" required value={cid} onChange={(e) => setCid(e.target.value)} />}
        {items.map((it, i) => (
          <div key={i} className="row" style={{ alignItems: 'flex-end' }}>
            <div className="grow"><Input label={i === 0 ? 'Description' : undefined} required value={it.description} onChange={(e) => setItems(items.map((x, j) => (j === i ? { ...x, description: e.target.value } : x)))} /></div>
            <div style={{ width: 90 }}><Input label={i === 0 ? 'Qty' : undefined} type="number" min={1} value={it.quantity} onChange={(e) => setItems(items.map((x, j) => (j === i ? { ...x, quantity: e.target.value } : x)))} /></div>
            <div style={{ width: 140 }}><Input label={i === 0 ? 'Unit price' : undefined} type="number" min={0} step="0.01" required value={it.price} onChange={(e) => setItems(items.map((x, j) => (j === i ? { ...x, price: e.target.value } : x)))} /></div>
            <Button type="button" variant="ghost" icon={Trash2} disabled={items.length === 1} onClick={() => setItems(items.filter((_, j) => j !== i))} aria-label="Remove line" />
          </div>
        ))}
        <Button type="button" size="sm" icon={Plus} onClick={() => setItems([...items, { description: '', quantity: 1, price: '' }])} style={{ alignSelf: 'flex-start' }}>Add line</Button>
        <div className="grid g2"><Input label="Discount" type="number" min={0} step="0.01" value={discount} onChange={(e) => setDiscount(e.target.value)} /><Input label="Notes" value={notes} onChange={(e) => setNotes(e.target.value)} /></div>
        <div className="row between"><span className="faint">Total before tax</span><b style={{ fontSize: 20 }}>{money(Math.max(0, total))}</b></div>
        <Button variant="primary" type="submit" loading={busy}>Create invoice</Button>
      </form>
    </Modal>
  );
}

export default function Billing() {
  const { toast, can } = useApp();
  const [tab, setTab] = useState('invoices');
  const [status, setStatus] = useState('');
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const [paying, setPaying] = useState(null);
  const [creating, setCreating] = useState(false);
  const summary = useLoad(() => api('/billing/summary'));
  const invoices = useLoad(() => api(`/billing/invoices?page=${page}&status=${status}&q=${encodeURIComponent(q)}`), [page, status, q]);
  const payments = useLoad(() => (tab === 'payments' ? api(`/billing/payments?page=${page}`) : Promise.resolve(null)), [tab, page]);
  const run = async (job) => { try { const r = await api.post(`/billing/run/${job}`); toast(job === 'generate' ? `${r.created} invoice(s) generated` : `${r.suspended} customer(s) suspended`); invoices.reload(); summary.reload(); } catch (e) { toast(e.message, 'bad'); } };
  const voidInv = async (id) => { if (!window.confirm('Void this invoice?')) return; try { await api.post(`/billing/invoices/${id}/void`); toast('Invoice voided'); invoices.reload(); } catch (e) { toast(e.message, 'bad'); } };
  const s = summary.data;

  return (
    <Page title="Billing" subtitle="Invoices, collections and online payments"
      actions={can('billing.manage') && <><Button icon={PlayCircle} onClick={() => run('generate')}>Generate due invoices</Button><Button icon={AlertCircle} onClick={() => run('overdue')}>Enforce overdue</Button><Button variant="primary" icon={Plus} onClick={() => setCreating(true)}>New invoice</Button></>}>
      {s && (
        <div className="grid g4 mb">
          <Stat icon={TrendingUp} label="Collected this month" value={s.collectedThisMonth} format={money} />
          <Stat icon={Wallet} label="Outstanding" value={s.outstanding} format={money} sub={`${s.outstandingCount} invoices`} />
          <Stat icon={AlertCircle} label="Overdue" value={s.overdue} format={money} sub={`${s.overdueCount} invoices`} />
          <div className="card"><div className="faint" style={{ fontWeight: 600 }}>By method (this month)</div><Donut height={130} data={s.byMethod.map((m) => ({ name: label(m.method), value: Number(m.v) }))} fmt={money} /></div>
        </div>
      )}
      <div className="row wrap mb">
        <Tabs tabs={['invoices', 'payments']} value={tab} onChange={(t) => { setTab(t); setPage(1); }} />
        {tab === 'invoices' && <Tabs tabs={[{ value: '', label: 'All' }, 'unpaid', 'overdue', 'partial', 'paid', 'void']} value={status} onChange={(v) => { setStatus(v); setPage(1); }} />}
        <div className="grow" />
        {tab === 'invoices' && <input className="input" style={{ maxWidth: 240 }} placeholder="Invoice #, customer…" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} aria-label="Search invoices" />}
      </div>
      <Card className="flush">
        {tab === 'invoices' ? (
          <>
            <DataTable loading={invoices.loading} rows={invoices.data?.rows} columns={[
              { key: 'number', title: 'Invoice', render: (r) => <b>{r.number}</b> },
              { key: 'customer_name', title: 'Customer', render: (r) => <div>{r.customer_name}<div className="faint">{r.customer_code}</div></div> },
              { key: 'issued_at', title: 'Issued', render: (r) => date(r.issued_at) },
              { key: 'due_date', title: 'Due', render: (r) => date(r.due_date) },
              { key: 'total_cents', title: 'Total', align: 'right', render: (r) => money(r.total_cents) },
              { key: 'status', title: 'Status', render: (r) => <Badge status={r.status} /> },
              { key: 'x', title: '', align: 'right', render: (r) => (
                <div className="row end">
                  <BillActions invoice={r} compact />
                  {can('billing.collect') && ['unpaid', 'overdue', 'partial'].includes(r.status) && <Button size="sm" variant="primary" onClick={() => setPaying(r)}>Collect</Button>}
                  {can('billing.manage') && r.paid_cents === 0 && r.status !== 'void' && <Button size="sm" variant="ghost" onClick={() => voidInv(r.id)}>Void</Button>}
                </div>) },
            ]} />
            {invoices.data && <Pager page={invoices.data.page} pageSize={invoices.data.pageSize} total={invoices.data.total} onPage={setPage} />}
          </>
        ) : (
          <>
            <DataTable loading={payments.loading} rows={payments.data?.rows} columns={[
              { key: 'created_at', title: 'Date', render: (r) => dateTime(r.completed_at || r.created_at) },
              { key: 'customer_name', title: 'Customer' },
              { key: 'invoice_number', title: 'Invoice' },
              { key: 'method', title: 'Method', render: (r) => label(r.method) },
              { key: 'gateway_ref', title: 'Reference', render: (r) => <span className="mono faint">{r.gateway_ref || '—'}</span> },
              { key: 'amount_cents', title: 'Amount', align: 'right', render: (r) => money(r.amount_cents) },
              { key: 'status', title: 'Status', render: (r) => <Badge status={r.status} /> },
              { key: 'receipt', title: '', align: 'right', render: (r) => <ReceiptButton payment={r} /> },
            ]} />
            {payments.data && <Pager page={payments.data.page} pageSize={payments.data.pageSize} total={payments.data.total} onPage={setPage} />}
          </>
        )}
      </Card>
      {paying && <RecordPayment invoice={paying} onClose={() => setPaying(null)} onDone={() => { setPaying(null); invoices.reload(); summary.reload(); }} />}
      {creating && <NewInvoice onClose={() => setCreating(false)} onDone={() => { setCreating(false); invoices.reload(); }} />}
    </Page>
  );
}
