import { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Pencil, Trash2, ShieldCheck, ShieldOff, KeyRound } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { ago, label } from '../../lib/format.js';
import { Badge, Button, Card, DataTable, Input, Modal, Page, Select, Spinner, Tabs, useLoad, fadeUp } from '../../components/ui.jsx';

function Users({ roles }) {
  const { toast, user } = useApp();
  const { data, reload } = useLoad(() => api('/staff'));
  const [edit, setEdit] = useState(null);
  const save = async (e) => {
    e.preventDefault();
    const p = { name: edit.name, email: edit.email, phone: edit.phone || null, role_id: Number(edit.role_id), type: edit.type, status: edit.status, ...(edit.password ? { password: edit.password } : {}) };
    try { if (edit.id) { delete p.email; await api.put(`/staff/${edit.id}`, p); } else await api.post('/staff', p); toast('Staff saved'); setEdit(null); reload(); } catch (err) { toast(err.message, 'bad'); }
  };
  return (
    <>
      <div className="row end mb"><Button variant="primary" icon={Plus} onClick={() => setEdit({ name: '', email: '', role_id: roles[0]?.id, type: 'staff', status: 'active', password: '' })}>Add staff</Button></div>
      <Card className="flush">
        <DataTable rows={data?.users} loading={!data} columns={[
          { key: 'name', title: 'Name', render: (r) => <div><b>{r.name}</b><div className="faint">{r.email}</div></div> },
          { key: 'role_name', title: 'Role', render: (r) => r.type === 'admin' ? <Badge kind="brand">Administrator</Badge> : r.role_name },
          { key: 'totp_enabled', title: '2FA', render: (r) => r.totp_enabled ? <ShieldCheck size={18} color="var(--ok)" /> : <ShieldOff size={18} color="var(--text-3)" /> },
          { key: 'last_login_at', title: 'Last login', render: (r) => ago(r.last_login_at) },
          { key: 'status', title: 'Status', render: (r) => <Badge status={r.status === 'active' ? 'active' : 'suspended'}>{r.status}</Badge> },
          { key: 'x', title: '', align: 'right', render: (r) => (
            <div className="row end">
              <Button size="sm" variant="ghost" icon={Pencil} onClick={() => setEdit({ ...r, password: '' })} aria-label="Edit" />
              {user.type === 'admin' && r.totp_enabled && r.id !== user.id && <Button size="sm" variant="ghost" icon={KeyRound} title="Reset 2FA" onClick={async () => { if (window.confirm('Reset 2FA for this user?')) { await api.post(`/staff/${r.id}/reset-2fa`); reload(); } }} aria-label="Reset 2FA" />}
              {r.id !== user.id && <Button size="sm" variant="ghost" icon={Trash2} onClick={async () => { if (window.confirm(`Delete ${r.name}?`)) { try { await api.del(`/staff/${r.id}`); reload(); } catch (e) { toast(e.message, 'bad'); } } }} aria-label="Delete" />}
            </div>) },
        ]} />
      </Card>
      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? 'Edit staff' : 'Add staff'}>
        {edit && <form className="col" onSubmit={save}>
          <Input label="Name" required value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
          <Input label="Email" type="email" required disabled={!!edit.id} value={edit.email} onChange={(e) => setEdit({ ...edit, email: e.target.value })} />
          <Input label="Phone" value={edit.phone || ''} onChange={(e) => setEdit({ ...edit, phone: e.target.value })} />
          <div className="grid g2">
            {user.type === 'admin' && <Select label="Account type" value={edit.type} onChange={(e) => setEdit({ ...edit, type: e.target.value })} options={[{ value: 'staff', label: 'Staff (role based)' }, { value: 'admin', label: 'Administrator (full access)' }]} />}
            <Select label="Role" value={edit.role_id} onChange={(e) => setEdit({ ...edit, role_id: e.target.value })} options={roles.map((r) => ({ value: r.id, label: r.name }))} />
            {edit.id && <Select label="Status" value={edit.status} onChange={(e) => setEdit({ ...edit, status: e.target.value })} options={['active', 'disabled']} />}
          </div>
          <Input label={edit.id ? 'New password (optional)' : 'Password'} type="password" required={!edit.id} minLength={10} value={edit.password} onChange={(e) => setEdit({ ...edit, password: e.target.value })} autoComplete="new-password" />
          <Button variant="primary" type="submit">Save</Button>
        </form>}
      </Modal>
    </>
  );
}

function Roles({ roles, catalog, reload }) {
  const { toast } = useApp();
  const [edit, setEdit] = useState(null);
  const save = async () => {
    try {
      const p = { name: edit.name, description: edit.description || null, permissions: edit.permissions, dashboard: edit.dashboard };
      if (edit.id) await api.put(`/staff/roles/${edit.id}`, p); else await api.post('/staff/roles', p);
      toast('Role saved — members must sign in again for changes to apply'); setEdit(null); reload();
    } catch (e) { toast(e.message, 'bad'); }
  };
  const togglePerm = (p) => setEdit((e) => ({ ...e, permissions: e.permissions.includes(p) ? e.permissions.filter((x) => x !== p) : [...e.permissions, p] }));
  const toggleGroup = (perms, on) => setEdit((e) => ({ ...e, permissions: on ? [...new Set([...e.permissions, ...perms])] : e.permissions.filter((x) => !perms.includes(x)) }));
  const toggleWidget = (w) => setEdit((e) => ({ ...e, dashboard: e.dashboard.includes(w) ? e.dashboard.filter((x) => x !== w) : [...e.dashboard, w] }));
  return (
    <>
      <div className="row end mb"><Button variant="primary" icon={Plus} onClick={() => setEdit({ name: '', description: '', permissions: ['dashboard.view'], dashboard: [] })}>New role</Button></div>
      <div className="grid g3">
        {roles.map((r) => (
          <motion.div key={r.id} variants={fadeUp} className="card hover">
            <div className="row between"><h3 style={{ margin: 0 }}>{r.name}</h3>{r.is_system ? <Badge kind="brand">system</Badge> : <Button size="sm" variant="ghost" icon={Pencil} onClick={() => setEdit({ ...r })} aria-label="Edit" />}</div>
            <p className="faint" style={{ marginTop: 6 }}>{r.description}</p>
            <div className="row between"><span className="faint">{r.members} member(s)</span><span className="faint">{r.slug === 'admin' ? 'all permissions' : `${r.permissions.length} permissions · ${r.dashboard.length} widgets`}</span></div>
            {!r.is_system && r.members === 0 && <Button size="sm" variant="ghost" icon={Trash2} onClick={async () => { await api.del(`/staff/roles/${r.id}`); reload(); }}>Delete</Button>}
          </motion.div>
        ))}
      </div>
      <Modal wide open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? `Role · ${edit.name}` : 'New role'} footer={<><Button onClick={() => setEdit(null)}>Cancel</Button><Button variant="primary" onClick={save}>Save role</Button></>}>
        {edit && <div className="col">
          <div className="grid g2"><Input label="Role name" required value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} /><Input label="Description" value={edit.description || ''} onChange={(e) => setEdit({ ...edit, description: e.target.value })} /></div>
          <h3 className="mt">Access permissions</h3>
          <div className="grid g3">
            {Object.entries(catalog.permissions).map(([group, perms]) => {
              const all = perms.every((p) => edit.permissions.includes(p));
              return (
                <div key={group} className="card" style={{ padding: 14 }}>
                  <label className="check" style={{ fontWeight: 700, marginBottom: 8 }}><input type="checkbox" checked={all} onChange={(e) => toggleGroup(perms, e.target.checked)} />{label(group)}</label>
                  {perms.map((p) => <label key={p} className="check" style={{ display: 'flex', margin: '4px 0 4px 8px' }}><input type="checkbox" checked={edit.permissions.includes(p)} onChange={() => togglePerm(p)} />{label(p.split('.')[1])}</label>)}
                </div>
              );
            })}
          </div>
          <h3 className="mt">Dashboard widgets for this role</h3>
          <div className="row wrap">{Object.entries(catalog.widgets).map(([k, w]) => <button type="button" key={k} className={`chip ${edit.dashboard.includes(k) ? 'on' : ''}`} onClick={() => toggleWidget(k)} title={`Requires ${w.permission}`}>{w.label}</button>)}</div>
          <div className="faint">Widgets only show if the role also has the matching permission.</div>
        </div>}
      </Modal>
    </>
  );
}

export default function Staff() {
  const [tab, setTab] = useState('staff');
  const roles = useLoad(() => api('/staff/roles'));
  const catalog = useLoad(() => api('/staff/catalog'));
  if (!roles.data || !catalog.data) return <Spinner />;
  const assignable = roles.data.roles.filter((r) => r.slug !== 'admin');
  return (
    <Page title="Staff & roles" subtitle="Role-based access control — you decide what each role can see and do">
      <div className="mb"><Tabs tabs={['staff', 'roles']} value={tab} onChange={setTab} /></div>
      {tab === 'staff' ? <Users roles={assignable.length ? assignable : roles.data.roles} /> : <Roles roles={roles.data.roles} catalog={catalog.data} reload={roles.reload} />}
    </Page>
  );
}
