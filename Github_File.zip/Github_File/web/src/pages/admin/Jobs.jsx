import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { useSearchParams, Link } from 'react-router-dom';
import {
  Plus, Search, MapPin, Navigation, Clock, User, Phone, Pencil, Trash2, ClipboardList, AlertTriangle, CalendarDays,
  CheckCircle2, Wrench, ChevronLeft, ChevronRight, X, Ticket,
} from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { dateTime, label } from '../../lib/format.js';
import { Badge, Button, Card, Confirm, DataTable, Empty, Input, Modal, Page, Pager, Select, Spinner, Stat, Tabs, Textarea, useLoad } from '../../components/ui.jsx';

const TYPES = ['installation', 'repair', 'survey', 'relocation', 'disconnection', 'maintenance'];
const STATUSES = ['new', 'scheduled', 'en_route', 'on_site', 'done', 'failed', 'cancelled'];
const OPEN = ['new', 'scheduled', 'en_route', 'on_site'];
const PRIORITIES = ['low', 'normal', 'high', 'urgent'];
const STATUS_TONE = { new: 'brand', scheduled: 'info', en_route: 'warn', on_site: 'warn', done: 'ok', failed: 'bad', cancelled: 'info' };
const ACTION_LABEL = { scheduled: 'Schedule', en_route: 'On my way', on_site: 'Arrived on site', done: 'Mark done', failed: 'Mark failed', cancelled: 'Cancel job', new: 'Back to new' };
const TZ = new Date().getTimezoneOffset();

// <input type="datetime-local"> works in local time; the API stores UTC ISO strings.
const toLocalInput = (iso) => { if (!iso) return ''; const d = new Date(iso); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16); };
const fromLocalInput = (v) => (v ? new Date(v).toISOString() : null);
const time = (iso) => (iso ? new Date(iso).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) : '');
const dayKey = (d) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
const isOverdue = (j) => j.scheduled_at && ['new', 'scheduled', 'en_route'].includes(j.status) && new Date(j.scheduled_at) < new Date();

export function directionsUrl(j) {
  if (j.lat && j.lng) return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${j.lat},${j.lng}`)}`;
  if (j.address) return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(j.address)}`;
  return null;
}

const StatusBadge = ({ s }) => <Badge kind={STATUS_TONE[s]}>{label(s)}</Badge>;

// ------------------------------------------------------------------ job card (board / my jobs / schedule)
function JobCard({ j, onOpen, draggable, compact }) {
  return (
    <motion.div layout className="card kanban-card hover" style={{ cursor: 'pointer' }} draggable={draggable}
      onDragStart={(e) => e.dataTransfer.setData('text/plain', String(j.id))} onClick={() => onOpen(j.id)}
      role="button" tabIndex={0} onKeyDown={(e) => e.key === 'Enter' && onOpen(j.id)} aria-label={`${j.number} ${j.title}`}>
      <div className="row between" style={{ gap: 6 }}>
        <span className="faint" style={{ fontSize: 12 }}>{j.number}</span>
        {j.priority !== 'normal' && <Badge status={j.priority} />}
      </div>
      <b style={{ fontSize: 14, display: 'block', margin: '4px 0' }}>{j.title}</b>
      <div className="faint" style={{ fontSize: 12 }}>{label(j.type)}</div>
      {j.scheduled_at && <div className="row" style={{ gap: 6, fontSize: 12.5, marginTop: 4, color: isOverdue(j) ? 'var(--bad)' : undefined }}><Clock size={13} />{compact ? time(j.scheduled_at) : dateTime(j.scheduled_at)}{isOverdue(j) && ' · overdue'}</div>}
      {j.customer_name && <div className="row" style={{ gap: 6, fontSize: 12.5, marginTop: 2 }}><User size={13} />{j.customer_name}</div>}
      <div className="row between" style={{ marginTop: 6, gap: 6 }}>
        <span className="faint" style={{ fontSize: 12 }}><Wrench size={12} style={{ verticalAlign: -2 }} /> {j.assignee_name || 'Unassigned'}</span>
        {j.checklist_total > 0 && <span className="faint" style={{ fontSize: 12 }}>{j.checklist_done}/{j.checklist_total}</span>}
      </div>
    </motion.div>
  );
}

// ------------------------------------------------------------------ lookup (customer / lead) for the form
function LinkPicker({ kind, value, valueLabel, onPick }) {
  const [q, setQ] = useState('');
  const [results, setResults] = useState([]);
  useEffect(() => {
    if (q.trim().length < 2) { setResults([]); return undefined; }
    const t = setTimeout(() => api(`/jobs/lookup?kind=${kind}&q=${encodeURIComponent(q.trim())}`).then((r) => setResults(r.results)).catch(() => setResults([])), 250);
    return () => clearTimeout(t);
  }, [q, kind]);
  if (value) {
    return (
      <div className="row between card" style={{ padding: '8px 12px' }}>
        <span>{valueLabel || `#${value}`}</span>
        <Button size="sm" variant="ghost" icon={X} onClick={() => onPick(null)} aria-label={`Remove linked ${kind}`} />
      </div>
    );
  }
  return (
    <div>
      <input className="input" placeholder={`Search ${kind}s by name, code or phone…`} value={q} onChange={(e) => setQ(e.target.value)} aria-label={`Search ${kind}`} />
      {results.length > 0 && (
        <div className="card" style={{ padding: 4, marginTop: 4, maxHeight: 220, overflow: 'auto' }}>
          {results.map((r) => (
            <button type="button" key={r.id} className="btn ghost" style={{ display: 'block', width: '100%', textAlign: 'left', height: 'auto', padding: '6px 10px' }}
              onClick={() => { onPick(r); setQ(''); setResults([]); }}>
              <div>{r.label}</div>{r.sub && <div className="faint" style={{ fontSize: 12 }}>{r.sub}</div>}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// ------------------------------------------------------------------ create / edit form
function JobForm({ job, meta, techs, onClose, onSaved }) {
  const { toast } = useApp();
  const defaults = (type) => (meta?.checklists?.[type] || []).map((l) => ({ label: l, done: false }));
  const [f, setF] = useState(() => (job?.id ? {
    ...job, scheduled_local: toLocalInput(job.scheduled_at), customer_label: job.customer_name ? `${job.customer_name} (${job.customer_code})` : '',
    lead_label: job.lead_name || '',
  } : { type: 'installation', title: '', priority: 'normal', duration_min: 60, checklist: defaults('installation'), scheduled_local: '', ...job }));
  const [customList, setCustomList] = useState(!!job?.id);
  const [newItem, setNewItem] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k, v) => setF((x) => ({ ...x, [k]: v }));
  const setType = (type) => setF((x) => ({ ...x, type, checklist: customList ? x.checklist : defaults(type) }));

  const save = async (e) => {
    e.preventDefault();
    setBusy(true);
    const body = {
      type: f.type, title: f.title, priority: f.priority, customer_id: f.customer_id || null, lead_id: f.lead_id || null,
      zone_id: f.zone_id ? Number(f.zone_id) : null, assigned_to: f.assigned_to ? Number(f.assigned_to) : null,
      address: f.address || null, lat: f.lat || null, lng: f.lng || null, scheduled_at: fromLocalInput(f.scheduled_local),
      duration_min: Number(f.duration_min) || 60, notes: f.notes || null, checklist: f.checklist,
    };
    if (job?.ticket_id && !job.id) body.ticket_id = job.ticket_id;
    try {
      const out = job?.id ? await api.put(`/jobs/${job.id}`, body) : await api.post('/jobs', body);
      toast(job?.id ? 'Job updated' : `Job ${out.number} created`);
      onSaved(job?.id || out.id);
    } catch (err) {
      const fe = err.details?.fieldErrors;
      toast(fe ? `${err.message}: ${Object.entries(fe).map(([k, v]) => `${k} ${v[0]}`).join(', ')}` : err.message, 'bad');
    } finally { setBusy(false); }
  };

  return (
    <Modal open onClose={onClose} wide title={job?.id ? `Edit ${job.number}` : 'New field job'} footer={<>
      <Button onClick={onClose}>Cancel</Button>
      <Button variant="primary" type="submit" form="job-form" loading={busy}>{job?.id ? 'Save changes' : 'Create job'}</Button>
    </>}>
      <form id="job-form" className="col" onSubmit={save}>
        <div className="grid g3">
          <Select label="Type" value={f.type} onChange={(e) => setType(e.target.value)} options={TYPES} />
          <Select label="Priority" value={f.priority} onChange={(e) => set('priority', e.target.value)} options={PRIORITIES} />
          <Select label="Technician" value={f.assigned_to || ''} onChange={(e) => set('assigned_to', e.target.value)}
            options={[{ value: '', label: 'Unassigned' }, ...techs.map((t) => ({ value: t.id, label: t.technician ? t.name : `${t.name} (no jobs.work)` }))]} />
        </div>
        <Input label="Title" required minLength={2} maxLength={200} value={f.title} onChange={(e) => set('title', e.target.value)} placeholder="e.g. New fibre connection" />
        <div className="grid g2">
          <div className="field"><span>Customer</span>
            <LinkPicker kind="customer" value={f.customer_id} valueLabel={f.customer_label}
              onPick={(r) => setF((x) => ({ ...x, customer_id: r?.id || null, customer_label: r?.label || '' }))} />
          </div>
          <div className="field"><span>Lead (prospect)</span>
            <LinkPicker kind="lead" value={f.lead_id} valueLabel={f.lead_label} onPick={(r) => setF((x) => ({ ...x, lead_id: r?.id || null, lead_label: r?.label || '' }))} />
          </div>
        </div>
        <Input label="Address" value={f.address || ''} onChange={(e) => set('address', e.target.value)} hint="Leave empty to use the linked customer's address and location" />
        <div className="grid g3">
          <Input label="Latitude" inputMode="decimal" value={f.lat || ''} onChange={(e) => set('lat', e.target.value)} placeholder="23.7808" />
          <Input label="Longitude" inputMode="decimal" value={f.lng || ''} onChange={(e) => set('lng', e.target.value)} placeholder="90.4152" />
          <Select label="Zone" value={f.zone_id || ''} onChange={(e) => set('zone_id', e.target.value)} options={[{ value: '', label: '—' }, ...(meta?.zones || []).map((z) => ({ value: z.id, label: z.name }))]} />
        </div>
        <div className="grid g2">
          <Input label="Scheduled for" type="datetime-local" value={f.scheduled_local} onChange={(e) => set('scheduled_local', e.target.value)} hint="Setting a time moves a new job to Scheduled" />
          <Input label="Duration (minutes)" type="number" min={5} max={1440} value={f.duration_min} onChange={(e) => set('duration_min', e.target.value)} />
        </div>
        <Textarea label="Notes for the technician" rows={3} value={f.notes || ''} onChange={(e) => set('notes', e.target.value)} />
        <div className="field">
          <span>Checklist</span>
          <div className="col" style={{ gap: 6 }}>
            {f.checklist.map((it, i) => (
              <div key={i} className="row" style={{ gap: 6 }}>
                <input className="input" value={it.label} aria-label={`Checklist item ${i + 1}`} onChange={(e) => { setCustomList(true); set('checklist', f.checklist.map((c, k) => (k === i ? { ...c, label: e.target.value } : c))); }} />
                <Button size="sm" variant="ghost" icon={Trash2} aria-label="Remove item" onClick={() => { setCustomList(true); set('checklist', f.checklist.filter((_, k) => k !== i)); }} />
              </div>
            ))}
            <div className="row" style={{ gap: 6 }}>
              <input className="input" placeholder="Add a step…" value={newItem} onChange={(e) => setNewItem(e.target.value)} aria-label="New checklist item"
                onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); if (newItem.trim()) { setCustomList(true); set('checklist', [...f.checklist, { label: newItem.trim(), done: false }]); setNewItem(''); } } }} />
              <Button size="sm" icon={Plus} type="button" disabled={!newItem.trim()} onClick={() => { setCustomList(true); set('checklist', [...f.checklist, { label: newItem.trim(), done: false }]); setNewItem(''); }}>Add</Button>
            </div>
          </div>
        </div>
      </form>
    </Modal>
  );
}

// ------------------------------------------------------------------ detail modal
function JobDetail({ id, onClose, onChanged, onEdit }) {
  const { toast, can } = useApp();
  const { data, loading, reload, setData } = useLoad(() => api(`/jobs/${id}`), [id]);
  const [result, setResult] = useState('');
  const [when, setWhen] = useState('');
  const [busy, setBusy] = useState('');
  const [del, setDel] = useState(false);
  const j = data?.job;
  useEffect(() => { if (j) { setResult(j.result || ''); setWhen(toLocalInput(j.scheduled_at)); } }, [j?.id, j?.result, j?.scheduled_at]); // eslint-disable-line react-hooks/exhaustive-deps

  const manager = can('jobs.manage');
  const canWork = !!j?.can_work;
  const locked = j && ['done', 'cancelled'].includes(j.status);

  const tick = async (i, done) => {
    setData((d) => ({ ...d, job: { ...d.job, checklist: d.job.checklist.map((c, k) => (k === i ? { ...c, done } : c)) } }));
    try { await api.patch(`/jobs/${id}/checklist/${i}`, { done }); onChanged(); } catch (e) { toast(e.message, 'bad'); reload(); }
  };
  const move = async (status) => {
    if (['done', 'failed'].includes(status) && !result.trim()) { toast('Write a result note first', 'bad'); return; }
    if (status === 'scheduled' && !when) { toast('Pick a date and time first', 'bad'); return; }
    setBusy(status);
    try {
      await api.post(`/jobs/${id}/status`, { status, result: result.trim() || undefined, scheduled_at: status === 'scheduled' ? fromLocalInput(when) : undefined });
      toast(`Job ${label(status)}`);
      await reload(); onChanged();
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(''); }
  };
  const saveResult = async () => {
    setBusy('result');
    try { await api.patch(`/jobs/${id}/result`, { result: result.trim() }); toast('Result saved'); await reload(); onChanged(); }
    catch (e) { toast(e.message, 'bad'); } finally { setBusy(''); }
  };
  const remove = async () => {
    try { await api.del(`/jobs/${id}`); toast('Job deleted'); onChanged(); onClose(); } catch (e) { toast(e.message, 'bad'); }
  };

  const maps = j && directionsUrl(j);
  const needsTime = j?.allowed?.includes('scheduled');
  return (
    <Modal open onClose={onClose} wide title={j ? `${j.number} · ${j.title}` : 'Job'}>
      {loading && !j ? <Spinner /> : !j ? <Empty title="Job not found" /> : (
        <div className="col">
          <div className="row wrap" style={{ gap: 6 }}>
            <StatusBadge s={j.status} /><Badge status={j.priority}>{label(j.priority)} priority</Badge><Badge kind="brand">{label(j.type)}</Badge>
            {isOverdue(j) && <Badge kind="bad">overdue</Badge>}
          </div>
          <div className="grid g2">
            <div className="col" style={{ gap: 6 }}>
              <div className="row" style={{ gap: 8 }}><Clock size={15} /> {j.scheduled_at ? `${dateTime(j.scheduled_at)} · ${j.duration_min} min` : 'Not scheduled yet'}</div>
              <div className="row" style={{ gap: 8 }}><Wrench size={15} /> {j.assignee_name || 'Unassigned'}</div>
              {j.zone_name && <div className="row" style={{ gap: 8 }}><MapPin size={15} /> Zone: {j.zone_name}</div>}
              {j.ticket_id && <div className="row" style={{ gap: 8 }}><Ticket size={15} /> {can('tickets.view') ? <Link to={`/admin/tickets/${j.ticket_id}`}>{j.ticket_number || `Ticket #${j.ticket_id}`}</Link> : (j.ticket_number || `Ticket #${j.ticket_id}`)}</div>}
            </div>
            <div className="col" style={{ gap: 6 }}>
              {j.customer_id && <div className="row" style={{ gap: 8 }}><User size={15} /> {can('customers.view') ? <Link to={`/admin/customers/${j.customer_id}`}>{j.customer_name}</Link> : j.customer_name} <span className="faint">{j.customer_code}</span></div>}
              {j.lead_name && <div className="row" style={{ gap: 8 }}><User size={15} /> Lead: {j.lead_name}</div>}
              {j.customer_phone && <div className="row" style={{ gap: 8 }}><Phone size={15} /> <a href={`tel:${j.customer_phone}`}>{j.customer_phone}</a></div>}
              {j.address && <div className="row" style={{ gap: 8, alignItems: 'flex-start' }}><MapPin size={15} style={{ flexShrink: 0, marginTop: 3 }} /> {j.address}</div>}
              {maps && <a className="btn sm" href={maps} target="_blank" rel="noopener noreferrer" style={{ alignSelf: 'flex-start' }}><Navigation size={15} /> Directions</a>}
            </div>
          </div>
          {j.notes && <div className="alert info" style={{ display: 'block', whiteSpace: 'pre-wrap' }}>{j.notes}</div>}

          {j.checklist.length > 0 && (
            <div>
              <div className="row between mb"><b>Checklist</b><span className="faint">{j.checklist.filter((c) => c.done).length}/{j.checklist.length} done</span></div>
              <div className="col" style={{ gap: 4 }}>
                {j.checklist.map((c, i) => (
                  <label key={i} className="row" style={{ gap: 10, cursor: canWork && !locked ? 'pointer' : 'default', padding: '4px 0' }}>
                    <input type="checkbox" checked={!!c.done} disabled={!canWork || locked} onChange={(e) => tick(i, e.target.checked)} />
                    <span style={{ textDecoration: c.done ? 'line-through' : 'none', opacity: c.done ? 0.7 : 1 }}>{c.label}</span>
                  </label>
                ))}
              </div>
            </div>
          )}

          {canWork && j.status !== 'cancelled' ? (
            <div className="col" style={{ gap: 6 }}>
              <Textarea label="Result / work done" rows={3} value={result} onChange={(e) => setResult(e.target.value)} placeholder="Required to close the job: what was done, readings, materials used…" />
              {result.trim() && result.trim() !== (j.result || '') && <Button size="sm" style={{ alignSelf: 'flex-start' }} loading={busy === 'result'} onClick={saveResult}>Save result</Button>}
            </div>
          ) : j.result && <div><b>Result</b><div className="muted" style={{ whiteSpace: 'pre-wrap' }}>{j.result}</div></div>}

          {needsTime && <Input label="Scheduled for" type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)} />}

          {j.allowed?.length > 0 && (
            <div className="row wrap" style={{ gap: 8 }}>
              {j.allowed.map((s) => (
                <Button key={s} variant={['done', 'on_site', 'en_route'].includes(s) ? 'primary' : s === 'cancelled' || s === 'failed' ? 'danger' : ''}
                  loading={busy === s} disabled={!!busy} onClick={() => move(s)}>{ACTION_LABEL[s] || label(s)}</Button>
              ))}
            </div>
          )}
          <div className="row between wrap faint" style={{ fontSize: 12.5 }}>
            <span>Created {dateTime(j.created_at)}{j.created_by_name ? ` by ${j.created_by_name}` : ''}{j.completed_at ? ` · completed ${dateTime(j.completed_at)}` : ''}</span>
            {manager && <div className="row" style={{ gap: 6 }}>
              <Button size="sm" icon={Pencil} onClick={() => onEdit(j)}>Edit</Button>
              <Button size="sm" variant="danger" icon={Trash2} onClick={() => setDel(true)}>Delete</Button>
            </div>}
          </div>
          <Confirm open={del} onClose={() => setDel(false)} onConfirm={remove} danger confirmText="Delete job" title={`Delete ${j.number}?`}>
            The work order and its checklist will be removed permanently.
          </Confirm>
        </div>
      )}
    </Modal>
  );
}

// ------------------------------------------------------------------ views
function Board({ filters, onOpen, reloadKey, onChanged }) {
  const { toast, can } = useApp();
  const qs = (extra) => new URLSearchParams(Object.entries({ ...filters, ...extra }).filter(([, v]) => v)).toString();
  const open = useLoad(() => api(`/jobs?${qs({ status: OPEN.join(','), pageSize: 200, sort: 'scheduled_at' })}`), [JSON.stringify(filters), reloadKey]);
  const closed = useLoad(() => api(`/jobs?${qs({ status: 'done,failed,cancelled', pageSize: 30, sort: '-created_at' })}`), [JSON.stringify(filters), reloadKey]);
  const [over, setOver] = useState(null);
  const rows = [...(open.data?.rows || []), ...(closed.data?.rows || [])];
  const drop = async (id, to) => {
    const j = rows.find((x) => x.id === id);
    if (!j || j.status === to) return;
    if (['done', 'failed', 'scheduled'].includes(to)) { onOpen(id); toast(to === 'scheduled' ? 'Pick a time, then Schedule' : 'Add a result note, then close the job', 'info'); return; }
    try { await api.post(`/jobs/${id}/status`, { status: to }); onChanged(); } catch (e) { toast(e.message, 'bad'); }
  };
  if ((open.loading || closed.loading) && !rows.length) return <Spinner />;
  return (
    <div className="kanban" style={{ gridTemplateColumns: `repeat(${STATUSES.length}, minmax(220px, 1fr))` }}>
      {STATUSES.map((s) => {
        const items = rows.filter((j) => j.status === s);
        return (
          <div key={s} className={`kanban-col ${over === s ? 'over' : ''}`} aria-label={`${label(s)} column`}
            onDragOver={(e) => { e.preventDefault(); setOver(s); }} onDragLeave={() => setOver(null)}
            onDrop={(e) => { e.preventDefault(); setOver(null); const id = Number(e.dataTransfer.getData('text/plain')); if (id) drop(id, s); }}>
            <div className="row between mb"><StatusBadge s={s} /><span className="faint">{items.length}{['done', 'failed', 'cancelled'].includes(s) ? ' recent' : ''}</span></div>
            {items.map((j) => <JobCard key={j.id} j={j} onOpen={onOpen} draggable={can('jobs.manage') || can('jobs.work')} />)}
            {!items.length && <div className="faint" style={{ fontSize: 12.5, textAlign: 'center', padding: 12 }}>No jobs</div>}
          </div>
        );
      })}
    </div>
  );
}

function ListView({ filters, onOpen, reloadKey }) {
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState('-scheduled_at');
  const [status, setStatus] = useState('');
  const [range, setRange] = useState({ from: '', to: '' });
  useEffect(() => setPage(1), [JSON.stringify(filters), status, range.from, range.to]); // eslint-disable-line react-hooks/exhaustive-deps
  const params = new URLSearchParams(Object.entries({
    ...filters, status, page, pageSize: 25, sort,
    from: range.from ? new Date(`${range.from}T00:00`).toISOString() : '', to: range.to ? new Date(new Date(`${range.to}T00:00`).getTime() + 86400000).toISOString() : '',
  }).filter(([, v]) => v)).toString();
  const { data, loading } = useLoad(() => api(`/jobs?${params}`), [params, reloadKey]);
  return (
    <Card className="flush">
      <div className="row wrap" style={{ padding: 12, gap: 10 }}>
        <div style={{ minWidth: 150 }}><Select label="Status" value={status} onChange={(e) => setStatus(e.target.value)} options={[{ value: '', label: 'Any status' }, ...STATUSES.map((s) => ({ value: s, label: label(s) }))]} /></div>
        <div style={{ minWidth: 150 }}><Input label="From" type="date" value={range.from} onChange={(e) => setRange({ ...range, from: e.target.value })} /></div>
        <div style={{ minWidth: 150 }}><Input label="To" type="date" value={range.to} onChange={(e) => setRange({ ...range, to: e.target.value })} /></div>
      </div>
      <DataTable loading={loading} rows={data?.rows} sort={sort} onSort={setSort} onRowClick={(j) => onOpen(j.id)} empty="No jobs match these filters" columns={[
        { key: 'number', title: 'Job', sort: true, render: (j) => <div><b>{j.number}</b><div className="faint" style={{ fontSize: 12 }}>{label(j.type)}</div></div> },
        { key: 'title', title: 'Title', render: (j) => <div>{j.title}{j.customer_name && <div className="faint" style={{ fontSize: 12 }}>{j.customer_name}</div>}</div> },
        { key: 'scheduled_at', title: 'Scheduled', sort: true, render: (j) => <span style={{ color: isOverdue(j) ? 'var(--bad)' : undefined }}>{j.scheduled_at ? dateTime(j.scheduled_at) : '—'}</span> },
        { key: 'assignee_name', title: 'Technician', render: (j) => j.assignee_name || <span className="faint">Unassigned</span> },
        { key: 'priority', title: 'Priority', sort: true, render: (j) => <Badge status={j.priority} /> },
        { key: 'status', title: 'Status', sort: true, render: (j) => <StatusBadge s={j.status} /> },
        { key: 'progress', title: 'Checklist', align: 'right', render: (j) => (j.checklist_total ? `${j.checklist_done}/${j.checklist_total}` : '—') },
      ]} />
      {data && <Pager page={data.page} pageSize={data.pageSize} total={data.total} onPage={setPage} />}
    </Card>
  );
}

function MyJobs({ onOpen, reloadKey }) {
  const [showClosed, setShowClosed] = useState(false);
  const { data, loading } = useLoad(() => api(`/jobs?mine=1&pageSize=100&sort=scheduled_at&status=${showClosed ? 'done,failed,cancelled' : OPEN.join(',')}`), [showClosed, reloadKey]);
  const rows = data?.rows || [];
  const today = dayKey(new Date());
  const groups = useMemo(() => {
    const g = {};
    for (const j of rows) {
      const k = j.scheduled_at ? (dayKey(new Date(j.scheduled_at)) < today && !showClosed ? 'Overdue' : new Date(j.scheduled_at).toLocaleDateString('en-GB', { weekday: 'long', day: '2-digit', month: 'short' })) : 'Not scheduled';
      (g[k] ||= []).push(j);
    }
    return Object.entries(g);
  }, [rows, today, showClosed]);
  return (
    <div className="col">
      <div className="row" style={{ gap: 8 }}>
        <button type="button" className={`chip ${!showClosed ? 'on' : ''}`} onClick={() => setShowClosed(false)}>Open</button>
        <button type="button" className={`chip ${showClosed ? 'on' : ''}`} onClick={() => setShowClosed(true)}>Completed</button>
      </div>
      {loading && !rows.length ? <Spinner /> : !rows.length ? <Card><Empty icon={CheckCircle2} title={showClosed ? 'No completed jobs yet' : 'No open jobs assigned to you'} /></Card> : groups.map(([g, items]) => (
        <div key={g}>
          <div className="row mb" style={{ gap: 8 }}><b style={{ color: g === 'Overdue' ? 'var(--bad)' : undefined }}>{g}</b><span className="faint">{items.length}</span></div>
          <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 12 }}>
            {items.map((j) => (
              <div key={j.id} className="col" style={{ gap: 0 }}>
                <JobCard j={j} onOpen={onOpen} />
                {directionsUrl(j) && !showClosed && <a className="btn sm" style={{ marginTop: -4 }} href={directionsUrl(j)} target="_blank" rel="noopener noreferrer"><Navigation size={14} /> Directions</a>}
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function Schedule({ filters, onOpen, reloadKey }) {
  const [start, setStart] = useState(() => { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return d; });
  const days = Array.from({ length: 7 }, (_, i) => { const d = new Date(start); d.setDate(d.getDate() + i); return d; });
  const end = new Date(start); end.setDate(end.getDate() + 7);
  const qs = new URLSearchParams(Object.entries({ ...filters, from: start.toISOString(), to: end.toISOString(), tz: String(TZ) }).filter(([, v]) => v)).toString();
  const { data, loading } = useLoad(() => api(`/jobs/calendar?${qs}`), [qs, reloadKey]);
  const shift = (n) => setStart((s) => { const d = new Date(s); d.setDate(d.getDate() + n); return d; });
  const today = dayKey(new Date());
  return (
    <div className="col">
      <div className="row between wrap">
        <div className="row" style={{ gap: 6 }}>
          <Button size="sm" icon={ChevronLeft} onClick={() => shift(-7)} aria-label="Previous week" />
          <Button size="sm" onClick={() => setStart(() => { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return d; })}>This week</Button>
          <Button size="sm" icon={ChevronRight} onClick={() => shift(7)} aria-label="Next week" />
        </div>
        <b>{days[0].toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })} – {days[6].toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}</b>
        <span className="faint">{loading ? 'Loading…' : `${data?.total ?? 0} job(s)`}</span>
      </div>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 10 }}>
        {days.map((d) => {
          const k = dayKey(d); const items = data?.days?.[k] || [];
          return (
            <div key={k} className="kanban-col" style={{ minHeight: 160, borderStyle: k === today ? 'solid' : 'dashed', borderColor: k === today ? 'var(--brand-1)' : undefined }}>
              <div className="row between mb"><b>{d.toLocaleDateString('en-GB', { weekday: 'short', day: '2-digit' })}</b><span className="faint">{items.length || ''}</span></div>
              {items.map((j) => <JobCard key={j.id} j={j} onOpen={onOpen} compact />)}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ------------------------------------------------------------------ page
export default function Jobs() {
  const { can, toast } = useApp();
  const [params, setParams] = useSearchParams();
  const viewer = can('jobs.view') || can('jobs.manage');
  const manager = can('jobs.manage');
  const worker = can('jobs.work');
  const tabs = viewer ? [{ value: 'board', label: 'Board' }, { value: 'list', label: 'List' }, { value: 'schedule', label: 'Schedule' }, ...(worker ? [{ value: 'mine', label: 'My jobs' }] : [])]
    : [{ value: 'mine', label: 'My jobs' }, { value: 'schedule', label: 'Schedule' }];
  const [tab, setTab] = useState(viewer ? 'board' : 'mine');
  const [q, setQ] = useState('');
  const [qDebounced, setQDebounced] = useState('');
  const [type, setType] = useState('');
  const [tech, setTech] = useState('');
  const [priority, setPriority] = useState('');
  const [editing, setEditing] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);
  useEffect(() => { const t = setTimeout(() => setQDebounced(q.trim()), 300); return () => clearTimeout(t); }, [q]);

  const meta = useLoad(() => api('/jobs/meta'));
  const techs = useLoad(() => (viewer ? api('/jobs/technicians') : Promise.resolve({ technicians: [] })), [viewer]);
  const summary = useLoad(() => api(`/jobs/summary?tz=${TZ}`), [reloadKey]);

  const openId = Number(params.get('job')) || null;
  const fromTicket = Number(params.get('fromTicket')) || null;
  // From a customer's page: /admin/jobs?customer=<id>&new=1 opens a new job already linked to that customer.
  useEffect(() => {
    const cid = Number(params.get('customer'));
    if (!params.get('new') || !cid || !manager) return;
    api(`/customers/${cid}`).then((r) => setEditing({ customer_id: cid, customer_name: r.customer.name, customer_code: r.customer.code, address: r.customer.address || '' }))
      .catch(() => setEditing({ customer_id: cid })).finally(() => setParams((p) => { p.delete('new'); p.delete('customer'); return p; }, { replace: true }));
  }, [params.get('customer'), params.get('new')]); // eslint-disable-line react-hooks/exhaustive-deps
  const openJob = (id) => setParams((p) => { const n = new URLSearchParams(p); n.set('job', String(id)); return n; });
  const closeParam = (key) => setParams((p) => { const n = new URLSearchParams(p); n.delete(key); return n; }, { replace: true });
  const changed = () => setReloadKey((k) => k + 1);

  const filters = { q: qDebounced, type, priority, assigned_to: tab === 'mine' ? '' : tech };
  const s = summary.data;

  const createFromTicket = async () => {
    try {
      const out = await api.post(`/jobs/from-ticket/${fromTicket}`, {});
      toast(`Job ${out.number} created from the ticket`);
      changed();
      setParams(() => new URLSearchParams({ job: String(out.id) }), { replace: true });
    } catch (e) { toast(e.message, 'bad'); }
  };

  return (
    <Page title="Field jobs" subtitle="Installations, repairs and site visits — schedule technicians and track every work order"
      actions={manager && <Button variant="primary" icon={Plus} onClick={() => setEditing({})}>New job</Button>}>
      <div className="grid g4 mb">
        <Stat icon={ClipboardList} label={viewer ? 'Open jobs' : 'My open jobs'} value={s?.open ?? 0} sub={s ? `${s.byStatus.on_site} on site · ${s.byStatus.en_route} en route` : ''} />
        <Stat icon={CalendarDays} label="Today" value={s?.today.count ?? 0} sub="scheduled for today" />
        <Stat icon={AlertTriangle} label="Overdue" value={s?.overdue ?? 0} sub="past their time, not started" />
        <Stat icon={User} label="Unassigned" value={s?.unassigned ?? 0} sub="open jobs without a technician" />
      </div>

      <div className="row between wrap mb" style={{ gap: 10 }}>
        <Tabs tabs={tabs} value={tab} onChange={setTab} />
        {tab !== 'mine' && (
          <div className="row wrap" style={{ gap: 8 }}>
            <div className="row" style={{ position: 'relative' }}>
              <Search size={15} style={{ position: 'absolute', left: 10, opacity: 0.6 }} aria-hidden="true" />
              <input className="input" style={{ paddingLeft: 32, minWidth: 180 }} placeholder="Search jobs…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search jobs" />
            </div>
            <select className="input" style={{ width: 'auto' }} value={type} onChange={(e) => setType(e.target.value)} aria-label="Filter by type">
              <option value="">All types</option>{TYPES.map((t) => <option key={t} value={t}>{label(t)}</option>)}
            </select>
            <select className="input" style={{ width: 'auto' }} value={priority} onChange={(e) => setPriority(e.target.value)} aria-label="Filter by priority">
              <option value="">Any priority</option>{PRIORITIES.map((t) => <option key={t} value={t}>{label(t)}</option>)}
            </select>
            {viewer && (
              <select className="input" style={{ width: 'auto' }} value={tech} onChange={(e) => setTech(e.target.value)} aria-label="Filter by technician">
                <option value="">All technicians</option><option value="none">Unassigned</option>
                {(techs.data?.technicians || []).map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
              </select>
            )}
          </div>
        )}
      </div>

      {tab === 'board' && <Board filters={filters} onOpen={openJob} reloadKey={reloadKey} onChanged={changed} />}
      {tab === 'list' && <ListView filters={filters} onOpen={openJob} reloadKey={reloadKey} />}
      {tab === 'schedule' && <Schedule filters={filters} onOpen={openJob} reloadKey={reloadKey} />}
      {tab === 'mine' && <MyJobs onOpen={openJob} reloadKey={reloadKey} />}

      {openId && !editing && <JobDetail id={openId} onClose={() => closeParam('job')} onChanged={changed} onEdit={(j) => setEditing(j)} />}
      {editing && <JobForm job={editing} meta={meta.data} techs={techs.data?.technicians || []} onClose={() => setEditing(null)}
        onSaved={(id) => { setEditing(null); changed(); openJob(id); }} />}
      {manager && <Confirm open={!!fromTicket} onClose={() => closeParam('fromTicket')} onConfirm={createFromTicket} confirmText="Create job" title="Create a field job from this ticket?">
        A repair job will be created with the ticket's customer, subject and priority. You can schedule and assign it next.
      </Confirm>}
    </Page>
  );
}
