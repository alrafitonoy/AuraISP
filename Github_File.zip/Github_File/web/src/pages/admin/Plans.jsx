import { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Pencil, Trash2, Star, Check } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { money, speed, toCents } from '../../lib/format.js';
import { Badge, Button, Confirm, Input, Modal, Page, Select, Spinner, Textarea, Toggle, useLoad, fadeUp, stagger } from '../../components/ui.jsx';

function PlanForm({ initial, onSubmit }) {
  const [f, setF] = useState({
    name: '', description: '', download_mbps: 20, upload_mbps: 20, price: 1000, setup_fee: 0, billing_cycle: 'monthly', data_cap_gb: 0,
    features: '', is_public: true, is_featured: false, is_default: false, active: true, sort: 0,
    ...(initial ? { ...initial, download_mbps: initial.download_kbps / 1000, upload_mbps: initial.upload_kbps / 1000, price: initial.price_cents / 100, setup_fee: (initial.setup_fee_cents || 0) / 100, data_cap_gb: (initial.data_cap_mb || 0) / 1024, features: (initial.features || []).join('\n') } : {}),
  });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault(); setBusy(true);
    try {
      await onSubmit({
        name: f.name, description: f.description, download_kbps: Math.round(f.download_mbps * 1000), upload_kbps: Math.round(f.upload_mbps * 1000),
        price_cents: toCents(f.price), setup_fee_cents: toCents(f.setup_fee), billing_cycle: f.billing_cycle, data_cap_mb: Math.round(Number(f.data_cap_gb) * 1024),
        features: f.features.split('\n').map((s) => s.trim()).filter(Boolean).slice(0, 20), is_public: f.is_public, is_featured: f.is_featured, is_default: f.is_default, active: f.active, sort: Number(f.sort) || 0,
      });
    } finally { setBusy(false); }
  };
  return (
    <form className="col" onSubmit={submit}>
      <div className="grid g2">
        <Input label="Name" required value={f.name} onChange={set('name')} />
        <Select label="Billing cycle" value={f.billing_cycle} onChange={set('billing_cycle')} options={['monthly', 'quarterly', 'yearly']} />
        <Input label="Download (Mbps)" type="number" min={0.064} step="any" required value={f.download_mbps} onChange={set('download_mbps')} />
        <Input label="Upload (Mbps)" type="number" min={0.064} step="any" required value={f.upload_mbps} onChange={set('upload_mbps')} />
        <Input label="Price" type="number" min={0} step="0.01" required value={f.price} onChange={set('price')} />
        <Input label="Setup fee" type="number" min={0} step="0.01" value={f.setup_fee} onChange={set('setup_fee')} />
        <Input label="Data cap (GB, 0 = unlimited)" type="number" min={0} value={f.data_cap_gb} onChange={set('data_cap_gb')} />
        <Input label="Sort order" type="number" value={f.sort} onChange={set('sort')} />
      </div>
      <Textarea label="Description" value={f.description || ''} onChange={set('description')} rows={2} />
      <Textarea label="Features (one per line)" value={f.features} onChange={set('features')} rows={4} />
      <div className="grid g2">
        <Toggle checked={f.active} onChange={(v) => setF({ ...f, active: v })} label="Active" />
        <Toggle checked={f.is_public} onChange={(v) => setF({ ...f, is_public: v })} label="Show on website & portal" />
        <Toggle checked={f.is_featured} onChange={(v) => setF({ ...f, is_featured: v })} label="Featured (most popular)" />
        <Toggle checked={f.is_default} onChange={(v) => setF({ ...f, is_default: v })} label="Default plan" />
      </div>
      <Button variant="primary" type="submit" loading={busy}>Save plan</Button>
    </form>
  );
}

export default function Plans() {
  const { toast, can } = useApp();
  const { data, reload } = useLoad(() => api('/plans'));
  const [editing, setEditing] = useState(null);
  const [deleting, setDeleting] = useState(null);
  if (!data) return <Spinner />;
  const save = async (payload) => {
    try {
      if (editing?.id) await api.put(`/plans/${editing.id}`, payload); else await api.post('/plans', payload);
      toast('Plan saved'); setEditing(null); reload();
    } catch (e) { toast(e.message, 'bad'); }
  };
  return (
    <Page title="Plans & packages" subtitle="Default plans offered on the website and portal" actions={can('plans.manage') && <Button variant="primary" icon={Plus} onClick={() => setEditing({})}>New plan</Button>}>
      <motion.div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))' }} variants={stagger} initial="hidden" animate="show">
        {data.plans.map((p) => (
          <motion.div key={p.id} variants={fadeUp} className={`card plan-card hover ${p.is_featured ? 'glow' : ''}`} style={{ opacity: p.active ? 1 : .55 }}>
            <div className="row between"><h3 style={{ margin: 0 }}>{p.name}</h3><div className="row" style={{ gap: 6 }}>{p.is_default && <Badge kind="brand">default</Badge>}{p.is_featured && <Star size={16} color="var(--warn)" />}{!p.is_public && <Badge kind="info">hidden</Badge>}{!p.active && <Badge kind="bad">inactive</Badge>}</div></div>
            <div className="gradient-text" style={{ font: '700 24px var(--font-display)' }}>{speed(p.download_kbps)} / {speed(p.upload_kbps)}</div>
            <div className="price">{money(p.price_cents)}<small> /{p.billing_cycle}</small></div>
            <ul>{p.features.slice(0, 4).map((f) => <li key={f}><Check size={15} />{f}</li>)}</ul>
            <div className="grow" />
            <div className="row between"><span className="faint">{p.subscribers} active subscribers</span>
              {can('plans.manage') && <div className="row"><Button size="sm" variant="ghost" icon={Pencil} onClick={() => setEditing(p)} aria-label="Edit" /><Button size="sm" variant="ghost" icon={Trash2} onClick={() => setDeleting(p)} aria-label="Delete" /></div>}
            </div>
          </motion.div>
        ))}
      </motion.div>
      <Modal wide open={!!editing} onClose={() => setEditing(null)} title={editing?.id ? `Edit ${editing.name}` : 'New plan'}>{editing && <PlanForm initial={editing.id ? editing : null} onSubmit={save} />}</Modal>
      <Confirm open={!!deleting} onClose={() => setDeleting(null)} danger confirmText="Delete" title={`Delete ${deleting?.name}?`} onConfirm={async () => { try { await api.del(`/plans/${deleting.id}`); toast('Plan deleted'); reload(); } catch (e) { toast(e.message, 'bad'); } }}>
        Plans with subscribers cannot be deleted — deactivate them instead.
      </Confirm>
    </Page>
  );
}
