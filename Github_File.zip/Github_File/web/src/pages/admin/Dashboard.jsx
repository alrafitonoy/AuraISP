import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, Wallet, AlertCircle, LifeBuoy, LayoutGrid, Activity, TrendingUp, ClipboardList, Boxes } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { ago, bps, label, money, moneyShort } from '../../lib/format.js';
import { Badge, Button, Card, Modal, Page, Spinner, Stat, useLoad } from '../../components/ui.jsx';
import { AreaSeries, Bars, Donut } from '../../components/charts.jsx';

const WIDGET_LABELS = {
  kpi_customers: 'Customers KPI', kpi_revenue: 'Revenue', kpi_due: 'Outstanding dues', kpi_tickets: 'Open tickets', revenue_chart: 'Revenue chart',
  live_bandwidth: 'Live bandwidth', top_users: 'Top users', plan_distribution: 'Plan distribution', recent_tickets: 'Recent tickets',
  recent_payments: 'Recent payments', sales_funnel: 'Sales funnel', network_status: 'Router status',
};

export default function Dashboard() {
  const { user, liveBw, toast } = useApp();
  const nav = useNavigate();
  const { data, reload } = useLoad(() => api('/dashboard'));
  const [customize, setCustomize] = useState(false);
  const [sel, setSel] = useState([]);
  if (!data) return <Spinner />;
  const d = data.data;
  const has = (w) => data.widgets.includes(w);
  const kpis = data.widgets.filter((w) => w.startsWith('kpi_'));

  const saveLayout = async () => {
    try { await api.put('/dashboard/layout', { widgets: sel }); setCustomize(false); toast('Dashboard updated'); reload(); } catch (e) { toast(e.message, 'bad'); }
  };

  return (
    <Page title={`Good ${new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 18 ? 'afternoon' : 'evening'}, ${user.name.split(' ')[0]}`} subtitle="Here's what's happening across your network today"
      actions={user.type === 'admin' && <Button icon={LayoutGrid} onClick={() => { setSel(data.widgets); setCustomize(true); }}>Customize</Button>}>
      {kpis.length > 0 && (
        <div className="grid g4 mb">
          {has('kpi_customers') && <Stat icon={Users} label="Active customers" value={d.kpi_customers.byStatus.active || 0} sub={`+${d.kpi_customers.newThisMonth} this month · ${d.kpi_customers.byStatus.suspended || 0} suspended`} />}
          {has('kpi_revenue') && <Stat icon={Wallet} label="Collected this month" value={d.kpi_revenue.current} format={moneyShort} delta={d.kpi_revenue.previous ? ((d.kpi_revenue.current - d.kpi_revenue.previous) / d.kpi_revenue.previous) * 100 : undefined} sub="vs last month" />}
          {has('kpi_due') && <Stat icon={AlertCircle} label="Outstanding" value={d.kpi_due.amount} format={moneyShort} sub={`${d.kpi_due.count} invoices · ${d.kpi_due.overdue} overdue`} />}
          {has('finance_profit') && d.finance_profit && <Stat icon={TrendingUp} label="Profit this month" value={d.finance_profit.profit_cents} format={moneyShort} sub={`${money(d.finance_profit.income_cents)} in · ${money(d.finance_profit.expense_cents)} out`} />}
          {has('jobs_today') && d.jobs_today && <Stat icon={ClipboardList} label="Field jobs today" value={d.jobs_today.today} sub={`${d.jobs_today.open} open · ${d.jobs_today.overdue} overdue`} />}
          {has('inventory_stock') && d.inventory_stock && <Stat icon={Boxes} label="Stock value" value={d.inventory_stock.stock_value_cents} format={moneyShort} sub={`${d.inventory_stock.items_deployed} deployed · ${d.inventory_stock.low_stock_count} low stock`} />}
          {has('kpi_tickets') && <Stat icon={LifeBuoy} label="Open tickets" value={d.kpi_tickets.total} sub={`${d.kpi_tickets.byPriority.urgent || 0} urgent · ${d.kpi_tickets.byPriority.high || 0} high`} />}
        </div>
      )}
      <div className="grid g3">
        {has('live_bandwidth') && (
          <Card className="span2" title="Network throughput" actions={<span className="row faint"><span className="pulse-dot" /> {bps((liveBw?.rx_bps ?? d.live_bandwidth.totals.rx_bps) || 0)} ↓ · {liveBw?.online ?? d.live_bandwidth.totals.online} online</span>}>
            <AreaSeries data={d.live_bandwidth.series} x="ts" fmtX={(v) => new Date(v).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} fmtY={bps} series={[{ key: 'rx', label: 'Download' }, { key: 'tx', label: 'Upload' }]} />
          </Card>
        )}
        {has('top_users') && (
          <Card title="Top users now" actions={<Activity size={16} className="muted" />}>
            {d.top_users.map((u, i) => (
              <div key={u.customer_id} className="list-item" style={{ cursor: 'pointer' }} onClick={() => nav(`/admin/customers/${u.customer_id}`)}>
                <span className="faint" style={{ width: 16 }}>{i + 1}</span><div className="grow"><b style={{ fontSize: 14 }}>{u.name}</b><div className="faint">{u.code}</div></div><span className="mono">{bps(u.rx_bps)}</span>
              </div>
            ))}
          </Card>
        )}
        {has('revenue_chart') && (
          <Card className="span2" title="Revenue — last 12 months">
            <Bars data={d.revenue_chart} x="month" fmtY={moneyShort} fmtX={(m) => new Date(`${m}-01`).toLocaleDateString('en', { month: 'short' })} series={[{ key: 'billed', label: 'Billed', color: 'var(--brand-2)' }, { key: 'collected', label: 'Collected', color: 'var(--brand-1)' }]} />
          </Card>
        )}
        {has('plan_distribution') && <Card title="Plan distribution"><Donut data={d.plan_distribution.map((p) => ({ name: p.name, value: Number(p.n) }))} /></Card>}
        {has('recent_tickets') && (
          <Card title="Recent tickets" actions={<Button size="sm" variant="ghost" onClick={() => nav('/admin/tickets')}>All</Button>}>
            {d.recent_tickets.map((t) => (
              <div key={t.id} className="list-item" style={{ cursor: 'pointer' }} onClick={() => nav(`/admin/tickets/${t.id}`)}>
                <div className="grow" style={{ minWidth: 0 }}><b style={{ fontSize: 14 }}>{t.subject}</b><div className="faint">{t.customer_name} · {ago(t.updated_at)}</div></div><Badge status={t.priority} />
              </div>
            ))}
          </Card>
        )}
        {has('recent_payments') && (
          <Card title="Recent payments">
            {d.recent_payments.map((p) => <div key={p.id} className="list-item"><div className="grow"><b style={{ fontSize: 14 }}>{p.customer_name}</b><div className="faint">{label(p.method)} · {ago(p.completed_at)}</div></div><b>{money(p.amount_cents)}</b></div>)}
          </Card>
        )}
        {has('sales_funnel') && <Card title="Sales funnel"><Bars data={['new', 'contacted', 'qualified', 'proposal', 'won', 'lost'].map((s) => ({ s, n: Number(d.sales_funnel.find((x) => x.status === s)?.n || 0) }))} x="s" series={[{ key: 'n', label: 'Leads' }]} height={220} /></Card>}
        {has('network_status') && (
          <Card title="Routers">
            {!d.network_status.length && <div className="faint">No routers yet</div>}
            {d.network_status.map((r) => <div key={r.id} className="list-item"><div className="grow"><b style={{ fontSize: 14 }}>{r.name}</b><div className="faint">{r.location || r.driver} · seen {ago(r.last_seen_at)}</div></div><Badge status={r.status} /></div>)}
          </Card>
        )}
      </div>
      <Modal open={customize} onClose={() => setCustomize(false)} title="Customize your dashboard" footer={<><Button onClick={() => setCustomize(false)}>Cancel</Button><Button variant="primary" onClick={saveLayout}>Save</Button></>}>
        <p className="muted">Choose the widgets you want to see. Staff dashboards are configured per role under Staff & roles.</p>
        <div className="grid g2">{Object.entries(WIDGET_LABELS).map(([k, l]) => <label key={k} className="check"><input type="checkbox" checked={sel.includes(k)} onChange={(e) => setSel(e.target.checked ? [...sel, k] : sel.filter((x) => x !== k))} />{l}</label>)}</div>
      </Modal>
    </Page>
  );
}
