// CRM live-chat inbox: agents pick up conversations started from the website/app chatbot.
import { useEffect, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Send, UserPlus, LifeBuoy, XCircle, Hand, User, MessagesSquare } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { ago, dateTime } from '../../lib/format.js';
import { Avatar, Badge, Button, Card, Empty, Page, Spinner, Tabs, useLoad } from '../../components/ui.jsx';

const STATUS_TONE = { waiting: 'warn', active: 'ok', closed: 'info' };

function Thread({ id, onChanged }) {
  const { toast, user, chatTick } = useApp();
  const nav = useNavigate();
  const { data, reload } = useLoad(() => api(`/chat/conversations/${id}`), [id]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState('');
  const end = useRef(null);
  useEffect(() => { const t = setInterval(reload, 3000); return () => clearInterval(t); }, [reload]);
  useEffect(() => { reload(); }, [chatTick]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }); }, [data?.messages?.length]);
  if (!data) return <Card><Spinner /></Card>;
  const c = data.conversation;
  const act = async (name, fn, msg) => {
    setBusy(name);
    try { const r = await fn(); if (msg) toast(msg); reload(); onChanged(); return r; } catch (e) { toast(e.message, 'bad'); } finally { setBusy(''); }
    return null;
  };
  const send = async (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    const body = text; setText('');
    await act('send', () => api.post(`/chat/conversations/${id}/reply`, { body }));
  };
  const mineOrFree = !c.assigned_to || c.assigned_to === user.id || user.type === 'admin';
  return (
    <Card className="col" style={{ minHeight: '60vh' }}>
      <div className="row wrap between">
        <div className="row"><Avatar user={{ name: c.guest_name }} size={40} /><div><b>{c.guest_name}</b><div className="faint">{c.guest_contact}{c.topic ? ` · ${c.topic}` : ''}</div></div></div>
        <div className="row wrap" style={{ gap: 6 }}>
          <Badge kind={STATUS_TONE[c.status]}>{c.status}</Badge>
          {c.status !== 'closed' && !c.assigned_to && <Button size="sm" icon={Hand} loading={busy === 'claim'} onClick={() => act('claim', () => api.post(`/chat/conversations/${id}/claim`), 'You joined the chat')}>Join</Button>}
          {data.customer ? <Button size="sm" icon={User} onClick={() => nav(`/admin/customers/${data.customer.id}`)}>Customer {data.customer.code}</Button>
            : <Button size="sm" icon={UserPlus} loading={busy === 'lead'} disabled={!!c.lead_id} onClick={() => act('lead', () => api.post(`/chat/conversations/${id}/lead`), 'Lead created in the CRM pipeline')}>{c.lead_id ? 'Lead created' : 'Create lead'}</Button>}
          {data.customer && <Button size="sm" icon={LifeBuoy} loading={busy === 'ticket'} disabled={!!c.ticket_id} onClick={async () => { const r = await act('ticket', () => api.post(`/chat/conversations/${id}/ticket`), 'Ticket created'); if (r?.id) nav(`/admin/tickets/${r.id}`); }}>{c.ticket_id ? 'Ticket created' : 'Create ticket'}</Button>}
          {c.status !== 'closed' && <Button size="sm" variant="danger" icon={XCircle} loading={busy === 'close'} onClick={() => act('close', () => api.post(`/chat/conversations/${id}/close`), 'Chat closed')}>End</Button>}
        </div>
      </div>
      {data.customer && <div className="faint">Plan: <b>{data.customer.plan_name || '—'}</b> · Status: <Badge status={data.customer.status} /> · {data.customer.area || ''}</div>}
      <div className="divider" style={{ margin: '4px 0' }} />
      <div className="thread grow">
        {data.messages.map((m) => m.sender === 'system' ? <div key={m.id} className="chat-system">{m.body}</div> : (
          <motion.div key={m.id} initial={{ y: 6 }} animate={{ y: 0 }} className="row" style={{ alignItems: 'flex-end', flexDirection: m.sender === 'agent' ? 'row-reverse' : 'row' }}>
            <Avatar user={m.sender === 'agent' ? { name: m.name, avatar: m.avatar } : { name: c.guest_name }} size={30} />
            <div style={{ maxWidth: '75%' }}>
              <div className="faint" style={{ textAlign: m.sender === 'agent' ? 'right' : 'left' }}>{m.sender === 'agent' ? m.name : c.guest_name} · {dateTime(m.created_at)}</div>
              <div className={`bubble ${m.sender === 'agent' ? 'me' : 'bot'}`} style={{ maxWidth: '100%', marginTop: 3 }}>{m.body}</div>
            </div>
          </motion.div>
        ))}
        <div ref={end} />
      </div>
      {c.status !== 'closed' && (mineOrFree
        ? <form className="row" onSubmit={send}><input className="input" value={text} onChange={(e) => setText(e.target.value)} placeholder="Reply to the customer…" maxLength={2000} aria-label="Reply" autoFocus /><Button variant="primary" type="submit" icon={Send} loading={busy === 'send'}>Send</Button></form>
        : <div className="alert info"><div>Another agent is handling this conversation.</div></div>)}
    </Card>
  );
}

export default function LiveChat() {
  const { chatTick } = useApp();
  const [params, setParams] = useSearchParams();
  const [tab, setTab] = useState('open');
  const selected = Number(params.get('c')) || null;
  const list = useLoad(() => api(`/chat/conversations?${tab === 'mine' ? 'status=open&mine=1' : `status=${tab}`}`), [tab]);
  useEffect(() => { const t = setInterval(list.reload, 5000); return () => clearInterval(t); }, [list.reload]);
  useEffect(() => { list.reload(); }, [chatTick]); // eslint-disable-line react-hooks/exhaustive-deps
  const rows = list.data?.rows || [];
  return (
    <Page title="Live chat" subtitle={`${list.data?.waiting ?? 0} waiting · customers & visitors who asked for a human from the chatbot`}>
      <div className="mb"><Tabs tabs={[{ value: 'open', label: 'Open' }, { value: 'waiting', label: 'Waiting' }, { value: 'mine', label: 'Mine' }, { value: 'closed', label: 'Closed' }]} value={tab} onChange={setTab} /></div>
      <div className="inbox">
        <Card className="col" style={{ padding: 10, gap: 4, maxHeight: '70vh', overflowY: 'auto' }}>
          {!rows.length && <Empty icon={MessagesSquare} title="No conversations">New chats appear here instantly.</Empty>}
          {rows.map((r) => (
            <div key={r.id} className={`conv ${selected === r.id ? 'on' : ''}`} onClick={() => setParams({ c: r.id })} role="button" tabIndex={0} onKeyDown={(e) => e.key === 'Enter' && setParams({ c: r.id })}>
              <Avatar user={{ name: r.guest_name }} size={36} />
              <div className="grow" style={{ minWidth: 0 }}>
                <div className="row between"><b style={{ fontSize: 14, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.guest_name}</b><span className="faint">{ago(r.last_message_at)}</span></div>
                <div className="row" style={{ gap: 6 }}><Badge kind={STATUS_TONE[r.status]}>{r.status}</Badge>{r.customer_code && <span className="faint">{r.customer_code}</span>}{r.agent_name && <span className="faint">· {r.agent_name}</span>}</div>
              </div>
              {r.unread_staff > 0 && <span className="chat-badge" style={{ position: 'static' }}>{r.unread_staff}</span>}
            </div>
          ))}
        </Card>
        {selected ? <Thread id={selected} onChanged={list.reload} /> : <Card><Empty icon={MessagesSquare} title="Select a conversation">Pick a chat on the left to reply.</Empty></Card>}
      </div>
    </Page>
  );
}
