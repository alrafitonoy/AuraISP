import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Pencil, Trash2, MapPinned, Users, Wallet, AlertTriangle, ChevronRight, Search, UserPlus, Router as RouterIcon, X, Layers } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { money, moneyShort } from '../../lib/format.js';
import { Badge, Button, Card, Confirm, DataTable, Empty, Input, Modal, Page, Pager, Select, Spinner, Stat, Tabs, Textarea, Toggle, useLoad } from '../../components/ui.jsx';

/** Flatten zones into tree order with depth, so children follow their parent. Orphans/cycles fall back to the root. */
function treeOrder(zones) {
  const ids = new Set(zones.map((z) => z.id));
  const kids = new Map();
  for (const z of zones) { const p = z.parent_id && ids.has(z.parent_id) ? z.parent_id : 0; if (!kids.has(p)) kids.set(p, []); kids.get(p).push(z); }
  const out = []; const seen = new Set();
  const walk = (p, depth) => { for (const z of (kids.get(p) || []).sort((a, b) => a.name.localeCompare(b.name))) { if (seen.has(z.id)) continue; seen.add(z.id); out.push({ ...z, depth }); walk(z.id, depth + 1); } };
  walk(0, 0);
  for (const z of zones) if (!seen.has(z.id)) out.push({ ...z, depth: 0 });
  return out;
}

/** Ids of a zone and all of its descendants (cannot be chosen as its parent). */
function subtreeIds(zones, id) {
  const out = new Set([id]); let grew = true;
  while (grew) { grew = false; for (const z of zones) if (z.parent_id && out.has(z.parent_id) && !out.has(z.id)) { out.add(z.id); grew = true; } }
  return out;
}

const indentName = (z) => `${'   '.repeat(z.depth)}${z.depth ? '↳ ' : ''}${z.name}`;

// ------------------------------------------------------------------ create / edit
function ZoneModal({ zone, zones, onClose, onSaved }) {
  const { toast } = useApp();
  const staff = useLoad(() => api('/zones/staff'));
  const [f, setF] = useState({ name: zone.name || '', parent_id: zone.parent_id ?? '', manager_id: zone.manager_id ?? '', notes: zone.notes || '' });
  const [busy, setBusy] = useState(false);
  const blocked = zone.id ? subtreeIds(zones, zone.id) : new Set();
  const parents = treeOrder(zones).filter((z) => !blocked.has(z.id));
  const save = async (e) => {
    e.preventDefault(); setBusy(true);
    const body = { name: f.name, parent_id: f.parent_id ? Number(f.parent_id) : null, manager_id: f.manager_id ? Number(f.manager_id) : null, notes: f.notes || null };
    try {
      if (zone.id) await api.put(`/zones/${zone.id}`, body); else await api.post('/zones', body);
      toast(zone.id ? 'Zone updated' : 'Zone created'); onSaved(); onClose();
    } catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  return (
    <Modal open onClose={onClose} title={zone.id ? `Edit ${zone.name}` : 'New zone'}>
      <form className="col" onSubmit={save}>
        <Input label="Name" required minLength={2} maxLength={120} autoFocus value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} placeholder="e.g. Mirpur POP" />
        <Select label="Parent zone" value={f.parent_id} onChange={(e) => setF({ ...f, parent_id: e.target.value })} options={[{ value: '', label: '— Top level —' }, ...parents.map((z) => ({ value: z.id, label: indentName(z) }))]} />
        <Select label="Manager" value={f.manager_id} onChange={(e) => setF({ ...f, manager_id: e.target.value })} options={[{ value: '', label: '— None —' }, ...(staff.data?.staff || []).map((s) => ({ value: s.id, label: `${s.name} (${s.email})` }))]} />
        <Textarea label="Notes" maxLength={250} value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} placeholder="POP address, upstream, contact…" />
        <div className="row end"><Button type="button" onClick={onClose}>Cancel</Button><Button variant="primary" type="submit" loading={busy}>Save</Button></div>
      </form>
    </Modal>
  );
}

// ------------------------------------------------------------------ bulk assign by area
function AreaAssign({ zones, initialZone, onClose, onDone }) {
  const { toast } = useApp();
  const areas = useLoad(() => api('/zones/areas'));
  const [zoneId, setZoneId] = useState(initialZone ?? '');
  const [area, setArea] = useState('');
  const [onlyUnassigned, setOnlyUnassigned] = useState(true);
  const [busy, setBusy] = useState(false);
  const chosen = (areas.data?.areas || []).find((a) => a.area === area);
  const run = async () => {
    setBusy(true);
    try {
      const r = await api.post(`/zones/${zoneId}/assign-area`, { area, only_unassigned: onlyUnassigned });
      toast(`${r.updated} customer(s) moved into the zone`); onDone(); onClose();
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  };
  return (
    <Modal open onClose={onClose} title="Assign customers by area" footer={<>
      <Button onClick={onClose}>Cancel</Button>
      <Button variant="primary" icon={Layers} loading={busy} disabled={!zoneId || !area} onClick={run}>Assign {chosen ? (onlyUnassigned ? chosen.unassigned : chosen.customers) : ''} customer(s)</Button>
    </>}>
      {areas.loading ? <Spinner /> : !(areas.data?.areas || []).length ? <Empty icon={MapPinned} title="No customer areas yet">Fill in the “Area” field on customers to assign them in bulk.</Empty> : (
        <div className="col">
          <p className="muted" style={{ margin: 0 }}>Every customer whose <b>Area</b> matches (ignoring case and spaces) joins the zone.</p>
          <Select label="Zone" value={zoneId} onChange={(e) => setZoneId(e.target.value)} options={[{ value: '', label: '— Choose a zone —' }, ...treeOrder(zones).map((z) => ({ value: z.id, label: indentName(z) }))]} />
          <Select label="Area" value={area} onChange={(e) => setArea(e.target.value)} options={[{ value: '', label: '— Choose an area —' }, ...areas.data.areas.map((a) => ({ value: a.area, label: `${a.area} · ${a.customers} customer(s), ${a.unassigned} without zone` }))]} />
          <Toggle checked={onlyUnassigned} onChange={setOnlyUnassigned} label="Only customers without a zone" hint="Turn off to also move customers that are already in another zone" />
        </div>
      )}
    </Modal>
  );
}

// ------------------------------------------------------------------ add customers by search
function AddCustomers({ zone, onClose, onDone }) {
  const { toast } = useApp();
  const [q, setQ] = useState('');
  const [picked, setPicked] = useState(new Map());
  const [busy, setBusy] = useState(false);
  const found = useLoad(() => (q.trim().length >= 2 ? api(`/customers?pageSize=25&q=${encodeURIComponent(q.trim())}`) : Promise.resolve({ rows: [] })), [q]);
  const toggle = (c) => setPicked((m) => { const n = new Map(m); if (n.has(c.id)) n.delete(c.id); else n.set(c.id, c); return n; });
  const run = async () => {
    setBusy(true);
    try { const r = await api.post(`/zones/${zone.id}/customers`, { customer_ids: [...picked.keys()] }); toast(`${r.updated} customer(s) added to ${zone.name}`); onDone(); onClose(); }
    catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  };
  return (
    <Modal open wide onClose={onClose} title={`Add customers to ${zone.name}`} footer={<>
      <Button onClick={onClose}>Cancel</Button>
      <Button variant="primary" icon={UserPlus} loading={busy} disabled={!picked.size} onClick={run}>Add {picked.size || ''} customer(s)</Button>
    </>}>
      <div className="col">
        <div style={{ position: 'relative' }}>
          <Search size={16} style={{ position: 'absolute', left: 12, top: 13, color: 'var(--text-3)' }} />
          <input className="input" style={{ paddingLeft: 36 }} autoFocus placeholder="Search name, phone, code, IP…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search customers" />
        </div>
        {picked.size > 0 && <div className="row wrap">{[...picked.values()].map((c) => <button key={c.id} type="button" className="chip on" onClick={() => toggle(c)} aria-label={`Remove ${c.name}`}>{c.name} <X size={12} /></button>)}</div>}
        {q.trim().length < 2 ? <p className="faint" style={{ margin: 0 }}>Type at least 2 characters to search.</p> : (
          <DataTable loading={found.loading} rows={found.data?.rows} empty="No matching customers" onRowClick={toggle} columns={[
            { key: 'pick', title: '', width: 36, render: (c) => <input type="checkbox" checked={picked.has(c.id)} onChange={() => toggle(c)} onClick={(e) => e.stopPropagation()} aria-label={`Select ${c.name}`} /> },
            { key: 'code', title: 'Code', render: (c) => <span className="mono">{c.code}</span> },
            { key: 'name', title: 'Customer', render: (c) => <div><b>{c.name}</b><div className="faint">{c.phone || c.email}</div></div> },
            { key: 'area', title: 'Area' },
            { key: 'zone_id', title: 'Current zone', render: (c) => (c.zone_id === zone.id ? <Badge kind="ok">this zone</Badge> : c.zone_id ? <Badge kind="info">other zone</Badge> : <span className="faint">none</span>) },
          ]} />
        )}
      </div>
    </Modal>
  );
}

// ------------------------------------------------------------------ routers in a zone
function ZoneRouters({ zone, onDone }) {
  const { toast } = useApp();
  const list = useLoad(() => api('/zones/routers'));
  const [sel, setSel] = useState(null);
  const [busy, setBusy] = useState(false);
  const routers = list.data?.routers || [];
  const current = sel ?? new Set(routers.filter((r) => r.zone_id === zone.id).map((r) => r.id));
  const flip = (id) => { const n = new Set(current); if (n.has(id)) n.delete(id); else n.add(id); setSel(n); };
  const save = async () => {
    setBusy(true);
    try { await api.post(`/zones/${zone.id}/routers`, { router_ids: [...current] }); toast('Routers updated'); setSel(null); list.reload(); onDone(); }
    catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  };
  if (list.loading && !list.data) return <Spinner />;
  if (!routers.length) return <Empty icon={RouterIcon} title="No routers yet" />;
  return (
    <div className="col">
      <div className="table-wrap">
        <table className="t">
          <thead><tr><th style={{ width: 36 }} /><th>Router</th><th>Location</th><th>Zone</th></tr></thead>
          <tbody>{routers.map((r) => (
            <tr key={r.id} className="click" onClick={() => flip(r.id)}>
              <td><input type="checkbox" checked={current.has(r.id)} onChange={() => flip(r.id)} onClick={(e) => e.stopPropagation()} aria-label={`Include ${r.name}`} /></td>
              <td><b>{r.name}</b></td><td>{r.location || <span className="faint">—</span>}</td>
              <td>{r.zone_id === zone.id ? <Badge kind="ok">this zone</Badge> : r.zone_name || <span className="faint">none</span>}</td>
            </tr>
          ))}</tbody>
        </table>
      </div>
      <div className="row end"><Button variant="primary" loading={busy} disabled={!sel} onClick={save}>Save routers</Button></div>
    </div>
  );
}

// ------------------------------------------------------------------ drill-down
function ZoneDetail({ zone, onClose, onChanged }) {
  const { toast, can } = useApp();
  const nav = useNavigate();
  const manage = can('zones.manage');
  const [tab, setTab] = useState('customers');
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const [adding, setAdding] = useState(false);
  const [removing, setRemoving] = useState(null);
  const list = useLoad(() => api(`/zones/${zone.id}/customers?page=${page}&pageSize=20&q=${encodeURIComponent(q)}&status=${status}`), [zone.id, page, q, status]);
  const s = zone.stats;
  const refresh = () => { list.reload(); onChanged(); };
  return (
    <Modal open wide onClose={onClose} title={zone.name}>
      <div className="col">
        <div className="row wrap" style={{ gap: 8 }}>
          <Badge kind="brand">{s.customers} customer(s)</Badge><Badge kind="ok">{s.active_customers} active</Badge><Badge kind="info">{s.routers} router(s)</Badge>
          <Badge kind="info">{money(s.expected_revenue_cents)} / month expected</Badge>
          <Badge kind={s.outstanding_cents ? 'bad' : 'ok'}>{money(s.outstanding_cents)} due</Badge>
          {zone.manager_name && <span className="faint">Manager: {zone.manager_name}</span>}
        </div>
        {zone.notes && <p className="muted" style={{ margin: 0 }}>{zone.notes}</p>}
        {manage && <Tabs tabs={[{ value: 'customers', label: 'Customers' }, { value: 'routers', label: 'Routers' }]} value={tab} onChange={setTab} />}
        {tab === 'customers' ? (
          <>
            <div className="row wrap">
              <div style={{ position: 'relative', flex: '1 1 200px' }}>
                <Search size={16} style={{ position: 'absolute', left: 12, top: 13, color: 'var(--text-3)' }} />
                <input className="input" style={{ paddingLeft: 36 }} placeholder="Search in this zone…" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} aria-label="Search customers in zone" />
              </div>
              <div style={{ width: 160 }}><Select aria-label="Status" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }} options={[{ value: '', label: 'All statuses' }, 'active', 'pending', 'suspended', 'terminated']} /></div>
              {manage && can('customers.view') && <Button icon={UserPlus} onClick={() => setAdding(true)}>Add customers</Button>}
            </div>
            <DataTable loading={list.loading} rows={list.data?.rows} empty="No customers in this zone" onRowClick={can('customers.view') ? (c) => nav(`/admin/customers/${c.id}`) : undefined} columns={[
              { key: 'code', title: 'Code', render: (c) => <span className="mono">{c.code}</span> },
              { key: 'name', title: 'Customer', render: (c) => <div><b>{c.name}</b><div className="faint">{c.phone || c.area || ''}</div></div> },
              { key: 'plan_name', title: 'Plan', render: (c) => (c.plan_name ? <div>{c.plan_name}<div className="faint">{money(c.price_cents)}</div></div> : <span className="faint">—</span>) },
              { key: 'due_cents', title: 'Due', align: 'right', render: (c) => (c.due_cents ? <b style={{ color: 'var(--bad)' }}>{money(c.due_cents)}</b> : <span className="faint">—</span>) },
              { key: 'status', title: 'Status', render: (c) => <Badge status={c.status} /> },
              ...(manage ? [{ key: 'rm', title: '', align: 'right', render: (c) => <Button size="sm" variant="ghost" icon={X} aria-label={`Remove ${c.name} from zone`} title="Remove from zone" onClick={(e) => { e.stopPropagation(); setRemoving(c); }} /> }] : []),
            ]} />
            {list.data && <Pager page={list.data.page} pageSize={list.data.pageSize} total={list.data.total} onPage={setPage} />}
          </>
        ) : <ZoneRouters zone={zone} onDone={onChanged} />}
      </div>
      {adding && <AddCustomers zone={zone} onClose={() => setAdding(false)} onDone={refresh} />}
      <Confirm open={!!removing} title="Remove from zone?" confirmText="Remove" onClose={() => setRemoving(null)} onConfirm={async () => {
        try { await api.post(`/zones/${zone.id}/customers/remove`, { customer_ids: [removing.id] }); toast(`${removing.name} removed from ${zone.name}`); refresh(); }
        catch (e) { toast(e.message, 'bad'); }
      }}>{removing && <>{removing.name} stays a customer but will no longer belong to any zone.</>}</Confirm>
    </Modal>
  );
}

// ------------------------------------------------------------------ page
export default function Zones() {
  const { toast, can } = useApp();
  const manage = can('zones.manage');
  const list = useLoad(() => api('/zones'));
  const [edit, setEdit] = useState(null);
  const [del, setDel] = useState(null);
  const [areaFor, setAreaFor] = useState(undefined);
  const [openId, setOpenId] = useState(null);
  const zones = list.data?.zones || [];
  const ordered = useMemo(() => treeOrder(zones), [zones]);
  const open = zones.find((z) => z.id === openId);
  const un = list.data?.unassigned;

  const sum = (k) => zones.reduce((s, z) => s + (z.stats?.[k] || 0), 0);
  const zonedCustomers = sum('customers');

  return (
    <Page title="Zones & areas" subtitle="Group customers and routers by POP or region and see how each area performs" actions={manage && <>
      <Button icon={Layers} onClick={() => setAreaFor(null)} disabled={!zones.length}>Assign by area</Button>
      <Button variant="primary" icon={Plus} onClick={() => setEdit({})}>New zone</Button>
    </>}>
      {list.error && <div className="alert bad mb">{list.error.message}</div>}
      <div className="grid g4 mb">
        <Stat icon={MapPinned} label="Zones" value={zones.length} sub={`${zones.filter((z) => !z.parent_id).length} top level`} />
        <Stat icon={Users} label="Customers in zones" value={zonedCustomers} sub={un ? `${un.customers} without a zone` : ''} />
        <Stat icon={Wallet} label="Expected monthly" value={sum('expected_revenue_cents') + (un?.expected_revenue_cents || 0)} format={moneyShort} sub="active customers’ plans" />
        <Stat icon={AlertTriangle} label="Outstanding dues" value={sum('outstanding_cents') + (un?.outstanding_cents || 0)} format={moneyShort} sub={`${sum('open_invoices') + (un?.open_invoices || 0)} open invoice(s)`} />
      </div>
      <Card className="flush">
        {list.loading && !list.data ? <Spinner /> : !zones.length ? (
          <Empty icon={MapPinned} title="No zones yet">{manage ? 'Create zones for your POPs or areas, then assign customers in bulk by their area.' : 'Ask an administrator to set up zones.'}</Empty>
        ) : (
          <div className="table-wrap">
            <table className="t">
              <thead><tr>
                <th>Zone</th><th style={{ textAlign: 'right' }}>Customers</th><th style={{ textAlign: 'right' }}>Routers</th>
                <th style={{ textAlign: 'right' }}>Expected / month</th><th style={{ textAlign: 'right' }}>Outstanding</th>{manage && <th />}
              </tr></thead>
              <tbody>
                {ordered.map((z) => (
                  <tr key={z.id} className="click" onClick={() => setOpenId(z.id)}>
                    <td>
                      <div className="row" style={{ gap: 6, paddingLeft: z.depth * 20 }}>
                        {z.depth > 0 && <ChevronRight size={14} style={{ color: 'var(--text-3)', flex: 'none' }} />}
                        <div><b>{z.name}</b><div className="faint">{[z.manager_name && `Manager: ${z.manager_name}`, z.children && `${z.children} sub-zone(s)`].filter(Boolean).join(' · ') || '—'}</div></div>
                      </div>
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      <b>{z.stats.active_customers}</b><span className="faint"> / {z.stats.customers}</span>
                      {z.children > 0 && <div className="faint">{z.totals.customers} incl. sub-zones</div>}
                    </td>
                    <td style={{ textAlign: 'right' }}>{z.stats.routers}</td>
                    <td style={{ textAlign: 'right' }}>{money(z.stats.expected_revenue_cents)}{z.children > 0 && <div className="faint">{money(z.totals.expected_revenue_cents)} total</div>}</td>
                    <td style={{ textAlign: 'right', color: z.stats.outstanding_cents ? 'var(--bad)' : undefined }}>{money(z.stats.outstanding_cents)}{z.children > 0 && <div className="faint">{money(z.totals.outstanding_cents)} total</div>}</td>
                    {manage && (
                      <td style={{ textAlign: 'right' }} onClick={(e) => e.stopPropagation()}>
                        <div className="row end" style={{ gap: 4 }}>
                          <Button size="sm" variant="ghost" icon={Layers} aria-label={`Assign area to ${z.name}`} title="Assign by area" onClick={() => setAreaFor(z.id)} />
                          <Button size="sm" variant="ghost" icon={Pencil} aria-label={`Edit ${z.name}`} onClick={() => setEdit(z)} />
                          <Button size="sm" variant="ghost" icon={Trash2} aria-label={`Delete ${z.name}`} onClick={() => setDel(z)} />
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
                {un && (
                  <tr>
                    <td><b className="muted">No zone</b><div className="faint">Customers and routers not assigned yet</div></td>
                    <td style={{ textAlign: 'right' }}><b>{un.active_customers}</b><span className="faint"> / {un.customers}</span></td>
                    <td style={{ textAlign: 'right' }}>{un.routers}</td>
                    <td style={{ textAlign: 'right' }}>{money(un.expected_revenue_cents)}</td>
                    <td style={{ textAlign: 'right' }}>{money(un.outstanding_cents)}</td>
                    {manage && <td />}
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </Card>
      {edit && <ZoneModal zone={edit} zones={zones} onClose={() => setEdit(null)} onSaved={list.reload} />}
      {areaFor !== undefined && <AreaAssign zones={zones} initialZone={areaFor} onClose={() => setAreaFor(undefined)} onDone={list.reload} />}
      {open && <ZoneDetail zone={open} onClose={() => setOpenId(null)} onChanged={list.reload} />}
      <Confirm open={!!del} danger title="Delete zone?" confirmText="Delete zone" onClose={() => setDel(null)} onConfirm={async () => {
        try {
          const r = await api.del(`/zones/${del.id}`);
          toast(`Zone deleted · ${r.customers} customer(s) and ${r.routers} router(s) are now without a zone`); list.reload();
        } catch (e) { toast(e.message, 'bad'); }
      }}>
        {del && <>“{del.name}” will be deleted. Its {del.stats.customers} customer(s) and {del.stats.routers} router(s) are kept but leave the zone{del.children ? `; its ${del.children} sub-zone(s) move up one level` : ''}.</>}
      </Confirm>
    </Page>
  );
}
