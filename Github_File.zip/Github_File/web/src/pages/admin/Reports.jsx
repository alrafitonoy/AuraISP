import { useState } from 'react';
import { motion } from 'framer-motion';
import { FileDown, Users, Wallet, TrendingUp, Building2 } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { downloadFile } from '../../lib/download.js';
import { Button, Input, Page, fadeUp, stagger } from '../../components/ui.jsx';

const iso = (d) => d.toISOString().slice(0, 10);
const PRESETS = [
  ['This month', () => { const n = new Date(); return [iso(new Date(Date.UTC(n.getFullYear(), n.getMonth(), 1))), iso(n)]; }],
  ['Last month', () => { const n = new Date(); return [iso(new Date(Date.UTC(n.getFullYear(), n.getMonth() - 1, 1))), iso(new Date(Date.UTC(n.getFullYear(), n.getMonth(), 0)))]; }],
  ['Last 90 days', () => [iso(new Date(Date.now() - 90 * 86400000)), iso(new Date())]],
  ['This year', () => [`${new Date().getFullYear()}-01-01`, iso(new Date())]],
];

const REPORTS = [
  { type: 'overall', icon: Building2, title: 'Overall business', text: 'Customers, MRR, ARPU, churn, revenue, network capacity, IP utilisation, top areas.' },
  { type: 'accounts', icon: Wallet, title: 'Accounts', text: 'Collections by month & method, invoiced vs collected, tax, receivables aging, top debtors.' },
  { type: 'sales', icon: TrendingUp, title: 'Sales', text: 'New connections, upgrades, plan mix, staff leaderboard, lead sources and pipeline.' },
  { type: 'customer', icon: Users, title: 'Customer statement', text: 'Profile, plan & IP, statement of account, usage graph, plan changes and tickets.' },
];

export default function Reports() {
  const { toast } = useApp();
  const [[from, to], setRange] = useState(PRESETS[0][1]());
  const [customerId, setCustomerId] = useState('');
  const [busy, setBusy] = useState('');
  const gen = async (type) => {
    if (type === 'customer' && !customerId) { toast('Enter a customer ID', 'bad'); return; }
    setBusy(type);
    try {
      const q = new URLSearchParams({ from, to, ...(type === 'customer' ? { customer_id: customerId } : {}) });
      const name = await downloadFile(`/pdf/reports/${type}?${q}`, { fallbackName: `${type}-report.pdf` });
      toast(`Downloaded ${name}`);
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(''); }
  };
  return (
    <Page title="PDF reports" subtitle="Branded, printable reports for management, accounts and customers">
      <motion.div variants={fadeUp} className="card mb">
        <div className="row wrap" style={{ alignItems: 'flex-end' }}>
          <div style={{ width: 170 }}><Input label="From" type="date" value={from} max={to} onChange={(e) => setRange([e.target.value, to])} /></div>
          <div style={{ width: 170 }}><Input label="To" type="date" value={to} min={from} onChange={(e) => setRange([from, e.target.value])} /></div>
          {PRESETS.map(([l, fn]) => <button key={l} className="chip" onClick={() => setRange(fn())}>{l}</button>)}
        </div>
      </motion.div>
      <motion.div className="grid g2" variants={stagger} initial="hidden" animate="show">
        {REPORTS.map((r) => (
          <motion.div key={r.type} variants={fadeUp} whileHover={{ y: -4 }} className="card hover col">
            <div className="row"><div className="stat"><div className="ico"><r.icon size={18} /></div></div><h3 style={{ margin: 0 }}>{r.title}</h3></div>
            <p className="muted" style={{ margin: 0 }}>{r.text}</p>
            {r.type === 'customer' && <Input label="Customer ID" type="number" min={1} value={customerId} onChange={(e) => setCustomerId(e.target.value)} />}
            <Button variant="primary" icon={FileDown} loading={busy === r.type} onClick={() => gen(r.type)} style={{ alignSelf: 'flex-start' }}>Download PDF</Button>
          </motion.div>
        ))}
      </motion.div>
    </Page>
  );
}
