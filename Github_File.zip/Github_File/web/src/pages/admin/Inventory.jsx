import { useEffect, useRef, useState } from 'react';
import {
  Package, Boxes, Warehouse, History, Plus, PackagePlus, Send, Undo2, AlertTriangle, ArrowLeftRight, Trash2, Pencil, Search, X,
  Wallet, Truck, Router as RouterIcon, UserCheck, Ban,
} from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { dateTime, label, money, toCents } from '../../lib/format.js';
import { Badge, Button, Card, Confirm, DataTable, Empty, Input, Modal, Page, Pager, Select, Spinner, Stat, Tabs, Textarea, Toggle, useLoad } from '../../components/ui.jsx';

// ------------------------------------------------------------------ shared bits
const STATUS_TONE = { in_stock: 'ok', with_staff: 'warn', assigned: 'brand', rented: 'info', sold: 'info', faulty: 'bad', written_off: 'info' };
const STATUSES = ['in_stock', 'with_staff', 'assigned', 'rented', 'sold', 'faulty', 'written_off'];
const CATEGORIES = ['router', 'onu', 'olt', 'switch', 'cable', 'splitter', 'connector', 'media_converter', 'sfp', 'tool', 'accessory', 'other'];
const MOVE_TYPES = ['receive', 'issue', 'issue_staff', 'return', 'transfer', 'faulty', 'write_off', 'edit'];
const MOVE_TONE = { receive: 'ok', issue: 'brand', issue_staff: 'warn', return: 'info', transfer: 'info', faulty: 'bad', write_off: 'bad', edit: 'info' };

const StatusBadge = ({ s }) => <Badge kind={STATUS_TONE[s] || 'info'}>{label(s === 'with_staff' ? 'with staff' : s)}</Badge>;
const qs = (o) => new URLSearchParams(Object.entries(o).filter(([, v]) => v !== '' && v !== null && v !== undefined)).toString();
const qtyText = (row) => (Number(row.track_serial) ? '1' : `${row.qty} ${row.unit || 'pcs'}`);
const holder = (i) => {
  if (['assigned', 'rented', 'sold'].includes(i.status)) return i.customer_name ? `${i.customer_name}${i.customer_code ? ` · ${i.customer_code}` : ''}` : `Customer #${i.customer_id}`;
  if (i.status === 'with_staff') return i.staff_name || 'Staff';
  return i.warehouse_name || '—';
};
/** Readable error text, including the per-line problems the receive endpoint returns. */
const errText = (e) => (e?.details?.problems?.length ? e.details.problems.slice(0, 8).join('\n') : e?.message || 'Something went wrong');

function useLookups() {
  return useLoad(() => api('/inventory/lookups'));
}

/** Search customers (name, code, phone, email) and pick one. */
function CustomerSearch({ value, onChange, label: l = 'Customer' }) {
  const [q, setQ] = useState('');
  const [hits, setHits] = useState([]);
  const [open, setOpen] = useState(false);
  const t = useRef();
  useEffect(() => {
    clearTimeout(t.current);
    const term = q.trim();
    if (term.length < 2) { setHits([]); return undefined; }
    t.current = setTimeout(() => api(`/inventory/lookup/customers?q=${encodeURIComponent(term)}`).then((r) => { setHits(r.rows || []); setOpen(true); }).catch(() => setHits([])), 250);
    return () => clearTimeout(t.current);
  }, [q]);
  if (value) {
    return (
      <label className="field"><span>{l}</span>
        <div className="picker-chips" style={{ marginTop: 0 }}>
          <span className="picker-chip">{value.name}{value.code ? ` · ${value.code}` : ''}<button type="button" aria-label="Change customer" onClick={() => onChange(null)}><X size={12} /></button></span>
        </div>
      </label>
    );
  }
  return (
    <div className="picker">
      <label className="field"><span>{l}</span>
        <div className="pw-wrap">
          <input className="input" value={q} placeholder="Search name, code, phone or email" aria-label="Find customer" autoComplete="off"
            onChange={(e) => setQ(e.target.value)} onFocus={() => hits.length && setOpen(true)} onBlur={() => setTimeout(() => setOpen(false), 150)}
            onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); if (hits[0]) { onChange(hits[0]); setQ(''); } } }} />
          <span className="pw-eye" aria-hidden="true"><Search size={16} /></span>
        </div>
      </label>
      {open && hits.length > 0 && (
        <div className="picker-menu" role="listbox">
          {hits.map((c) => (
            <button type="button" role="option" aria-selected="false" key={c.id} onMouseDown={(e) => e.preventDefault()} onClick={() => { onChange(c); setQ(''); setOpen(false); }}>
              <span>{c.name} <span className="faint">· {c.code}</span></span><span className="faint">{c.phone}</span>
            </button>
          ))}
        </div>
      )}
      {open && q.trim().length >= 2 && !hits.length && <small className="faint">No matching customers</small>}
    </div>
  );
}

function StaffSelect({ value, onChange }) {
  const staff = useLoad(() => api('/inventory/lookup/staff'));
  return <Select label="Staff member / technician" value={value || ''} onChange={(e) => onChange(e.target.value ? Number(e.target.value) : '')}
    options={[{ value: '', label: staff.loading ? 'Loading…' : 'Choose…' }, ...(staff.data?.rows || []).map((s) => ({ value: s.id, label: s.name }))]} />;
}

const warehouseOptions = (lk, placeholder = 'Choose…') => [{ value: '', label: placeholder }, ...(lk?.warehouses || []).map((w) => ({ value: w.id, label: w.name }))];

// ------------------------------------------------------------------ receive
function ReceiveModal({ lookups, productId, onClose, onDone }) {
  const { toast } = useApp();
  const products = (lookups?.products || []).filter((p) => Number(p.active));
  const [f, setF] = useState({ product_id: productId || '', warehouse_id: lookups?.warehouses?.length === 1 ? lookups.warehouses[0].id : '', serials: '', qty: '', cost: '', note: '' });
  const [busy, setBusy] = useState(false);
  const [problems, setProblems] = useState('');
  const p = products.find((x) => x.id === Number(f.product_id));
  const serial = p ? Number(p.track_serial) === 1 : true;
  // One unit per line: "SERIAL" or "SERIAL, MAC" (comma, tab, semicolon or spaces).
  const units = f.serials.split(/\r?\n/).map((l) => l.trim()).filter(Boolean).map((l) => { const [s, m] = l.split(/[\s,;\t]+/); return { serial: s, mac: m || null }; });
  const set = (k) => (e) => { setF({ ...f, [k]: e.target.value }); setProblems(''); };
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setProblems('');
    try {
      const body = { product_id: Number(f.product_id), warehouse_id: Number(f.warehouse_id), note: f.note || null };
      if (f.cost !== '') body.unit_cost_cents = toCents(f.cost);
      if (serial) body.units = units; else body.qty = Number(f.qty);
      const r = await api.post('/inventory/receive', body);
      toast(`Received ${r.received} ${serial ? 'unit(s)' : p?.unit || 'pcs'} of ${p?.name}`);
      onDone(); onClose();
    } catch (err) { setProblems(errText(err)); toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  if (!products.length) {
    return <Modal open onClose={onClose} title="Receive stock"><Empty icon={Package} title="No active products">Add a product in the Products tab first.</Empty></Modal>;
  }
  if (!lookups?.warehouses?.length) {
    return <Modal open onClose={onClose} title="Receive stock"><Empty icon={Warehouse} title="No warehouses">Add a warehouse in the Warehouses tab first.</Empty></Modal>;
  }
  return (
    <Modal open onClose={onClose} title="Receive stock" wide>
      <form className="col" onSubmit={submit}>
        <div className="grid g2">
          <Select label="Product" required value={f.product_id} onChange={set('product_id')} options={[{ value: '', label: 'Choose…' }, ...products.map((x) => ({ value: x.id, label: `${x.name}${x.sku ? ` (${x.sku})` : ''}` }))]} />
          <Select label="Into warehouse" required value={f.warehouse_id} onChange={set('warehouse_id')} options={warehouseOptions(lookups)} />
        </div>
        {serial ? (
          <Textarea label="Serial numbers" rows={8} required value={f.serials} onChange={set('serials')} placeholder={'One unit per line — serial, optionally followed by MAC\nZTE2401A001\nZTE2401A002, 00:1A:2B:3C:4D:5E'}
            hint={`${units.length} unit(s) · duplicate serials or MACs are refused (nothing is saved). Up to 1000 per batch.`} />
        ) : (
          <Input label={`Quantity (${p?.unit || 'pcs'})`} type="number" min={1} step={1} required value={f.qty} onChange={set('qty')} />
        )}
        <div className="grid g2">
          <Input label="Unit cost" type="number" min={0} step="0.01" value={f.cost} onChange={set('cost')} placeholder={p ? (Number(p.buy_cents) / 100).toFixed(2) : ''} hint="Leave empty to use the product's buy price" />
          <Input label="Note / supplier invoice" maxLength={250} value={f.note} onChange={set('note')} />
        </div>
        {problems && <div className="alert bad" style={{ whiteSpace: 'pre-line' }}><AlertTriangle size={16} /><div>{problems}</div></div>}
        <div className="row end"><Button type="button" onClick={onClose}>Cancel</Button><Button variant="primary" type="submit" icon={PackagePlus} loading={busy} disabled={!f.product_id || !f.warehouse_id || (serial ? !units.length : !(Number(f.qty) > 0))}>Receive</Button></div>
      </form>
    </Modal>
  );
}

// ------------------------------------------------------------------ issue (by product, or a specific item)
/**
 * Issue equipment. With `item` the unit is fixed; otherwise pick a product, then the serial unit (serialised) or the
 * warehouse + quantity (bulk). With `customer` the recipient is fixed to that customer.
 */
function IssueModal({ lookups, item, customer, onClose, onDone }) {
  const { toast } = useApp();
  const products = (lookups?.products || []).filter((p) => Number(p.active) || (item && p.id === item.product_id));
  const [target, setTarget] = useState('customer');
  const [cust, setCust] = useState(customer || null);
  const [staffId, setStaffId] = useState('');
  const [f, setF] = useState({ product_id: item?.product_id || '', item_id: item?.id || '', warehouse_id: '', qty: item && !Number(item.track_serial) ? String(item.qty) : '1', mode: 'assigned', note: '' });
  const [unitQ, setUnitQ] = useState('');
  const [busy, setBusy] = useState(false);
  const p = products.find((x) => x.id === Number(f.product_id));
  const serial = item ? Number(item.track_serial) === 1 : p ? Number(p.track_serial) === 1 : true;
  const units = useLoad(async () => {
    if (item || !p || !serial) return { rows: [] };
    return api(`/inventory/items?${qs({ product_id: p.id, status: 'in_stock', q: unitQ.trim(), pageSize: 50, sort: 'serial' })}`);
  }, [p?.id, serial, unitQ, item?.id]);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const canStaff = !customer && (!item || item.status === 'in_stock');
  const ready = (target === 'customer' ? !!cust : !!staffId) && (item || (f.product_id && (serial ? f.item_id : f.warehouse_id && Number(f.qty) > 0)));
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      const who = target === 'customer' ? { customer_id: cust.id, mode: f.mode } : { staff_id: staffId };
      const qty = serial ? undefined : Number(f.qty);
      if (item) await api.post(`/inventory/items/${item.id}/${target === 'customer' ? 'issue' : 'issue-staff'}`, { ...who, qty, note: f.note || null });
      else await api.post('/inventory/issue', { product_id: Number(f.product_id), ...(serial ? { item_id: Number(f.item_id) } : { warehouse_id: Number(f.warehouse_id), qty }), ...who, note: f.note || null });
      toast(target === 'customer' ? `Issued to ${cust.name}` : 'Issued to staff');
      onDone(); onClose();
    } catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  return (
    <Modal open onClose={onClose} title={item ? `Issue ${item.serial || item.product_name}` : 'Issue equipment'} wide>
      <form className="col" onSubmit={submit}>
        {canStaff && <Tabs tabs={[{ value: 'customer', label: 'To a customer' }, { value: 'staff', label: 'To staff / technician' }]} value={target} onChange={setTarget} />}
        {target === 'customer' ? (
          <div className="grid g2">
            {customer ? <Input label="Customer" value={`${customer.name}${customer.code ? ` · ${customer.code}` : ''}`} disabled /> : <CustomerSearch value={cust} onChange={setCust} />}
            <Select label="As" value={f.mode} onChange={set('mode')} options={[{ value: 'assigned', label: 'Assigned (ISP-owned, free)' }, { value: 'rented', label: 'Rented (ISP-owned, rent)' }, { value: 'sold', label: 'Sold (customer-owned)' }]} />
          </div>
        ) : <StaffSelect value={staffId} onChange={setStaffId} />}
        {item ? (
          <div className="alert info"><Package size={16} /><div><b>{item.product_name}</b> {item.serial ? <span className="mono">{item.serial}</span> : null} · <StatusBadge s={item.status} /> · {holder(item)}</div></div>
        ) : (
          <Select label="Product" required value={f.product_id} onChange={(e) => { setF({ ...f, product_id: e.target.value, item_id: '' }); setUnitQ(''); }}
            options={[{ value: '', label: 'Choose…' }, ...products.map((x) => ({ value: x.id, label: `${x.name}${x.sku ? ` (${x.sku})` : ''}` }))]} />
        )}
        {!item && p && serial && (
          <div className="col" style={{ gap: 8 }}>
            <Input label="Find unit" value={unitQ} onChange={(e) => setUnitQ(e.target.value)} placeholder="Serial or MAC" />
            {units.loading && !units.data ? <Spinner /> : (units.data?.rows || []).length ? (
              <Select label="Unit in stock" required value={f.item_id} onChange={set('item_id')}
                options={[{ value: '', label: `Choose… (${units.data.total} in stock${units.data.total > 50 ? ', showing 50' : ''})` }, ...units.data.rows.map((u) => ({ value: u.id, label: `${u.serial}${u.mac ? ` · ${u.mac}` : ''} — ${u.warehouse_name || 'no warehouse'}` }))]} />
            ) : <div className="alert warn"><AlertTriangle size={16} /><div>No {p.name} in stock{unitQ ? ' matching that search' : ''}. Receive stock first.</div></div>}
          </div>
        )}
        {!serial && (
          <div className="grid g2">
            {!item && <Select label="From warehouse" required value={f.warehouse_id} onChange={set('warehouse_id')} options={warehouseOptions(lookups)} />}
            <Input label={`Quantity (${item?.unit || p?.unit || 'pcs'})`} type="number" min={1} max={item ? item.qty : undefined} step={1} required value={f.qty} onChange={set('qty')}
              hint={item ? `${item.qty} in this lot — a smaller quantity splits it` : 'Drawn from the oldest lots first'} />
          </div>
        )}
        <Input label="Note" maxLength={250} value={f.note} onChange={set('note')} placeholder="e.g. new connection, replacement" />
        <div className="row end"><Button type="button" onClick={onClose}>Cancel</Button><Button variant="primary" type="submit" icon={Send} loading={busy} disabled={!ready}>Issue</Button></div>
      </form>
    </Modal>
  );
}

// ------------------------------------------------------------------ return / transfer / faulty / write-off
const ACTION_META = {
  return: { title: 'Return to warehouse', icon: Undo2, path: 'return', verb: 'Return', warehouse: true },
  transfer: { title: 'Transfer to another warehouse', icon: ArrowLeftRight, path: 'transfer', verb: 'Transfer', warehouse: true },
  faulty: { title: 'Mark as faulty', icon: AlertTriangle, path: 'faulty', verb: 'Mark faulty' },
  write_off: { title: 'Write off', icon: Ban, path: 'write-off', verb: 'Write off', danger: true },
};

function ActionModal({ lookups, item, action, onClose, onDone }) {
  const { toast } = useApp();
  const meta = ACTION_META[action];
  const bulk = !Number(item.track_serial);
  const [f, setF] = useState({ warehouse_id: '', qty: String(item.qty), condition: 'good', note: '' });
  const [busy, setBusy] = useState(false);
  const needsWh = meta.warehouse || (action === 'faulty' && item.status === 'with_staff');
  const whs = (lookups?.warehouses || []).filter((w) => action !== 'transfer' || w.id !== item.warehouse_id);
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      const body = { note: f.note || null };
      if (bulk) body.qty = Number(f.qty);
      if (needsWh) body.warehouse_id = Number(f.warehouse_id);
      if (action === 'return') body.condition = f.condition;
      await api.post(`/inventory/items/${item.id}/${meta.path}`, body);
      toast(`${meta.verb}: done`);
      onDone(); onClose();
    } catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  return (
    <Modal open onClose={onClose} title={meta.title}>
      <form className="col" onSubmit={submit}>
        <div className="alert info"><Package size={16} /><div><b>{item.product_name}</b> {item.serial && <span className="mono">{item.serial}</span>} · <StatusBadge s={item.status} /> · {holder(item)}</div></div>
        {needsWh && <Select label={action === 'transfer' ? 'To warehouse' : 'Warehouse'} required value={f.warehouse_id} onChange={(e) => setF({ ...f, warehouse_id: e.target.value })} options={[{ value: '', label: 'Choose…' }, ...whs.map((w) => ({ value: w.id, label: w.name }))]} />}
        {action === 'return' && item.status !== 'faulty' && <Select label="Condition" value={f.condition} onChange={(e) => setF({ ...f, condition: e.target.value })} options={[{ value: 'good', label: 'Good — back in stock' }, { value: 'faulty', label: 'Faulty — needs repair' }]} />}
        {action === 'return' && item.status === 'faulty' && <p className="faint" style={{ margin: 0 }}>The repaired item goes back into stock.</p>}
        {bulk && <Input label={`Quantity (${item.unit || 'pcs'})`} type="number" min={1} max={item.qty} step={1} required value={f.qty} onChange={(e) => setF({ ...f, qty: e.target.value })} hint={`${item.qty} in this lot`} />}
        {action === 'write_off' && <div className="alert warn"><AlertTriangle size={16} /><div>Written-off stock leaves the inventory permanently (lost, scrapped or damaged beyond repair).</div></div>}
        <Input label="Note" maxLength={250} value={f.note} onChange={(e) => setF({ ...f, note: e.target.value })} />
        <div className="row end"><Button type="button" onClick={onClose}>Cancel</Button><Button variant={meta.danger ? 'danger' : 'primary'} type="submit" icon={meta.icon} loading={busy} disabled={(needsWh && !f.warehouse_id) || (bulk && !(Number(f.qty) > 0))}>{meta.verb}</Button></div>
      </form>
    </Modal>
  );
}

/** Which actions make sense for an item's current state (mirrors the server rules). */
function actionsFor(i) {
  const s = i.status;
  return {
    issue: s === 'in_stock' || s === 'with_staff',
    return: ['assigned', 'rented', 'with_staff', 'faulty'].includes(s),
    transfer: s === 'in_stock' || s === 'faulty',
    faulty: s === 'in_stock' || s === 'with_staff',
    write_off: ['in_stock', 'faulty', 'with_staff'].includes(s),
  };
}

function ItemActions({ item, onAction, canManage }) {
  if (!canManage) return null;
  const a = actionsFor(item);
  return (
    <div className="row" style={{ gap: 4, justifyContent: 'flex-end' }} onClick={(e) => e.stopPropagation()}>
      {a.issue && <Button size="sm" variant="ghost" icon={Send} title="Issue" aria-label="Issue" onClick={() => onAction(item, 'issue')} />}
      {a.return && <Button size="sm" variant="ghost" icon={Undo2} title={item.status === 'faulty' ? 'Repaired — back to stock' : 'Return'} aria-label="Return" onClick={() => onAction(item, 'return')} />}
      {a.transfer && <Button size="sm" variant="ghost" icon={ArrowLeftRight} title="Transfer" aria-label="Transfer" onClick={() => onAction(item, 'transfer')} />}
      {a.faulty && <Button size="sm" variant="ghost" icon={AlertTriangle} title="Mark faulty" aria-label="Mark faulty" onClick={() => onAction(item, 'faulty')} />}
      {a.write_off && <Button size="sm" variant="ghost" icon={Ban} title="Write off" aria-label="Write off" onClick={() => onAction(item, 'write_off')} />}
    </div>
  );
}

// ------------------------------------------------------------------ item detail (edit + history)
function ItemDetail({ id, onClose, onChanged }) {
  const { toast, can } = useApp();
  const { data, reload } = useLoad(() => api(`/inventory/items/${id}`), [id]);
  const [f, setF] = useState(null);
  const [busy, setBusy] = useState(false);
  const it = data?.item;
  useEffect(() => { if (it) setF({ serial: it.serial || '', mac: it.mac || '', cost: (Number(it.cost_cents) / 100).toFixed(2), notes: it.notes || '' }); }, [it]);
  const save = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      const body = { mac: f.mac || null, cost_cents: toCents(f.cost), notes: f.notes || null };
      if (Number(it.track_serial)) body.serial = f.serial;
      await api.put(`/inventory/items/${id}`, body);
      toast('Item saved'); reload(); onChanged();
    } catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  return (
    <Modal open onClose={onClose} title={it ? `${it.product_name}${it.serial ? ` · ${it.serial}` : ''}` : 'Item'} wide>
      {!it || !f ? <Spinner /> : (
        <div className="col">
          <div className="row wrap"><StatusBadge s={it.status} /><span className="faint">{holder(it)}</span><span className="faint">· qty {qtyText(it)}</span></div>
          <form className="col" onSubmit={save}>
            <div className="grid g2">
              {Number(it.track_serial) ? <Input label="Serial" required maxLength={64} value={f.serial} onChange={(e) => setF({ ...f, serial: e.target.value })} disabled={!can('inventory.manage')} /> : null}
              {Number(it.track_serial) ? <Input label="MAC address" maxLength={32} value={f.mac} onChange={(e) => setF({ ...f, mac: e.target.value })} disabled={!can('inventory.manage')} /> : null}
              <Input label="Unit cost" type="number" min={0} step="0.01" value={f.cost} onChange={(e) => setF({ ...f, cost: e.target.value })} disabled={!can('inventory.manage')} />
              <Input label="Notes" maxLength={250} value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} disabled={!can('inventory.manage')} />
            </div>
            {can('inventory.manage') && <div className="row end"><Button variant="primary" type="submit" loading={busy}>Save</Button></div>}
          </form>
          <h4 style={{ margin: '6px 0 0' }}>History</h4>
          <DataTable rows={data.movements} empty="No movements" columns={[
            { key: 'created_at', title: 'When', render: (m) => dateTime(m.created_at) },
            { key: 'type', title: 'Movement', render: (m) => <Badge kind={MOVE_TONE[m.type]}>{label(m.type)}</Badge> },
            { key: 'qty', title: 'Qty', align: 'right' },
            { key: 'where', title: 'Warehouse / customer', render: (m) => m.customer_name || m.warehouse_name || '—' },
            { key: 'user_name', title: 'By' },
            { key: 'note', title: 'Note', render: (m) => m.note || '—' },
          ]} />
        </div>
      )}
    </Modal>
  );
}

// ------------------------------------------------------------------ tabs
function StockTab({ lookups, version, onReceive }) {
  const [wh, setWh] = useState('');
  const [low, setLow] = useState(false);
  const [cat, setCat] = useState('');
  const { data, loading } = useLoad(() => api(`/inventory/stock?${qs({ warehouse_id: wh, low: low ? 1 : '', category: cat })}`), [wh, low, cat, version]);
  const rows = data?.products || [];
  return (
    <Card>
      <div className="row wrap mb" style={{ alignItems: 'flex-end' }}>
        <div style={{ minWidth: 180 }}><Select label="Warehouse" value={wh} onChange={(e) => setWh(e.target.value)} options={warehouseOptions(lookups, 'All warehouses')} /></div>
        <div style={{ minWidth: 160 }}><Select label="Category" value={cat} onChange={(e) => setCat(e.target.value)} options={[{ value: '', label: 'All' }, ...CATEGORIES.map((c) => ({ value: c, label: label(c) }))]} /></div>
        <div style={{ minWidth: 180 }}><Toggle label="Low stock only" checked={low} onChange={setLow} /></div>
        <div className="grow" />
        {data && <div className="faint">Value {wh ? 'in this warehouse' : 'in stock'}: <b style={{ color: 'var(--text)' }}>{money(data.totals.value_cents)}</b></div>}
      </div>
      <DataTable loading={loading} rows={rows} empty={low ? 'Nothing is below its minimum stock' : 'No products yet'} columns={[
        { key: 'name', title: 'Product', render: (p) => <div><b>{p.name}</b>{p.sku && <div className="faint mono">{p.sku}</div>}</div> },
        { key: 'category', title: 'Category', render: (p) => label(p.category || '—') },
        { key: 'in_stock', title: 'In stock', align: 'right', render: (p) => <span>{p.in_stock} <span className="faint">{p.unit}</span>{p.low && <> <Badge kind="bad">Low</Badge></>}</span> },
        { key: 'min_stock', title: 'Min', align: 'right', render: (p) => p.min_stock || '—' },
        { key: 'warehouses', title: 'By warehouse', render: (p) => (p.warehouses.length ? <div className="row wrap" style={{ gap: 6 }}>{p.warehouses.map((w) => <Badge key={w.warehouse_id ?? 0} kind="info">{w.name}: {w.qty}</Badge>)}</div> : <span className="faint">—</span>) },
        { key: 'with_staff', title: 'With staff', align: 'right', render: (p) => p.with_staff || '—' },
        { key: 'deployed', title: 'At customers', align: 'right', render: (p) => p.deployed || '—' },
        { key: 'faulty', title: 'Faulty', align: 'right', render: (p) => (p.faulty ? <Badge kind="bad">{p.faulty}</Badge> : '—') },
        { key: 'value_cents', title: 'Value', align: 'right', render: (p) => money(p.value_cents) },
        ...(onReceive ? [{ key: 'act', title: '', render: (p) => (p.active ? <Button size="sm" icon={PackagePlus} onClick={(e) => { e.stopPropagation(); onReceive(p.id); }}>Receive</Button> : <Badge kind="info">inactive</Badge>) }] : []),
      ]} />
    </Card>
  );
}

function ItemsTab({ lookups, version, bump }) {
  const { can } = useApp();
  const [f, setF] = useState({ product_id: '', status: '', warehouse_id: '', q: '' });
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState('');
  const [act, setAct] = useState(null);
  const [detail, setDetail] = useState(null);
  useEffect(() => { const t = setTimeout(() => { setF((x) => ({ ...x, q })); setPage(1); }, 300); return () => clearTimeout(t); }, [q]);
  const { data, loading } = useLoad(() => api(`/inventory/items?${qs({ ...f, page, pageSize: 25, sort })}`), [f, page, sort, version]);
  const setFilter = (k) => (e) => { setF({ ...f, [k]: e.target.value }); setPage(1); };
  const onAction = (item, action) => setAct({ item, action });
  return (
    <Card>
      <div className="grid g4 mb">
        <Input label="Search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Serial, MAC, customer, staff" />
        <Select label="Product" value={f.product_id} onChange={setFilter('product_id')} options={[{ value: '', label: 'All products' }, ...(lookups?.products || []).map((p) => ({ value: p.id, label: p.name }))]} />
        <Select label="Status" value={f.status} onChange={setFilter('status')} options={[{ value: '', label: 'Any status' }, ...STATUSES.map((s) => ({ value: s, label: label(s) }))]} />
        <Select label="Warehouse" value={f.warehouse_id} onChange={setFilter('warehouse_id')} options={warehouseOptions(lookups, 'All warehouses')} />
      </div>
      <DataTable loading={loading} rows={data?.rows} sort={sort} onSort={setSort} onRowClick={(i) => setDetail(i.id)} empty="No items match" columns={[
        { key: 'product', title: 'Product', sort: true, render: (i) => i.product_name },
        { key: 'serial', title: 'Serial / MAC', sort: true, render: (i) => (i.serial ? <div><span className="mono">{i.serial}</span>{i.mac && <div className="faint mono">{i.mac}</div>}</div> : <span className="faint">bulk lot</span>) },
        { key: 'qty', title: 'Qty', align: 'right', render: qtyText },
        { key: 'status', title: 'Status', sort: true, render: (i) => <StatusBadge s={i.status} /> },
        { key: 'holder', title: 'Location / holder', render: holder },
        { key: 'cost_cents', title: 'Unit cost', align: 'right', render: (i) => money(i.cost_cents) },
        { key: 'updated_at', title: 'Updated', sort: true, render: (i) => dateTime(i.updated_at) },
        { key: 'act', title: '', render: (i) => <ItemActions item={i} onAction={onAction} canManage={can('inventory.manage')} /> },
      ]} />
      {data && <Pager page={data.page} pageSize={data.pageSize} total={data.total} onPage={setPage} />}
      {act?.action === 'issue' && <IssueModal lookups={lookups} item={act.item} onClose={() => setAct(null)} onDone={bump} />}
      {act && act.action !== 'issue' && <ActionModal lookups={lookups} item={act.item} action={act.action} onClose={() => setAct(null)} onDone={bump} />}
      {detail && <ItemDetail id={detail} onClose={() => setDetail(null)} onChanged={bump} />}
    </Card>
  );
}

const emptyProduct = { name: '', sku: '', category: 'router', unit: 'pcs', buy: '', sell: '', rent: '', track_serial: true, min_stock: 0, active: true };

function ProductsTab({ version, bump }) {
  const { toast, can } = useApp();
  const { data, loading, reload } = useLoad(() => api('/inventory/products'), [version]);
  const [edit, setEdit] = useState(null);
  const [del, setDel] = useState(null);
  const [busy, setBusy] = useState(false);
  const save = async (e) => {
    e.preventDefault();
    setBusy(true);
    const body = { name: edit.name, sku: edit.sku || null, category: edit.category, unit: edit.unit || 'pcs', buy_cents: toCents(edit.buy || 0), sell_cents: toCents(edit.sell || 0),
      rent_cents: toCents(edit.rent || 0), min_stock: Number(edit.min_stock) || 0, active: !!edit.active };
    if (!edit.id || !edit.item_rows) body.track_serial = !!edit.track_serial;
    try {
      if (edit.id) await api.put(`/inventory/products/${edit.id}`, body); else await api.post('/inventory/products', body);
      toast(edit.id ? 'Product saved' : 'Product added'); setEdit(null); reload(); bump();
    } catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  const rows = data?.products || [];
  return (
    <Card title="Products" actions={can('inventory.manage') && <Button variant="primary" size="sm" icon={Plus} onClick={() => setEdit({ ...emptyProduct })}>New product</Button>}>
      <DataTable loading={loading} rows={rows} empty="No products yet — add routers, ONUs, cable…" onRowClick={can('inventory.manage') ? (p) => setEdit({ ...p, buy: Number(p.buy_cents) / 100, sell: Number(p.sell_cents) / 100, rent: Number(p.rent_cents) / 100, track_serial: !!Number(p.track_serial), active: !!Number(p.active) }) : undefined} columns={[
        { key: 'name', title: 'Name', render: (p) => <b>{p.name}</b> },
        { key: 'sku', title: 'SKU', render: (p) => (p.sku ? <span className="mono">{p.sku}</span> : '—') },
        { key: 'category', title: 'Category', render: (p) => label(p.category || '—') },
        { key: 'track', title: 'Tracking', render: (p) => (Number(p.track_serial) ? <Badge kind="brand">serial</Badge> : <Badge kind="info">bulk ({p.unit})</Badge>) },
        { key: 'buy_cents', title: 'Buy', align: 'right', render: (p) => money(p.buy_cents) },
        { key: 'sell_cents', title: 'Sell', align: 'right', render: (p) => money(p.sell_cents) },
        { key: 'rent_cents', title: 'Rent / mo', align: 'right', render: (p) => (Number(p.rent_cents) ? money(p.rent_cents) : '—') },
        { key: 'min_stock', title: 'Min stock', align: 'right' },
        { key: 'active', title: 'Status', render: (p) => <Badge kind={Number(p.active) ? 'ok' : 'info'}>{Number(p.active) ? 'active' : 'inactive'}</Badge> },
        ...(can('inventory.manage') ? [{ key: 'act', title: '', render: (p) => (
          <div className="row" style={{ gap: 4, justifyContent: 'flex-end' }} onClick={(e) => e.stopPropagation()}>
            <Button size="sm" variant="ghost" icon={Pencil} aria-label={`Edit ${p.name}`} onClick={() => setEdit({ ...p, buy: Number(p.buy_cents) / 100, sell: Number(p.sell_cents) / 100, rent: Number(p.rent_cents) / 100, track_serial: !!Number(p.track_serial), active: !!Number(p.active) })} />
            {!p.item_rows && <Button size="sm" variant="ghost" icon={Trash2} aria-label={`Delete ${p.name}`} onClick={() => setDel(p)} />}
          </div>
        ) }] : []),
      ]} />
      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? 'Edit product' : 'New product'}>
        {edit && (
          <form className="col" onSubmit={save}>
            <Input label="Name" required minLength={2} maxLength={120} value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} placeholder="e.g. Huawei HG8145V5 ONU" />
            <div className="grid g2">
              <Input label="SKU" maxLength={60} value={edit.sku || ''} onChange={(e) => setEdit({ ...edit, sku: e.target.value })} />
              <Select label="Category" value={edit.category || 'other'} onChange={(e) => setEdit({ ...edit, category: e.target.value })} options={CATEGORIES.map((c) => ({ value: c, label: label(c) }))} />
              <Input label="Unit" maxLength={20} value={edit.unit} onChange={(e) => setEdit({ ...edit, unit: e.target.value })} hint="pcs, m, box…" />
              <Input label="Minimum stock" type="number" min={0} step={1} value={edit.min_stock} onChange={(e) => setEdit({ ...edit, min_stock: e.target.value })} hint="Flagged as low below this" />
              <Input label="Buy price" type="number" min={0} step="0.01" value={edit.buy} onChange={(e) => setEdit({ ...edit, buy: e.target.value })} />
              <Input label="Sell price" type="number" min={0} step="0.01" value={edit.sell} onChange={(e) => setEdit({ ...edit, sell: e.target.value })} />
              <Input label="Rent per month" type="number" min={0} step="0.01" value={edit.rent} onChange={(e) => setEdit({ ...edit, rent: e.target.value })} />
            </div>
            {edit.id && edit.item_rows ? <p className="faint" style={{ margin: 0 }}>Tracking: {edit.track_serial ? 'one row per serial number' : 'bulk quantity'} (locked — the product has stock).</p>
              : <Toggle label="Track serial numbers" hint="On for routers / ONUs (one unit per serial). Off for cable, connectors and other bulk stock." checked={edit.track_serial} onChange={(v) => setEdit({ ...edit, track_serial: v })} />}
            <Toggle label="Active" hint="Inactive products cannot receive new stock" checked={edit.active} onChange={(v) => setEdit({ ...edit, active: v })} />
            <div className="row end"><Button type="button" onClick={() => setEdit(null)}>Cancel</Button><Button variant="primary" type="submit" loading={busy}>Save</Button></div>
          </form>
        )}
      </Modal>
      <Confirm open={!!del} onClose={() => setDel(null)} danger confirmText="Delete" title="Delete product?"
        onConfirm={async () => { try { await api.del(`/inventory/products/${del.id}`); toast('Product deleted'); reload(); bump(); } catch (err) { toast(err.message, 'bad'); } }}>
        "{del?.name}" has no stock and will be removed permanently.
      </Confirm>
    </Card>
  );
}

function WarehousesTab({ lookups, version, bump }) {
  const { toast, can } = useApp();
  const { data, loading, reload } = useLoad(() => api('/inventory/warehouses'), [version]);
  const [edit, setEdit] = useState(null);
  const [del, setDel] = useState(null);
  const [busy, setBusy] = useState(false);
  const zones = lookups?.zones || [];
  const save = async (e) => {
    e.preventDefault();
    setBusy(true);
    const body = { name: edit.name, address: edit.address || null, zone_id: edit.zone_id ? Number(edit.zone_id) : null };
    try {
      if (edit.id) await api.put(`/inventory/warehouses/${edit.id}`, body); else await api.post('/inventory/warehouses', body);
      toast(edit.id ? 'Warehouse saved' : 'Warehouse added'); setEdit(null); reload(); bump();
    } catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  };
  return (
    <Card title="Warehouses" actions={can('inventory.manage') && <Button variant="primary" size="sm" icon={Plus} onClick={() => setEdit({ name: '', address: '', zone_id: '' })}>New warehouse</Button>}>
      <DataTable loading={loading} rows={data?.warehouses} empty="No warehouses yet — add your store, POPs or a technician van" onRowClick={can('inventory.manage') ? (w) => setEdit({ ...w, zone_id: w.zone_id || '' }) : undefined} columns={[
        { key: 'name', title: 'Name', render: (w) => <b>{w.name}</b> },
        { key: 'zone_name', title: 'Zone', render: (w) => w.zone_name || '—' },
        { key: 'address', title: 'Address', render: (w) => w.address || '—' },
        { key: 'units', title: 'Units held', align: 'right' },
        { key: 'value_cents', title: 'Value', align: 'right', render: (w) => money(w.value_cents) },
        ...(can('inventory.manage') ? [{ key: 'act', title: '', render: (w) => (
          <div className="row" style={{ gap: 4, justifyContent: 'flex-end' }} onClick={(e) => e.stopPropagation()}>
            <Button size="sm" variant="ghost" icon={Pencil} aria-label={`Edit ${w.name}`} onClick={() => setEdit({ ...w, zone_id: w.zone_id || '' })} />
            <Button size="sm" variant="ghost" icon={Trash2} aria-label={`Delete ${w.name}`} onClick={() => setDel(w)} />
          </div>
        ) }] : []),
      ]} />
      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? 'Edit warehouse' : 'New warehouse'}>
        {edit && (
          <form className="col" onSubmit={save}>
            <Input label="Name" required minLength={2} maxLength={120} value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
            {zones.length > 0 && <Select label="Zone" value={edit.zone_id} onChange={(e) => setEdit({ ...edit, zone_id: e.target.value })} options={[{ value: '', label: '—' }, ...zones.map((z) => ({ value: z.id, label: z.name }))]} />}
            <Input label="Address" maxLength={250} value={edit.address || ''} onChange={(e) => setEdit({ ...edit, address: e.target.value })} />
            <div className="row end"><Button type="button" onClick={() => setEdit(null)}>Cancel</Button><Button variant="primary" type="submit" loading={busy}>Save</Button></div>
          </form>
        )}
      </Modal>
      <Confirm open={!!del} onClose={() => setDel(null)} danger confirmText="Delete" title="Delete warehouse?"
        onConfirm={async () => { try { await api.del(`/inventory/warehouses/${del.id}`); toast('Warehouse deleted'); reload(); bump(); } catch (err) { toast(err.message, 'bad'); } }}>
        {del?.units ? `"${del.name}" still holds ${del.units} unit(s); transfer them first or the delete will be refused.` : `"${del?.name}" will be removed. Its movement history is kept.`}
      </Confirm>
    </Card>
  );
}

function MovementsTab({ lookups, version }) {
  const [f, setF] = useState({ product_id: '', type: '', warehouse_id: '', from: '', to: '' });
  const [page, setPage] = useState(1);
  const { data, loading } = useLoad(() => api(`/inventory/movements?${qs({ ...f, page, pageSize: 50 })}`), [f, page, version]);
  const setFilter = (k) => (e) => { setF({ ...f, [k]: e.target.value }); setPage(1); };
  return (
    <Card>
      <div className="grid g4 mb">
        <Select label="Product" value={f.product_id} onChange={setFilter('product_id')} options={[{ value: '', label: 'All products' }, ...(lookups?.products || []).map((p) => ({ value: p.id, label: p.name }))]} />
        <Select label="Type" value={f.type} onChange={setFilter('type')} options={[{ value: '', label: 'All movements' }, ...MOVE_TYPES.map((t) => ({ value: t, label: label(t) }))]} />
        <Input label="From" type="date" value={f.from} onChange={setFilter('from')} />
        <Input label="To" type="date" value={f.to} onChange={setFilter('to')} />
      </div>
      <DataTable loading={loading} rows={data?.rows} empty="No stock movements yet" columns={[
        { key: 'created_at', title: 'When', render: (m) => dateTime(m.created_at) },
        { key: 'type', title: 'Movement', render: (m) => <Badge kind={MOVE_TONE[m.type]}>{label(m.type)}</Badge> },
        { key: 'product_name', title: 'Product', render: (m) => <div>{m.product_name || `#${m.product_id}`}{m.serial && <div className="faint mono">{m.serial}</div>}</div> },
        { key: 'qty', title: 'Qty', align: 'right', render: (m) => `${m.qty}${m.unit && m.unit !== 'pcs' ? ` ${m.unit}` : ''}` },
        { key: 'warehouse_name', title: 'Warehouse', render: (m) => m.warehouse_name || '—' },
        { key: 'customer_name', title: 'Customer', render: (m) => (m.customer_name ? `${m.customer_name}${m.customer_code ? ` · ${m.customer_code}` : ''}` : '—') },
        { key: 'user_name', title: 'By', render: (m) => m.user_name || '—' },
        { key: 'note', title: 'Note', render: (m) => m.note || '—' },
      ]} />
      {data && <Pager page={data.page} pageSize={data.pageSize} total={data.total} onPage={setPage} />}
    </Card>
  );
}

// ------------------------------------------------------------------ page
export default function Inventory() {
  const { can } = useApp();
  const [tab, setTab] = useState('stock');
  const [version, setVersion] = useState(0);
  const [receive, setReceive] = useState(null); // null | { productId }
  const [issue, setIssue] = useState(false);
  const lookups = useLookups();
  const summary = useLoad(() => api('/inventory/summary'), [version]);
  const bump = () => { setVersion((v) => v + 1); lookups.reload(); };
  const manage = can('inventory.manage');
  const s = summary.data;
  return (
    <Page title="Inventory" subtitle="Equipment stock, serial numbers and what each customer holds"
      actions={manage && <>
        <Button icon={Send} onClick={() => setIssue(true)} disabled={!lookups.data}>Issue</Button>
        <Button variant="primary" icon={PackagePlus} onClick={() => setReceive({})} disabled={!lookups.data}>Receive stock</Button>
      </>}>
      <div className="grid g4 mb">
        <Stat icon={Wallet} label="Stock value" value={s?.stock_value_cents || 0} format={(v) => money(v)} sub="in warehouses + with staff" />
        <Stat icon={Boxes} label="Units in stock" value={s?.units_in_stock || 0} />
        <Stat icon={UserCheck} label="Deployed at customers" value={s?.items_deployed || 0} sub={s?.with_staff ? `${s.with_staff} with staff` : undefined} />
        <Stat icon={AlertTriangle} label="Low-stock products" value={s?.low_stock_count || 0} sub={s?.faulty ? `${s.faulty} faulty unit(s)` : undefined} />
      </div>
      <div className="mb" style={{ overflowX: 'auto' }}>
        <Tabs value={tab} onChange={setTab} tabs={[
          { value: 'stock', label: <span className="row" style={{ gap: 6 }}><Boxes size={15} />Stock</span> },
          { value: 'items', label: <span className="row" style={{ gap: 6 }}><RouterIcon size={15} />Items</span> },
          { value: 'products', label: <span className="row" style={{ gap: 6 }}><Package size={15} />Products</span> },
          { value: 'warehouses', label: <span className="row" style={{ gap: 6 }}><Warehouse size={15} />Warehouses</span> },
          { value: 'movements', label: <span className="row" style={{ gap: 6 }}><History size={15} />Movements</span> },
        ]} />
      </div>
      {lookups.error && <div className="alert bad mb"><AlertTriangle size={16} /><div>{lookups.error.message}</div></div>}
      {tab === 'stock' && <StockTab lookups={lookups.data} version={version} onReceive={manage ? (productId) => setReceive({ productId }) : null} />}
      {tab === 'items' && <ItemsTab lookups={lookups.data} version={version} bump={bump} />}
      {tab === 'products' && <ProductsTab version={version} bump={bump} />}
      {tab === 'warehouses' && <WarehousesTab lookups={lookups.data} version={version} bump={bump} />}
      {tab === 'movements' && <MovementsTab lookups={lookups.data} version={version} />}
      {receive && lookups.data && <ReceiveModal lookups={lookups.data} productId={receive.productId} onClose={() => setReceive(null)} onDone={bump} />}
      {issue && lookups.data && <IssueModal lookups={lookups.data} onClose={() => setIssue(false)} onDone={bump} />}
    </Page>
  );
}

// ------------------------------------------------------------------ customer page widget
/**
 * Equipment a customer currently holds (assigned / rented / sold), with Issue and Return actions.
 * Usage on the customer detail page: <CustomerEquipment customerId={customer.id} />
 * Renders nothing when the inventory module is off or the user lacks inventory.view.
 */
export function CustomerEquipment({ customerId }) {
  const { can, moduleOn } = useApp();
  const allowed = (moduleOn ? moduleOn('inventory') : true) && (can('inventory.view') || can('inventory.manage'));
  const manage = can('inventory.manage');
  const { data, loading, error, reload } = useLoad(() => (allowed && customerId ? api(`/inventory/customers/${customerId}/equipment`) : Promise.resolve(null)), [customerId, allowed]);
  const lookups = useLoad(() => (allowed && manage ? api('/inventory/lookups') : Promise.resolve(null)), [allowed, manage]);
  const [issue, setIssue] = useState(false);
  const [ret, setRet] = useState(null);
  if (!allowed) return null;
  const items = data?.items || [];
  return (
    <Card title={<span className="row" style={{ gap: 8 }}><RouterIcon size={18} />Equipment</span>}
      actions={manage && <Button size="sm" icon={Send} onClick={() => setIssue(true)} disabled={!lookups.data || !data}>Issue</Button>}>
      {error ? <div className="alert bad"><AlertTriangle size={16} /><div>{error.message}</div></div>
        : loading && !data ? <Spinner />
          : !items.length ? <Empty icon={Truck} title="No equipment with this customer">{manage ? 'Issue a router, ONU or cable to record it here.' : null}</Empty>
            : (
              <>
                <DataTable rows={items} columns={[
                  { key: 'product_name', title: 'Item', render: (i) => <div><b>{i.product_name}</b>{i.serial && <div className="faint mono">{i.serial}{i.mac ? ` · ${i.mac}` : ''}</div>}</div> },
                  { key: 'qty', title: 'Qty', align: 'right', render: qtyText },
                  { key: 'status', title: 'As', render: (i) => <StatusBadge s={i.status} /> },
                  { key: 'value', title: 'Value', align: 'right', render: (i) => (i.status === 'rented' && Number(i.rent_cents) ? <span>{money(Number(i.rent_cents) * Number(i.qty))}<span className="faint">/mo</span></span> : money(Number(i.cost_cents) * Number(i.qty))) },
                  { key: 'updated_at', title: 'Since', render: (i) => dateTime(i.updated_at) },
                  ...(manage ? [{ key: 'act', title: '', render: (i) => (i.status !== 'sold' ? <Button size="sm" variant="ghost" icon={Undo2} onClick={() => setRet(i)}>Return</Button> : <span className="faint">customer-owned</span>) }] : []),
                ]} />
                {data.monthly_rent_cents > 0 && <div className="faint" style={{ padding: '10px 4px 0' }}>Equipment rent: <b style={{ color: 'var(--text)' }}>{money(data.monthly_rent_cents)}</b> per month</div>}
              </>
            )}
      {issue && lookups.data && data && <IssueModal lookups={lookups.data} customer={data.customer} onClose={() => setIssue(false)} onDone={reload} />}
      {ret && lookups.data && <ActionModal lookups={lookups.data} item={ret} action="return" onClose={() => setRet(null)} onDone={reload} />}
    </Card>
  );
}
