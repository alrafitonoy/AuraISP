// IP management (real / dedicated / shared), core capacity & bandwidth transparency, router discovery & import.
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Plus, Trash2, Upload, RefreshCw, Search, Globe2, Lock, Share2, AlertTriangle, CheckCircle2, Info, Radar, Server } from 'lucide-react';
import { useApp } from '../../context.jsx';
import { api } from '../../lib/api.js';
import { bps, date, money, speed, toCents } from '../../lib/format.js';
import { Badge, Button, Card, DataTable, Empty, Gauge, Input, Modal, Page, Pager, Select, Spinner, Stat, Tabs, useLoad } from '../../components/ui.jsx';
import { AreaSeries } from '../../components/charts.jsx';

export const KIND_META = {
  real: { label: 'Real IP', icon: Globe2, hint: 'Public IPv4 routed to the customer (may change on request).' },
  dedicated: { label: 'Dedicated IP', icon: Lock, hint: 'Public static IPv4 reserved for one customer — servers, CCTV, VPN.' },
  shared: { label: 'Shared IP', icon: Share2, hint: 'Private/CGNAT address behind a shared public NAT address.' },
};

// ------------------------------------------------------------------ IP management
function PoolForm({ routers, onSubmit }) {
  const [f, setF] = useState({ name: '', kind: 'shared', cidr: '', gateway: '', dns: '', nat_address: '', router_id: '', price: 0, description: '' });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return (
    <form className="col" onSubmit={async (e) => {
      e.preventDefault(); setBusy(true);
      try { await onSubmit({ name: f.name, kind: f.kind, cidr: f.cidr, gateway: f.gateway || null, dns: f.dns || null, nat_address: f.kind === 'shared' ? f.nat_address || null : null, router_id: f.router_id ? Number(f.router_id) : null, monthly_price_cents: f.kind === 'shared' ? 0 : toCents(f.price), description: f.description || null }); }
      finally { setBusy(false); }
    }}>
      <div className="grid g3">
        {Object.entries(KIND_META).map(([k, m]) => (
          <button type="button" key={k} onClick={() => setF({ ...f, kind: k })} className={`card ${f.kind === k ? 'glow' : 'hover'}`} style={{ textAlign: 'left', cursor: 'pointer', font: 'inherit', color: 'inherit', padding: 14 }} aria-pressed={f.kind === k}>
            <div className="row"><m.icon size={18} /><b>{m.label}</b></div><div className="faint" style={{ marginTop: 4 }}>{m.hint}</div>
          </button>
        ))}
      </div>
      <div className="grid g2">
        <Input label="Pool name" required value={f.name} onChange={set('name')} />
        <Input label="Network (CIDR)" required value={f.cidr} onChange={set('cidr')} placeholder={f.kind === 'shared' ? '100.64.0.0/22' : '203.0.113.0/27'} hint="Between /20 and /32. Network & broadcast are skipped." />
        <Input label="Gateway" value={f.gateway} onChange={set('gateway')} hint="Reserved automatically" />
        <Input label="DNS servers" value={f.dns} onChange={set('dns')} placeholder="1.1.1.1, 8.8.8.8" />
        {f.kind === 'shared' && <Input label="Public NAT address" value={f.nat_address} onChange={set('nat_address')} placeholder="198.51.100.10" hint="Shared customers go online through this address" />}
        {f.kind !== 'shared' && <Input label="Monthly price per IP" type="number" min={0} step="0.01" value={f.price} onChange={set('price')} hint="Added to the customer's recurring invoice" />}
        <Select label="Router" value={f.router_id} onChange={set('router_id')} options={[{ value: '', label: '— any —' }, ...routers.map((r) => ({ value: r.id, label: r.name }))]} />
      </div>
      <Input label="Description" value={f.description} onChange={set('description')} />
      <Button variant="primary" type="submit" loading={busy}>Create pool</Button>
    </form>
  );
}

export function Ipam() {
  const { toast, can } = useApp();
  const nav = useNavigate();
  const summary = useLoad(() => api('/network/ipam/summary'));
  const pools = useLoad(() => api('/network/ipam/pools'));
  const routers = useLoad(() => api('/network/routers'));
  const [filter, setFilter] = useState({ pool_id: '', status: '', kind: '', q: '' });
  const [page, setPage] = useState(1);
  const addrs = useLoad(() => api(`/network/ipam/addresses?page=${page}&pageSize=50&pool_id=${filter.pool_id}&status=${filter.status}&kind=${filter.kind}&q=${encodeURIComponent(filter.q)}`), [page, filter]);
  const [creating, setCreating] = useState(false);
  const [assign, setAssign] = useState(null);

  const create = async (p) => { try { const r = await api.post('/network/ipam/pools', p); toast(`Pool created with ${r.hosts} usable addresses`); setCreating(false); pools.reload(); summary.reload(); addrs.reload(); } catch (e) { toast(e.message, 'bad'); } };
  const apply = async (p) => { const r = await api.post(`/network/ipam/pools/${p.id}/apply`); toast(r.ok ? 'Pool pushed to router' : `Router: ${r.error}`, r.ok ? 'ok' : 'bad'); };
  const del = async (p) => { if (!window.confirm(`Delete pool ${p.name}?`)) return; try { await api.del(`/network/ipam/pools/${p.id}`); pools.reload(); summary.reload(); addrs.reload(); } catch (e) { toast(e.message, 'bad'); } };
  const setStatus = async (a, status) => { try { await api.patch(`/network/ipam/addresses/${a.id}`, { status }); addrs.reload(); pools.reload(); } catch (e) { toast(e.message, 'bad'); } };
  const reconcile = async () => { const r = await api.post('/network/ipam/reconcile'); toast(`${r.fixed} assignment(s) reconciled`); addrs.reload(); pools.reload(); };
  const doAssign = async (e) => {
    e.preventDefault();
    try { const r = await api.post('/network/ipam/assign', { customer_id: Number(assign.customer_id), kind: assign.address ? undefined : assign.kind, address: assign.address || undefined }); toast(`Assigned ${r.address}${r.sync.ok ? '' : ` (router: ${r.sync.error})`}`, r.sync.ok ? 'ok' : 'info'); setAssign(null); addrs.reload(); pools.reload(); summary.reload(); }
    catch (err) { toast(err.message, 'bad'); }
  };

  const k = (kind) => {
    const rows = (summary.data?.byKind || []).filter((r) => r.kind === kind);
    const total = rows.reduce((s, r) => s + Number(r.n), 0); const used = Number(rows.find((r) => r.status === 'assigned')?.n || 0);
    return { total, used };
  };

  return (
    <Page title="IP management" subtitle="Create, provide and maintain Real, Dedicated and Shared IPs"
      actions={can('network.manage') && <><Button icon={RefreshCw} onClick={reconcile}>Reconcile</Button><Button icon={Plus} onClick={() => setAssign({ customer_id: '', kind: 'shared', address: '' })}>Assign IP</Button><Button variant="primary" icon={Plus} onClick={() => setCreating(true)}>New pool</Button></>}>
      <div className="grid g4 mb">
        {Object.entries(KIND_META).map(([kind, m]) => { const s = k(kind); return <Stat key={kind} icon={m.icon} label={m.label} value={s.used} sub={`of ${s.total} assigned · ${s.total - s.used} free`} />; })}
        <Stat icon={AlertTriangle} label="Active customers without IP" value={summary.data?.customersWithoutIp || 0} sub={`IP add-ons: ${money(summary.data?.ipAddonMonthlyCents || 0)}/mo`} />
      </div>
      <Card title="Pools" className="mb">
        {!pools.data ? <Spinner /> : !pools.data.pools.length ? <Empty title="No IP pools yet">Create a shared (CGNAT) pool for regular customers and real/dedicated pools for public IPs.</Empty> : (
          <div className="grid g3">
            {pools.data.pools.map((p) => {
              const M = KIND_META[p.kind];
              const pct = p.total ? (p.assigned / p.total) * 100 : 0;
              return (
                <motion.div key={p.id} className="card hover" whileHover={{ y: -3 }} style={{ padding: 16 }}>
                  <div className="row between"><div className="row"><M.icon size={18} /><b>{p.name}</b></div><Badge kind={p.kind === 'shared' ? 'info' : p.kind === 'dedicated' ? 'brand' : 'ok'}>{M.label}</Badge></div>
                  <div className="mono" style={{ margin: '8px 0' }}>{p.cidr}</div>
                  <div className="progress"><i style={{ width: `${pct}%`, background: pct > 90 ? 'var(--bad)' : undefined }} /></div>
                  <div className="row between faint" style={{ marginTop: 6 }}><span>{p.assigned}/{p.total} used</span><span>{p.kind === 'shared' ? `NAT ${p.nat_address || '—'}` : `${money(p.monthly_price_cents)}/mo`}</span></div>
                  {can('network.manage') && <div className="row mt"><Button size="sm" icon={Upload} onClick={() => apply(p)}>Push to router</Button><Button size="sm" variant="ghost" onClick={() => { setFilter({ ...filter, pool_id: String(p.id) }); setPage(1); }}>Addresses</Button><div className="grow" /><Button size="sm" variant="ghost" icon={Trash2} onClick={() => del(p)} aria-label="Delete pool" /></div>}
                </motion.div>
              );
            })}
          </div>
        )}
      </Card>
      <div className="row wrap mb">
        <Tabs tabs={[{ value: '', label: 'All' }, 'free', 'assigned', 'reserved', 'blocked']} value={filter.status} onChange={(v) => { setFilter({ ...filter, status: v }); setPage(1); }} />
        <Tabs tabs={[{ value: '', label: 'Any type' }, { value: 'real', label: 'Real' }, { value: 'dedicated', label: 'Dedicated' }, { value: 'shared', label: 'Shared' }]} value={filter.kind} onChange={(v) => { setFilter({ ...filter, kind: v }); setPage(1); }} />
        {filter.pool_id && <Button size="sm" onClick={() => setFilter({ ...filter, pool_id: '' })}>Clear pool filter ×</Button>}
        <div className="grow" />
        <div style={{ position: 'relative', width: 260 }}><Search size={16} style={{ position: 'absolute', left: 12, top: 13, color: 'var(--text-3)' }} /><input className="input" style={{ paddingLeft: 36 }} placeholder="IP, customer, code…" value={filter.q} onChange={(e) => { setFilter({ ...filter, q: e.target.value }); setPage(1); }} aria-label="Search addresses" /></div>
      </div>
      <Card className="flush">
        <DataTable rows={addrs.data?.rows} loading={addrs.loading} empty="No addresses" columns={[
          { key: 'address', title: 'Address', render: (r) => <span className="mono">{r.address}</span> },
          { key: 'kind', title: 'Type', render: (r) => KIND_META[r.kind]?.label },
          { key: 'pool_name', title: 'Pool' },
          { key: 'status', title: 'Status', render: (r) => <Badge kind={{ free: 'ok', assigned: 'brand', reserved: 'warn', blocked: 'bad' }[r.status]}>{r.status}</Badge> },
          { key: 'customer_name', title: 'Customer', render: (r) => r.customer_id ? <a onClick={() => nav(`/admin/customers/${r.customer_id}`)} style={{ cursor: 'pointer', color: 'var(--brand-1)' }}>{r.customer_name} <span className="faint">{r.customer_code}</span></a> : r.notes ? <span className="faint">{r.notes}</span> : '—' },
          { key: 'assigned_at', title: 'Since', render: (r) => (r.assigned_at && r.status === 'assigned' ? date(r.assigned_at) : '—') },
          { key: 'x', title: '', align: 'right', render: (r) => can('network.manage') && r.status !== 'assigned' && (
            <div className="row end">
              {r.status !== 'free' && <Button size="sm" variant="ghost" onClick={() => setStatus(r, 'free')}>Free</Button>}
              {r.status !== 'reserved' && <Button size="sm" variant="ghost" onClick={() => setStatus(r, 'reserved')}>Reserve</Button>}
              {r.status !== 'blocked' && <Button size="sm" variant="ghost" onClick={() => setStatus(r, 'blocked')}>Block</Button>}
            </div>) },
        ]} />
        {addrs.data && <Pager page={addrs.data.page} pageSize={addrs.data.pageSize} total={addrs.data.total} onPage={setPage} />}
      </Card>
      <Modal wide open={creating} onClose={() => setCreating(false)} title="New IP pool"><PoolForm routers={routers.data?.routers || []} onSubmit={create} /></Modal>
      <Modal open={!!assign} onClose={() => setAssign(null)} title="Assign IP to customer">
        {assign && <form className="col" onSubmit={doAssign}>
          <Input label="Customer ID" type="number" required value={assign.customer_id} onChange={(e) => setAssign({ ...assign, customer_id: e.target.value })} />
          <Select label="IP type" value={assign.kind} onChange={(e) => setAssign({ ...assign, kind: e.target.value })} options={Object.entries(KIND_META).map(([v, m]) => ({ value: v, label: m.label }))} />
          <Input label="Specific address (optional)" value={assign.address} onChange={(e) => setAssign({ ...assign, address: e.target.value })} hint="Leave empty to pick the next free address" />
          <Button variant="primary" type="submit">Assign & push to router</Button>
        </form>}
      </Modal>
    </Page>
  );
}

// ------------------------------------------------------------------ core capacity
const FLAG = { over_limit: ['bad', 'over plan'], idle: ['info', 'idle'], no_data: ['info', 'no data'], no_ip: ['warn', 'no IP'], no_plan_speed: ['warn', 'no speed'] };

export function Capacity() {
  const { toast, can } = useApp();
  const nav = useNavigate();
  const [days, setDays] = useState(7);
  const { data, reload } = useLoad(() => api(`/network/capacity?days=${days}`), [days]);
  const routers = useLoad(() => api('/network/routers'));
  const [link, setLink] = useState(null);
  const [only, setOnly] = useState('');
  if (!data) return <Spinner />;
  const cap = data.capacity;
  const saveLink = async (e) => {
    e.preventDefault();
    const p = { name: link.name, provider: link.provider || null, router_id: link.router_id ? Number(link.router_id) : null, interface: link.interface || null, capacity_down_kbps: Math.round(Number(link.down) * 1000), capacity_up_kbps: Math.round(Number(link.up) * 1000), monthly_cost_cents: toCents(link.cost || 0) };
    try { if (link.id) await api.put(`/network/upstream-links/${link.id}`, p); else await api.post('/network/upstream-links', p); setLink(null); reload(); toast('Upstream link saved'); } catch (err) { toast(err.message, 'bad'); }
  };
  const rows = only ? data.customers.filter((c) => c.flags.includes(only)) : data.customers;
  return (
    <Page title="Core capacity & bandwidth" subtitle={data.source === 'configured' ? 'Using the upstream links you configured' : 'No upstream links configured — capacity is detected from observed core traffic'}
      actions={<><Tabs tabs={[{ value: 1, label: '24h' }, { value: 7, label: '7d' }, { value: 30, label: '30d' }]} value={days} onChange={setDays} />{can('network.manage') && <Button variant="primary" icon={Plus} onClick={() => setLink({ name: '', provider: '', router_id: '', interface: '', down: '', up: '', cost: '' })}>Upstream link</Button>}</>}>
      {data.recommendations.map((r, i) => (
        <motion.div key={i} className={`alert ${r.level} mb`} initial={{ x: -10 }} animate={{ x: 0 }} transition={{ delay: i * 0.05 }}>
          {r.level === 'bad' ? <AlertTriangle size={18} /> : r.level === 'warn' ? <AlertTriangle size={18} /> : <Info size={18} />}<div>{r.text}</div>
        </motion.div>
      ))}
      <div className="grid g3 mb">
        <Card title="Upstream utilisation (live)" className="span2">
          <div className="row wrap" style={{ justifyContent: 'space-around' }}>
            <Gauge value={data.usage.liveRxBps / 1000} max={cap.downKbps || 1} label={`${data.usage.liveUtilization ?? 0}%`} sub={`${bps(data.usage.liveRxBps)} of ${speed(cap.downKbps)}`} />
            <Gauge value={data.usage.peakRxBps / 1000} max={cap.downKbps || 1} label={`${data.usage.peakUtilization ?? 0}%`} sub={`peak ${bps(data.usage.peakRxBps)}`} size={170} />
            <div className="col" style={{ minWidth: 200 }}>
              <div><div className="faint">Upstream capacity {data.source === 'detected' && <Badge kind="info">estimated</Badge>}</div><b style={{ fontSize: 22, fontFamily: 'var(--font-display)' }}>{speed(cap.downKbps)} ↓ / {speed(cap.upKbps)} ↑</b></div>
              <div><div className="faint">Sold to customers</div><b>{speed(data.provisioned.downKbps)} · {data.provisioned.customers} active</b></div>
              <div><div className="faint">Contention ratio</div><b>{data.oversubscription ? `1 : ${data.oversubscription}` : '—'}</b></div>
              <div><div className="faint">Headroom at peak</div><b>{data.usage.headroomBps != null ? bps(data.usage.headroomBps) : '—'}</b></div>
            </div>
          </div>
        </Card>
        <Card title="Upstream links">
          {!data.links.length ? <Empty icon={Server} title="None configured">Add the bandwidth you buy from your upstream provider for exact figures.</Empty> : data.links.map((l) => (
            <div key={l.id} className="list-item"><Server size={18} className="muted" /><div className="grow"><b>{l.name}</b><div className="faint">{l.provider || '—'} {l.interface ? `· ${l.interface}` : ''}</div></div><b>{speed(l.capacity_down_kbps)}</b>
              {can('network.manage') && <Button size="sm" variant="ghost" icon={Trash2} onClick={async () => { await api.del(`/network/upstream-links/${l.id}`); reload(); }} aria-label="Delete link" />}</div>
          ))}
          {data.source === 'detected' && <div className="faint mt">Observed peak: {bps(cap.observedPeakRxBps)} ↓ / {bps(cap.observedPeakTxBps)} ↑ → rounded up to {speed(cap.downKbps)}.</div>}
        </Card>
      </div>
      <Card title="Total customer traffic vs capacity" className="mb">
        <AreaSeries data={data.series.map((s) => ({ ...s, cap: cap.downKbps * 1000 }))} x="ts" fmtY={bps} fmtX={(v) => new Date(v).toLocaleString([], { month: 'short', day: '2-digit', hour: '2-digit' })}
          series={[{ key: 'rx', label: 'Download' }, { key: 'tx', label: 'Upload' }, { key: 'cap', label: 'Capacity', color: 'var(--bad)' }]} />
      </Card>
      <div className="row wrap mb">
        <b>Per-customer: provided vs used</b><div className="grow" />
        <Tabs tabs={[{ value: '', label: `All (${data.customers.length})` }, { value: 'over_limit', label: `Over plan (${data.summary.overLimit})` }, { value: 'idle', label: `Idle (${data.summary.idle})` }, { value: 'no_ip', label: `No IP (${data.summary.noIp})` }]} value={only} onChange={setOnly} />
      </div>
      <Card className="flush">
        <DataTable rows={rows.slice(0, 300)} onRowClick={(r) => nav(`/admin/customers/${r.id}`)} columns={[
          { key: 'name', title: 'Customer', render: (r) => <div><b>{r.name}</b><div className="faint">{r.code} · {r.plan || 'no plan'}</div></div> },
          { key: 'ip', title: 'IP', render: (r) => r.ip ? <span className="mono">{r.ip} <span className="faint">{r.ipType ? KIND_META[r.ipType]?.label : ''}</span></span> : '—' },
          { key: 'prov', title: 'Provided', render: (r) => speed(r.provisionedDownKbps) },
          { key: 'avg', title: 'Avg used', align: 'right', render: (r) => bps(r.avgRxBps) },
          { key: 'peak', title: 'Peak used', align: 'right', render: (r) => bps(r.peakRxBps) },
          { key: 'util', title: 'Utilisation', width: 160, render: (r) => r.utilization == null ? '—' : <div className="row" style={{ gap: 8 }}><div className="progress grow"><i style={{ width: `${Math.min(100, r.utilization)}%`, background: r.utilization > 110 ? 'var(--bad)' : undefined }} /></div><span className="faint">{r.utilization}%</span></div> },
          { key: 'flags', title: '', render: (r) => <div className="row wrap" style={{ gap: 4 }}>{r.flags.map((f) => <Badge key={f} kind={FLAG[f]?.[0]}>{FLAG[f]?.[1] || f}</Badge>)}</div> },
        ]} />
      </Card>
      <Modal open={!!link} onClose={() => setLink(null)} title="Upstream link">
        {link && <form className="col" onSubmit={saveLink}>
          <div className="grid g2">
            <Input label="Name" required value={link.name} onChange={(e) => setLink({ ...link, name: e.target.value })} placeholder="IIG transit A" />
            <Input label="Provider" value={link.provider} onChange={(e) => setLink({ ...link, provider: e.target.value })} />
            <Input label="Download capacity (Mbps)" type="number" min={1} required value={link.down} onChange={(e) => setLink({ ...link, down: e.target.value })} />
            <Input label="Upload capacity (Mbps)" type="number" min={1} required value={link.up} onChange={(e) => setLink({ ...link, up: e.target.value })} />
            <Select label="Core router" value={link.router_id} onChange={(e) => setLink({ ...link, router_id: e.target.value })} options={[{ value: '', label: '—' }, ...(routers.data?.routers || []).map((r) => ({ value: r.id, label: r.name }))]} />
            <Input label="WAN interface" value={link.interface} onChange={(e) => setLink({ ...link, interface: e.target.value })} placeholder="sfp-sfpplus1" hint="Sampled every minute for real usage" />
            <Input label="Monthly cost" type="number" min={0} step="0.01" value={link.cost} onChange={(e) => setLink({ ...link, cost: e.target.value })} />
          </div>
          <Button variant="primary" type="submit">Save link</Button>
        </form>}
      </Modal>
    </Page>
  );
}

// ------------------------------------------------------------------ discover & import from core router
export function DiscoverModal({ router, onClose }) {
  const { toast } = useApp();
  const { data, error } = useLoad(() => api.post(`/network/routers/${router.id}/discover`), [router.id]);
  const [sel, setSel] = useState(null);
  const [planMap, setPlanMap] = useState({});
  const [def, setDef] = useState('');
  const [busy, setBusy] = useState(false);
  if (data && sel === null) setSel(data.pppSecrets.filter((s) => !s.known).map((s) => s.name));
  const doImport = async () => {
    setBusy(true);
    try {
      const secrets = data.pppSecrets.filter((s) => sel.includes(s.name)).map((s) => ({ name: s.name, remoteAddress: s.remoteAddress, profile: s.profile }));
      const r = await api.post(`/network/routers/${router.id}/import`, { secrets, planMap: Object.fromEntries(Object.entries(planMap).filter(([, v]) => v)), defaultPlanId: def ? Number(def) : undefined });
      toast(`${r.created} customer(s) imported${r.skipped.length ? `, ${r.skipped.length} skipped` : ''}`); onClose(true);
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  };
  return (
    <Modal wide open onClose={() => onClose(false)} title={`Discover · ${router.name}`}>
      {error ? <div className="alert bad"><div>{error.message}</div></div> : !data ? <Spinner /> : (
        <div className="col">
          <div className="grid g4">
            <Stat icon={Radar} label="RouterOS" value={0} format={() => data.router.version} sub={data.router.board} />
            <Stat label="WAN interface" value={0} format={() => data.wanInterface || '—'} sub="auto-detected" />
            <Stat label="PPPoE users" value={data.pppSecrets.length} sub={`${data.pppSecrets.filter((s) => !s.known).length} not in AuraISP`} />
            <Stat label="Unknown sessions" value={data.unknownSessions.length} sub="online, not billed" />
          </div>
          <Card title="Interfaces"><DataTable rows={data.interfaces.map((i) => ({ ...i, id: i.name }))} columns={[{ key: 'name', title: 'Interface', render: (r) => <span className="mono">{r.name}{r.name === data.wanInterface && <Badge kind="brand"> WAN</Badge>}</span> }, { key: 'running', title: 'State', render: (r) => <Badge status={r.running ? 'online' : 'offline'} /> }, { key: 'rx', title: 'Rx now', align: 'right', render: (r) => bps(r.rxBps) }, { key: 'tx', title: 'Tx now', align: 'right', render: (r) => bps(r.txBps) }]} /></Card>
          {data.unknownSessions.length > 0 && <div className="alert warn"><AlertTriangle size={18} /><div>{data.unknownSessions.length} active session(s) are not linked to any customer: {data.unknownSessions.slice(0, 8).map((s) => s.name).join(', ')}{data.unknownSessions.length > 8 ? '…' : ''}. Import them below so they are billed.</div></div>}
          <Card title="Import existing PPPoE users">
            {!data.pppSecrets.length ? <Empty title="No PPPoE secrets on this router" /> : <>
              {data.profiles.length > 0 && <div className="grid g3 mb">{data.profiles.map((p) => <Select key={p} label={`Profile "${p}" → plan`} value={planMap[p] || ''} onChange={(e) => setPlanMap({ ...planMap, [p]: e.target.value })} options={[{ value: '', label: '— default —' }, ...data.plans.map((x) => ({ value: x.id, label: `${x.name} (${speed(x.download_kbps)})` }))]} />)}</div>}
              <Select label="Default plan" value={def} onChange={(e) => setDef(e.target.value)} options={[{ value: '', label: '— none —' }, ...data.plans.map((x) => ({ value: x.id, label: x.name }))]} />
              <div className="col mt" style={{ maxHeight: 280, overflowY: 'auto', gap: 4 }}>
                {data.pppSecrets.map((s) => (
                  <label key={s.name} className="check" style={{ opacity: s.known ? 0.5 : 1 }}>
                    <input type="checkbox" disabled={s.known} checked={!!sel?.includes(s.name)} onChange={(e) => setSel(e.target.checked ? [...sel, s.name] : sel.filter((x) => x !== s.name))} />
                    <span className="mono">{s.name}</span> <span className="faint">{s.profile} {s.remoteAddress ? `· ${s.remoteAddress}` : ''} {s.known ? '· already a customer' : ''}</span>
                  </label>
                ))}
              </div>
              <div className="faint mt">Imported customers get a placeholder email; edit their contact details, then they can set a password with "Forgot password".</div>
              <Button variant="primary" className="mt" loading={busy} disabled={!sel?.length} onClick={doImport}>Import {sel?.length || 0} customer(s)</Button>
            </>}
          </Card>
        </div>
      )}
    </Modal>
  );
}

export function PinCertificate({ router, onDone }) {
  const { toast } = useApp();
  const [info, setInfo] = useState(null);
  const [busy, setBusy] = useState(false);
  const fetchFp = async () => { setBusy(true); try { setInfo(await api.post('/network/routers/fingerprint', { host: router.host, port: router.port || 443 })); } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); } };
  const pin = async () => { await api.post(`/network/routers/${router.id}/pin`, { fingerprint: info.fingerprint256 }); toast('Certificate pinned'); onDone(); };
  return (
    <div className="col">
      <p className="muted">Self-signed router certificates are trusted by <b>pinning</b> their exact fingerprint — connections are refused if the certificate ever changes (protects against interception). Compare the fingerprint below with the router (<span className="mono">/certificate print detail</span>) before pinning.</p>
      {!info ? <Button loading={busy} onClick={fetchFp}>Fetch certificate from {router.host}</Button> : (
        <>
          <div className="card" style={{ padding: 12 }}><div className="faint">Subject / issuer</div><b>{info.subject} / {info.issuer}</b> {info.selfSigned && <Badge kind="warn">self-signed</Badge>}<div className="faint mt">SHA-256 fingerprint</div><code className="mono" style={{ wordBreak: 'break-all' }}>{info.fingerprint256}</code><div className="faint mt">Valid to {info.validTo}</div></div>
          <Button variant="primary" icon={CheckCircle2} onClick={pin}>I verified it — pin this certificate</Button>
        </>
      )}
    </div>
  );
}
