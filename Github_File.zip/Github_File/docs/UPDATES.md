# Updates & Releases

## How installations update

* Every night at 03:20 the server checks the GitHub repo in `UPDATE_REPO` for the newest release.
* Only **stable** releases are considered: published (not draft), not marked pre-release, and tagged exactly `vX.Y.Z`.
  Tags like `v1.4.0-beta.1` are ignored.
* The package `aura-isp-X.Y.Z.tar.gz` is downloaded and its **Ed25519 signature** (`.sig`) is verified
  against `UPDATE_PUBLIC_KEY`. With no key configured, nothing is installed.
* Before installing, a backup of the current code is written to `server/data/backups/` (the last 5 are kept).
* Files are extracted (never touching `.env`, `data/` or `node_modules`), dependencies are installed with `npm ci --omit=dev`,
  and the process restarts. On restart, database migrations run automatically.

**Admin → Updates** offers: check now, install now (admin only), automatic install on/off, history, and
**Restore** from any backup (rollback). With automatic install off, the server still checks and shows available versions.

The desktop app updates itself from the same GitHub releases (stable only) through electron-updater.
The mobile app updates through the app stores. Because it loads the web build bundled at compile time,
publish a new store build when the web UI changes.

## Publishing a release (maintainers)

1. One-time setup: generate the signing key pair.
   ```bash
   node server/scripts/sign-release.js keygen
   ```
   Put the **private key** in the GitHub secret `RELEASE_PRIVATE_KEY`. Put the **public key** in every installation's `.env`
   as `UPDATE_PUBLIC_KEY`, and set `UPDATE_REPO=owner/repo`.
2. Bump `server/package.json` (and `desktop/package.json`) versions and commit.
3. `git tag v1.1.0 && git push --tags`. The **Release** workflow tests, builds the web app, packages, signs, publishes, and builds desktop installers.
4. For a pre-release, use a tag like `v1.1.0-rc.1`. It is published as a GitHub pre-release and installations ignore it.

Never put the private key on a customer server. If it leaks, generate a new pair, update `UPDATE_PUBLIC_KEY` everywhere, and re-sign.
