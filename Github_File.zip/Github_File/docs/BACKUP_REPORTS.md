# Backups & PDF Reports

## Backups (Admin → Backups)

| Type | Contains | Use it for |
|---|---|---|
| **Database** | Every table as a portable NDJSON dump (gzip) | Daily safety net, and moving between SQLite and MySQL |
| **UI + database** | Database + built web app (`web/dist`) + uploaded branding | Restoring the site exactly as it looked |
| **Entire system** | Database + web app + uploads + server code + deploy files + docs; optionally `.env` | Disaster recovery or moving to a new server |

* **Encryption**: optional passphrase (12+ characters) using scrypt + AES-256-GCM. Including `.env` (master key and DB credentials) **requires** a passphrase. Lose the passphrase and the backup cannot be opened.
* **Schedule**: daily at a chosen hour, with a chosen type and *keep the newest N* retention. Settings live on the same page.
* **Download / delete / restore** require you to re-enter your password. Restore is administrator-only.
* **Restore** safety:
  * the SHA-256 checksum is verified first
  * an automatic **pre-restore database backup** is taken
  * the archive is extracted with path-traversal protection
  * data is replaced inside a single transaction, and all sessions are revoked
  * restoring code or `.env` restarts the server
  * backups from older or newer versions restore safely (unknown tables and columns are skipped)
* **Upload** a backup from another server, then restore it. A database backup made on SQLite restores into MySQL and vice-versa.
* Moving to a new server: install AuraISP, then upload an *entire system* backup that includes `.env` and restore it with *Restore .env too* ticked.
* Files are stored in `server/data/backups/system/`. **Copy them off the server** regularly by downloading them, or sync that folder to external storage.

> Settings secrets (router passwords, API keys) are encrypted with `APP_KEY`. Restoring a database onto a server with a different
> `APP_KEY` keeps all data, but you must re-enter those secrets. Use an entire-system backup with `.env` to carry the key.

## PDF reports (Admin → PDF reports)

| Report | Contents |
|---|---|
| **Overall business** | Active/suspended/pending customers, MRR, ARPU, revenue, outstanding, new customers and churn, tickets, network capacity and contention, customers by plan, top areas, IP utilisation |
| **Accounts** | Collected vs invoiced, collection rate, tax, discounts, refunds, collections by month and method, receivables aging (current / 1-30 / 31-60 / 61-90 / 90+), top debtors |
| **Sales** | Sales value, deals, new connections, upgrades/downgrades, terminations, sales by month and plan, staff leaderboard, lead sources and conversion, pipeline |
| **Customer** | Profile, plan, IP and connection; statement of account with opening and running balance; daily data usage chart; plan changes; tickets |

* Pick a date range (or a preset). Reports download as branded A4 PDFs with your company name and colours.
* **Invoice PDFs**: a *PDF* button sits on every invoice (admin and customer portal).
* **Customers** can download their own invoices and a 12-month statement from Portal → Billing.
* Access: the `reports.view` permission is required for business reports (Manager and Billing Officer have it by default). Every report download is recorded in the audit log.
