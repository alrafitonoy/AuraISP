# ISP Core: IP Management, Bandwidth & Core Integration

AuraISP is designed to run the whole ISP. It connects to the **core system** (your border/core router and NAS/BRAS
routers), provisions customers on it, and continuously compares what you **provide** with what is **used**.

## 1. Connect the core

1. **Network → Routers → Add router**. Set *Role* to **Core / border** for the router that carries your upstream internet, and to **NAS / BRAS** for routers that terminate customer PPPoE sessions (one router can be both).
2. Self-signed certificate? Tick *Router uses a self-signed certificate*, save, then click **Pin now**. AuraISP shows the certificate's SHA-256 fingerprint. Compare it with `/certificate print detail` on the router, then pin it. Connections are refused if the certificate ever changes. Verification is never simply switched off.
3. **Test**, then **Discover & import**. AuraISP reads the router without changing anything:
   * RouterOS version, interfaces and live rates, and the **WAN interface** (auto-detected from the default route)
   * existing PPPoE secrets, active sessions, queues and IP pools
   * **unknown sessions**: users online on the router who are not in AuraISP and therefore not billed
4. Map each PPPoE profile to a plan and import the users. They become customers with their current IPs, and you can edit their contact details afterwards.

## 2. IP management (Network → IP management)

| Type | What it is | Typical use | Billing |
|---|---|---|---|
| **Shared IP** | Private / CGNAT address (e.g. `100.64.0.0/10`) that goes online through a shared public **NAT address** | Regular home users | Free (included) |
| **Real IP** | Public IPv4 routed to the customer | Gamers, port forwarding, remote access | Monthly price per pool |
| **Dedicated IP** | Public **static** IPv4 reserved permanently for one customer | Servers, CCTV, VPN, businesses | Monthly price per pool |

* **Create a pool**: choose the type and enter the CIDR (between /20 and /32). Usable host addresses are created, and the gateway is reserved automatically. Real and dedicated pools must be public; a shared pool needs a public NAT address.
* **Push to router** creates the `/ip pool` on the router. For shared pools it also creates the source-NAT rule to the NAT address.
* **Assign** from a customer page (*IP address* card) or from IP management. Pick a type for the next free address, or type a specific one. On the router, the PPPoE secret's `remote-address` is set and the session reconnects. The address is also added to the `aura-real` / `aura-dedicated` / `aura-shared` address list, so you can write firewall/QoS rules per type.
* Each customer has exactly one IP. Assigning a new one releases the old one. **Release** frees it, **Reserve** / **Block** take addresses out of rotation, and **Reconcile** links IPs that were typed manually or imported to their customers.
* Real and dedicated IP charges are added to every recurring invoice automatically (multiplied by the plan's cycle length).

## 3. Bandwidth management & setup

* **Plan speeds** apply to everyone on the plan. A **custom limit** on the customer page overrides them.
* **Push speed + IP to router** (customer page) re-applies both in one click. **Sync all** (router card) re-applies every customer on that router.
* Suspensions, parental controls and site rules use the same pipeline.

## 4. Core capacity & transparency (Network → Core capacity)

* **Configured**: add your **upstream links** (bandwidth bought from IIG/transit providers, with WAN interface and cost). Their interfaces are sampled every minute.
* **Not configured**: AuraISP **detects** capacity. It samples the core router's auto-detected WAN interface every minute, combines that with total customer traffic, takes the observed peak (+20% margin), and rounds up to a standard circuit size (100 M, 200 M, 500 M, 1 G, 2 G, 10 G…). This is clearly labelled *estimated*.
* The page shows:
  * upstream capacity vs. **provided** (sum of customer speeds) → **contention ratio**
  * live and peak utilisation, and headroom at peak
  * total traffic vs. capacity over 24 h, 7 d or 30 d
  * **per customer**: provided speed, average and peak usage, utilisation %, and flags (**over plan** = the router isn't enforcing the limit, **idle**, **no data**, **no IP**)
  * plain-language recommendations (congestion, high contention, unenforced limits, customers without IPs)

## Router support

The MikroTik RouterOS 7 REST driver implements everything above. Other vendors (Cisco, Huawei, Juniper, RADIUS CoA, OLT/TR-069)
can be added by implementing the driver interface. See [DEVELOPER.md](DEVELOPER.md#adding-a-router-vendor). New driver methods are
`discover`, `interfaceRates`, `ensurePool`, `assignIp` and `releaseIp`.
