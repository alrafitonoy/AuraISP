# Choosing a database

AuraISP runs on **MySQL / MariaDB**, **PostgreSQL** or **SQLite**. Every feature works on all three. The automated test suite (53 tests)
runs against each one. You choose the database in the browser installer, which also recommends one for your server.

| | MySQL / MariaDB | PostgreSQL | SQLite |
|---|---|---|---|
| **Best for** | Most ISPs; shared hosting; VPS | Large ISPs, heavy concurrent load | Trials, demos, very small ISPs |
| **Pros** | Included with almost every hosting plan (cPanel → MySQL Databases); fast; phpMyAdmin; easy backups; load balancing | Strongest integrity and concurrency; instant cross-server realtime (LISTEN/NOTIFY); load balancing | Zero setup — one file; no server to manage |
| **Requirements** | MySQL 8.0+ or MariaDB 10.4+ | PostgreSQL 12+ | Node.js 22.13+ |
| **Load balancing / multiple servers** | ✅ | ✅ | ❌ (single process) |
| **Realtime events between servers** | via a small polled table (≈1 s) | native LISTEN/NOTIFY (instant) | n/a (single process) |
| **Typical size** | up to ~50,000 customers | 50,000+ customers | up to ~300 customers |

## How the installer recommends
1. **Shared hosting detected** (cPanel, Phusion Passenger): **MySQL/MariaDB**. It's always available and managed by your host.
2. **A database server already runs on the machine**: that one (MySQL/MariaDB preferred if both run).
3. **Powerful VPS** (4+ cores, 8+ GB RAM) with nothing installed: **PostgreSQL** for heavy load (MySQL/MariaDB is equally supported).
4. **Other VPS/cloud**: **MySQL/MariaDB** (`apt install mariadb-server`).
5. **Small machine with no database server**: **SQLite**.

**Our general recommendation is MySQL / MariaDB.** PostgreSQL is the choice for very large, high-traffic deployments. SQLite is only for evaluation or tiny single-server setups.

## Security built in (all databases)
* The application connects with a **dedicated, least-privilege user**: rights on its own database only (SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, REFERENCES), and **no** FILE, SUPER, GRANT, DROP or access to other databases. The installer **refuses superuser accounts**.
* **Remote databases use TLS with full certificate and hostname verification** (`DB_SSL=verify-full`, optional private CA in `DB_SSL_CA`). Unverified TLS is not offered.
* Every query uses **bound parameters**. MySQL runs with `multipleStatements=false` (no stacked queries), strict SQL mode and a 30-second statement timeout. PostgreSQL has `statement_timeout` and an idle-transaction timeout.
* Sensitive values (router passwords, API keys, 2FA seeds) are **AES-256-GCM encrypted** inside the database, so a stolen dump doesn't reveal them.
* SQLite files are created `0600` (owner-only), with `secure_delete` on.

## Hardening the database server (VPS)
**MariaDB/MySQL**
```ini
[mysqld]
bind-address=127.0.0.1          # or your private network IP
skip-name-resolve
local_infile=0
require_secure_transport=ON     # when the app connects over the network
ssl_cert=/etc/mysql/server-cert.pem
ssl_key=/etc/mysql/server-key.pem
sql_mode=STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION
```
Then run `mysql_secure_installation`, which removes anonymous users, remote root and the test database.

**PostgreSQL**
```conf
# postgresql.conf
listen_addresses = 'localhost'      # or the private interface
password_encryption = scram-sha-256
ssl = on
# pg_hba.conf  — TLS + SCRAM only
hostssl  aura_isp  aura_app  10.0.0.0/24  scram-sha-256
```

## Switching databases later
1. Admin → Backups → **Database** backup (a portable dump).
2. Install fresh with the new database.
3. Admin → Backups → **Upload** → **Restore**.

The dump format is the same for all three databases.

## Local development setup used for testing
* MariaDB 11.4 LTS (TLS-only, hardened as above) on port 3306
* PostgreSQL 17 (TLS-only, SCRAM) on port 5432
* SQLite via Node's built-in driver

Run `npm run test:all` in `server/` to test against all three (needs `.env.test.mysql`, `.env.test.postgres`, `.env.test.sqlite`).
