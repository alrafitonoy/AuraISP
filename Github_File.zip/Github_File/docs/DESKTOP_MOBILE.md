# Desktop & Mobile Apps

Both apps reuse the web app, so a feature built once appears everywhere.

## Desktop (admins & staff)
`desktop/` is an Electron shell. On first launch it asks for your server address, then loads `https://your-server/login`
inside a locked-down window. Customer accounts are refused (`app: desktop` login flag).

```bash
cd desktop && npm install && npm start
```
To build installers, put icons in `desktop/build/` (`icon.ico`, `icon.icns`, `icon.png` 512×512), then run:
```bash
npm run dist:win
```
`dist:mac` and `dist:linux` build the other platforms. Installers land in `desktop/release/`. Code-sign for production: Windows needs `CSC_LINK`/`CSC_KEY_PASSWORD`;
macOS needs an Apple Developer ID plus notarisation (`APPLE_ID`, `APPLE_APP_SPECIFIC_PASSWORD`).

Updates: tagging a release runs `.github/workflows/release.yml`, which publishes installers to GitHub Releases. Installed apps update
automatically from stable releases only. **File → Change server…** switches servers.

Because the UI is loaded from the server, the console always matches the server version. Only the thin shell needs app updates.

**Ready-made Windows installer:** `desktop/release/AuraISP-Console-Setup-1.0.0.exe` (built locally, **unsigned**, so Windows
SmartScreen shows "unknown publisher" until you sign it with a code-signing certificate).

## Mobile (customers only)
`mobile/` is a Capacitor project that bundles `web/dist`. The app is **for customers only**: the server refuses staff and
admin logins from it (`app: mobile`), and the app never shows the admin console.

**Automatic builds:** GitHub → Actions → **Mobile apps** → *Run workflow* (or push a `v*` tag) produces:
* **Android**: debug APK (install directly) plus release APK/AAB (signed if you add the `ANDROID_KEYSTORE_*` secrets), ready for Google Play.
* **iOS**: an unsigned Xcode archive. Open it on a Mac, sign it with your Apple Developer account and upload with Xcode/Transporter. Apple requires signing; it can't be done without your account.

Set the repository variable `AURA_SERVER_URL` (e.g. `https://portal.your-isp.com`) so the app connects to your server out of the box.

### Build on your own machine

```bash
cd mobile && npm install
npm run add:android        # once (and/or add:ios on macOS)
npm run sync               # builds web + copies into native projects
npm run open:android       # Android Studio → Run / Build → Generate signed bundle
```
* Pre-set your server at build time with `VITE_API_URL=https://portal.example.com npm run build:web`. Otherwise the app asks on first launch.
* Server `.env`: no change is needed. `capacitor://localhost` and `https://localhost` are already allowed by CORS.
* **Push**: add `google-services.json` to `mobile/android/app/` (and APNs + `GoogleService-Info.plist` for iOS), and paste the
  Firebase service-account JSON into Settings → Integrations → Push. Users tap *Enable push on this device* under Notifications.
* **Payments** open in the system browser (gateway apps and 3-D Secure work there), and the app refreshes when you return.
* **Icons and splash**: `npx @capacitor/assets generate` with a 1024×1024 icon in `mobile/assets/`.
* Release: Google Play (AAB) and the App Store (Xcode Archive). Publish a new build when the web UI changes.
