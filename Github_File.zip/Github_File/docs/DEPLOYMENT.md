# Hosting & Deployment

The easiest way to install is the **browser installer**: [INSTALL.md](INSTALL.md).
This page covers hosting choices and production operations.

| Option | Recommended database | Load balancing | Updates |
|---|---|---|---|
| Shared hosting (cPanel "Setup Node.js App") | MySQL / MariaDB (cPanel → MySQL Databases) | 1–2 workers (host limits) | Self-update (Passenger restart) |
| VPS / cloud (PM2 + Nginx) | MySQL / MariaDB, or PostgreSQL for very large ISPs | `WEB_CONCURRENCY=max` + optional extra servers | Self-update (rolling restart) |
| Docker / Compose | MariaDB (included) | 3 replicas + Nginx (included) | Pull or rebuild the image |
| Localhost / office PC | SQLite or MariaDB | single process (SQLite) | Self-update |

> Always serve production over **HTTPS**. Secure cookies, HSTS, Web Push and payment callbacks depend on it.

## Shared hosting (cPanel)
See [INSTALL.md](INSTALL.md#shared-hosting-cpanel). Notes:
* Use **MySQL Databases** to create the database and user (grant ALL PRIVILEGES on that database only).
* Shared hosts may stop idle Node apps. Add a cPanel **Cron job** so scheduled billing, reminders and enforcement keep running:
  `*/5 * * * * curl -fsS https://your-domain/api/health >/dev/null`
* Keep `WEB_CONCURRENCY` at 1–2 unless your plan allows more processes.

## VPS / cloud (Ubuntu)
```bash
sudo apt install -y nginx mariadb-server unzip && curl -fsSL https://deb.nodesource.com/setup_22.x | sudo bash - && sudo apt install -y nodejs
sudo mysql_secure_installation
unzip AuraISP_Installer.zip -d /opt && cd /opt/AuraISP/server
sudo npm i -g pm2 && pm2 start app.cjs --name aura && pm2 save && pm2 startup
```
Open `http://SERVER-IP:4000/install/`, finish the wizard, then configure Nginx with HTTPS:
* one server: `deploy/nginx.conf`
* several servers: `deploy/nginx-loadbalancer.conf` (see [LOAD_BALANCING.md](LOAD_BALANCING.md))

Firewall: expose only 80/443 (`ufw allow 'Nginx Full'`), and keep 4000 and the database ports private.

## Docker
```bash
cp server/.env.example server/.env      # set APP_KEY=$(openssl rand -base64 32), APP_URL, VAPID keys
DB_PASSWORD=$(openssl rand -base64 24) docker compose up -d --build
docker compose exec app node scripts/setup.js --email you@example.com
```
This runs MariaDB, 3 AuraISP replicas (each using all CPU cores) and an Nginx load balancer on port 8080. Put TLS in front.
Turn off automatic updates in Docker (Admin → Updates) and upgrade by rebuilding the image.

## Routers (MikroTik RouterOS 7.1+)
```
/user group add name=aura policy=read,write,api,rest-api,test,!ftp,!ssh,!winbox,!policy,!password,!reboot
/user add name=aura-api group=aura password=<long-random>
/ip service set www-ssl disabled=no certificate=<your-cert> address=<aura-server-ip>/32
/ip firewall filter add chain=forward src-address-list=aura-suspended action=drop comment="aura suspended"
```
Add the router under Network → Routers. For a self-signed certificate, **pin** it (Routers → Pin now). Then use **Test**, **Discover & import** and **Sync all**.

## Backups
* Admin → Backups: database, UI + database, or the entire system; encrypted, scheduled and with retention.
* Database-level backups too: `mysqldump --single-transaction aura_isp`, `pg_dump aura_isp`, or copy the SQLite file while the app is stopped.
* **Always back up `server/.env`.** Without `APP_KEY`, the encrypted secrets can't be read.
