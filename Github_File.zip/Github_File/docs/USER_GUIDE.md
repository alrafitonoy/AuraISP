# User Guide

## Roles at a glance
* **Administrator**: everything, including settings, updates, staff and roles.
* **Staff**: only what their role allows. Built-in roles are Manager, Billing Officer, Support Agent, Network Engineer and Sales Executive. Create your own under **Staff & roles**.
* **Customer**: self-service portal (web and mobile).

## First day checklist (admin)
1. Sign in with the account printed by `setup`. Go to **Profile & security**, change your password and enable 2FA.
2. **Settings → Branding**: logo, name, colours. **Company**: currency, tax, invoice prefix.
3. **Settings → Integrations**: SMTP first, then SMS, WhatsApp and payments. Use the test buttons.
4. **Network → Routers**: add your MikroTik router, then **Test**.
5. **Plans**: adjust the default plans, or create your own.
6. **Staff & roles**: create staff accounts, adjust role permissions and dashboards.
7. **Settings → Website**: hero text, coverage areas, social links.

## Customers
* **Add customer**: personal details, plan, router, PPPoE/IP. Optionally creates the first invoice. If you leave the password blank, a temporary one is shown once and emailed.
* **Customer page**: live usage, **Bandwidth control** (custom Mbps overrides the plan; *Reset to plan* removes it), Suspend/Activate, Reconnect PPPoE, invoices with *Collect*, tickets, parental controls.
* Search by name, phone, code, IP or PPPoE username.

## Plans
Speed, price, cycle (monthly/quarterly/yearly), setup fee, data cap, features list. *Show on website & portal* controls visibility. *Featured* adds the "Most popular" badge.

## Billing
* Invoices are generated automatically before each renewal (Settings → Billing). **Generate due invoices** runs this now.
* **Collect** records cash, bank, bKash/Nagad/Rocket (manual), POS card and similar payments.
* Customers pay online from **Portal → Billing → Pay now**.
* Overdue customers are suspended after the grace period and restored automatically on payment. **Enforce overdue** runs this now.
* **View** opens a printable invoice. Use the browser's *Print → Save as PDF*.

## Support
Customers open tickets from the portal. Staff reply, add **internal notes** (hidden from customers), set status and priority, assign tickets, and can **Request remote support** from a ticket.

## Network
* **Live bandwidth**: real-time throughput per customer (polled every minute).
* **Traffic analysis**: daily volume, peak-hour heatmap, per-plan usage, top consumers.
* **Access control**: block or allow domains or categories for everyone or for one customer, with optional time windows.
* **Device testing**: ping, traceroute, DNS, TCP port tests, run from the server or from a customer's router; device inventory.
* **Remote support**: request a session. The customer approves it in their app, then you can check status, ping, check DNS, verify the speed profile, re-push config or reconnect. Everything is logged.

## Notifications
* **Compose**: send to all customers, by status, plan, area, overdue, or chosen IDs, over any channels.
* **Templates**: edit automatic messages. **Reminders**: when and how reminders go out. **Delivery log**: every attempt and its error.

## CRM & sales
* **Pipeline**: drag leads between stages. Website and chatbot leads arrive automatically. Moving a lead to *Won* records a sale.
* **Campaigns**: multi-channel messages (plus Facebook page posts), scheduled or sent immediately.
* **Sales**: revenue by month and type, staff leaderboard, conversion rate.
* **FAQ & chatbot**: the knowledge base the chatbot answers from. Test it live.

## Field jobs
Create work orders for installations, repairs, surveys and relocations (also straight from a ticket: **Create field job**).
Assign a technician and a time; the technician is notified and sees the job under **Field jobs → My jobs** (staff role
permission *jobs.work*). Statuses: new → scheduled → en route → on site → done/failed. Done and failed need a result note.

## Inventory
Add products (router, ONU, cable…), receive stock into a warehouse (paste serials/MACs, one per line), then issue items to a
customer (assigned / rented / sold) or to a technician, return them, transfer or mark faulty. Every move is kept in
**Movements**. The customer page shows the equipment each customer holds.

## Expenses & profit
Record expenses with category, zone, method and an optional receipt. **Profit & loss** shows collections (completed
payments; prepaid-balance use is not counted twice) minus expenses per month or zone, with CSV export.

## Zones, map, KYC and IP log
* **Zones & areas** group customers and routers by area/POP; assign customers in bulk by area name.
* **Network map** shows customers and sites; use **Location** on a customer page to place them.
* **KYC documents**: staff or the customer (Profile page) upload NID/photo/agreement; verify or reject them in **KYC & IP log**.
  Files are stored privately (never public) and only staff with *kyc.view* or the owner can download them.
* **Session & IP log** records who used which IP and when (every minute). Search by IP and date/time and export CSV for BTRC.

## Website
**Website** in the admin menu previews the public site (desktop / tablet / phone) and **Visit website** opens it.
Branding → *Show in the header, website and emails* chooses logo + name, logo only or name only.

## Customer portal
Overview (live speed gauges, usage, dues), Billing (pay, history), Plans (upgrade with proration or downgrade), Support,
Parental controls (categories, websites, bedtime schedules, safe search), Devices & tests (speed test, approve remote support),
Notifications (enable push), Profile & security (password, 2FA, sessions).

## Updates
**Admin → Updates**: see the installed version, check for updates, install, toggle automatic updates, restore backups.
