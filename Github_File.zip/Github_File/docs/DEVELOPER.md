# Developer Guide

## Architecture

```
web (React SPA) ─┐                       ┌─ routers (MikroTik REST / simulator)
desktop (Electron loads server URL) ─┼─ HTTPS ─ server (Express 5) ─┼─ DB (SQLite | MySQL)
mobile (Capacitor, bundled web) ─┘   JSON + SSE         └─ SMTP · SMS · WhatsApp · FCM · Web Push · bKash · SSLCommerz · Stripe
```

```
server/src
├── index.js            boot: config → db → migrations → seed → app → scheduler
├── app.js              middleware stack and route mounting
├── config.js           .env loading
├── db/                 adapter (index.js), schema.js (versioned migrations), seed.js
├── lib/                crypto, totp, settings (encrypted), notify + channels, events (SSE), audit, catalog
├── middleware/         auth (JWT, permissions, modules), security (helmet, rate limits, CSRF, body guard)
├── billing/            service (invoices, proration, payments, overdue), gateways, invoice-html
├── network/            drivers (vendor adapters), service (sync, polling, aggregation)
├── routes/             one file per module
├── network/ipam.js     IP pools & allocation · network/capacity.js  core capacity & per-customer analysis
├── reports/pdf.js      branded PDF invoices & reports (pdfkit)
├── backup.js           database / UI+DB / full backups, encryption, restore
├── jobs/scheduler.js   cron jobs
└── updater.js          signed self-update
web/src
├── context.jsx         auth, branding, theme, toasts, realtime
├── lib/                api client (token refresh, SSE), platform detection, formatting, push
├── components/         ui kit (Aura), Shell, charts, Chatbot
└── pages/              public · portal · shared · admin
```

## Modules

Each module is defined by:
1. An entry in `server/src/lib/catalog.js` → `MODULES` (on/off switch), `PERMISSIONS` (RBAC) and optionally `WIDGETS`.
2. A route file in `server/src/routes/` guarded with `requireModule('x')` and `requirePerm('x.view')`.
3. Pages in `web/src/pages/...`, linked in `components/Shell.jsx` with `perm` and `module` keys so the nav hides them automatically.

### Adding a new module (example: "inventory")
1. `catalog.js`: add `inventory: { label, description }` to `MODULES` and `inventory: ['inventory.view','inventory.manage']` to `PERMISSIONS`.
2. `db/schema.js`: append a migration `{ id: 3, name: 'inventory', up: (d) => [...] }`. **Never edit applied migrations.**
3. `routes/inventory.js`: a `Router` with `authenticate`, `requireModule('inventory')`, zod `validate()` on every input, and parameterised SQL only.
4. Mount it in `app.js`: `app.use('/api/inventory', inventoryRoutes)`.
5. `web`: create `pages/admin/Inventory.jsx`, add a lazy import and route in `App.jsx` and a nav entry in `Shell.jsx`.
6. Add tests in `server/test/api.test.js`, including access-control tests.

### Rules for changes
* Validate every input with zod. Unknown keys are stripped, which prevents mass assignment.
* Scope customer data with `req.user.customer_id`. Never trust IDs from the client.
* Use `?` placeholders. Never interpolate values into SQL.
* Encrypt new secrets in settings: keys matching `pass|secret|token|apikey|...` are encrypted and masked automatically.
* Request handlers send notifications with `queueNotify()` (non-blocking). Jobs may `await notify()`.
* Call `audit(req, 'module.action', entity, id, meta)` for security-relevant actions.

### Adding a router vendor
Implement the driver interface in `network/drivers.js` (`test`, `applyBandwidth`, `setEnabled`, `kick`, `stats`, `ping`,
`traceroute`, `syncSiteRules`, `applyParental`), register it in `getDriver()`, and add it to the driver enum in `routes/network.js`
and to the router form. RADIUS CoA, Cisco, Huawei, OLT and TR-069 ACS integrations all fit this interface.

### Adding a payment gateway
Implement `init(payment, ctx) → { redirectUrl }` and a server-side verification in `billing/gateways.js`, add return/webhook routes
in `routes/billing.js` that verify with the gateway, then call `completePayment(id, { gatewayAmountCents })`. Add its settings
schema in `routes/settings.js` and UI in `Settings.jsx`.

### Adding a notification channel
Add a sender in `lib/channels.js`, a branch in `lib/notify.js`, the channel name in `catalog.js` `CHANNELS`, settings, and `ChannelPicker` in `Notify.jsx`.

## API overview
All endpoints are under `/api`. Auth is `Authorization: Bearer <accessToken>`.

| Prefix | Purpose |
|---|---|
| `/auth` | register, login, login/mfa, refresh, logout, me, verify/:channel, password/*, 2fa/*, sessions |
| `/public` | config, plans, faqs, contact, coverage, chatbot |
| `/portal` | overview, usage, plans, plans/change, parental, devices, speedtest-result, remote-sessions |
| `/customers` | CRUD, bandwidth, status, reconnect, usage, pppoe-password |
| `/plans` | CRUD |
| `/billing` | invoices, pay, record-payment, void, payments, summary, gateways, run/:job, return/*, webhooks/* |
| `/tickets` | list, create, get, messages, patch |
| `/notifications` | mine, read, stream (SSE), push/*, templates, reminders, send, log, test |
| `/network` | routers, live, poll, traffic, site-rules, customers/:id/parental, diagnostics, devices, remote-sessions |
| `/network/ipam` | summary, pools (CRUD, apply), addresses (list, patch), assign, release, reconcile |
| `/network` (core) | capacity, upstream-links, routers/fingerprint, routers/:id/discover, routers/:id/import, routers/:id/pin, customers/:id/provision |
| `/pdf` | invoices/:id, reports/customer, reports/accounts, reports/sales, reports/overall (`from`, `to`, `customer_id`) |
| `/backups` | list, create, settings, :id/download, :id/restore, :id (delete), upload |
| `/crm` | leads, campaigns, sales, faqs |
| `/staff` | users, roles, catalog |
| `/settings` | get, put/:group, reset, upload |
| `/dashboard`, `/updates`, `/audit`, `/health`, `/speedtest/*` | system |

Lists accept `page`, `pageSize` (max 200) and `sort` (`col` or `-col`, allow-listed). Errors are returned as `{ error, details? }`.

## Theming
Aura theme tokens live in `web/src/styles.css` (`:root` for light, `[data-theme=dark]` for dark). Brand colours
`--brand-1/2/3` are injected from Settings → Branding at runtime. Animations use framer-motion and respect `prefers-reduced-motion`.

## Running tests
`cd server && npm test` runs unit and integration tests on a throwaway SQLite DB. `node test/smoke.mjs [url]` runs a live end-to-end check.
