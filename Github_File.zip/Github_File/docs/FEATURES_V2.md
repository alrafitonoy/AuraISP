# Live chat, enforcement, invoicing rules, bills, profile pictures, apps

## Live chat with human agents (CRM)
* In the website/app chatbot, visitors and customers tap **Talk to a human** (or the person icon). Guests enter a name and a phone number or email; signed-in customers are recognised automatically.
* Agents with the **chat.handle** permission (Support Agent and Sales Executive roles by default) work in **Admin → Live chat**:
  * a realtime inbox (Open / Waiting / Mine / Closed) with unread counts and push alerts
  * **Join** or reply (replying joins automatically), and **End**
  * **Create lead**: turns a visitor into a CRM lead (source *chatbot*) assigned to the agent
  * **Create ticket**: for signed-in customers, copies the transcript into a support ticket
  * customer details (plan, status, area) alongside the conversation
* Security: each guest conversation is protected by a random token (stored hashed), messages are rate-limited, and there's a honeypot field against bots.
* Toggle the feature with Settings → Modules → **Live chat**.

## Strict bandwidth & data enforcement
No customer can use more speed or data than their package or the limit you set (Settings → **Enforcement**).
* **Hard speed cap**: router queues use `max-limit` with burst disabled.
* **Speed watchdog** (every minute): anyone measured above their limit (beyond a small tolerance) gets the limit re-applied immediately. The violation is logged in the audit log and counted on the customer page.
* **Data caps** (set per plan): when the monthly allowance is used up, the customer is **throttled** (default 512 Kbps) or **paused** until next month, and notified. The allowance renews automatically on the 1st.

## Subscription stop rules & manual override
Settings → **Billing** → *Subscription stop rules*. Service is suspended automatically only when **all** of these hold, after the grace period:
* at least N overdue invoices
* at least X overdue amount
* a warning has been sent N days before suspension

You can also set **auto-terminate** after N days overdue (off by default).
* Paying all overdue invoices **restores service automatically**, but only for suspensions caused by non-payment.
* **Manual override** (customer page → *Billing rules & manual override*): keep a customer connected despite overdue invoices, until a date or indefinitely. A reason is required and recorded in the audit log, and the customer can be reactivated at the same time.
* Manual suspend and activate always win. A suspension made by staff is never lifted automatically.

## Bills: View · Print · PDF
Every bill shows **View** (opens it), **Print** (opens the print dialog; choose a printer or *Save as PDF*) and **PDF** (a branded A4 PDF). They appear for customers (Portal → Billing) and staff (Billing, and the customer page). On phones the buttons collapse to icons.

## Profile pictures
Everyone (customers, staff, admins) can upload a picture in **Profile & security** (PNG/JPG/WEBP, max 1 MB). Content is checked, so SVG and fake images are rejected. Pictures appear in the sidebar, support tickets and live chat.

## Apps
* **Desktop (Windows/macOS/Linux)**: for **admins and staff only**. Customer logins are refused. Windows installer: `desktop/release/AuraISP-Console-Setup-1.0.0.exe`.
* **Mobile (Android & iOS)**: for **customers only**. Staff and admin logins are refused by the server. Built by GitHub Actions (`.github/workflows/mobile.yml`); see [DESKTOP_MOBILE.md](DESKTOP_MOBILE.md).

## Developer credit
A credit line, **"Developed by: S.K.M. AL RAFI"**, sits at the bottom of every page (website, portal, admin, apps and installer). It scrolls with the page rather than staying fixed. Clicking it opens the developer's contact details.
