# Security

## Measures in place

| Threat | Control |
|---|---|
| Password theft / cracking | Argon2id (19 MiB memory, 2 iterations; OWASP parameters), unique salts, one-way. Policy: length ≥10 (configurable), mixed case + digit, common-password block. |
| Credential stuffing / brute force | Per-account lockout (configurable; applies to passwords **and** 2FA codes), per-IP rate limits on auth/OTP/registration, constant-time responses for unknown accounts |
| Account takeover | TOTP 2FA (RFC 6238) with replay protection, 10 single-use HMAC-hashed backup codes, optional mandatory 2FA for staff, email and phone verification |
| Session hijacking | 15-minute JWT access tokens in memory only (never in localStorage or URLs); rotating refresh tokens in an httpOnly, Secure, SameSite=Strict cookie (web) or app-private storage (mobile); token-reuse detection revokes the whole session family; password change and disabling a user revoke all sessions |
| CSRF | Bearer-token API; cookie endpoints require SameSite=Strict **and** a custom `X-Requested-With` header |
| XSS | React auto-escaping, no `dangerouslySetInnerHTML`, HTML-escaped email and invoice templates, strict CSP (`script-src 'self'`, `object-src 'none'`, `frame-ancestors 'none'`), SVG uploads rejected, uploads served with `CSP: default-src 'none'` + `nosniff` |
| SQL injection | 100% parameterised queries; identifiers whitelisted in code; sort columns mapped through allow-lists |
| Command injection | No shell use with user input; diagnostics run through the router API with strict hostname regex; updater uses `execFile` with fixed arguments |
| Mass assignment / prototype pollution | zod schemas strip unknown keys; `__proto__`/`constructor` keys rejected anywhere in a body; 1 MB body limit |
| IDOR / broken access control | Every customer query is scoped to `req.user.customer_id`; staff routes check granular permissions; non-admin managers cannot grant permissions they lack, edit their own role, or create admins; the last admin cannot be removed |
| Payment fraud | Payments are confirmed **server-to-server** with the gateway (Stripe session lookup + HMAC webhook, SSLCommerz validation API, bKash execute). Amount and currency are checked; completion is idempotent; gateway refs are unique; overpayment is blocked. |
| Secret exposure | Router passwords, API keys, SMTP passwords, TOTP seeds and PPPoE passwords are AES-256-GCM encrypted with an HKDF-derived key; secrets are masked in the admin UI; credentials are never placed in in-app notifications |
| Supply-chain / update tampering | Self-updates require an Ed25519 signature, stable tags only, safe tar extraction (no `..`, absolute paths, `.env` or `data/`); backups enable rollback; CI runs `npm audit` |
| DoS | Global and per-route rate limits, capped SSE streams per user, request/header timeouts, bounded pagination, size limits on every input |
| Clickjacking / transport | `frame-ancestors 'none'`, X-Frame-Options, HSTS in production, Referrer-Policy, COOP/CORP |
| Accountability | Audit log of logins, failures, lockouts, token reuse, settings changes, payments, role changes, remote-support actions, PPPoE password reveals |
| Remote support abuse | Sessions require explicit customer approval in their app; every action is recorded and visible to the customer |
| Router transport | HTTPS to routers; self-signed certificates are **pinned** by SHA-256 fingerprint. The TLS handshake and pin check finish *before* any credentials are sent, and a mismatch aborts the connection. Verification is never simply disabled. |
| Backups | Optional scrypt + AES-256-GCM encryption; `.env` can only be included with a passphrase; SHA-256 verified before restore; automatic safety backup; path-traversal-safe extraction; password re-confirmation for download, restore and delete; restore is admin-only |
| Reports | Business reports need `reports.view`; customers can only get their own invoices and statement; every report download is audited |
| Database | Least-privilege app user (own database only, no admin/FILE/DROP); installer refuses superusers; TLS with full certificate verification for remote databases; bound parameters everywhere; MySQL `multipleStatements=false` + strict mode + statement timeout; PostgreSQL statement/idle timeouts; SQLite file `0600` |
| Load balancer | Login/OTP/registration limits shared across all nodes; cluster-wide locks for backups, restores, updates and migrations; single leader-elected scheduler |
| Installer | Runs only while not installed; every call needs a one-time token from the server console/file; disables itself permanently after install |
| Live chat | Per-conversation random token (stored hashed), rate limits, honeypot, agents need `chat.handle` |
| Usage enforcement | Hard router speed caps (no burst), minute-by-minute speed watchdog with audit log, monthly data caps (throttle/suspend) |
| Desktop app | `contextIsolation`, `sandbox`, no Node integration, navigation locked to the configured server, permissions denied by default, webviews blocked |

## Security testing performed

`server/test/api.test.js` contains automated attack tests that run in CI:

* Account enumeration (identical errors), lockout after failures, desktop refusing customers
* 2FA: TOTP replay rejected, backup codes single-use
* Refresh token: anti-CSRF header required, rotation, reuse after logout revokes the family
* RBAC matrix for customer, support and admin; privilege escalation by a staff manager (4 vectors) blocked
* IDOR on invoices, invoice HTML, payments and tickets across customers; internal notes hidden from customers
* SQL injection in search and sort parameters; shell metacharacters in diagnostics; prototype pollution; malformed or oversized JSON
* Mass assignment (`type: admin` ignored); SVG upload rejected; secrets masked and encrypted at rest
* Stripe webhook forged signature rejected; payment amount mismatch rejected; idempotent completion
* Security headers present; `X-Powered-By` removed

**Manual review findings fixed during development:** concurrent-refresh false positives, staff privilege escalation via role
assignment, 2FA brute force across many IPs, unvalidated staff parental-control input reaching router rules, temporary passwords
stored in in-app notifications, OTP codes logged outside development, slow providers blocking requests, invoice/ticket number races,
SSLCommerz currency not checked, unbounded SSE streams, unthrottled registration and speed-test endpoints, and two vulnerable
dependencies (nodemailer, zod), which were upgraded. `npm audit`: **0 vulnerabilities**.

**Second review round (v1.1):**
* **Vulnerable dependencies fixed** across all four packages:
  * web: Vite → 8, React Router → 7
  * desktop: Electron → 45, electron-builder → 26, minimatch pinned
  * mobile: Capacitor → 8, which fixes a critical `tar` issue
* The router "verify TLS = off" option was replaced with certificate pinning.
* An uncaught JSON parse error in the router client could crash the process; it is now handled.
* `npm audit` reports **0 vulnerabilities in server, web, desktop and mobile**.

**Dynamic scanning:** `hawk` (StackHawk HawkScan) is installed but needs credentials. Run `hawk init --browser` or set
`HAWK_API_KEY`, then scan the running app. Also run an external penetration test before going live.

## Known trade-offs / your responsibilities

* **Registration reveals whether an email exists** (409). This is accepted for usability; login and password reset do not reveal it.
* **Staff diagnostics** (ping, traceroute, TCP port) can reach internal hosts by design. Grant `network.diagnostics` only to trusted staff.
* **Admins configure outbound URLs** (SMS gateway, router hosts). Protect admin accounts with 2FA.
* **Restoring an uploaded "entire system" backup replaces server code.** That is the purpose of the feature, so it is limited to administrators and needs password confirmation. Only restore backups you created.
* **Imported PPPoE customers** get a placeholder `@imported.invalid` email and an unusable random password until you add their real contact details.
* **Traffic categories** in Traffic analysis are *estimated* until you integrate DNS logs or NetFlow.
* **Mobile refresh tokens** use Capacitor Preferences (app-private storage). For higher assurance, swap in a Keychain/Keystore plugin.
* **Lockout can be triggered by an attacker** against a known email (temporary, configurable duration).

## Hardening checklist before going live

- [ ] HTTPS everywhere; `NODE_ENV=production`; `TRUST_PROXY` set correctly
- [ ] Back up `.env` (APP_KEY) offline; DB backups scheduled and restore-tested
- [ ] Enable **mandatory staff 2FA**; change the setup password; give each staff member their own account
- [ ] Remove demo data; delete unused roles
- [ ] Restrict MikroTik `www-ssl` to the AuraISP IP; dedicated API user with limited policy
- [ ] Payment gateways in live mode only after sandbox tests; Stripe webhook secret set
- [ ] `UPDATE_PUBLIC_KEY` set (otherwise self-update refuses to run)
- [ ] OS firewall exposes only 80/443; automatic OS security updates on
- [ ] Review the audit log weekly; run `npm audit` with each release
- [ ] Run a DAST scan (HawkScan) and an external pentest

## Reporting vulnerabilities
Email security@your-domain with details. Please do not open public issues for security bugs.
