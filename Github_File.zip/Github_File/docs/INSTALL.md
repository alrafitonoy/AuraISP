# Install AuraISP from the browser

You need: **Node.js 20+** (22.13+ if you want SQLite) and one of the databases in [DATABASES.md](DATABASES.md).
The installer package `AuraISP_Installer.zip` already contains the built web app and all server dependencies, so there's no build step.

## 1. Upload and start

### Shared hosting (cPanel)
1. **File Manager** → upload `AuraISP_Installer.zip` to your home folder → **Extract** (you get a folder `AuraISP`).
2. **MySQL® Databases** (recommended on shared hosting) → create a database (e.g. `cpuser_aura`) and a user with a strong password → **Add user to database** → tick **ALL PRIVILEGES** on that database only.
3. **Setup Node.js App** → **Create application**:
   * Node.js version: 22 (or newest)
   * Application root: `AuraISP/server`
   * Application URL: your domain or subdomain
   * Application startup file: `app.cjs`
4. Click **Create**, then **Start**.

### VPS / cloud server (Ubuntu example)
```bash
sudo apt install -y unzip nodejs npm mariadb-server      # or postgresql
unzip AuraISP_Installer.zip -d /opt && cd /opt/AuraISP/server
sudo npm i -g pm2 && pm2 start app.cjs --name aura && pm2 save && pm2 startup
```
Put Nginx with HTTPS in front (`deploy/nginx.conf` for one server, `deploy/nginx-loadbalancer.conf` for several).

### Windows / localhost
Extract the zip, open a terminal in `AuraISP\server` and run `node app.cjs`.

## 2. Open the installer
Browse to `https://your-domain/install/` (or `http://localhost:4000/install/`).

**Install token:** the installer only opens with a one-time token that proves you control the server. You'll find it in either place:
* the application log (cPanel → Setup Node.js App → log, or `pm2 logs aura`)
* the file `server/data/install-token.txt` (cPanel File Manager)

## 3. Wizard steps
1. **Verify**: paste the token. The installer checks the Node version, files and permissions, and **analyses your server** (hosting type, CPU, RAM, which database servers are running).
2. **Database**: choose **MySQL / MariaDB**, **PostgreSQL** or **SQLite**. The recommended option for *your* server is highlighted, with the reason; each card lists its pros and requirements.
   * Enter the host, port, database name, user and password (from step 1).
   * Connection security: *this server* (no TLS) or *remote* (TLS with full certificate verification; paste the CA certificate if it's private).
   * Optional **"Create the database and user for me"**: give the database admin login once. It's used to create a **limited** user (only its own database, no admin rights) and is never stored. On shared hosting, leave it unticked.
   * Click **Test connection**. The installer refuses database superusers for the application.
3. **Site & admin**: site URL, company name, currency, timezone, **load balancing** (1 process, or one per CPU core), and your administrator account.
4. **Install**: tables, default plans, roles and templates are created, `server/.env` is written (with a fresh encryption key), and the app starts immediately. The installer then **disables itself permanently**.

## 4. After installing
* Sign in at `/login`, enable **two-factor authentication** (Profile & security), then configure Settings → SMTP, payments and routers.
* **Back up `server/.env`**: it holds the master key (`APP_KEY`) that decrypts stored secrets.
* If you chose more than one worker, restart the app once (cPanel **Restart** or `pm2 restart aura`) to start the load-balanced workers.
* Schedule backups: Admin → Backups.

## Reinstalling
Delete `server/.env` and `server/data/installed.lock`, then restart. The installer appears again with a new token.
Your existing database is reused, and existing tables are kept.

## Command-line alternative
```bash
cd server && npm run setup -- --email you@example.com --db-host localhost --db-name aura_isp --db-user aura_app --db-password '...'
```
Set `DB_CLIENT=mysql|postgres|sqlite` in `.env` first.
