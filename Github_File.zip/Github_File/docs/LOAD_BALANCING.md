# Load balancing & heavy load

AuraISP scales on two levels. Both need **MySQL/MariaDB or PostgreSQL**; SQLite always runs as one process.

## 1. Built-in load balancer (one server, all CPU cores)
Set `WEB_CONCURRENCY=max` in `server/.env` (or choose "one per CPU core" in the installer) and restart.
* A primary process starts one **worker per CPU core** and spreads connections across them.
* A crashed worker is restarted automatically (with back-off if it keeps crashing).
* After an update or restore, workers are replaced **one at a time** (rolling restart), so the site stays up.

## 2. Several servers behind a load balancer
Run AuraISP on 2+ servers with the **same database** and the **same `server/.env`** (same `APP_KEY`), then put
Nginx/HAProxy/a cloud load balancer in front. See `deploy/nginx-loadbalancer.conf` (least-connections, health checks
with automatic failover, per-IP rate limits, SSE support). `docker-compose.yml` runs MariaDB plus **3 app replicas** plus Nginx.

No sticky sessions are needed. Everything that must be shared is coordinated through the database:

| Concern | How it works across processes/servers |
|---|---|
| Sign-in sessions | Stateless JWT + refresh tokens stored in the database |
| Login / OTP / registration rate limits | Shared counters in the database, so attackers can't multiply attempts by hitting other nodes |
| Realtime notifications, live bandwidth, live chat | PostgreSQL LISTEN/NOTIFY, or a polled event table on MySQL/MariaDB |
| Scheduled jobs (billing, reminders, enforcement, backups) | **Leader election**: exactly one process holds a database lock (PostgreSQL advisory lock / MySQL `GET_LOCK`). If it dies, another takes over within about 20 seconds |
| Backups, restores, updates, migrations | Cluster-wide database locks, so they never run twice at once |

Put `server/data` (uploads and backups) on shared storage (NFS/EFS), or serve `/uploads` from one node.

## Measured performance (local test, 4 workers, MariaDB 11.4, 100 concurrent connections)
| Scenario | Requests/s | p50 | p99 | Errors |
|---|---|---|---|---|
| Public plans (website) | ~10,500 | 9 ms | 23 ms | 0 |
| Customer portal overview | ~2,450 | 72 ms | 83 ms | 0 |
| Customer invoices | ~6,900 | 13 ms | 34 ms | 0 |
| Admin customer search | ~1,850 | 53 ms | 65 ms | 0 |
| Admin dashboard (heavy) | ~1,130 | 9 ms | 183 ms | 0 |

Reproduce with `node test/load.mjs http://localhost:4000 10 100` and `node test/cluster.mjs`.
Raise `RATE_LIMIT_GLOBAL` for load tests (all traffic comes from one IP).

## Tuning
* `DB_POOL_MAX` (default 15) × workers × servers must stay below the database's `max_connections`.
* Keep `TRUST_PROXY=1` behind a proxy so rate limits see real client IPs.
* For very large ISPs: use PostgreSQL, a dedicated database server, and 2+ app servers.
