// AuraISP Console — Electron shell for administrators & staff.
// It loads the web app from YOUR server (so it is always in sync with the server version) and adds:
// native window, tray-less menu, desktop notifications, secure navigation rules and signed auto-updates.
const { app, BrowserWindow, Menu, shell, ipcMain, session, dialog, Notification } = require('electron');
const path = require('node:path');
const fs = require('node:fs');

const CONFIG = () => path.join(app.getPath('userData'), 'config.json');
const readConfig = () => { try { return JSON.parse(fs.readFileSync(CONFIG(), 'utf8')); } catch { return {}; } };
const writeConfig = (c) => fs.writeFileSync(CONFIG(), JSON.stringify(c, null, 2));

let win;
let serverOrigin = null;

function secureWebPreferences() {
  return {
    preload: path.join(__dirname, 'preload.js'),
    contextIsolation: true,
    sandbox: true,
    nodeIntegration: false,
    webSecurity: true,
    allowRunningInsecureContent: false,
    spellcheck: true,
  };
}

function loadApp() {
  const { server } = readConfig();
  if (!server) {
    serverOrigin = null;
    win.loadFile(path.join(__dirname, 'setup.html'));
    return;
  }
  serverOrigin = new URL(server).origin;
  win.loadURL(`${serverOrigin}/login`);
}

function createWindow() {
  win = new BrowserWindow({
    width: 1440, height: 900, minWidth: 1024, minHeight: 680,
    backgroundColor: '#07061a', title: 'AuraISP Console', show: false,
    // App icons for installers live in desktop/build/ (icon.ico / icon.icns / icon.png) — see docs/DESKTOP_MOBILE.md
    webPreferences: secureWebPreferences(),
  });
  win.once('ready-to-show', () => win.show());
  win.webContents.setUserAgent(`${win.webContents.getUserAgent()} AuraISP-Desktop/${app.getVersion()}`);

  // Only the configured server (or the local setup page) may be displayed inside the app.
  win.webContents.on('will-navigate', (e, url) => {
    const u = new URL(url);
    if (u.protocol === 'file:' && !serverOrigin) return;
    if (serverOrigin && u.origin === serverOrigin) return;
    e.preventDefault();
    if (u.protocol === 'https:') shell.openExternal(url);
  });
  // New windows: allow same-origin blob: invoices; everything else opens in the system browser.
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('blob:') && serverOrigin && url.startsWith(`blob:${serverOrigin}`)) {
      return { action: 'allow', overrideBrowserWindowOptions: { webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false } } };
    }
    if (/^https:\/\//.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  loadApp();
}

function buildMenu() {
  const template = [
    ...(process.platform === 'darwin' ? [{ role: 'appMenu' }] : []),
    {
      label: 'File',
      submenu: [
        { label: 'Change server…', click: () => { writeConfig({ ...readConfig(), server: '' }); loadApp(); } },
        { label: 'Check for updates', click: () => checkUpdates(true) },
        { type: 'separator' },
        process.platform === 'darwin' ? { role: 'close' } : { role: 'quit' },
      ],
    },
    { role: 'editMenu' },
    {
      label: 'View',
      submenu: [
        { role: 'reload' }, { role: 'forceReload' }, { type: 'separator' },
        { role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { type: 'separator' }, { role: 'togglefullscreen' },
        ...(app.isPackaged ? [] : [{ role: 'toggleDevTools' }]),
      ],
    },
    { role: 'windowMenu' },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// Signed auto-updates from GitHub Releases — stable channel only (no pre-releases).
function checkUpdates(manual = false) {
  if (!app.isPackaged) { if (manual) dialog.showMessageBox(win, { message: 'Updates are only available in installed builds.' }); return; }
  const { autoUpdater } = require('electron-updater');
  autoUpdater.allowPrerelease = false;
  autoUpdater.allowDowngrade = false;
  autoUpdater.autoInstallOnAppQuit = true;
  autoUpdater.once('update-downloaded', (info) => {
    dialog.showMessageBox(win, { type: 'info', buttons: ['Restart now', 'Later'], message: `AuraISP Console ${info.version} is ready to install.` })
      .then(({ response }) => response === 0 && autoUpdater.quitAndInstall());
  });
  if (manual) autoUpdater.once('update-not-available', () => dialog.showMessageBox(win, { message: 'You have the latest version.' }));
  autoUpdater.checkForUpdatesAndNotify().catch(() => {});
}

ipcMain.handle('aura:set-server', async (_e, url) => {
  try {
    const u = new URL(String(url));
    const local = /^(localhost|127\.0\.0\.1|\[::1\]|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(u.hostname);
    if (u.protocol !== 'https:' && !(u.protocol === 'http:' && local)) return { ok: false, error: 'Use an https:// address (http is allowed only on a local network)' };
    const res = await fetch(`${u.origin}/api/health`, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return { ok: false, error: `Server responded with ${res.status}` };
    writeConfig({ ...readConfig(), server: u.origin });
    loadApp();
    return { ok: true };
  } catch (e) { return { ok: false, error: e.message || 'Could not reach the server' }; }
});
ipcMain.handle('aura:change-server', () => { writeConfig({ ...readConfig(), server: '' }); loadApp(); });
ipcMain.handle('aura:notify', (_e, { title, body }) => { if (Notification.isSupported()) new Notification({ title: String(title).slice(0, 120), body: String(body).slice(0, 300) }).show(); });

app.whenReady().then(() => {
  // Deny every permission except notifications and clipboard writes.
  session.defaultSession.setPermissionRequestHandler((_wc, permission, cb) => cb(['notifications', 'clipboard-sanitized-write'].includes(permission)));
  app.setAppUserModelId('com.auraisp.console');
  buildMenu();
  createWindow();
  setTimeout(() => checkUpdates(false), 10_000);
  app.on('activate', () => BrowserWindow.getAllWindows().length === 0 && createWindow());
});

// Block any attempt to attach webviews.
app.on('web-contents-created', (_e, contents) => contents.on('will-attach-webview', (ev) => ev.preventDefault()));
app.on('window-all-closed', () => process.platform !== 'darwin' && app.quit());
