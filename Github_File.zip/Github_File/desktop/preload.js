// Minimal, explicit bridge — the web app never gets Node.js access.
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('auraDesktop', {
  isDesktop: true,
  setServer: (url) => ipcRenderer.invoke('aura:set-server', String(url)),
  changeServer: () => ipcRenderer.invoke('aura:change-server'),
  notify: (title, body) => ipcRenderer.invoke('aura:notify', { title, body }),
});
