document.getElementById('f').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const b = document.getElementById('b');
  const e = document.getElementById('e');
  b.disabled = true;
  e.textContent = '';
  const r = await window.auraDesktop.setServer(document.getElementById('u').value.trim());
  if (!r.ok) { e.textContent = r.error; b.disabled = false; }
});
