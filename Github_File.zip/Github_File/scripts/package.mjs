#!/usr/bin/env node
// Builds the two deliverables into ./dist-packages:
//   Github_File.zip         — source code for GitHub (no secrets, local data, node_modules or build output)
//   AuraISP_Installer.zip   — ready-to-upload package: built web app + production server dependencies + browser installer
// Usage: node scripts/package.mjs
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = path.join(root, 'dist-packages');
const win = process.platform === 'win32';
const run = (cmd, args, cwd = root) => execFileSync(cmd, args, { cwd, stdio: 'inherit', shell: win && /^(npm|npx)$/.test(cmd) });
const log = (m) => console.log(`\n▶ ${m}`);

// Files that must never ship (defence in depth on top of .gitignore).
const FORBIDDEN = [/(^|\/)\.env($|\.)(?!example)/, /\.env$/,/(^|\/)server\/data\//, /(^|\/)node_modules\//, /\.pem$/, /\.db(-wal|-shm)?$/, /(^|\/)release\//, /^dist-packages\//, /^\.claude\//, /^AI Prompts\.docx$/];

function zipDir(srcDir, entries, zipFile) {
  fs.rmSync(zipFile, { force: true });
  // Windows' own bsdtar writes .zip by extension (Git-for-Windows' GNU tar on PATH cannot).
  if (win) run(path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe'), ['-a', '-c', '-f', zipFile, ...entries], srcDir);
  else run('zip', ['-qr', zipFile, ...entries], srcDir);
}

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });

// ---------------------------------------------------------------- 1) build the web app
log('Building web app');
run('npm', ['run', 'build'], path.join(root, 'web'));

// ---------------------------------------------------------------- 2) Github_File.zip
log('Collecting source files for GitHub');
const files = execFileSync('git', ['ls-files', '--cached', '--others', '--exclude-standard'], { cwd: root, encoding: 'utf8' })
  .split('\n').map((f) => f.trim()).filter(Boolean)
  .filter((f) => fs.existsSync(path.join(root, f)) && !FORBIDDEN.some((re) => re.test(f)));
const listFile = path.join(out, 'github-files.txt');
fs.writeFileSync(listFile, files.join('\n'));
const ghStage = path.join(out, 'Github_File');
for (const f of files) {
  const dest = path.join(ghStage, f);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.copyFileSync(path.join(root, f), dest);
}
zipDir(out, ['Github_File'], path.join(out, 'Github_File.zip'));
fs.rmSync(ghStage, { recursive: true, force: true });
console.log(`  ${files.length} files → dist-packages/Github_File.zip`);

// ---------------------------------------------------------------- 3) AuraISP_Installer.zip
log('Assembling installer package');
const stage = path.join(out, 'AuraISP');
const copy = (rel, to = rel) => {
  const src = path.join(root, rel);
  if (!fs.existsSync(src)) return;
  fs.cpSync(src, path.join(stage, to), { recursive: true, filter: (p) => !FORBIDDEN.some((re) => re.test(path.relative(root, p).replace(/\\/g, '/'))) });
};
for (const p of ['server/src', 'server/scripts', 'server/installer', 'server/package.json', 'server/package-lock.json', 'server/app.cjs', 'server/.env.example', 'web/dist', 'deploy', 'docs', 'README.md', 'Dockerfile', 'docker-compose.yml']) copy(p);
// Hosts that deploy only the server folder (Hostinger "Root directory: AuraISP/server") need the UI inside it too.
copy('web/dist', 'server/public');
fs.mkdirSync(path.join(stage, 'server', 'data'), { recursive: true });
fs.writeFileSync(path.join(stage, 'server', 'data', '.keep'), '');
fs.writeFileSync(path.join(stage, 'INSTALL.txt'), [
  'AuraISP — installation',
  '======================',
  '1. Upload this folder to your server (cPanel: File Manager → upload the zip → Extract).',
  '2. Create a database (MySQL/MariaDB recommended on shared hosting; PostgreSQL or SQLite also supported).',
  '3. Start the app:  cPanel → Setup Node.js App → root: AuraISP/server, startup file: app.cjs → Start',
  '                   VPS: cd AuraISP/server && pm2 start app.cjs --name aura      (or: node app.cjs)',
  '4. Open https://your-domain/install/ in a browser and follow the wizard.',
  '   The install token is in the app log and in server/data/install-token.txt',
  '',
  'Requirements: Node.js 20+ (22.13+ for SQLite). Full guide: docs/INSTALL.md — database guide: docs/DATABASES.md',
  '',
  'Developed by: S.K.M. AL RAFI — +880 1717-151255 — alrafitonoy@gmail.com',
  '',
].join('\n'));
const guard = () => {
  const walkFiles = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? (e.name === 'node_modules' ? [] : walkFiles(path.join(d, e.name))) : [path.join(d, e.name)]));
  const found = walkFiles(stage).map((f) => path.relative(stage, f).replace(/\\/g, '/')).filter((f) => /\.env$|\.pem$|\.db$|install-token|installed\.lock/.test(f));
  if (found.length) { console.error('Refusing to package secrets/local data:', found); process.exit(1); }
};
guard();
// Slim package for hosts that run "npm install" themselves (Hostinger, Render...): no node_modules, small upload.
zipDir(out, ['AuraISP'], path.join(out, 'AuraISP_Hostinger.zip'));
log('Installing production dependencies (portable: no native modules)');
run('npm', ['ci', '--omit=dev', '--no-audit', '--no-fund', '--ignore-scripts'], path.join(stage, 'server'));
// Final guard: nothing forbidden may be in the package (except the server's own node_modules).
const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? (e.name === 'node_modules' ? [] : walk(path.join(d, e.name))) : [path.join(d, e.name)]));
const bad = walk(stage).map((f) => path.relative(stage, f).replace(/\\/g, '/')).filter((f) => /\.env$|\.pem$|\.db$|install-token|installed\.lock/.test(f));
if (bad.length) { console.error('Refusing to package secrets/local data:', bad); process.exit(1); }
zipDir(out, ['AuraISP'], path.join(out, 'AuraISP_Installer.zip'));
fs.rmSync(stage, { recursive: true, force: true });
fs.rmSync(listFile, { force: true });

for (const z of ['Github_File.zip', 'AuraISP_Installer.zip', 'AuraISP_Hostinger.zip']) {
  console.log(`  ${z}: ${(fs.statSync(path.join(out, z)).size / 1024 / 1024).toFixed(1)} MB`);
}
console.log('\n✔ Packages ready in dist-packages/');
