import { assertConfig } from '../src/config.js';
import { initDb, db } from '../src/db/index.js';
import { migrate } from '../src/db/migrate.js';
import { seedDefaults } from '../src/db/seed.js';

assertConfig();
await initDb();
await migrate();
await seedDefaults();
await db().close();
console.log('Migrations complete');
