#!/usr/bin/env node
// Release signing (run by maintainers / CI, never on customer servers).
//   node scripts/sign-release.js keygen                 -> prints a new Ed25519 key pair
//   node scripts/sign-release.js sign <file.tar.gz>      -> writes <file>.sig using RELEASE_PRIVATE_KEY env var
import fs from 'node:fs';
import crypto from 'node:crypto';

const [cmd, file] = process.argv.slice(2);
if (cmd === 'keygen') {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  console.log('# Put this in every installation\'s .env as UPDATE_PUBLIC_KEY (keep \\n escapes):');
  console.log(`UPDATE_PUBLIC_KEY="${publicKey.export({ type: 'spki', format: 'pem' }).replace(/\n/g, '\\n')}"`);
  console.log('\n# Store this ONLY as the GitHub Actions secret RELEASE_PRIVATE_KEY:');
  console.log(privateKey.export({ type: 'pkcs8', format: 'pem' }));
} else if (cmd === 'sign' && file) {
  const pem = (process.env.RELEASE_PRIVATE_KEY || '').replace(/\\n/g, '\n');
  if (!pem) { console.error('RELEASE_PRIVATE_KEY not set'); process.exit(1); }
  const sig = crypto.sign(null, fs.readFileSync(file), crypto.createPrivateKey(pem)).toString('base64');
  fs.writeFileSync(`${file}.sig`, sig);
  console.log(`Signed ${file}`);
} else {
  console.log('Usage: sign-release.js keygen | sign <file>');
  process.exit(1);
}
