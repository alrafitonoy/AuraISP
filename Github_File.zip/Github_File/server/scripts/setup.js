#!/usr/bin/env node
// Command-line setup (alternative to the browser installer at /install):
// creates .env (APP_KEY, VAPID keys, PostgreSQL settings), runs migrations, seeds defaults and creates the first admin.
// Usage:  npm run setup -- --email admin@example.com [--password 'S3cure-Pass'] [--name 'Admin']
//                          [--db-host localhost --db-port 5432 --db-name aura_isp --db-user aura_app --db-password '...' --db-ssl disable|verify-full]
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const envPath = path.join(root, '.env');
const args = Object.fromEntries(process.argv.slice(2).reduce((acc, a, i, arr) => (a.startsWith('--') ? [...acc, [a.slice(2), arr[i + 1] && !arr[i + 1].startsWith('--') ? arr[i + 1] : 'true']] : acc), []));

if (!fs.existsSync(envPath)) {
  const webpush = (await import('web-push')).default;
  const vapid = webpush.generateVAPIDKeys();
  const example = fs.readFileSync(path.join(root, '.env.example'), 'utf8');
  const env = example
    .replace(/^APP_KEY=.*$/m, `APP_KEY=${crypto.randomBytes(32).toString('base64')}`)
    .replace(/^VAPID_PUBLIC_KEY=.*$/m, `VAPID_PUBLIC_KEY=${vapid.publicKey}`)
    .replace(/^VAPID_PRIVATE_KEY=.*$/m, `VAPID_PRIVATE_KEY=${vapid.privateKey}`);
  let out = env;
  for (const [flag, key] of [['db-host', 'DB_HOST'], ['db-port', 'DB_PORT'], ['db-name', 'DB_NAME'], ['db-user', 'DB_USER'], ['db-password', 'DB_PASSWORD'], ['db-ssl', 'DB_SSL'], ['db-ssl-ca', 'DB_SSL_CA']]) {
    if (args[flag]) out = out.replace(new RegExp(`^${key}=.*$`, 'm'), `${key}=${args[flag]}`);
  }
  fs.writeFileSync(envPath, out, { mode: 0o600 });
  console.log('✔ Created .env with a fresh APP_KEY and VAPID keys. BACK UP THIS FILE — encrypted secrets depend on APP_KEY.');
} else {
  console.log('• .env already exists — keeping it');
}

const { default: config, assertConfig } = await import('../src/config.js');
assertConfig();
if (!config.db.password) { console.error('✖ Set DB_PASSWORD (and other DB_* values) in server/.env or pass --db-password, then run setup again.'); process.exit(1); }
const { initDb, db, insert, now } = await import('../src/db/index.js');
const { migrate } = await import('../src/db/migrate.js');
const { seedDefaults } = await import('../src/db/seed.js');
const { hashPassword, randomToken } = await import('../src/lib/crypto.js');

await initDb();
await migrate();
await seedDefaults();
console.log(`✔ Database ready (${config.db.client}, ${config.db.user}@${config.db.host}/${config.db.database}, ssl=${config.db.ssl})`);
fs.mkdirSync(config.dataDir, { recursive: true });
fs.writeFileSync(path.join(config.dataDir, 'installed.lock'), new Date().toISOString());

const existing = await db().get("SELECT id, email FROM users WHERE type = 'admin' LIMIT 1");
if (existing) {
  console.log(`• Administrator already exists (${existing.email})`);
} else {
  const email = (args.email || process.env.ADMIN_EMAIL || 'admin@example.com').toLowerCase();
  const password = args.password || process.env.ADMIN_PASSWORD || `${randomToken(12)}Aa1`;
  const role = await db().get("SELECT id FROM roles WHERE slug = 'admin'");
  await insert('users', { type: 'admin', role_id: role.id, name: args.name || 'Administrator', email, password_hash: await hashPassword(password), status: 'active', email_verified_at: now(), created_at: now(), updated_at: now() });
  console.log('\n✔ Administrator created');
  console.log(`   Email:    ${email}`);
  if (!args.password && !process.env.ADMIN_PASSWORD) console.log(`   Password: ${password}   <-- shown ONCE, change it after first login`);
}
await db().close();
console.log('\nDone. Start the server with: npm start');
