// Demo data: a simulator router, 40 customers, invoices, payments, tickets, leads and 7 days of usage.
// NEVER run on production. Usage: npm run seed:demo
import { assertConfig } from '../src/config.js';
import { initDb, db, insert, now } from '../src/db/index.js';
import { migrate } from '../src/db/migrate.js';
import { seedDefaults } from '../src/db/seed.js';
import { hashPassword } from '../src/lib/crypto.js';
import { createInvoice, addCycle } from '../src/billing/service.js';
import { aggregateDaily } from '../src/network/service.js';

assertConfig();
await initDb();
await migrate();
await seedDefaults();

if (await db().get("SELECT id FROM customers WHERE code = 'C900001'")) {
  console.log('Demo data already present');
  process.exit(0);
}

const first = ['Rahim', 'Karim', 'Nusrat', 'Farhana', 'Tanvir', 'Sadia', 'Arif', 'Mitu', 'Rakib', 'Jannat', 'Imran', 'Shila', 'Fahim', 'Ritu', 'Nayeem', 'Sumaiya', 'Hasan', 'Tania', 'Sabbir', 'Lamia'];
const last = ['Ahmed', 'Hossain', 'Rahman', 'Islam', 'Chowdhury', 'Khan', 'Akter', 'Uddin', 'Sarker', 'Haque'];
const areas = ['Gulshan', 'Banani', 'Bashundhara R/A', 'Uttara', 'Dhanmondi', 'Mirpur'];
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const ts = now();

const router = await insert('routers', { name: 'Core-Sim-01', driver: 'simulator', host: 'virtual', location: 'Dhaka POP', status: 'online', created_at: ts });
const plans = await db().all('SELECT * FROM plans ORDER BY price_cents');
const role = await db().get("SELECT id FROM roles WHERE slug = 'customer'");
const pw = await hashPassword('Customer#2026');

// Staff samples
for (const [slug, name, email] of [['support', 'Sumon Support', 'support@demo.local'], ['billing', 'Bina Billing', 'billing@demo.local'], ['network', 'Nabil Network', 'noc@demo.local']]) {
  const r = await db().get('SELECT id FROM roles WHERE slug = ?', [slug]);
  if (!(await db().get('SELECT id FROM users WHERE email = ?', [email]))) {
    await insert('users', { type: 'staff', role_id: r.id, name, email, password_hash: await hashPassword('Staff#2026demo'), status: 'active', email_verified_at: ts, created_at: ts, updated_at: ts });
  }
}

for (let i = 1; i <= 40; i++) {
  const name = `${pick(first)} ${pick(last)}`;
  const email = i === 1 ? 'customer@demo.local' : `customer${i}@demo.local`;
  const created = new Date(Date.now() - Math.floor(Math.random() * 300) * 86400000).toISOString();
  const u = await insert('users', { type: 'customer', role_id: role.id, name: i === 1 ? 'Demo Customer' : name, email, phone: `+8801${7 + (i % 3)}${String(10000000 + i * 7919).slice(0, 8)}`, password_hash: pw, status: 'active', email_verified_at: ts, created_at: created, updated_at: ts });
  const plan = plans[i % plans.length];
  const status = i % 13 === 0 ? 'suspended' : i % 17 === 0 ? 'pending' : 'active';
  const c = await insert('customers', {
    user_id: u.id, code: `C${900000 + i}`, address: `House ${i}, Road ${(i % 20) + 1}`, area: pick(areas), connection_type: 'pppoe',
    pppoe_username: `user${900000 + i}`, ip_address: `10.20.${Math.floor(i / 250)}.${(i % 250) + 2}`, router_id: router.id, plan_id: plan.id, status,
    billing_day: (i % 28) + 1, next_due_date: addCycle(new Date(), 'monthly').toISOString(), created_at: created, updated_at: ts,
  });
  // 3 months of invoices
  for (let m = 3; m >= 1; m--) {
    const start = new Date(); start.setUTCMonth(start.getUTCMonth() - m);
    const inv = await createInvoice({ customerId: c.id, items: [{ description: `${plan.name} monthly`, quantity: 1, unit_cents: plan.price_cents }], periodStart: start.toISOString(), periodEnd: addCycle(start, 'monthly').toISOString(), dueDate: start.toISOString() });
    await db().run('UPDATE invoices SET issued_at = ?, created_at = ? WHERE id = ?', [start.toISOString(), start.toISOString(), inv.id]);
    const paid = !(status === 'suspended' && m === 1) && Math.random() > 0.08;
    if (paid) {
      const at = new Date(start.getTime() + Math.random() * 5 * 86400000).toISOString();
      await insert('payments', { invoice_id: inv.id, customer_id: c.id, amount_cents: inv.total_cents, currency: 'BDT', method: pick(['bkash', 'sslcommerz', 'cash', 'bkash', 'stripe']), gateway_ref: `DEMO-${inv.id}`, status: 'success', created_at: at, completed_at: at });
      await db().run("UPDATE invoices SET paid_cents = total_cents, status = 'paid', paid_at = ? WHERE id = ?", [at, inv.id]);
    } else {
      await db().run("UPDATE invoices SET status = 'overdue' WHERE id = ?", [inv.id]);
    }
  }
  await insert('sales', { customer_id: c.id, plan_id: plan.id, kind: 'new', amount_cents: plan.price_cents, created_at: created });
  if (i % 4 === 0) {
    const t = await insert('tickets', { number: `T-${String(900000 + i)}`, customer_id: c.id, created_by: u.id, subject: pick(['Slow speed in the evening', 'Connection drops', 'Billing question', 'Router setup help', 'Upgrade request']), category: pick(['speed', 'connection', 'billing', 'technical']), priority: pick(['low', 'normal', 'high', 'urgent']), status: pick(['open', 'in_progress', 'awaiting_customer', 'resolved']), created_at: ts, updated_at: ts });
    await insert('ticket_messages', { ticket_id: t.id, user_id: u.id, body: 'Hi, could you please check my connection? Thanks.', internal: 0, created_at: ts });
  }
  // 7 days of hourly usage samples
  let rx = Math.random() * 1e10, tx = rx / 6;
  for (let h = 24 * 7; h >= 0; h--) {
    const t = new Date(Date.now() - h * 3600000);
    const hourFactor = [0.2, 0.1, 0.05, 0.05, 0.05, 0.1, 0.2, 0.3, 0.35, 0.4, 0.4, 0.45, 0.5, 0.5, 0.45, 0.5, 0.55, 0.65, 0.8, 0.95, 1, 0.95, 0.7, 0.4][t.getUTCHours()];
    const rbps = Math.round(plan.download_kbps * 1000 * hourFactor * (0.3 + Math.random() * 0.6));
    const tbps = Math.round(rbps / 5);
    rx += (rbps / 8) * 3600; tx += (tbps / 8) * 3600;
    await insert('usage_samples', { customer_id: c.id, ts: t.toISOString(), rx_bytes: Math.round(rx), tx_bytes: Math.round(tx), rx_bps: rbps, tx_bps: tbps });
  }
}

for (let d = 7; d >= 0; d--) await aggregateDaily(new Date(Date.now() - d * 86400000).toISOString().slice(0, 10));

for (const [name, status, src] of [['Sharif Uddin', 'new', 'website'], ['Mahi Akter', 'contacted', 'facebook'], ['Rafiq Islam', 'qualified', 'referral'], ['Joya Rahman', 'proposal', 'whatsapp'], ['Kamal Hossain', 'won', 'walk_in'], ['Popy Khan', 'lost', 'phone']]) {
  await insert('leads', { name, phone: '+8801700000000', source: src, status, plan_id: pick(plans).id, value_cents: pick(plans).price_cents, created_at: ts, updated_at: ts });
}
await insert('devices', { customer_id: 1, name: 'Home router', kind: 'router', ip_address: '10.20.0.3', model: 'TP-Link Archer C6', firmware: '1.3.2', status: 'online', created_at: ts });

await db().close();
console.log('✔ Demo data created.');
console.log('  Customer login: customer@demo.local / Customer#2026');
console.log('  Staff logins:   support@demo.local, billing@demo.local, noc@demo.local / Staff#2026demo');
