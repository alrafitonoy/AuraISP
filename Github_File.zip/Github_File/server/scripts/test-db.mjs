// Run the test suite against one or more databases: node scripts/test-db.mjs mysql postgres sqlite
import { spawnSync } from 'node:child_process';
const targets = process.argv.slice(2).length ? process.argv.slice(2) : ['mysql'];
let failed = false;
for (const t of targets) {
  console.log(`\n===== tests on ${t} =====`);
  const r = spawnSync(process.execPath, ['--test', '--test-concurrency=1', 'test/unit.test.js', 'test/api.test.js', 'test/features.test.js', 'test/round3.test.js', 'test/round5.test.js', 'test/round6.test.js', 'test/inventory.test.js', 'test/jobs.test.js', 'test/finance.test.js', 'test/ops.test.js'], { stdio: 'inherit', env: { ...process.env, TEST_DB_CLIENT: t } });
  if (r.status !== 0) failed = true;
}
process.exit(failed ? 1 : 0);
