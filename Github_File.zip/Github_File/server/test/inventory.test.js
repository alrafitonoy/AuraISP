// Inventory & equipment: catalogue, warehouses, receiving (serialised + bulk), every item transition, stock
// overview / low-stock, movements, customer equipment and access control.
import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { call, login, close, PASSWORDS, db } from './helpers.js';
import { normMac } from '../src/routes/inventory.js';

after(close);
const A = (await login('admin@test.local', PASSWORDS.admin)).accessToken;
const S = (await login('support@test.local', PASSWORDS.staff)).accessToken; // support role: no inventory permissions
const C = (await login('c1@test.local', PASSWORDS.customer)).accessToken;
const ok = (res, code = 200) => { assert.equal(res.status, code, JSON.stringify(res.body)); return res.body; };
const adminId = (await db().get("SELECT id FROM users WHERE email = 'admin@test.local'")).id;
const ctx = {};

test('normMac normalises and rejects', () => {
  assert.equal(normMac('aa-bb-cc-dd-ee-ff'), 'AA:BB:CC:DD:EE:FF');
  assert.equal(normMac('aabb.ccdd.eeff'), 'AA:BB:CC:DD:EE:FF');
  assert.equal(normMac('zz:bb:cc:dd:ee:ff'), null);
  assert.equal(normMac('aa:bb:cc'), null);
});

test('access control: customers and staff without inventory permissions are refused', async () => {
  for (const tok of [C, S]) {
    assert.equal((await call('GET', '/api/inventory/stock', { token: tok })).status, 403);
    assert.equal((await call('POST', '/api/inventory/products', { token: tok, body: { name: 'X router' } })).status, 403);
    assert.equal((await call('GET', '/api/inventory/customers/1/equipment', { token: tok })).status, 403);
  }
  assert.equal((await call('GET', '/api/inventory/summary')).status, 401);
});

test('products and warehouses CRUD with validation', async () => {
  ctx.router = ok(await call('POST', '/api/inventory/products', { token: A, body: { name: 'TP-Link Archer C6', sku: 'TPL-C6', category: 'router', buy_cents: 250000, sell_cents: 320000, rent_cents: 15000, min_stock: 5 } }), 201).id;
  ctx.cable = ok(await call('POST', '/api/inventory/products', { token: A, body: { name: 'Drop cable 2-core', sku: 'CAB-2C', category: 'cable', unit: 'm', track_serial: false, buy_cents: 1200, min_stock: 100 } }), 201).id;
  assert.equal((await call('POST', '/api/inventory/products', { token: A, body: { name: 'Dup', sku: 'tpl-c6' } })).status, 409, 'SKU unique (case-insensitive)');
  assert.equal((await call('POST', '/api/inventory/products', { token: A, body: { name: 'Bad', category: 'spaceship' } })).status, 400);
  assert.equal((await call('POST', '/api/inventory/products', { token: A, body: { name: 'B', buy_cents: -5 } })).status, 400);
  ok(await call('PUT', `/api/inventory/products/${ctx.router}`, { token: A, body: { sell_cents: 330000 } }));
  ctx.main = ok(await call('POST', '/api/inventory/warehouses', { token: A, body: { name: 'Main store', address: 'Banani' } }), 201).id;
  ctx.van = ok(await call('POST', '/api/inventory/warehouses', { token: A, body: { name: 'North POP' } }), 201).id;
  assert.equal((await call('POST', '/api/inventory/warehouses', { token: A, body: { name: 'Z', zone_id: 99999 } })).status, 400);
  const tmp = ok(await call('POST', '/api/inventory/warehouses', { token: A, body: { name: 'Temp store' } }), 201).id;
  ok(await call('DELETE', `/api/inventory/warehouses/${tmp}`, { token: A }));
  const lk = ok(await call('GET', '/api/inventory/lookups', { token: A }));
  assert.equal(lk.products.length, 2);
  assert.equal(lk.warehouses.length, 2);
});

test('receive serialised stock: duplicates refused, MACs normalised', async () => {
  const units = [{ serial: 'SN001', mac: 'aa:bb:cc:00:00:01' }, { serial: 'SN002' }, { serial: 'SN003' }, { serial: 'SN004' }];
  const out = ok(await call('POST', '/api/inventory/receive', { token: A, body: { product_id: ctx.router, warehouse_id: ctx.main, unit_cost_cents: 240000, units } }), 201);
  assert.equal(out.received, 4);
  ctx.units = out.ids;
  const mac = await db().get('SELECT mac FROM inv_items WHERE serial = ?', ['SN001']);
  assert.equal(mac.mac, 'AA:BB:CC:00:00:01');
  // Existing serial (any case) refuses the whole batch.
  const dup = await call('POST', '/api/inventory/receive', { token: A, body: { product_id: ctx.router, warehouse_id: ctx.main, units: [{ serial: 'SN005' }, { serial: 'sn001' }] } });
  assert.equal(dup.status, 400);
  assert.match(dup.body.error, /SN001/);
  assert.equal(await db().get("SELECT id FROM inv_items WHERE serial = 'SN005'"), undefined, 'nothing saved');
  assert.equal((await call('POST', '/api/inventory/receive', { token: A, body: { product_id: ctx.router, warehouse_id: ctx.main, units: [{ serial: 'X1' }, { serial: 'x1' }] } })).status, 400, 'repeat in list');
  assert.equal((await call('POST', '/api/inventory/receive', { token: A, body: { product_id: ctx.router, warehouse_id: ctx.main, units: [{ serial: 'X2', mac: 'AA:BB:CC:00:00:01' }] } })).status, 400, 'duplicate MAC');
  assert.equal((await call('POST', '/api/inventory/receive', { token: A, body: { product_id: ctx.router, warehouse_id: ctx.main, units: [{ serial: 'X3', mac: 'nope' }] } })).status, 400, 'bad MAC');
  assert.equal((await call('POST', '/api/inventory/receive', { token: A, body: { product_id: ctx.router, warehouse_id: ctx.main, qty: 5 } })).status, 400, 'serial product needs serials');
  assert.equal((await call('POST', '/api/inventory/receive', { token: A, body: { product_id: ctx.router, warehouse_id: 99999, units: [{ serial: 'X4' }] } })).status, 400);
  // Serial tracking is locked once there is stock.
  assert.equal((await call('PUT', `/api/inventory/products/${ctx.router}`, { token: A, body: { track_serial: false } })).status, 400);
  assert.equal((await call('DELETE', `/api/inventory/products/${ctx.router}`, { token: A })).status, 400, 'product with stock cannot be deleted');
});

test('receive bulk stock and the stock overview / low-stock flag', async () => {
  const out = ok(await call('POST', '/api/inventory/receive', { token: A, body: { product_id: ctx.cable, warehouse_id: ctx.main, qty: 300, unit_cost_cents: 1000 } }), 201);
  ctx.lot = out.ids[0];
  assert.equal((await call('POST', '/api/inventory/receive', { token: A, body: { product_id: ctx.cable, warehouse_id: ctx.main } })).status, 400, 'qty required');
  const st = ok(await call('GET', '/api/inventory/stock', { token: A }));
  const router = st.products.find((p) => p.id === ctx.router);
  const cable = st.products.find((p) => p.id === ctx.cable);
  assert.equal(router.in_stock, 4);
  assert.equal(router.low, true, '4 < min 5');
  assert.equal(router.value_cents, 4 * 240000);
  assert.equal(cable.in_stock, 300);
  assert.equal(cable.low, false);
  assert.equal(cable.warehouses[0].warehouse_id, ctx.main);
  assert.equal(st.totals.value_cents, 4 * 240000 + 300 * 1000);
  const low = ok(await call('GET', '/api/inventory/stock?low=1', { token: A }));
  assert.deepEqual(low.products.map((p) => p.id), [ctx.router]);
});

test('serialised item lifecycle: issue, impossible transitions, return, faulty, transfer, write-off', async () => {
  const [u1, u2, u3, u4] = ctx.units;
  // Assign to a customer (rented).
  ok(await call('POST', `/api/inventory/items/${u1}/issue`, { token: A, body: { customer_id: 1, mode: 'rented', note: 'install' } }));
  let it = await db().get('SELECT * FROM inv_items WHERE id = ?', [u1]);
  assert.deepEqual([it.status, it.customer_id, it.warehouse_id], ['rented', 1, null]);
  // Assigning again is impossible: not in stock.
  const again = await call('POST', `/api/inventory/items/${u1}/issue`, { token: A, body: { customer_id: 2 } });
  assert.equal(again.status, 400);
  assert.match(again.body.error, /rented/);
  assert.equal((await call('POST', `/api/inventory/items/${u1}/transfer`, { token: A, body: { warehouse_id: ctx.van } })).status, 400);
  assert.equal((await call('POST', `/api/inventory/items/${u2}/issue`, { token: A, body: { customer_id: 99999 } })).status, 400, 'unknown customer');
  assert.equal((await call('POST', `/api/inventory/items/${u2}/issue`, { token: A, body: { customer_id: 1, qty: 2 } })).status, 400, 'serial qty must be 1');
  assert.equal((await call('POST', `/api/inventory/items/${u2}/return`, { token: A, body: { warehouse_id: ctx.main } })).status, 400, 'in-stock item cannot be returned');
  assert.equal((await call('POST', '/api/inventory/items/999999/issue', { token: A, body: { customer_id: 1 } })).status, 404);

  // Customer equipment.
  const eq = ok(await call('GET', '/api/inventory/customers/1/equipment', { token: A }));
  assert.equal(eq.items.length, 1);
  assert.equal(eq.items[0].serial, 'SN001');
  assert.equal(eq.customer.name, 'Customer 1');
  assert.equal(eq.monthly_rent_cents, 15000);
  assert.equal((await call('GET', '/api/inventory/customers/99999/equipment', { token: A })).status, 404);

  // Return faulty from the customer into the second warehouse, then repair it back into stock.
  ok(await call('POST', `/api/inventory/items/${u1}/return`, { token: A, body: { warehouse_id: ctx.van, condition: 'faulty' } }));
  it = await db().get('SELECT * FROM inv_items WHERE id = ?', [u1]);
  assert.deepEqual([it.status, it.customer_id, it.warehouse_id], ['faulty', null, ctx.van]);
  assert.equal(ok(await call('GET', '/api/inventory/customers/1/equipment', { token: A })).items.length, 0);
  ok(await call('POST', `/api/inventory/items/${u1}/return`, { token: A, body: { warehouse_id: ctx.main } }));
  assert.equal((await db().get('SELECT status FROM inv_items WHERE id = ?', [u1])).status, 'in_stock');

  // Staff (technician) issue, then install at a customer straight from the van.
  ok(await call('POST', `/api/inventory/items/${u2}/issue-staff`, { token: A, body: { staff_id: adminId } }));
  assert.equal((await call('POST', `/api/inventory/items/${u2}/issue-staff`, { token: A, body: { staff_id: adminId } })).status, 400);
  const cust = (await db().get("SELECT id FROM users WHERE email = 'c1@test.local'")).id;
  assert.equal((await call('POST', `/api/inventory/items/${u3}/issue-staff`, { token: A, body: { staff_id: cust } })).status, 400, 'customer is not staff');
  ok(await call('POST', `/api/inventory/items/${u2}/issue`, { token: A, body: { customer_id: 2, mode: 'sold' } }));
  assert.equal((await call('POST', `/api/inventory/items/${u2}/return`, { token: A, body: { warehouse_id: ctx.main } })).status, 400, 'sold items are customer-owned');

  // Faulty → transfer → write-off.
  ok(await call('POST', `/api/inventory/items/${u3}/faulty`, { token: A, body: { note: 'no power' } }));
  assert.equal((await call('POST', `/api/inventory/items/${u3}/issue`, { token: A, body: { customer_id: 1 } })).status, 400, 'faulty cannot be issued');
  ok(await call('POST', `/api/inventory/items/${u3}/transfer`, { token: A, body: { warehouse_id: ctx.van } }));
  assert.equal((await call('POST', `/api/inventory/items/${u3}/transfer`, { token: A, body: { warehouse_id: ctx.van } })).status, 400, 'same warehouse');
  ok(await call('POST', `/api/inventory/items/${u3}/write-off`, { token: A, body: { note: 'scrapped' } }));
  assert.equal((await call('POST', `/api/inventory/items/${u3}/write-off`, { token: A, body: {} })).status, 400);

  // Issue by product + serial.
  ok(await call('POST', '/api/inventory/issue', { token: A, body: { product_id: ctx.router, serial: 'sn004', customer_id: 1 } }));
  assert.equal((await db().get('SELECT status FROM inv_items WHERE id = ?', [u4])).status, 'assigned');
  assert.equal((await call('POST', '/api/inventory/issue', { token: A, body: { product_id: ctx.router, serial: 'NOPE', customer_id: 1 } })).status, 400);
  assert.equal((await call('POST', '/api/inventory/issue', { token: A, body: { product_id: ctx.router, serial: 'SN001', customer_id: 1, staff_id: adminId } })).status, 400, 'customer XOR staff');

  // Item edit: duplicate serial refused.
  assert.equal((await call('PUT', `/api/inventory/items/${u1}`, { token: A, body: { serial: 'SN002' } })).status, 409);
  ok(await call('PUT', `/api/inventory/items/${u1}`, { token: A, body: { notes: 'Refurbished' } }));

  // Movement history for the first unit.
  const mv = ok(await call('GET', `/api/inventory/movements?item_id=${u1}`, { token: A }));
  assert.deepEqual(mv.rows.map((m) => m.type).reverse(), ['receive', 'issue', 'return', 'return', 'edit']);
  const byCust = ok(await call('GET', '/api/inventory/movements?customer_id=1&type=issue', { token: A }));
  assert.ok(byCust.rows.length >= 2);
});

test('bulk lots split on partial issue / return / transfer', async () => {
  ok(await call('POST', `/api/inventory/items/${ctx.lot}/issue`, { token: A, body: { customer_id: 1, qty: 40 } }));
  let lot = await db().get('SELECT qty, status FROM inv_items WHERE id = ?', [ctx.lot]);
  assert.deepEqual([Number(lot.qty), lot.status], [260, 'in_stock']);
  const atCust = await db().get("SELECT id, qty, cost_cents FROM inv_items WHERE product_id = ? AND customer_id = 1 AND status = 'assigned'", [ctx.cable]);
  assert.deepEqual([Number(atCust.qty), Number(atCust.cost_cents)], [40, 1000]);
  assert.equal((await call('POST', `/api/inventory/items/${ctx.lot}/issue`, { token: A, body: { customer_id: 1, qty: 1000 } })).status, 400, 'more than the lot');
  // Partial return of 10 m.
  ok(await call('POST', `/api/inventory/items/${atCust.id}/return`, { token: A, body: { warehouse_id: ctx.main, qty: 10 } }));
  assert.equal(Number((await db().get('SELECT qty FROM inv_items WHERE id = ?', [atCust.id])).qty), 30);
  // Partial transfer.
  ok(await call('POST', `/api/inventory/items/${ctx.lot}/transfer`, { token: A, body: { warehouse_id: ctx.van, qty: 60 } }));
  // Issue by product draws FIFO across lots in one warehouse (260-60 = 200 in lot + 10 returned = 210 in Main).
  const many = ok(await call('POST', '/api/inventory/issue', { token: A, body: { product_id: ctx.cable, warehouse_id: ctx.main, qty: 205, customer_id: 2 } }));
  assert.equal(many.item_ids.length, 2, 'split across two lots');
  assert.equal((await call('POST', '/api/inventory/issue', { token: A, body: { product_id: ctx.cable, warehouse_id: ctx.main, qty: 6, customer_id: 2 } })).status, 400, 'only 5 left');
  assert.equal((await call('POST', '/api/inventory/issue', { token: A, body: { product_id: ctx.cable, qty: 1, customer_id: 2 } })).status, 400, 'warehouse required');
  const st = ok(await call('GET', '/api/inventory/stock', { token: A }));
  const cable = st.products.find((p) => p.id === ctx.cable);
  assert.equal(cable.in_stock, 65);
  assert.equal(cable.deployed, 235);
  assert.equal(cable.low, true);
  const wq = Object.fromEntries(cable.warehouses.map((w) => [w.warehouse_id, w.qty]));
  assert.deepEqual(wq, { [ctx.main]: 5, [ctx.van]: 60 });
  // Warehouse holding stock cannot be deleted.
  assert.equal((await call('DELETE', `/api/inventory/warehouses/${ctx.van}`, { token: A })).status, 400);
});

test('item list filters + pagination, summary', async () => {
  const all = ok(await call('GET', '/api/inventory/items?pageSize=2', { token: A }));
  assert.equal(all.rows.length, 2);
  assert.ok(all.total > 2);
  const rented = ok(await call('GET', `/api/inventory/items?product_id=${ctx.router}&status=in_stock&warehouse_id=`, { token: A }));
  assert.deepEqual(rented.rows.map((x) => x.serial), ['SN001']);
  const search = ok(await call('GET', '/api/inventory/items?q=Customer%202', { token: A }));
  assert.ok(search.rows.length >= 2 && search.rows.every((x) => x.customer_id === 2));
  const mac = ok(await call('GET', '/api/inventory/items?q=00:00:01', { token: A }));
  assert.equal(mac.rows[0].serial, 'SN001');
  assert.equal((await call('GET', '/api/inventory/items?status=flying', { token: A })).status, 400);
  const sum = ok(await call('GET', '/api/inventory/summary', { token: A }));
  assert.equal(sum.low_stock_count, 2);
  assert.equal(sum.items_deployed, 1 + 235, 'SN004 assigned + cable at customers');
  assert.equal(sum.sold, 1);
  assert.equal(sum.stock_value_cents, 1 * 240000 + 65 * 1000);
});

test('lookups for pickers and product delete without stock', async () => {
  const c = ok(await call('GET', '/api/inventory/lookup/customers?q=CT2', { token: A }));
  assert.equal(c.rows[0].id, 2);
  const s = ok(await call('GET', '/api/inventory/lookup/staff', { token: A }));
  assert.ok(s.rows.some((x) => x.id === adminId));
  assert.equal((await call('GET', '/api/inventory/lookup/customers?q=CT2', { token: S })).status, 403);
  const p = ok(await call('POST', '/api/inventory/products', { token: A, body: { name: 'Spare SFP', category: 'sfp' } }), 201).id;
  ok(await call('DELETE', `/api/inventory/products/${p}`, { token: A }));
  assert.equal((await call('DELETE', `/api/inventory/products/${p}`, { token: A })).status, 404);
});

test('module switch disables the API', async () => {
  const cur = ok(await call('GET', '/api/settings', { token: A }));
  const mods = cur.modules || cur.settings?.modules;
  if (!mods) return; // settings shape differs: covered by requireModule elsewhere
  ok(await call('PUT', '/api/settings/modules', { token: A, body: { ...mods, inventory: false } }));
  assert.equal((await call('GET', '/api/inventory/summary', { token: A })).status, 404);
  ok(await call('PUT', '/api/settings/modules', { token: A, body: { ...mods, inventory: true } }));
  assert.equal((await call('GET', '/api/inventory/summary', { token: A })).status, 200);
});
