// Load test: node test/load.mjs [baseUrl] [seconds] [connections]
// Logs in as the demo admin/customer, then hammers public, customer and admin endpoints concurrently.
// Run the server with RATE_LIMIT_GLOBAL raised (all load comes from one IP) and WEB_CONCURRENCY=max.
import autocannon from 'autocannon';

const BASE = process.argv[2] || 'http://localhost:4000';
const DURATION = Number(process.argv[3]) || 15;
const CONNECTIONS = Number(process.argv[4]) || 100;
const H = { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' };

async function token(email, password) {
  const r = await fetch(`${BASE}/api/auth/login`, { method: 'POST', headers: H, body: JSON.stringify({ email, password, client: 'native' }) });
  const j = await r.json();
  if (!j.accessToken) throw new Error(`login failed for ${email}: ${JSON.stringify(j)}`);
  return j.accessToken;
}

const admin = await token(process.env.LOAD_ADMIN || 'admin@aura.local', process.env.LOAD_ADMIN_PASSWORD || 'Admin#Aura2026');
const cust = await token(process.env.LOAD_CUSTOMER || 'customer@demo.local', process.env.LOAD_CUSTOMER_PASSWORD || 'Customer#2026');

const scenarios = [
  { name: 'Public plans (website)', requests: [{ method: 'GET', path: '/api/public/plans' }] },
  { name: 'Customer portal overview', requests: [{ method: 'GET', path: '/api/portal/overview', headers: { Authorization: `Bearer ${cust}` } }] },
  { name: 'Customer invoices', requests: [{ method: 'GET', path: '/api/billing/invoices', headers: { Authorization: `Bearer ${cust}` } }] },
  { name: 'Admin customer search', requests: [{ method: 'GET', path: '/api/customers?q=a&pageSize=25', headers: { Authorization: `Bearer ${admin}` } }] },
  { name: 'Admin dashboard (heavy)', requests: [{ method: 'GET', path: '/api/dashboard', headers: { Authorization: `Bearer ${admin}` } }] },
];

let failed = false;
console.log(`Load test ${BASE} — ${DURATION}s per scenario, ${CONNECTIONS} concurrent connections\n`);
console.log('Scenario'.padEnd(30), 'req/s'.padStart(9), 'p50 ms'.padStart(8), 'p99 ms'.padStart(8), 'errors'.padStart(8), 'non-2xx'.padStart(8));
for (const s of scenarios) {
  const r = await autocannon({ url: BASE, connections: CONNECTIONS, duration: DURATION, requests: s.requests, timeout: 20 });
  const non2xx = r.non2xx || 0;
  if (r.errors || non2xx) failed = true;
  console.log(s.name.padEnd(30), String(Math.round(r.requests.average)).padStart(9), String(r.latency.p50).padStart(8), String(r.latency.p99).padStart(8), String(r.errors).padStart(8), String(non2xx).padStart(8));
}
console.log(failed ? '\nSome requests failed — see above.' : '\nAll requests succeeded.');
process.exit(failed ? 1 : 0);
