// Regression tests for the round-5 audit fixes: payment idempotency under concurrency, revenue without prepaid
// double counting, abandoned upgrade quotes, usage after counter resets, portable cascading deletes, password reset.
import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { call, login, close, PASSWORDS, db } from './helpers.js';
import { insert, now } from '../src/db/index.js';

after(close);
const admin = await login('admin@test.local', PASSWORDS.admin);
const A = admin.accessToken;

test('completePayment credits exactly once when webhook and return race', async () => {
  const { completePayment } = await import('../src/billing/service.js');
  const before = Number((await db().get('SELECT balance_cents FROM customers WHERE id = 2')).balance_cents);
  const p = await insert('payments', { customer_id: 2, amount_cents: 500, currency: 'BDT', method: 'stripe', status: 'pending', created_at: now() });
  const results = await Promise.allSettled([completePayment(p.id), completePayment(p.id), completePayment(p.id)]);
  assert.ok(results.every((r) => r.status === 'fulfilled'), 'no call may throw');
  const after = Number((await db().get('SELECT balance_cents FROM customers WHERE id = 2')).balance_cents);
  assert.equal(after - before, 500, 'balance credited once');
  assert.equal((await db().get('SELECT status FROM payments WHERE id = ?', [p.id])).status, 'success');
});

test('prepaid balance applied to an invoice is not counted as revenue again', async () => {
  const s1 = (await call('GET', '/api/billing/summary', { token: A })).body;
  await insert('payments', { customer_id: 2, amount_cents: 700, currency: 'BDT', method: 'balance', status: 'success', created_at: now(), completed_at: now() });
  const s2 = (await call('GET', '/api/billing/summary', { token: A })).body;
  assert.equal(s2.collectedThisMonth, s1.collectedThisMonth);
  assert.ok(!s2.byMethod.some((m) => m.method === 'balance'));
});

test('abandoning an upgrade quote voids its invoice and it never counts towards suspension', async () => {
  const c2 = await login('c2@test.local', PASSWORDS.customer);
  const plans = await db().all('SELECT id, slug FROM plans');
  const id = (slug) => plans.find((p) => p.slug === slug).id;
  const up = await call('POST', '/api/portal/plans/change', { token: c2.accessToken, body: { planId: id('family') } });
  assert.equal(up.status, 200);
  assert.ok(up.body.invoice?.id, 'upgrade creates a quote invoice');
  const quote = up.body.invoice.id;
  // Still open quote past its due date: must not suspend the customer.
  await db().run("UPDATE invoices SET due_date = ?, status = 'overdue' WHERE id = ?", [new Date(Date.now() - 30 * 86400000).toISOString(), quote]);
  await call('PUT', '/api/settings/billing', { token: A, body: { autoSuspend: true, graceDays: 0, suspendMinOverdueInvoices: 1, suspendMinOverdueCents: 0 } });
  const { enforceOverdue } = await import('../src/billing/service.js');
  await enforceOverdue();
  assert.equal((await db().get('SELECT status FROM customers WHERE id = 2')).status, 'active', 'open upgrade quote is not a debt');
  // Choosing another plan instead abandons the quote: its invoice is voided.
  const down = await call('POST', '/api/portal/plans/change', { token: c2.accessToken, body: { planId: id('starter') } });
  assert.equal(down.status, 200);
  assert.equal((await db().get('SELECT status FROM invoices WHERE id = ?', [quote])).status, 'void');
});

test('daily usage survives router counter resets (sum of increases, not max-min)', async () => {
  const { aggregateDaily } = await import('../src/network/service.js');
  const day = '2020-02-03';
  const at = (h) => `${day}T0${h}:00:00.000Z`;
  // Cumulative counter: 1000 → 3000, router reboots (→ 500), then 1500. Real usage = 2000 + 500 + 1000 = 3500.
  for (const [h, bytes] of [[1, 1000], [2, 3000], [3, 500], [4, 1500]]) {
    await insert('usage_samples', { customer_id: 2, ts: at(h), rx_bytes: bytes, tx_bytes: 0, rx_bps: 0, tx_bps: 0 });
  }
  await aggregateDaily(day);
  const row = await db().get("SELECT bytes FROM traffic_daily WHERE customer_id = 2 AND day = ? AND category = 'total'", [day]);
  assert.equal(Number(row.bytes), 3500);
});

test('deleting a pool removes its addresses and deleting a customer frees its IP (any database)', async () => {
  const pool = await call('POST', '/api/network/ipam/pools', { token: A, body: { name: 'T5', kind: 'real', cidr: '198.51.100.0/29', monthly_price_cents: 0 } });
  assert.equal(pool.status, 201);
  // A throwaway customer gets an address from the pool, then is deleted.
  const role = (await db().get("SELECT id FROM roles WHERE slug = 'customer'")).id;
  const u = await insert('users', { type: 'customer', role_id: role, name: 'Temp', email: 'temp5@test.local', password_hash: 'x', status: 'active', created_at: now(), updated_at: now() });
  const c = await insert('customers', { user_id: u.id, code: 'CT5', status: 'active', created_at: now(), updated_at: now() });
  const a = await call('POST', '/api/network/ipam/assign', { token: A, body: { customer_id: c.id, pool_id: pool.body.id } });
  assert.equal(a.status, 200, JSON.stringify(a.body));
  const del = await call('DELETE', `/api/customers/${c.id}?force=true`, { token: A });
  assert.equal(del.status, 200);
  assert.equal(await db().get('SELECT id FROM customers WHERE id = ?', [c.id]), undefined, 'customer row removed');
  const ip = await db().get('SELECT status, customer_id FROM ip_addresses WHERE address = ?', [a.body.address]);
  assert.deepEqual([ip.status, ip.customer_id], ['free', null], 'IP released');
  const gone = await call('DELETE', `/api/network/ipam/pools/${pool.body.id}`, { token: A });
  assert.equal(gone.status, 200);
  assert.equal(Number((await db().get('SELECT COUNT(*) AS n FROM ip_addresses WHERE pool_id = ?', [pool.body.id])).n), 0);
});

test('a weak new password does not burn the reset code', async () => {
  const { codeHash } = await import('../src/lib/crypto.js');
  const u = await db().get("SELECT id FROM users WHERE email = 'c1@test.local'");
  await insert('verification_codes', { user_id: u.id, purpose: 'reset', code_hash: codeHash('123456'), attempts: 0, expires_at: new Date(Date.now() + 600000).toISOString(), created_at: now() });
  const weak = await call('POST', '/api/auth/password/reset', { body: { email: 'c1@test.local', code: '123456', password: 'abcdefghij' } });
  assert.equal(weak.status, 400);
  const ok = await call('POST', '/api/auth/password/reset', { body: { email: 'c1@test.local', code: '123456', password: 'Better#Pass2026' } });
  assert.equal(ok.status, 200, JSON.stringify(ok.body));
  const back = await call('POST', '/api/auth/password/reset', { body: { email: 'c1@test.local', code: '123456', password: PASSWORDS.customer } });
  assert.equal(back.status, 400, 'code is single-use');
  // restore the original password for other test files
  await insert('verification_codes', { user_id: u.id, purpose: 'reset', code_hash: codeHash('654321'), attempts: 0, expires_at: new Date(Date.now() + 600000).toISOString(), created_at: now() });
  assert.equal((await call('POST', '/api/auth/password/reset', { body: { email: 'c1@test.local', code: '654321', password: PASSWORDS.customer } })).status, 200);
});

test('router "test connection" keeps discovered info; unreachable router errors are explained, not 500', async () => {
  const r = await call('POST', '/api/network/routers', { token: A, body: { name: 'Core T5', driver: 'simulator', role: 'core' } });
  assert.equal(r.status, 201);
  assert.equal((await call('POST', `/api/network/routers/${r.body.id}/discover`, { token: A, body: {} })).status, 200);
  await call('POST', `/api/network/routers/${r.body.id}/test`, { token: A, body: {} });
  const info = JSON.parse((await db().get('SELECT info FROM routers WHERE id = ?', [r.body.id])).info);
  assert.ok(info.wanInterface, 'wanInterface survives a connection test');
  const mt = await call('POST', '/api/network/routers', { token: A, body: { name: 'Dead MT', driver: 'mikrotik', host: '127.0.0.1', port: 1, username: 'a', password: 'b', use_tls: false } });
  const d = await call('POST', `/api/network/routers/${mt.body.id}/discover`, { token: A, body: {} });
  assert.equal(d.status, 502);
  assert.match(d.body.error, /Could not reach the router/);
});

test('customers: duplicate PPPoE username refused; editing the name keeps the phone', async () => {
  await db().run("UPDATE customers SET pppoe_username = 'dup-user' WHERE id = 1");
  const dup = await call('POST', '/api/customers', { token: A, body: { name: 'Dup', email: 'dup5@test.local', pppoe_username: 'dup-user' } });
  assert.equal(dup.status, 409);
  const before = (await db().get('SELECT u.phone FROM users u JOIN customers c ON c.user_id = u.id WHERE c.id = 2')).phone;
  assert.equal((await call('PUT', '/api/customers/2', { token: A, body: { name: 'Customer 2 renamed' } })).status, 200);
  const after = await db().get('SELECT u.phone, u.name FROM users u JOIN customers c ON c.user_id = u.id WHERE c.id = 2');
  assert.deepEqual([after.name, after.phone], ['Customer 2 renamed', before]);
});

test('CRM: CSV import (preview, dedupe, aliases, validation) and export round trip', async () => {
  const { BASE } = await import('./helpers.js');
  const csv = '\uFEFFFull name,E-mail,Mobile,Stage,Package,Amount,Notes\r\n'
    + 'Rahim Uddin,rahim.csv@example.com,+8801711111111,new,Home,800,"Wants ""fast"" install, next week"\r\n'
    + 'Karim,karim.csv@example.com,01722222222,qualified,,1200,\r\n'
    + 'Bad Email,not-an-email,,new,,,\r\n'
    + 'Unknown Plan,up.csv@example.com,,new,Nonexistent,,\r\n'
    + 'Rahim again,rahim.csv@example.com,,new,,,\r\n'
    + '=HYPERLINK("evil"),evil.csv@example.com,,new,,,\r\n';
  const send = async (dryRun, onDuplicate = 'skip') => {
    const form = new FormData();
    form.append('file', new Blob([csv], { type: 'text/csv' }), 'leads.csv');
    form.append('dryRun', String(dryRun)); form.append('onDuplicate', onDuplicate);
    const r = await fetch(`${BASE}/api/crm/leads/import`, { method: 'POST', headers: { Authorization: `Bearer ${A}`, 'X-Requested-With': 'XMLHttpRequest' }, body: form });
    return { status: r.status, body: await r.json() };
  };
  const pre = await send(true);
  assert.equal(pre.status, 200, JSON.stringify(pre.body));
  assert.deepEqual([pre.body.created, pre.body.skipped, pre.body.errors.length], [3, 1, 2], JSON.stringify(pre.body));
  assert.equal(Number((await db().get("SELECT COUNT(*) AS n FROM leads WHERE email LIKE '%.csv@example.com'")).n), 0, 'preview saves nothing');
  const run = await send(false);
  assert.equal(run.body.created, 3);
  const rahim = await db().get("SELECT * FROM leads WHERE email = 'rahim.csv@example.com'");
  assert.equal(rahim.notes, 'Wants "fast" install, next week');
  assert.equal(Number(rahim.value_cents), 80000);
  assert.ok(rahim.plan_id, 'plan matched by name');
  const again = await send(false);
  assert.deepEqual([again.body.created, again.body.skipped], [0, 4], 're-import skips existing leads');
  const exp = await fetch(`${BASE}/api/crm/leads/export.csv`, { headers: { Authorization: `Bearer ${A}` } });
  assert.equal(exp.status, 200);
  assert.match(exp.headers.get('content-disposition'), /leads-.*\.csv/);
  const bytes = Buffer.from(await exp.arrayBuffer());
  assert.deepEqual([...bytes.subarray(0, 3)], [0xef, 0xbb, 0xbf], 'UTF-8 BOM so Excel shows Bangla correctly');
  const text = bytes.toString('utf8').slice(1);
  assert.ok(text.startsWith('name,email,phone'), 'header row');
  assert.ok(text.includes('"Wants ""fast"" install, next week"'), 'quotes escaped');
  assert.ok(text.includes("'=HYPERLINK"), 'formula injection neutralised');
  const noFile = await fetch(`${BASE}/api/crm/leads/import`, { method: 'POST', headers: { Authorization: `Bearer ${A}`, 'X-Requested-With': 'XMLHttpRequest' } });
  assert.equal(noFile.status, 400);
});

test('email designs: every design renders, content is escaped, unsafe links are refused, defaults apply', async () => {
  const designs = (await call('GET', '/api/notifications/email-designs', { token: A })).body.designs;
  assert.deepEqual(Object.keys(designs).sort(), ['bold', 'dark', 'minimal', 'modern', 'promo']);
  for (const design of Object.keys(designs)) {
    const r = await call('POST', '/api/notifications/email-preview', { token: A, body: {
      subject: 'Hello {{name}}', body: 'Line one\n\n**Bold** <script>alert(1)</script>',
      email_design: { design, heading: 'Hi {{name}}', buttonText: 'Pay now', buttonUrl: '/portal/billing', badge: '20% OFF', accent: '#ff3366' },
    } });
    assert.equal(r.status, 200, design);
    const html = r.body.html;
    assert.match(html, /^<!doctype html>/i);
    assert.ok(html.includes('Hi Admin'), `${design}: heading variables rendered`);
    assert.ok(!html.includes('<script>'), `${design}: body HTML escaped`);
    assert.ok(html.includes('<strong>Bold</strong>'), `${design}: **bold** supported`);
    assert.ok(/href="http[^"]*\/portal\/billing"/.test(html), `${design}: relative button link made absolute`);
  }
  const bad = await call('POST', '/api/notifications/email-preview', { token: A, body: { email_design: { design: 'modern', buttonUrl: 'javascript:alert(1)' } } });
  assert.equal(bad.status, 400, 'javascript: links rejected');
  // Settings → Email default design is used when nothing else is chosen.
  assert.equal((await call('PUT', '/api/settings/email', { token: A, body: { design: 'dark', footerNote: 'Footer from settings' } })).status, 200);
  const def = await call('POST', '/api/notifications/email-preview', { token: A, body: { subject: 'S', body: 'B' } });
  assert.ok(def.body.html.includes('#07061a') && def.body.html.includes('Footer from settings'), 'default design + footer applied');
  // Campaign and template keep their design.
  const camp = await call('POST', '/api/crm/campaigns', { token: A, body: { name: 'Design camp', channels: ['email'], audience: { type: 'all_customers' }, subject: 'Offer', body: 'Hi', email_design: { design: 'promo', badge: 'NEW' } } });
  assert.equal(camp.status, 201);
  const list = (await call('GET', '/api/crm/campaigns', { token: A })).body.campaigns;
  assert.equal(list.find((c) => c.id === camp.body.id).email_design.design, 'promo');
  const tpl = (await call('GET', '/api/notifications/templates', { token: A })).body.templates[0];
  assert.equal((await call('PUT', `/api/notifications/templates/${tpl.id}`, { token: A, body: { email_design: { design: 'minimal', buttonText: 'Open' } } })).status, 200);
  const again = (await call('GET', '/api/notifications/templates', { token: A })).body.templates.find((t) => t.id === tpl.id);
  assert.equal(again.email_design.design, 'minimal');
});
