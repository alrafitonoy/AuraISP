// Expenses & profit/loss and zones & areas: CRUD, validation, private receipts, P&L maths, zone trees and access control.
import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { call, login, close, PASSWORDS, db, BASE } from './helpers.js';
import config from '../src/config.js';
import { insert, now } from '../src/db/index.js';

after(close);
const A = (await login('admin@test.local', PASSWORDS.admin)).accessToken;
const S = (await login('support@test.local', PASSWORDS.staff)).accessToken; // has customers.view, no finance.* / zones.manage
const C = (await login('c1@test.local', PASSWORDS.customer)).accessToken;

const PNG = Buffer.from('89504e470d0a1a0a0000000d4948445200000001000000010806000000', 'hex');
async function upload(p, buf, { name = 'r.png', type = 'image/png', token = A } = {}) {
  const form = new FormData();
  form.append('file', new Blob([buf], { type }), name);
  const res = await fetch(BASE + p, { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'X-Requested-With': 'XMLHttpRequest' }, body: form });
  return { status: res.status, body: await res.json().catch(() => null) };
}
const month = new Date().toISOString().slice(0, 7);
const today = new Date().toISOString().slice(0, 10);

// ================================================================== finance
test('categories are seeded on first read and can be managed', async () => {
  const list = await call('GET', '/api/finance/categories', { token: A });
  assert.equal(list.status, 200);
  const names = list.body.categories.map((c) => c.name);
  for (const n of ['Bandwidth / IIG', 'Staff salary', 'BTRC & licence fees', 'Other']) assert.ok(names.includes(n), n);
  const again = await call('GET', '/api/finance/categories', { token: A });
  assert.equal(again.body.categories.length, list.body.categories.length, 'seeded once');

  const c = await call('POST', '/api/finance/categories', { token: A, body: { name: 'Pole rent' } });
  assert.equal(c.status, 201);
  assert.equal((await call('POST', '/api/finance/categories', { token: A, body: { name: 'pole RENT' } })).status, 409);
  assert.equal((await call('POST', '/api/finance/categories', { token: A, body: { name: 'x' } })).status, 400);
  assert.equal((await call('PUT', `/api/finance/categories/${c.body.id}`, { token: A, body: { name: 'Pole & duct rent' } })).status, 200);

  const e = await call('POST', '/api/finance/expenses', { token: A, body: { amount_cents: 1000, spent_on: '2024-01-05', category_id: c.body.id } });
  assert.equal(e.status, 201);
  const del = await call('DELETE', `/api/finance/categories/${c.body.id}`, { token: A });
  assert.equal(del.status, 200);
  assert.equal(del.body.uncategorised, 1);
  assert.equal((await db().get('SELECT category_id FROM expenses WHERE id = ?', [e.body.id])).category_id, null, 'expense kept, uncategorised');
  await call('DELETE', `/api/finance/expenses/${e.body.id}`, { token: A });
});

test('expenses: create, validate, filter, totals, update, delete', async () => {
  const cats = (await call('GET', '/api/finance/categories', { token: A })).body.categories;
  const bw = cats.find((c) => c.name === 'Bandwidth / IIG').id;
  const rent = cats.find((c) => c.name === 'Office rent').id;
  const bad = [
    { amount_cents: 0, spent_on: '2025-03-01' }, { amount_cents: 100, spent_on: '2025-02-30' }, { amount_cents: 100, spent_on: '01/03/2025' },
    { amount_cents: 100, spent_on: '2025-03-01', method: 'cheque' }, { amount_cents: 100, spent_on: '2025-03-01', category_id: 999999 },
    { amount_cents: 100, spent_on: '2025-03-01', zone_id: 999999 },
  ];
  for (const body of bad) assert.equal((await call('POST', '/api/finance/expenses', { token: A, body })).status, 400, JSON.stringify(body));

  const ids = [];
  for (const body of [
    { amount_cents: 500000, spent_on: '2025-03-02', category_id: bw, vendor: 'Summit IIG', method: 'bank', reference: 'INV-77' },
    { amount_cents: 200000, spent_on: '2025-03-10', category_id: rent, vendor: 'Landlord', method: 'cash' },
    { amount_cents: 300000, spent_on: '2025-04-01', category_id: bw, vendor: 'Summit IIG', method: 'bkash', notes: 'April upstream' },
  ]) {
    const r = await call('POST', '/api/finance/expenses', { token: A, body });
    assert.equal(r.status, 201); ids.push(r.body.id);
  }
  const march = await call('GET', '/api/finance/expenses?from=2025-03-01&to=2025-03-31', { token: A });
  assert.equal(march.status, 200);
  assert.equal(march.body.total, 2);
  assert.equal(march.body.totals.amount_cents, 700000);
  const byCat = await call('GET', `/api/finance/expenses?from=2025-01-01&to=2025-12-31&category_id=${bw}`, { token: A });
  assert.equal(byCat.body.totals.amount_cents, 800000);
  const search = await call('GET', '/api/finance/expenses?q=upstream', { token: A });
  assert.deepEqual(search.body.rows.map((x) => x.id), [ids[2]]);
  const paged = await call('GET', '/api/finance/expenses?from=2025-01-01&to=2025-12-31&pageSize=1&page=2', { token: A });
  assert.equal(paged.body.rows.length, 1);
  assert.equal(paged.body.totals.count, 3, 'totals cover the whole filtered set, not just the page');
  assert.equal((await call('GET', '/api/finance/expenses?from=2025-05-01&to=2025-01-01', { token: A })).status, 400);

  assert.equal((await call('PUT', `/api/finance/expenses/${ids[1]}`, { token: A, body: { amount_cents: 250000 } })).status, 200);
  assert.equal((await call('GET', `/api/finance/expenses/${ids[1]}`, { token: A })).body.expense.amount_cents, 250000);
  assert.equal((await call('PUT', '/api/finance/expenses/999999', { token: A, body: { amount_cents: 1 } })).status, 404);
  for (const id of ids) assert.equal((await call('DELETE', `/api/finance/expenses/${id}`, { token: A })).status, 200);
});

test('receipts are stored privately, type-checked and streamed only to finance staff', async () => {
  const e = await call('POST', '/api/finance/expenses', { token: A, body: { amount_cents: 1234, spent_on: today, vendor: 'Hardware shop' } });
  const p = `/api/finance/expenses/${e.body.id}/receipt`;
  assert.equal((await upload(p, Buffer.from('<svg onload=alert(1)>'), { name: 'x.svg', type: 'image/svg+xml' })).status, 400, 'svg rejected');
  assert.equal((await upload(p, Buffer.from('not really a png'), { name: 'x.png', type: 'image/png' })).status, 400, 'magic bytes checked');
  assert.equal((await upload(p, Buffer.concat([Buffer.from('%PDF-1.4\n'), Buffer.alloc(5 * 1024 * 1024 + 10)]), { name: 'big.pdf', type: 'application/pdf' })).status, 413);
  assert.equal((await upload(p, PNG, { token: S })).status, 403);
  const ok = await upload(p, PNG);
  assert.equal(ok.status, 201, JSON.stringify(ok.body));

  const row = await db().get('SELECT attachment FROM expenses WHERE id = ?', [e.body.id]);
  const file = path.join(config.dataDir, 'private', 'receipts', row.attachment);
  assert.ok(fs.existsSync(file), 'stored under dataDir/private/receipts');
  assert.ok(!fs.existsSync(path.join(config.uploadsDir, row.attachment)), 'never in the public uploads dir');

  const list = await call('GET', `/api/finance/expenses?q=Hardware`, { token: A });
  assert.equal(list.body.rows[0].has_receipt, true);
  assert.equal(list.body.rows[0].attachment, undefined, 'file name not exposed');

  const dl = await fetch(BASE + p, { headers: { Authorization: `Bearer ${A}` } });
  assert.equal(dl.status, 200);
  assert.match(dl.headers.get('content-disposition'), /^attachment; filename="receipt-\d+\.png"$/);
  assert.equal(dl.headers.get('x-content-type-options'), 'nosniff');
  assert.ok(Buffer.from(await dl.arrayBuffer()).equals(PNG));
  assert.equal((await call('GET', p, { token: S })).status, 403);
  assert.equal((await call('GET', p)).status, 401);

  assert.equal((await call('DELETE', `/api/finance/expenses/${e.body.id}`, { token: A })).status, 200);
  assert.ok(!fs.existsSync(file), 'receipt removed with the expense');
});

test('P&L: income excludes balance payments; expenses, profit, margin, categories and CSV', async () => {
  const cust = await db().get("SELECT id FROM customers WHERE code = 'CT1'");
  const at = '2023-06-15T10:00:00.000Z';
  await insert('payments', { customer_id: cust.id, amount_cents: 100000, currency: 'BDT', method: 'cash', status: 'success', created_at: at, completed_at: at });
  await insert('payments', { customer_id: cust.id, amount_cents: 70000, currency: 'BDT', method: 'balance', status: 'success', created_at: at, completed_at: at });
  await insert('payments', { customer_id: cust.id, amount_cents: 50000, currency: 'BDT', method: 'bkash', status: 'failed', created_at: at, completed_at: at });
  const cats = (await call('GET', '/api/finance/categories', { token: A })).body.categories;
  const salary = cats.find((c) => c.name === 'Staff salary').id;
  await call('POST', '/api/finance/expenses', { token: A, body: { amount_cents: 30000, spent_on: '2023-06-20', category_id: salary } });
  await call('POST', '/api/finance/expenses', { token: A, body: { amount_cents: 150000, spent_on: '2023-07-01' } });

  const r = await call('GET', '/api/finance/pnl?from=2023-06-01&to=2023-07-31&group=month', { token: A });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.deepEqual(r.body.periods.map((p) => p.key), ['2023-06', '2023-07']);
  const [jun, jul] = r.body.periods;
  assert.deepEqual([jun.income_cents, jun.expense_cents, jun.profit_cents, jun.margin], [100000, 30000, 70000, 70]);
  assert.deepEqual([jul.income_cents, jul.expense_cents, jul.profit_cents, jul.margin], [0, 150000, -150000, null]);
  assert.equal(r.body.totals.profit_cents, -80000);
  assert.deepEqual(r.body.by_category.map((c) => [c.name, c.amount_cents]), [['Uncategorised', 150000], ['Staff salary', 30000]]);
  assert.ok(r.body.kpis && typeof r.body.kpis.arpu_cents === 'number');

  const csv = await call('GET', '/api/finance/pnl.csv?from=2023-06-01&to=2023-07-31', { token: A });
  assert.equal(csv.status, 200);
  assert.match(csv.headers.get('content-disposition'), /profit-loss-2023-06-01-to-2023-07-31\.csv/);
  assert.match(csv.body, /2023-06,1000\.00,300\.00,700\.00,70%/);
  assert.match(csv.body, /2023-07,0\.00,1500\.00,\(1500\.00\),/);

  assert.equal((await call('GET', '/api/finance/pnl?from=2023-08-01&to=2023-01-01', { token: A })).status, 400);
  assert.equal((await call('GET', '/api/finance/pnl?group=year', { token: A })).status, 400);
  const def = await call('GET', '/api/finance/pnl', { token: A });
  assert.equal(def.body.periods.length, 12, 'defaults to the last 12 months');
  assert.equal(def.body.periods.at(-1).key, month);
});

test('KPIs: this month income/expense/profit and ARPU', async () => {
  const before = (await call('GET', '/api/finance/kpis', { token: A })).body;
  const cust = await db().get("SELECT id FROM customers WHERE code = 'CT2'");
  await insert('payments', { customer_id: cust.id, amount_cents: 40000, currency: 'BDT', method: 'cash', status: 'success', created_at: now(), completed_at: now() });
  await insert('payments', { customer_id: cust.id, amount_cents: 99999, currency: 'BDT', method: 'balance', status: 'success', created_at: now(), completed_at: now() });
  await call('POST', '/api/finance/expenses', { token: A, body: { amount_cents: 15000, spent_on: today } });
  const k = (await call('GET', '/api/finance/kpis', { token: A })).body;
  assert.equal(k.income_cents - before.income_cents, 40000);
  assert.equal(k.expense_cents - before.expense_cents, 15000);
  assert.equal(k.profit_cents, k.income_cents - k.expense_cents);
  assert.equal(k.arpu_cents, k.active_customers ? Math.round(k.income_cents / k.active_customers) : 0);
});

test('finance access control', async () => {
  for (const [m, p] of [['GET', '/api/finance/categories'], ['GET', '/api/finance/expenses'], ['GET', '/api/finance/pnl'], ['GET', '/api/finance/pnl.csv'], ['POST', '/api/finance/expenses']]) {
    assert.equal((await call(m, p, { token: S, body: m === 'POST' ? { amount_cents: 1, spent_on: today } : undefined })).status, 403, `staff ${m} ${p}`);
    assert.equal((await call(m, p, { token: C, body: m === 'POST' ? { amount_cents: 1, spent_on: today } : undefined })).status, 403, `customer ${m} ${p}`);
  }
  assert.equal((await call('GET', '/api/finance/expenses')).status, 401);
  // A role with finance.view can read but not write.
  const role = await call('POST', '/api/staff/roles', { token: A, body: { name: 'Accounts viewer', permissions: ['finance.view'], dashboard: [] } });
  assert.equal(role.status, 201, JSON.stringify(role.body));
  const { hashPassword } = await import('../src/lib/crypto.js');
  await insert('users', { type: 'staff', role_id: role.body.id, name: 'Viewer', email: 'fviewer@test.local', password_hash: await hashPassword(PASSWORDS.staff), status: 'active', email_verified_at: now(), created_at: now(), updated_at: now() });
  const V = (await login('fviewer@test.local', PASSWORDS.staff)).accessToken;
  assert.equal((await call('GET', '/api/finance/pnl', { token: V })).status, 200);
  assert.equal((await call('POST', '/api/finance/expenses', { token: V, body: { amount_cents: 1, spent_on: today } })).status, 403);
  assert.equal((await call('POST', '/api/finance/categories', { token: V, body: { name: 'Nope' } })).status, 403);
  // Module switch off → 404.
  await call('PUT', '/api/settings/modules', { token: A, body: { finance: false } });
  assert.equal((await call('GET', '/api/finance/pnl', { token: A })).status, 404);
  await call('PUT', '/api/settings/modules', { token: A, body: { finance: true } });
  assert.equal((await call('GET', '/api/finance/pnl', { token: A })).status, 200);
});

// ================================================================== zones
test('zones: CRUD, unique names, manager validation and cycle protection', async () => {
  const north = await call('POST', '/api/zones', { token: A, body: { name: 'North', notes: 'POP 1' } });
  assert.equal(north.status, 201);
  const sub = await call('POST', '/api/zones', { token: A, body: { name: 'North / Block A', parent_id: north.body.id } });
  const subsub = await call('POST', '/api/zones', { token: A, body: { name: 'North / Block A / Lane 3', parent_id: sub.body.id } });
  assert.equal(subsub.status, 201);
  assert.equal((await call('POST', '/api/zones', { token: A, body: { name: 'north' } })).status, 409);
  assert.equal((await call('POST', '/api/zones', { token: A, body: { name: 'X' } })).status, 400);
  assert.equal((await call('POST', '/api/zones', { token: A, body: { name: 'Ghost child', parent_id: 999999 } })).status, 400);
  const cust = await db().get("SELECT user_id FROM customers WHERE code = 'CT1'");
  assert.equal((await call('POST', '/api/zones', { token: A, body: { name: 'Bad mgr', manager_id: cust.user_id } })).status, 400, 'customer cannot manage');
  const staff = (await call('GET', '/api/zones/staff', { token: A })).body.staff;
  const support = staff.find((s) => s.email === 'support@test.local');
  assert.equal((await call('PUT', `/api/zones/${north.body.id}`, { token: A, body: { manager_id: support.id } })).status, 200);

  assert.equal((await call('PUT', `/api/zones/${north.body.id}`, { token: A, body: { parent_id: north.body.id } })).status, 400, 'self parent');
  assert.equal((await call('PUT', `/api/zones/${north.body.id}`, { token: A, body: { parent_id: subsub.body.id } })).status, 400, 'descendant parent');
  assert.equal((await call('PUT', `/api/zones/${subsub.body.id}`, { token: A, body: { parent_id: null } })).status, 200, 'detach ok');
  assert.equal((await call('PUT', `/api/zones/${subsub.body.id}`, { token: A, body: { parent_id: sub.body.id } })).status, 200);

  const one = await call('GET', `/api/zones/${north.body.id}`, { token: A });
  assert.equal(one.body.zone.manager_name, 'Support');
  assert.equal(one.body.zone.children, 1);

  // Deleting the middle zone re-parents its child and keeps members.
  const del = await call('DELETE', `/api/zones/${sub.body.id}`, { token: A });
  assert.equal(del.status, 200);
  assert.equal(del.body.subzones, 1);
  assert.equal(Number((await db().get('SELECT parent_id FROM zones WHERE id = ?', [subsub.body.id])).parent_id), north.body.id);
  assert.equal((await call('GET', `/api/zones/${sub.body.id}`, { token: A })).status, 404);
  await call('DELETE', `/api/zones/${subsub.body.id}`, { token: A });
  await call('DELETE', `/api/zones/${north.body.id}`, { token: A });
});

test('zones: bulk assignment, area assignment, stats, drill-down and delete clears members', async () => {
  const z = (await call('POST', '/api/zones', { token: A, body: { name: 'Mirpur' } })).body.id;
  const parent = (await call('POST', '/api/zones', { token: A, body: { name: 'Dhaka' } })).body.id;
  await call('PUT', `/api/zones/${z}`, { token: A, body: { parent_id: parent } });
  const c1 = await db().get("SELECT id FROM customers WHERE code = 'CT1'");
  const c2 = await db().get("SELECT id FROM customers WHERE code = 'CT2'");
  await db().run("UPDATE customers SET area = 'Mirpur 10' WHERE id = ?", [c2.id]);

  assert.equal((await call('POST', `/api/zones/${z}/customers`, { token: A, body: { customer_ids: [] } })).status, 400);
  const a = await call('POST', `/api/zones/${z}/customers`, { token: A, body: { customer_ids: [c1.id] } });
  assert.equal(a.body.updated, 1);
  const areas = (await call('GET', '/api/zones/areas', { token: A })).body.areas;
  assert.ok(areas.some((x) => x.area === 'Mirpur 10' && x.unassigned === 1));
  const b = await call('POST', `/api/zones/${z}/assign-area`, { token: A, body: { area: '  mirpur 10 ', only_unassigned: true } });
  assert.equal(b.status, 200);
  assert.equal(b.body.updated, 1, 'area match is case/space-insensitive');

  // Expected revenue = active customers' plan price; dues = open invoices.
  const inv = await insert('invoices', { number: `ZT-${Date.now()}`, customer_id: c1.id, total_cents: 80000, paid_cents: 30000, status: 'partial', created_at: now() });
  const router = await insert('routers', { name: 'Mirpur NAS', driver: 'simulator', created_at: now() });
  assert.equal((await call('POST', `/api/zones/${z}/routers`, { token: A, body: { router_ids: [router.id] } })).status, 200);

  const list = (await call('GET', '/api/zones', { token: A })).body;
  const mz = list.zones.find((x) => x.id === z);
  const plans = await db().all("SELECT c.id, p.price_cents FROM customers c JOIN plans p ON p.id = c.plan_id WHERE c.id IN (?, ?) AND c.status = 'active'", [c1.id, c2.id]);
  assert.equal(mz.stats.customers, 2);
  assert.equal(mz.stats.active_customers, plans.length);
  assert.equal(mz.stats.expected_revenue_cents, plans.reduce((s, p) => s + Number(p.price_cents), 0));
  assert.equal(mz.stats.routers, 1);
  const due = Number((await db().get("SELECT COALESCE(SUM(total_cents - paid_cents),0) AS v FROM invoices WHERE customer_id IN (?, ?) AND status IN ('unpaid','partial','overdue')", [c1.id, c2.id])).v);
  assert.equal(mz.stats.outstanding_cents, due);
  assert.ok(due >= 50000);
  const dz = list.zones.find((x) => x.id === parent);
  assert.equal(dz.stats.customers, 0);
  assert.equal(dz.totals.customers, 2, 'parent totals roll up children');

  const drill = await call('GET', `/api/zones/${z}/customers?pageSize=1`, { token: A });
  assert.equal(drill.status, 200);
  assert.equal(drill.body.total, 2);
  assert.equal(drill.body.rows.length, 1);
  const lite = await call('GET', '/api/zones?lite=1', { token: S });
  assert.equal(lite.status, 200, 'customers.view can read zones for pickers');
  assert.deepEqual(Object.keys(lite.body.zones[0]).sort(), ['id', 'name', 'parent_id']);

  const rm = await call('POST', `/api/zones/${z}/customers/remove`, { token: A, body: { customer_ids: [c2.id] } });
  assert.equal(rm.body.removed, 1);

  // Expense in the zone + delete: members stay, zone_id is cleared everywhere.
  const exp = await call('POST', '/api/finance/expenses', { token: A, body: { amount_cents: 777, spent_on: today, zone_id: z } });
  const byZone = await call('GET', `/api/finance/pnl?group=zone&from=${today}&to=${today}`, { token: A });
  assert.equal(byZone.body.periods.find((p) => p.zone_id === z).expense_cents, 777);
  const del = await call('DELETE', `/api/zones/${z}`, { token: A });
  assert.equal(del.status, 200);
  assert.deepEqual([del.body.customers, del.body.routers], [1, 1]);
  assert.equal((await db().get('SELECT zone_id FROM customers WHERE id = ?', [c1.id])).zone_id, null);
  assert.equal((await db().get('SELECT zone_id FROM routers WHERE id = ?', [router.id])).zone_id, null);
  assert.equal((await db().get('SELECT zone_id FROM expenses WHERE id = ?', [exp.body.id])).zone_id, null);
  assert.ok(await db().get('SELECT id FROM customers WHERE id = ?', [c1.id]), 'customer kept');
  await db().run('DELETE FROM invoices WHERE id = ?', [inv.id]);
  await call('DELETE', `/api/zones/${parent}`, { token: A });
});

test('zones access control', async () => {
  assert.equal((await call('GET', '/api/zones', { token: S })).status, 200);
  assert.equal((await call('POST', '/api/zones', { token: S, body: { name: 'Nope zone' } })).status, 403);
  assert.equal((await call('GET', '/api/zones/areas', { token: S })).status, 403);
  assert.equal((await call('GET', '/api/zones', { token: C })).status, 403);
  assert.equal((await call('POST', '/api/zones', { token: C, body: { name: 'Nope zone' } })).status, 403);
  assert.equal((await call('GET', '/api/zones')).status, 401);
  assert.equal((await call('GET', '/api/zones/999999', { token: A })).status, 404);
  assert.equal((await call('PUT', '/api/zones/abc', { token: A, body: { name: 'Whatever' } })).status, 404);
});
