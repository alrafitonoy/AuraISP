// Quick end-to-end smoke run against a running server: node test/smoke.mjs [baseUrl]
const BASE = process.argv[2] || 'http://localhost:4000';
const H = { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' };
let fails = 0;
async function call(method, path, body, token) {
  const res = await fetch(BASE + path, { method, headers: { ...H, ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let json; try { json = JSON.parse(text); } catch { json = text; }
  return { status: res.status, json };
}
function check(name, cond, info) { if (cond) console.log(`  ok   ${name}`); else { fails++; console.log(`  FAIL ${name}`, info ?? ''); } }

const login = async (email, password) => (await call('POST', '/api/auth/login', { email, password, client: 'native' })).json;

const admin = await login('admin@aura.local', 'Admin#Aura2026');
check('admin login', admin.accessToken, admin);
const A = admin.accessToken;
for (const p of ['/api/dashboard', '/api/customers', '/api/plans', '/api/billing/invoices', '/api/billing/summary', '/api/billing/payments', '/api/tickets', '/api/network/routers', '/api/network/live', '/api/network/traffic', '/api/network/site-rules', '/api/crm/leads', '/api/crm/sales', '/api/crm/campaigns', '/api/crm/faqs', '/api/staff', '/api/staff/roles', '/api/settings', '/api/notifications', '/api/notifications/templates', '/api/notifications/reminders', '/api/updates', '/api/audit', '/api/network/devices', '/api/network/remote-sessions']) {
  const r = await call('GET', p, null, A);
  check(`GET ${p}`, r.status === 200, r.json);
}
const cust = await login('customer@demo.local', 'Customer#2026');
const C = cust.accessToken;
check('customer login', C, cust);
for (const p of ['/api/portal/overview', '/api/portal/usage', '/api/portal/plans', '/api/portal/parental', '/api/portal/devices', '/api/billing/invoices', '/api/billing/payments', '/api/tickets']) {
  const r = await call('GET', p, null, C);
  check(`customer GET ${p}`, r.status === 200, r.json);
}
// authorisation boundaries
check('customer cannot list customers', (await call('GET', '/api/customers', null, C)).status === 403);
check('customer cannot read settings', (await call('GET', '/api/settings', null, C)).status === 403);
check('anon cannot read dashboard', (await call('GET', '/api/dashboard')).status === 401);
const other = await call('GET', '/api/billing/invoices/10', null, C);
check('customer cannot read others invoice (IDOR)', other.status === 404, other.status);
const support = await login('support@demo.local', 'Staff#2026demo');
check('support cannot change settings', (await call('PUT', '/api/settings/branding', { companyName: 'x' }, support.accessToken)).status === 403);
check('support cannot manage staff', (await call('GET', '/api/staff', null, support.accessToken)).status === 403);
// public
check('public config', (await call('GET', '/api/public/config')).status === 200);
const bot = await call('POST', '/api/public/chatbot', { message: 'how do I pay my bill' });
check('chatbot answers', bot.json.reply && bot.json.matched, bot.json);
// flows
const t = await call('POST', '/api/tickets', { subject: 'Smoke test ticket', body: 'Testing the ticket flow' }, C);
check('customer creates ticket', t.status === 201, t.json);
const plans = (await call('GET', '/api/portal/plans', null, C)).json.plans;
const up = plans.find((p) => p.quote && p.price_cents > 0);
const ch = await call('POST', '/api/portal/plans/change', { planId: up.id }, C);
check('customer plan change', ch.status === 200, ch.json);
if (ch.json.invoice) {
  const rp = await call('POST', `/api/billing/invoices/${ch.json.invoice.id}/record-payment`, { amount_cents: ch.json.invoice.total_cents, method: 'cash' }, A);
  check('staff records payment', rp.status === 201, rp.json);
}
const bw = await call('POST', '/api/customers/2/bandwidth', { download_kbps: 15000, upload_kbps: 5000 }, A);
check('admin sets customer bandwidth', bw.status === 200 && bw.json.ok, bw.json);
const diag = await call('POST', '/api/network/diagnostics', { test: 'ping', target: '8.8.8.8', customer_id: 2 }, A);
check('diagnostics ping', diag.status === 200, diag.json);
const inj = await call('POST', '/api/network/diagnostics', { test: 'ping', target: '8.8.8.8; rm -rf /' }, A);
check('diagnostics rejects injection', inj.status === 400, inj.json);
const par = await call('PUT', '/api/portal/parental', { enabled: true, safeSearch: true, blockedCategories: ['gaming'], blockedDomains: ['example.com'], schedules: [{ from: '22:00', to: '23:59', days: ['mon', 'tue'] }] }, C);
check('parental controls save', par.status === 200, par.json);
const role = await call('POST', '/api/staff/roles', { name: `Smoke Role ${Date.now()}`, permissions: ['tickets.view'], dashboard: ['kpi_tickets'] }, A);
check('create role', role.status === 201, role.json);
const proto = await fetch(BASE + '/api/public/contact', { method: 'POST', headers: H, body: '{"name":"x","phone":"123456","__proto__":{"admin":true}}' });
check('prototype pollution rejected', proto.status === 403, proto.status);
const bad = await call('POST', '/api/auth/login', { email: 'admin@aura.local', password: 'wrong' });
check('bad password rejected', bad.status === 401);
const refreshNoHeader = await fetch(BASE + '/api/auth/refresh', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ refreshToken: admin.refreshToken }) });
check('refresh requires anti-CSRF header', refreshNoHeader.status === 403);
const ref = await call('POST', '/api/auth/refresh', { refreshToken: admin.refreshToken });
check('refresh rotates', ref.status === 200 && ref.json.refreshToken, ref.json);
await call('POST', '/api/auth/logout', { refreshToken: ref.json.refreshToken });
const reuse = await call('POST', '/api/auth/refresh', { refreshToken: ref.json.refreshToken });
check('refresh token reuse after logout rejected', reuse.status === 401);
const html = await fetch(BASE + '/api/billing/invoices/1/html', { headers: { Authorization: `Bearer ${A}` } });
check('invoice html', html.status === 200);

console.log(fails ? `\n${fails} check(s) FAILED` : '\nAll smoke checks passed');
process.exit(fails ? 1 : 0);
