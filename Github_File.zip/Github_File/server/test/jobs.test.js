// Field jobs / work orders: CRUD, numbering, workflow, technician scoping, notifications, calendar and summary.
import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { call, login, close, PASSWORDS, db } from './helpers.js';
import { insert, now } from '../src/db/index.js';
import { hashPassword } from '../src/lib/crypto.js';

after(close);
const A = (await login('admin@test.local', PASSWORDS.admin)).accessToken;
const support = await login('support@test.local', PASSWORDS.staff); // support role: no jobs.* permission
const cust = (await login('c1@test.local', PASSWORDS.customer)).accessToken;

// Technician (jobs.work only), a second technician, and a viewer (jobs.view only).
const ts = now();
const mkRole = async (slug, perms) => (await insert('roles', { name: slug, slug, permissions: JSON.stringify(perms), dashboard: '[]', is_system: 0, created_at: ts })).id;
const techRole = await mkRole('t_technician', ['jobs.work']);
const viewRole = await mkRole('t_jobviewer', ['jobs.view']);
const mkUser = async (email, roleId, status = 'active') => (await insert('users', { type: 'staff', role_id: roleId, name: email.split('@')[0], email, password_hash: await hashPassword(PASSWORDS.staff), status, email_verified_at: ts, created_at: ts, updated_at: ts })).id;
const tech1 = await mkUser('tech1@test.local', techRole);
const tech2 = await mkUser('tech2@test.local', techRole);
await mkUser('viewer@test.local', viewRole);
const inactive = await mkUser('gone@test.local', techRole, 'disabled');
const T1 = (await login('tech1@test.local', PASSWORDS.staff)).accessToken;
const T2 = (await login('tech2@test.local', PASSWORDS.staff)).accessToken;
const V = (await login('viewer@test.local', PASSWORDS.staff)).accessToken;

await db().run("UPDATE customers SET address = 'House 5, Road 2, Banani', lat = '23.79', lng = '90.40' WHERE id = 1");
const custUser = (await db().get('SELECT user_id FROM customers WHERE id = 1')).user_id;
const settle = () => new Promise((r) => setTimeout(r, 150)); // queueNotify runs on setImmediate

const future = new Date(Date.now() + 2 * 3600000).toISOString();
let jobId;

test('create: numbered, default checklist, address from customer, notifications', async () => {
  const r = await call('POST', '/api/jobs', { token: A, body: { type: 'installation', title: 'New fibre connection', customer_id: 1, assigned_to: tech1, scheduled_at: future, priority: 'high' } });
  assert.equal(r.status, 201, JSON.stringify(r.body));
  assert.match(r.body.number, /^JOB-\d{4}-\d{5}$/);
  jobId = r.body.id;
  const j = (await call('GET', `/api/jobs/${jobId}`, { token: A })).body.job;
  assert.equal(j.status, 'scheduled');
  assert.equal(j.address, 'House 5, Road 2, Banani');
  assert.equal(j.lat, '23.79');
  assert.equal(j.checklist.length, 6);
  assert.ok(j.checklist.every((i) => i.done === false));
  await settle();
  const techNote = await db().get('SELECT link FROM notifications WHERE user_id = ? ORDER BY id DESC', [tech1]);
  assert.equal(techNote?.link, `/admin/jobs?job=${jobId}`);
  const custLog = await db().all("SELECT channel FROM notification_log WHERE user_id = ? AND ref LIKE ?", [custUser, `job:${jobId}:scheduled%`]);
  assert.deepEqual(custLog.map((x) => x.channel).sort(), ['inapp', 'sms']);
});

test('numbers are unique and sequential, even when created concurrently', async () => {
  const res = await Promise.all([1, 2, 3, 4].map((n) => call('POST', '/api/jobs', { token: A, body: { type: 'survey', title: `Survey ${n}` } })));
  assert.ok(res.every((r) => r.status === 201), JSON.stringify(res.map((r) => r.body)));
  const numbers = res.map((r) => r.body.number);
  assert.equal(new Set(numbers).size, 4);
  const survey = (await call('GET', `/api/jobs/${res[0].body.id}`, { token: A })).body.job;
  assert.equal(survey.status, 'new');
  assert.equal(survey.checklist[0].label, 'Check line of sight / cable route');
});

test('validation: bad type, inactive or customer assignee, unknown links, bad coordinates', async () => {
  const bad = async (body) => (await call('POST', '/api/jobs', { token: A, body })).status;
  assert.equal(await bad({ type: 'party', title: 'x y' }), 400);
  assert.equal(await bad({ type: 'repair' }), 400);
  assert.equal(await bad({ type: 'repair', title: 'Fix', assigned_to: inactive }), 400);
  assert.equal(await bad({ type: 'repair', title: 'Fix', assigned_to: custUser }), 400);
  assert.equal(await bad({ type: 'repair', title: 'Fix', customer_id: 99999 }), 400);
  assert.equal(await bad({ type: 'repair', title: 'Fix', lat: 123, lng: 10 }), 400);
  assert.equal(await bad({ type: 'repair', title: 'Fix', priority: 'asap' }), 400);
  assert.equal(await bad({ type: 'repair', title: 'Fix', checklist: [{ label: '' }] }), 400);
});

test('permissions: customer and staff without jobs.* are denied; viewer cannot write', async () => {
  assert.equal((await call('GET', '/api/jobs', { token: cust })).status, 403);
  assert.equal((await call('GET', '/api/jobs', { token: support.accessToken })).status, 403);
  assert.equal((await call('POST', '/api/jobs', { token: support.accessToken, body: { type: 'repair', title: 'Fix it' } })).status, 403);
  assert.equal((await call('GET', '/api/jobs', { token: V })).status, 200);
  assert.equal((await call('POST', '/api/jobs', { token: V, body: { type: 'repair', title: 'Fix it' } })).status, 403);
  assert.equal((await call('POST', `/api/jobs/${jobId}/status`, { token: V, body: { status: 'en_route' } })).status, 403);
  assert.equal((await call('GET', '/api/jobs/technicians', { token: V })).status, 200);
  assert.equal((await call('GET', '/api/jobs/technicians', { token: T1 })).status, 403);
});

test('technician sees only own jobs and cannot create, edit, delete or cancel', async () => {
  const list = (await call('GET', '/api/jobs', { token: T1 })).body;
  assert.ok(list.rows.length >= 1);
  assert.ok(list.rows.every((j) => j.assigned_to === tech1));
  assert.equal((await call('GET', '/api/jobs', { token: T2 })).body.total, 0);
  assert.equal((await call('GET', `/api/jobs/${jobId}`, { token: T2 })).status, 404);
  assert.equal((await call('POST', `/api/jobs/${jobId}/status`, { token: T2, body: { status: 'en_route' } })).status, 404);
  assert.equal((await call('PUT', `/api/jobs/${jobId}`, { token: T1, body: { title: 'Changed' } })).status, 403);
  assert.equal((await call('DELETE', `/api/jobs/${jobId}`, { token: T1 })).status, 403);
  assert.equal((await call('POST', '/api/jobs', { token: T1, body: { type: 'repair', title: 'Mine' } })).status, 403);
  assert.equal((await call('POST', `/api/jobs/${jobId}/status`, { token: T1, body: { status: 'cancelled' } })).status, 403);
  const detail = (await call('GET', `/api/jobs/${jobId}`, { token: T1 })).body.job;
  assert.deepEqual(detail.allowed, ['en_route']);
  assert.equal(detail.can_work, true);
});

test('workflow: transitions enforced, checklist ticking, result required, completed_at set', async () => {
  const st = (status, extra = {}, token = T1) => call('POST', `/api/jobs/${jobId}/status`, { token, body: { status, ...extra } });
  assert.equal((await st('done', { result: 'x' })).status, 400, 'cannot skip to done');
  assert.equal((await st('en_route')).status, 200);
  await settle();
  const enRoute = await db().get('SELECT id FROM notification_log WHERE user_id = ? AND ref = ?', [custUser, `job:${jobId}:en_route:${future}`]);
  assert.ok(enRoute, 'customer told the technician is on the way');
  assert.equal((await st('on_site')).status, 200);
  const tick = await call('PATCH', `/api/jobs/${jobId}/checklist/0`, { token: T1, body: { done: true } });
  assert.equal(tick.status, 200);
  assert.equal(tick.body.checklist[0].done, true);
  assert.equal((await call('PATCH', `/api/jobs/${jobId}/checklist/42`, { token: T1, body: { done: true } })).status, 400);
  assert.equal((await st('done')).status, 400, 'result note required');
  const done = await st('done', { result: 'Installed ONU, 100 Mbps speed test OK' });
  assert.equal(done.status, 200);
  const j = (await call('GET', `/api/jobs/${jobId}`, { token: A })).body.job;
  assert.equal(j.status, 'done');
  assert.ok(j.completed_at);
  assert.equal(j.checklist_done, 1);
  assert.equal((await st('scheduled', {}, A)).status, 400, 'done is final');
  assert.equal((await call('PATCH', `/api/jobs/${jobId}/checklist/1`, { token: T1, body: { done: true } })).status, 400, 'closed job locked');
});

test('failed requires a result; managers can reschedule; scheduling needs a time', async () => {
  const c = await call('POST', '/api/jobs', { token: A, body: { type: 'repair', title: 'No internet', assigned_to: tech2 } });
  const id = c.body.id;
  const st = (status, extra = {}, token = A) => call('POST', `/api/jobs/${id}/status`, { token, body: { status, ...extra } });
  assert.equal((await st('scheduled')).status, 400, 'needs a time');
  assert.equal((await st('scheduled', { scheduled_at: future })).status, 200);
  assert.equal((await st('en_route', {}, T2)).status, 200);
  assert.equal((await st('on_site', {}, T2)).status, 200);
  assert.equal((await st('failed', {}, T2)).status, 400);
  assert.equal((await call('PATCH', `/api/jobs/${id}/result`, { token: T2, body: { result: 'Fibre cut on pole, needs splicing crew' } })).status, 200);
  assert.equal((await st('failed', {}, T2)).status, 200, 'existing result satisfies the requirement');
  assert.equal((await st('scheduled', {}, T2)).status, 403, 'technician cannot reopen');
  assert.equal((await st('scheduled')).status, 200, 'manager reopens');
  assert.equal((await st('cancelled')).status, 200);
});

test('edit: reassign notifies new technician; type switch swaps untouched default checklist', async () => {
  const c = await call('POST', '/api/jobs', { token: A, body: { type: 'repair', title: 'Slow speed' } });
  const r = await call('PUT', `/api/jobs/${c.body.id}`, { token: A, body: { assigned_to: tech2, type: 'maintenance', scheduled_at: future } });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  const j = (await call('GET', `/api/jobs/${c.body.id}`, { token: A })).body.job;
  assert.equal(j.assigned_to, tech2);
  assert.equal(j.status, 'scheduled');
  assert.equal(j.checklist[0].label, 'Inspect equipment');
  await settle();
  assert.ok(await db().get('SELECT id FROM notifications WHERE user_id = ? AND link = ?', [tech2, `/admin/jobs?job=${c.body.id}`]));
  assert.equal((await call('DELETE', `/api/jobs/${c.body.id}`, { token: A })).status, 200);
  assert.equal((await call('GET', `/api/jobs/${c.body.id}`, { token: A })).status, 404);
});

test('create from ticket copies customer and subject; a second open job conflicts', async () => {
  const t = await insert('tickets', { number: 'T-JOB-1', customer_id: 1, created_by: custUser, subject: 'Router keeps rebooting', category: 'technical', priority: 'urgent', status: 'open', created_at: now(), updated_at: now() });
  const r = await call('POST', `/api/jobs/from-ticket/${t.id}`, { token: A, body: { assigned_to: tech1 } });
  assert.equal(r.status, 201, JSON.stringify(r.body));
  const j = (await call('GET', `/api/jobs/${r.body.id}`, { token: A })).body.job;
  assert.deepEqual([j.title, j.customer_id, j.ticket_id, j.type, j.priority, j.ticket_number], ['Router keeps rebooting', 1, t.id, 'repair', 'urgent', 'T-JOB-1']);
  assert.equal(j.address, 'House 5, Road 2, Banani');
  assert.equal((await call('POST', `/api/jobs/from-ticket/${t.id}`, { token: A, body: {} })).status, 409);
  assert.equal((await call('POST', '/api/jobs/from-ticket/999999', { token: A, body: {} })).status, 404);
  assert.ok(await db().get('SELECT id FROM ticket_messages WHERE ticket_id = ? AND internal = 1', [t.id]));
});

test('list filters, search and pagination', async () => {
  const byType = (await call('GET', '/api/jobs?type=survey&pageSize=2', { token: A })).body;
  assert.equal(byType.total, 4);
  assert.equal(byType.rows.length, 2);
  assert.ok(byType.rows.every((j) => j.type === 'survey'));
  const search = (await call('GET', '/api/jobs?q=rebooting', { token: A })).body;
  assert.equal(search.total, 1);
  const tech = (await call('GET', `/api/jobs?assigned_to=${tech1}&status=new,scheduled`, { token: A })).body;
  assert.ok(tech.rows.every((j) => j.assigned_to === tech1 && ['new', 'scheduled'].includes(j.status)));
  const range = (await call('GET', `/api/jobs?from=${encodeURIComponent(new Date(Date.now() - 86400000).toISOString())}&to=${encodeURIComponent(new Date(Date.now() + 86400000).toISOString())}`, { token: A })).body;
  assert.ok(range.rows.every((j) => j.scheduled_at));
  assert.equal((await call('GET', '/api/jobs?from=notadate', { token: A })).status, 400);
});

test('calendar groups by local day; summary counts overdue and today', async () => {
  const past = new Date(Date.now() - 3 * 86400000).toISOString();
  await call('POST', '/api/jobs', { token: A, body: { type: 'repair', title: 'Overdue visit', scheduled_at: past, assigned_to: tech1 } });
  const from = new Date(Date.now() - 7 * 86400000).toISOString(); const to = new Date(Date.now() + 7 * 86400000).toISOString();
  const cal = (await call('GET', `/api/jobs/calendar?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&tz=-360`, { token: A })).body;
  assert.ok(cal.total >= 2);
  const pastDay = new Date(Date.parse(past) + 360 * 60000).toISOString().slice(0, 10);
  assert.ok(cal.days[pastDay]?.some((j) => j.title === 'Overdue visit'));
  assert.equal((await call('GET', '/api/jobs/calendar', { token: A })).status, 400);
  assert.equal((await call('GET', `/api/jobs/calendar?from=${encodeURIComponent(from)}&to=${encodeURIComponent(new Date(Date.now() + 200 * 86400000).toISOString())}`, { token: A })).status, 400);

  const s = (await call('GET', '/api/jobs/summary', { token: A })).body;
  assert.ok(s.overdue >= 1);
  assert.equal(typeof s.byStatus.done, 'number');
  assert.ok(s.open >= 1);
  const mine = (await call('GET', '/api/jobs/summary', { token: T2 })).body;
  assert.equal(mine.overdue, 0, 'technician summary is scoped to own jobs');
  const t1cal = (await call('GET', `/api/jobs/calendar?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`, { token: T1 })).body;
  assert.ok(Object.values(t1cal.days).flat().every((j) => j.assigned_to === tech1));
});

test('technicians endpoint, meta and lookup', async () => {
  const techs = (await call('GET', '/api/jobs/technicians', { token: A })).body.technicians;
  assert.ok(techs.some((t) => t.id === tech1 && t.technician));
  assert.ok(!techs.some((t) => t.id === inactive));
  assert.ok(!techs.some((t) => t.id === custUser));
  const meta = (await call('GET', '/api/jobs/meta', { token: T1 })).body;
  assert.ok(meta.types.includes('installation') && meta.checklists.installation.length === 6);
  const look = (await call('GET', '/api/jobs/lookup?kind=customer&q=Customer', { token: A })).body.results;
  assert.ok(look.length >= 2);
  assert.equal((await call('GET', '/api/jobs/lookup?q=x', { token: T1 })).status, 403);
});

test('module switch off hides the API', async () => {
  const r = await call('PUT', '/api/settings/modules', { token: A, body: { jobs: false } });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal((await call('GET', '/api/jobs', { token: A })).status, 404);
  await call('PUT', '/api/settings/modules', { token: A, body: { jobs: true } });
  assert.equal((await call('GET', '/api/jobs', { token: A })).status, 200);
});
