// Operations suite: network map (sites + customer locations), KYC documents (private uploads, magic bytes, ownership),
// session / IP log (recordSessions state machine, "who had IP X at time T", CSV export).
import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { call, login, close, PASSWORDS, db, BASE } from './helpers.js';
import { insert, now } from '../src/db/index.js';
import config from '../src/config.js';

after(close);
const A = (await login('admin@test.local', PASSWORDS.admin)).accessToken;
const S = (await login('support@test.local', PASSWORDS.staff)).accessToken; // support: network.view only, no kyc / customers.edit
const C1 = (await login('c1@test.local', PASSWORDS.customer)).accessToken;
const C2 = (await login('c2@test.local', PASSWORDS.customer)).accessToken;
const cid = async (code) => (await db().get('SELECT id FROM customers WHERE code = ?', [code])).id;
const ID1 = await cid('CT1'); const ID2 = await cid('CT2');

const PNG = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(64, 1)]);
const PDF = Buffer.from('%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF');

async function upload(p, token, { buf = PNG, mime = 'image/png', name = 'doc.png', fields = { type: 'nid_front', number: '1990123456789' } } = {}) {
  const form = new FormData();
  for (const [k, v] of Object.entries(fields)) form.append(k, v);
  if (buf) form.append('file', new Blob([buf], { type: mime }), name);
  const res = await fetch(BASE + p, { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'X-Requested-With': 'XMLHttpRequest' }, body: form });
  const text = await res.text(); let body; try { body = JSON.parse(text); } catch { body = text; }
  return { status: res.status, body };
}
const raw = (p, token) => fetch(BASE + p, { headers: { Authorization: `Bearer ${token}`, 'X-Requested-With': 'XMLHttpRequest' } });

// ------------------------------------------------------------------ (A) map
test('network sites: CRUD with coordinate validation and permissions', async () => {
  const bad = await call('POST', '/api/ops/sites', { token: A, body: { name: 'X', type: 'pop', lat: 95, lng: 90 } });
  assert.equal(bad.status, 400);
  const badType = await call('POST', '/api/ops/sites', { token: A, body: { name: 'X', type: 'castle', lat: 23.8, lng: 90.4 } });
  assert.equal(badType.status, 400);
  const badZone = await call('POST', '/api/ops/sites', { token: A, body: { name: 'X', type: 'pop', lat: 23.8, lng: 90.4, zone_id: 99999 } });
  assert.equal(badZone.status, 400);
  const denied = await call('POST', '/api/ops/sites', { token: S, body: { name: 'POP', type: 'pop', lat: 23.8, lng: 90.4 } });
  assert.equal(denied.status, 403, 'support lacks network.manage');
  const ok = await call('POST', '/api/ops/sites', { token: A, body: { name: 'Banani POP', type: 'pop', lat: '23.7937', lng: '90.4066', notes: 'Rooftop' } });
  assert.equal(ok.status, 201);
  const up = await call('PUT', `/api/ops/sites/${ok.body.id}`, { token: A, body: { type: 'olt', lat: 23.8 } });
  assert.equal(up.status, 200);
  const list = await call('GET', '/api/ops/sites', { token: S });
  assert.equal(list.status, 200, 'network.view may read');
  const site = list.body.rows.find((s) => s.id === ok.body.id);
  assert.deepEqual([site.type, site.lat, site.lng], ['olt', 23.8, 90.4066]);
  assert.equal((await call('PUT', '/api/ops/sites/99999', { token: A, body: { name: 'Y' } })).status, 404);
  assert.equal((await call('GET', '/api/ops/sites', { token: C1 })).status, 403, 'customers cannot read sites');
  assert.equal((await call('DELETE', `/api/ops/sites/${ok.body.id}`, { token: A })).status, 200);
  assert.equal((await call('DELETE', `/api/ops/sites/${ok.body.id}`, { token: A })).status, 404);
});

test('map: customer location set/clear, numeric coordinates, live and overdue flags', async () => {
  assert.equal((await call('PUT', `/api/ops/customers/${ID1}/location`, { token: S, body: { lat: 23.81, lng: 90.41 } })).status, 403, 'needs customers.edit');
  assert.equal((await call('PUT', `/api/ops/customers/${ID1}/location`, { token: A, body: { lat: 23.81, lng: null } })).status, 400);
  assert.equal((await call('PUT', `/api/ops/customers/${ID1}/location`, { token: A, body: { lat: 23.81, lng: 200 } })).status, 400);
  assert.equal((await call('PUT', '/api/ops/customers/99999/location', { token: A, body: { lat: 23.81, lng: 90.41 } })).status, 404);
  assert.equal((await call('PUT', `/api/ops/customers/${ID1}/location`, { token: A, body: { lat: 23.8103, lng: 90.4125 } })).status, 200);
  // A legacy string value that is not a number is ignored, never crashes the map.
  await db().run('UPDATE customers SET lat = ?, lng = ? WHERE id = ?', ['abc', '90.1', ID2]);
  const { live } = await import('../src/network/service.js');
  live.perCustomer.set(ID1, { customer_id: ID1, online: true, rx_bytes: 0, tx_bytes: 0, rx_bps: 0, tx_bps: 0 });
  const inv = await insert('invoices', { number: 'INV-OPS-1', customer_id: ID1, total_cents: 100, status: 'overdue', due_date: now(), created_at: now() });
  const m = await call('GET', '/api/ops/map', { token: S });
  assert.equal(m.status, 200);
  const c = m.body.customers.find((x) => x.id === ID1);
  assert.deepEqual([c.lat, c.lng, c.online, c.overdue, typeof c.lat], [23.8103, 90.4125, true, true, 'number']);
  assert.ok(!m.body.customers.some((x) => x.id === ID2));
  assert.ok(m.body.unplaced >= 1);
  await db().run('DELETE FROM invoices WHERE id = ?', [inv.id]);
  live.perCustomer.delete(ID1);
  assert.equal((await call('PUT', `/api/ops/customers/${ID2}/location`, { token: A, body: { lat: null, lng: null } })).status, 200);
  assert.equal((await db().get('SELECT lat FROM customers WHERE id = ?', [ID2])).lat, null);
});

// ------------------------------------------------------------------ (B) KYC
test('kyc: staff upload is stored privately with a random name and verified by magic bytes', async () => {
  const noPerm = await upload(`/api/ops/customers/${ID1}/documents`, S);
  assert.equal(noPerm.status, 403);
  const fake = await upload(`/api/ops/customers/${ID1}/documents`, A, { buf: Buffer.from('<html><script>alert(1)</script>'), mime: 'image/png' });
  assert.equal(fake.status, 400, 'PNG MIME with HTML content is rejected');
  const badMime = await upload(`/api/ops/customers/${ID1}/documents`, A, { buf: PDF, mime: 'text/html', name: 'x.html' });
  assert.equal(badMime.status, 400);
  const big = await upload(`/api/ops/customers/${ID1}/documents`, A, { buf: Buffer.concat([PNG, Buffer.alloc(5 * 1024 * 1024)]) });
  assert.equal(big.status, 413);
  const badType = await upload(`/api/ops/customers/${ID1}/documents`, A, { fields: { type: 'selfie' } });
  assert.equal(badType.status, 400);
  const noFile = await upload(`/api/ops/customers/${ID1}/documents`, A, { buf: null });
  assert.equal(noFile.status, 400);
  const ok = await upload(`/api/ops/customers/${ID1}/documents`, A, { buf: PDF, mime: 'application/pdf', name: 'agreement.pdf', fields: { type: 'agreement' } });
  assert.equal(ok.status, 201);
  const row = await db().get('SELECT * FROM customer_documents WHERE id = ?', [ok.body.id]);
  assert.match(row.file, /^[a-f0-9]{48}\.pdf$/);
  assert.equal(row.mime, 'application/pdf');
  assert.ok(fs.existsSync(path.join(config.dataDir, 'private', 'kyc', row.file)), 'stored under dataDir/private/kyc');
  assert.ok(!fs.existsSync(path.join(config.uploadsDir, row.file)), 'never in public uploads');
  const list = await call('GET', `/api/ops/customers/${ID1}/documents`, { token: A });
  assert.equal(list.body.rows[0].file, undefined, 'internal file name is not exposed');
  const f = await raw(`/api/ops/documents/${ok.body.id}/file`, A);
  assert.equal(f.status, 200);
  assert.match(f.headers.get('content-disposition'), /^attachment; filename="CT1-agreement-\d+\.pdf"$/);
  assert.equal(f.headers.get('x-content-type-options'), 'nosniff');
  assert.ok(Buffer.from(await f.arrayBuffer()).equals(PDF));
});

test('kyc: customer self-service — own documents only, cannot verify, cannot delete verified', async () => {
  const mine = await upload('/api/ops/my/documents', C2, { fields: { type: 'photo' } });
  assert.equal(mine.status, 201);
  const other = await upload('/api/ops/my/documents', C1, { fields: { type: 'nid_back' } });
  assert.equal(other.status, 201);
  const list = await call('GET', '/api/ops/my/documents', { token: C2 });
  assert.equal(list.status, 200);
  assert.ok(list.body.rows.every((d) => d.customer_id === ID2));
  assert.equal((await raw(`/api/ops/documents/${mine.body.id}/file`, C2)).status, 200, 'owner can download');
  assert.equal((await raw(`/api/ops/documents/${other.body.id}/file`, C2)).status, 404, 'other customer cannot');
  assert.equal((await raw(`/api/ops/documents/${mine.body.id}/file`, S)).status, 403, 'staff without kyc.view cannot');
  assert.equal((await call('GET', `/api/ops/customers/${ID2}/documents`, { token: C2 })).status, 403);
  assert.equal((await call('POST', `/api/ops/documents/${mine.body.id}/verify`, { token: C2, body: { status: 'verified' } })).status, 403);
  assert.equal((await call('GET', '/api/ops/my/documents', { token: A })).status, 403, 'staff have no "my" documents');
  // Pending documents may be withdrawn by the customer; verified ones may not.
  const extra = await upload('/api/ops/my/documents', C2, { fields: { type: 'other' } });
  assert.equal((await call('DELETE', `/api/ops/my/documents/${extra.body.id}`, { token: C2 })).status, 200);
  assert.equal((await call('POST', `/api/ops/documents/${mine.body.id}/verify`, { token: A, body: { status: 'verified', note: 'Matches NID' } })).status, 200);
  assert.equal((await call('DELETE', `/api/ops/my/documents/${mine.body.id}`, { token: C2 })).status, 403);
  assert.equal((await call('DELETE', `/api/ops/my/documents/${other.body.id}`, { token: C2 })).status, 404);
});

test('kyc: queue, verify/reject with reason, delete removes the file', async () => {
  const q = await call('GET', '/api/ops/documents?status=pending', { token: A });
  assert.equal(q.status, 200);
  assert.ok(q.body.rows.length >= 1 && q.body.rows.every((d) => d.status === 'pending'));
  assert.ok(q.body.rows[0].customer_name);
  assert.ok(q.body.counts.pending >= 1 && q.body.counts.verified >= 1);
  assert.equal((await call('GET', '/api/ops/documents', { token: S })).status, 403);
  const d = q.body.rows[0];
  assert.equal((await call('POST', `/api/ops/documents/${d.id}/verify`, { token: A, body: { status: 'rejected' } })).status, 400, 'reason required');
  assert.equal((await call('POST', `/api/ops/documents/${d.id}/verify`, { token: A, body: { status: 'rejected', note: 'Blurry photo' } })).status, 200);
  const row = await db().get('SELECT status, note, verified_by FROM customer_documents WHERE id = ?', [d.id]);
  assert.deepEqual([row.status, row.note, !!row.verified_by], ['rejected', 'Blurry photo', true]);
  const file = (await db().get('SELECT file FROM customer_documents WHERE id = ?', [d.id])).file;
  assert.equal((await call('DELETE', `/api/ops/documents/${d.id}`, { token: S })).status, 403);
  assert.equal((await call('DELETE', `/api/ops/documents/${d.id}`, { token: A })).status, 200);
  assert.ok(!fs.existsSync(path.join(config.dataDir, 'private', 'kyc', file)));
  assert.equal((await call('POST', `/api/ops/documents/${d.id}/verify`, { token: A, body: { status: 'verified' } })).status, 404);
});

test('kyc: module switch hides every endpoint', async () => {
  await call('PUT', '/api/settings/modules', { token: A, body: { kyc: false } });
  assert.equal((await call('GET', '/api/ops/my/documents', { token: C1 })).status, 404);
  assert.equal((await call('GET', '/api/ops/documents', { token: A })).status, 404);
  await call('PUT', '/api/settings/modules', { token: A, body: { kyc: true } });
  assert.equal((await call('GET', '/api/ops/documents', { token: A })).status, 200);
});

// ------------------------------------------------------------------ (C) session log
test('recordSessions opens, keeps, rotates on IP change and closes sessions without duplicates', async () => {
  const { live } = await import('../src/network/service.js');
  const { recordSessions, _resetCounters } = await import('../src/network/sessions.js');
  _resetCounters();
  await db().run('DELETE FROM session_logs');
  live.perCustomer.clear();
  live.at = null;
  assert.equal((await recordSessions()).skipped, true, 'no poll yet: nothing happens');
  live.at = now();
  await db().run('UPDATE customers SET ip_address = ?, pppoe_username = ?, mac_address = ? WHERE id = ?', ['10.50.0.1', 'ct1', 'AA:BB:CC:00:00:01', ID1]);
  await db().run('UPDATE customers SET ip_address = ? WHERE id = ?', ['10.50.0.2', ID2]);
  live.perCustomer.set(ID1, { customer_id: ID1, online: true, rx_bytes: 1000, tx_bytes: 100 });
  live.perCustomer.set(ID2, { customer_id: ID2, online: false, rx_bytes: 0, tx_bytes: 0 });
  assert.equal((await recordSessions()).opened, 1);
  live.perCustomer.set(ID1, { customer_id: ID1, online: true, rx_bytes: 5000, tx_bytes: 600 });
  const second = await recordSessions();
  assert.deepEqual([second.opened, second.closed, second.touched], [0, 0, 1], 'idempotent while nothing changes');
  let rows = await db().all('SELECT * FROM session_logs ORDER BY id');
  assert.equal(rows.length, 1);
  assert.deepEqual([rows[0].ip, rows[0].username, rows[0].mac, Number(rows[0].bytes_in), Number(rows[0].bytes_out), rows[0].ended_at], ['10.50.0.1', 'ct1', 'AA:BB:CC:00:00:01', 4000, 500, null]);
  // IP change while online → old row closed, new one opened.
  await db().run('UPDATE customers SET ip_address = ? WHERE id = ?', ['10.50.0.9', ID1]);
  const third = await recordSessions();
  assert.deepEqual([third.opened, third.closed], [1, 1]);
  // Offline → closed; a duplicate open row (crash leftovers) is also cleaned up.
  await insert('session_logs', { customer_id: ID1, ip: '10.50.0.9', started_at: '2000-01-01T00:00:00.000Z', last_seen_at: '2000-01-01T00:00:00.000Z' });
  live.perCustomer.set(ID1, { customer_id: ID1, online: false, rx_bytes: 0, tx_bytes: 0 });
  await recordSessions();
  rows = await db().all('SELECT * FROM session_logs ORDER BY id');
  assert.ok(rows.every((s) => s.ended_at), 'all sessions closed');
  assert.equal(rows.filter((s) => s.ip === '10.50.0.1').length, 1);
  live.perCustomer.clear();
});

test('session search answers "who had IP X at time T", with pagination and a safe CSV export', async () => {
  await db().run('DELETE FROM session_logs');
  const T = (h) => `2026-03-01T${String(h).padStart(2, '0')}:00:00.000Z`;
  await insert('session_logs', { customer_id: ID1, username: 'ct1', ip: '100.64.0.7', started_at: T(1), ended_at: T(3), last_seen_at: T(3) });
  await insert('session_logs', { customer_id: ID2, username: '=HYPERLINK("x")', ip: '100.64.0.7', started_at: T(4), ended_at: null, last_seen_at: T(9) });
  await insert('session_logs', { customer_id: ID2, username: 'ct2', ip: '100.64.0.8', started_at: T(1), ended_at: null, last_seen_at: T(9) });
  const at = async (iso) => (await call('GET', `/api/ops/sessions?ip=100.64.0.7&at=${encodeURIComponent(iso)}`, { token: A })).body.rows.map((s) => s.customer_id);
  assert.deepEqual(await at(T(2)), [ID1]);
  assert.deepEqual(await at(T(3)), [ID1], 'ended_at boundary is inclusive');
  assert.deepEqual(await at('2026-03-01T03:30:00Z'), [], 'gap between sessions');
  assert.deepEqual(await at(T(20)), [ID2], 'open session still matches');
  assert.deepEqual(await at(T(0)), []);
  const range = await call('GET', `/api/ops/sessions?ip=100.64.0.7&from=${T(2)}&to=${T(5)}`, { token: A });
  assert.equal(range.body.total, 2);
  assert.equal(range.body.rows[0].customer_code, 'CT2', 'newest first, with customer details');
  const paged = await call('GET', '/api/ops/sessions?pageSize=1&page=2', { token: A });
  assert.deepEqual([paged.body.total, paged.body.rows.length, paged.body.page], [3, 1, 2]);
  assert.equal((await call('GET', '/api/ops/sessions?at=not-a-date', { token: A })).status, 400);
  assert.equal((await call('GET', `/api/ops/sessions?from=${T(5)}&to=${T(2)}`, { token: A })).status, 400);
  assert.equal((await call('GET', '/api/ops/sessions', { token: S })).status, 403);
  assert.equal((await call('GET', '/api/ops/sessions', { token: C1 })).status, 403);
  const csv = await raw('/api/ops/sessions.csv?ip=100.64.0.7', A);
  assert.equal(csv.status, 200);
  assert.match(csv.headers.get('content-disposition'), /attachment; filename="session-log-/);
  const text = await csv.text();
  assert.ok(text.includes('100.64.0.7') && !text.includes('100.64.0.8'));
  assert.ok(text.includes(`"'=HYPERLINK(""x"")"`), 'formula injection neutralised');
  assert.equal((await raw('/api/ops/sessions.csv', S)).status, 403);
  await call('PUT', '/api/settings/modules', { token: A, body: { session_log: false } });
  assert.equal((await call('GET', '/api/ops/sessions', { token: A })).status, 404);
  await call('PUT', '/api/settings/modules', { token: A, body: { session_log: true } });
});
