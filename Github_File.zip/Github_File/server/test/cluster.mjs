// Cluster checks against a running multi-worker server: node test/cluster.mjs [baseUrl]
// 1) login rate limit is shared across workers  2) realtime events cross workers (PostgreSQL LISTEN/NOTIFY)
const BASE = process.argv[2] || 'http://localhost:4000';
const H = { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' };
let fails = 0;
const check = (name, ok, info = '') => { console.log(`  ${ok ? 'ok  ' : 'FAIL'} ${name}`, ok ? '' : info); if (!ok) fails++; };
const post = (p, body, token) => fetch(BASE + p, { method: 'POST', headers: { ...H, ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: JSON.stringify(body) });

// Log in BEFORE the brute-force check (that check deliberately exhausts this IP's shared login allowance).
const login = await (await post('/api/auth/login', { email: 'admin@aura.local', password: 'Admin#Aura2026', client: 'native' })).json();
const T = login.accessToken;
check('admin login', !!T, JSON.stringify(login));

// 1. Shared brute-force protection: 25 wrong passwords spread over many connections/workers.
const victim = `nobody-${Date.now()}@example.com`;
const statuses = [];
await Promise.all(Array.from({ length: 25 }, () => post('/api/auth/login', { email: victim, password: 'wrong-password' }).then((r) => statuses.push(r.status))));
const limited = statuses.filter((s) => s === 429).length;
check(`auth limit enforced cluster-wide (${limited}/25 blocked, limit is 20 per 15 min)`, limited >= 5, statuses.join(','));

// 2. Cross-worker realtime: open SSE streams (they land on different workers), send a broadcast from another request.
const streams = await Promise.all(Array.from({ length: 4 }, async () => {
  const ctrl = new AbortController();
  const res = await fetch(`${BASE}/api/notifications/stream`, { headers: { Authorization: `Bearer ${T}` }, signal: ctrl.signal });
  const reader = res.body.getReader(); const dec = new TextDecoder();
  const got = new Promise((resolve) => {
    let buf = '';
    (async () => { try { for (;;) { const { value, done } = await reader.read(); if (done) break; buf += dec.decode(value); if (buf.includes('Cluster test')) return resolve(true); } } catch { /* aborted */ } resolve(false); })();
    setTimeout(() => resolve(false), 8000);
  });
  return { ctrl, got };
}));
await new Promise((r) => setTimeout(r, 500));
const send = await post('/api/notifications/send', { audience: { type: 'staff' }, channels: ['inapp'], subject: 'Cluster test', body: 'cross-worker delivery' }, T);
check('broadcast accepted', send.status === 200, send.status);
const received = await Promise.all(streams.map((s) => s.got));
streams.forEach((s) => s.ctrl.abort());
check(`realtime event reached all ${received.length} SSE streams (any worker)`, received.every(Boolean), received.join(','));

console.log(fails ? `\n${fails} cluster check(s) FAILED` : '\nAll cluster checks passed');
process.exit(fails ? 1 : 0);
