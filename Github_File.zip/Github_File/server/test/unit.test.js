import { test } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';

process.env.APP_KEY ||= crypto.randomBytes(32).toString('base64');
const { hotp, verifyTotp, generateSecret, base32Encode, base32Decode } = await import('../src/lib/totp.js');
const { encrypt, decrypt, hashPassword, verifyPassword, codeHash, safeEqual } = await import('../src/lib/crypto.js');
const { render } = await import('../src/lib/notify.js');
const { compareVersions, verifySignature } = await import('../src/updater.js');
const { addCycle } = await import('../src/billing/service.js');

test('HOTP matches RFC 4226 test vectors', () => {
  const secret = base32Encode(Buffer.from('12345678901234567890'));
  const expected = ['755224', '287082', '359152', '969429', '338314', '254676', '287922', '162583', '399871', '520489'];
  expected.forEach((code, i) => assert.equal(hotp(secret, i), code));
});

test('TOTP verifies current code and blocks replay', () => {
  const s = generateSecret();
  const step = Math.floor(Date.now() / 30000);
  const code = hotp(s, step);
  const used = verifyTotp(s, code);
  assert.ok(used >= step - 1);
  assert.equal(verifyTotp(s, code, { lastStep: used }), null, 'same code must not be accepted twice');
  assert.equal(verifyTotp(s, '000000x'), null);
});

test('base32 round trip', () => {
  const b = crypto.randomBytes(20);
  assert.deepEqual(base32Decode(base32Encode(b)), b);
});

test('AES-GCM encrypt/decrypt and tamper detection', () => {
  const blob = encrypt('router-secret');
  assert.notEqual(blob, 'router-secret');
  assert.equal(decrypt(blob), 'router-secret');
  const parts = blob.split(':');
  parts[3] = Buffer.from('tampered').toString('base64');
  assert.equal(decrypt(parts.join(':')), null);
  assert.equal(encrypt(''), null);
});

test('argon2id password hashing is one-way and salted', async () => {
  const a = await hashPassword('Correct#Horse9');
  const b = await hashPassword('Correct#Horse9');
  assert.match(a, /^\$argon2id\$/);
  assert.notEqual(a, b, 'salts must differ');
  assert.ok(await verifyPassword(a, 'Correct#Horse9'));
  assert.ok(!(await verifyPassword(a, 'wrong')));
  assert.ok(!(await verifyPassword('garbage', 'x')));
});

test('codeHash normalises backup codes', () => {
  assert.equal(codeHash('abcd-efgh'), codeHash('ABCDEFGH'));
  assert.ok(safeEqual('x', 'x'));
  assert.ok(!safeEqual('x', 'xy'));
});

test('template rendering escapes HTML when requested', () => {
  assert.equal(render('Hi {{user.name}}', { user: { name: '<b>x</b>' } }, { html: true }), 'Hi &lt;b&gt;x&lt;/b&gt;');
  assert.equal(render('{{missing}}!', {}), '!');
});

test('semantic version comparison ignores pre-release tags', () => {
  assert.equal(compareVersions('1.2.0', '1.1.9'), 1);
  assert.equal(compareVersions('v2.0.0', '2.0.0'), 0);
  assert.equal(compareVersions('1.0.0', '1.0.1'), -1);
  assert.equal(compareVersions('1.3.0-beta', '1.0.0'), 0, 'non-stable tags are not comparable');
});

test('update signatures: valid accepted, tampered rejected, missing key refused', () => {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  const pem = publicKey.export({ type: 'spki', format: 'pem' });
  const data = Buffer.from('release-bytes');
  const sig = crypto.sign(null, data, privateKey).toString('base64');
  assert.ok(verifySignature(data, sig, pem));
  assert.ok(!verifySignature(Buffer.from('release-bytes!'), sig, pem));
  assert.throws(() => verifySignature(data, sig, ''), /refusing/);
});

test('billing cycles clamp to month end', () => {
  assert.equal(addCycle('2026-01-31T00:00:00.000Z', 'monthly').toISOString().slice(0, 10), '2026-02-28');
  assert.equal(addCycle('2026-01-15T00:00:00.000Z', 'quarterly').toISOString().slice(0, 10), '2026-04-15');
  assert.equal(addCycle('2026-02-10T00:00:00.000Z', 'yearly').toISOString().slice(0, 10), '2027-02-10');
});
