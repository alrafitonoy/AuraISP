// Enforcement, invoicing rules + override, live chat, avatars, app restrictions.
import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { call, login, close, PASSWORDS, db, BASE } from './helpers.js';

after(close);
const admin = await login('admin@test.local', PASSWORDS.admin);
const staff = await login('support@test.local', PASSWORDS.staff);
const c1 = await login('c1@test.local', PASSWORDS.customer);
const A = admin.accessToken;

test('mobile app is customers-only; desktop is staff-only', async () => {
  const s = await call('POST', '/api/auth/login', { body: { email: 'support@test.local', password: PASSWORDS.staff, app: 'mobile' } });
  assert.equal(s.status, 403);
  const c = await call('POST', '/api/auth/login', { body: { email: 'c1@test.local', password: PASSWORDS.customer, app: 'mobile' } });
  assert.equal(c.status, 200);
  const d = await call('POST', '/api/auth/login', { body: { email: 'c1@test.local', password: PASSWORDS.customer, app: 'desktop' } });
  assert.equal(d.status, 403);
});

test('invoicing rules: min overdue count/amount, grace, override, manual suspension not auto-lifted', async () => {
  const { enforceOverdue } = await import('../src/billing/service.js');
  await call('PUT', '/api/settings/billing', { token: A, body: { graceDays: 3, suspendMinOverdueInvoices: 2, suspendMinOverdueCents: 0, autoSuspend: true } });
  const old = new Date(Date.now() - 10 * 86400000).toISOString();
  const i1 = await call('POST', '/api/billing/invoices', { token: A, body: { customer_id: 1, items: [{ description: 'A', quantity: 1, unit_cents: 1000 }], due_date: old } });
  await enforceOverdue();
  assert.equal((await db().get('SELECT status FROM customers WHERE id = 1')).status, 'active', 'one overdue invoice < rule of 2');
  await call('POST', '/api/billing/invoices', { token: A, body: { customer_id: 1, items: [{ description: 'B', quantity: 1, unit_cents: 1000 }], due_date: old } });
  // Override protects the customer.
  const noReason = await call('POST', '/api/customers/1/override', { token: A, body: { mode: 'never_suspend' } });
  assert.equal(noReason.status, 400);
  await call('POST', '/api/customers/1/override', { token: A, body: { mode: 'never_suspend', reason: 'Hospital — payment promised', until: new Date(Date.now() + 86400000).toISOString() } });
  await enforceOverdue();
  assert.equal((await db().get('SELECT status FROM customers WHERE id = 1')).status, 'active', 'override in force');
  await call('POST', '/api/customers/1/override', { token: A, body: { mode: 'none' } });
  await enforceOverdue();
  const s = await db().get('SELECT status, suspended_reason FROM customers WHERE id = 1');
  assert.deepEqual([s.status, s.suspended_reason], ['suspended', 'overdue']);
  // Paying everything restores an overdue suspension automatically.
  const invs = await db().all("SELECT id, total_cents, paid_cents FROM invoices WHERE customer_id = 1 AND status = 'overdue'");
  for (const i of invs) await call('POST', `/api/billing/invoices/${i.id}/record-payment`, { token: A, body: { amount_cents: i.total_cents - i.paid_cents, method: 'cash' } });
  assert.equal((await db().get('SELECT status FROM customers WHERE id = 1')).status, 'active');
  // Manual suspension is NOT lifted by a payment.
  await call('POST', '/api/customers/1/status', { token: A, body: { status: 'suspended', reason: 'abuse' } });
  const i3 = await call('POST', '/api/billing/invoices', { token: A, body: { customer_id: 1, items: [{ description: 'C', quantity: 1, unit_cents: 500 }] } });
  await call('POST', `/api/billing/invoices/${i3.body.id}/record-payment`, { token: A, body: { amount_cents: 500, method: 'cash' } });
  assert.equal((await db().get('SELECT status FROM customers WHERE id = 1')).status, 'suspended');
  await call('POST', '/api/customers/1/status', { token: A, body: { status: 'active' } });
  void i1;
});

test('data cap: throttle when used up, renew next month', async () => {
  const { enforceDataCaps, allowedSpeed } = await import('../src/network/enforcement.js');
  const { insert } = await import('../src/db/index.js');
  const plan = await db().get('SELECT plan_id FROM customers WHERE id = 2');
  await db().run('UPDATE plans SET data_cap_mb = 100 WHERE id = ?', [plan.plan_id]);
  await insert('traffic_daily', { customer_id: 2, day: new Date().toISOString().slice(0, 10), category: 'total', bytes: 200 * 1024 * 1024 });
  const r1 = await enforceDataCaps();
  assert.ok(r1.capped >= 1);
  const c = await db().get('SELECT c.*, p.download_kbps, p.upload_kbps FROM customers c JOIN plans p ON p.id = c.plan_id WHERE c.id = 2');
  assert.equal(Number(c.cap_exceeded), 1);
  const sp = await allowedSpeed(c);
  assert.equal(sp.throttled, true); assert.equal(sp.downKbps, 512);
  // Rollover while still over the allowance → stays capped (no flapping).
  await db().run("UPDATE customers SET cap_period = '2000-01' WHERE id = 2");
  assert.equal((await enforceDataCaps()).renewed, 0);
  assert.equal(Number((await db().get('SELECT cap_exceeded FROM customers WHERE id = 2')).cap_exceeded), 1);
  // Real new month (no usage yet) → renewed.
  await db().run('DELETE FROM traffic_daily WHERE customer_id = 2');
  await db().run("UPDATE customers SET cap_period = '2000-01' WHERE id = 2");
  const r2 = await enforceDataCaps();
  assert.ok(r2.renewed >= 1);
  assert.equal(Number((await db().get('SELECT cap_exceeded FROM customers WHERE id = 2')).cap_exceeded), 0);
  await db().run('UPDATE plans SET data_cap_mb = 0 WHERE id = ?', [plan.plan_id]);
});

test('speed watchdog re-applies limits for customers above their plan', async () => {
  const { enforceSpeed } = await import('../src/network/enforcement.js');
  const { live } = await import('../src/network/service.js');
  live.perCustomer.set(2, { customer_id: 2, online: true, rx_bps: 900_000_000, tx_bps: 1000, rx_bytes: 0, tx_bytes: 0 });
  const fixed = await enforceSpeed();
  assert.equal(fixed, 1);
  assert.ok(Number((await db().get('SELECT speed_violations FROM customers WHERE id = 2')).speed_violations) >= 1);
  live.perCustomer.clear();
});

test('live chat: guest → agent → lead; tokens isolate conversations', async () => {
  const start = await call('POST', '/api/chat/start', { body: { name: 'Karim Visitor', contact: '+8801711000000', message: 'I want a 100 Mbps connection' } });
  assert.equal(start.status, 201);
  const { id, token } = start.body;
  const noTok = await call('GET', `/api/chat/${id}/messages`);
  assert.equal(noTok.status, 404, 'needs the conversation token');
  const wrong = await call('GET', `/api/chat/${id}/messages`, { headers: { 'X-Chat-Token': 'nope' } });
  assert.equal(wrong.status, 404);
  assert.equal((await call('GET', '/api/chat/conversations', { token: c1.accessToken })).status, 403, 'customers cannot see the inbox');
  const inbox = await call('GET', '/api/chat/conversations?status=open', { token: staff.accessToken });
  assert.ok(inbox.body.rows.some((r) => r.id === id));
  await call('POST', `/api/chat/conversations/${id}/reply`, { token: staff.accessToken, body: { body: 'Hello Karim! Which area are you in?' } });
  const msgs = await call('GET', `/api/chat/${id}/messages`, { headers: { 'X-Chat-Token': token } });
  assert.equal(msgs.body.status, 'active');
  assert.ok(msgs.body.messages.some((m) => m.sender === 'agent' && m.name === 'Support'));
  assert.ok(!JSON.stringify(msgs.body).includes('token_hash'));
  await call('POST', `/api/chat/${id}/messages`, { headers: { 'X-Chat-Token': token }, body: { body: 'Gulshan' } });
  const lead = await call('POST', `/api/chat/conversations/${id}/lead`, { token: staff.accessToken });
  assert.equal(lead.status, 201);
  assert.equal((await db().get('SELECT source FROM leads WHERE id = ?', [lead.body.id])).source, 'chatbot');
  await call('POST', `/api/chat/conversations/${id}/close`, { token: staff.accessToken });
  const after = await call('POST', `/api/chat/${id}/messages`, { headers: { 'X-Chat-Token': token }, body: { body: 'hi' } });
  assert.equal(after.status, 400);
  const guestNoInfo = await call('POST', '/api/chat/start', { body: { message: 'hi' } });
  assert.equal(guestNoInfo.status, 400);
});

test('signed-in customer chat converts to a ticket', async () => {
  const s = await call('POST', '/api/chat/start', { token: c1.accessToken, body: { message: 'My speed is low tonight' } });
  const t = await call('POST', `/api/chat/conversations/${s.body.id}/ticket`, { token: staff.accessToken });
  assert.equal(t.status, 201);
  const own = await call('GET', `/api/chat/${s.body.id}/messages`, { token: c1.accessToken });
  assert.equal(own.status, 200, 'customer reads own chat via session');
});

test('profile picture upload accepts images only', async () => {
  const png = Buffer.from('89504e470d0a1a0a0000000d4948445200000001000000010806000000', 'hex');
  const ok = new FormData(); ok.append('file', new Blob([png], { type: 'image/png' }), 'a.png');
  const r = await fetch(`${BASE}/api/auth/me/avatar`, { method: 'POST', headers: { Authorization: `Bearer ${c1.accessToken}` }, body: ok });
  assert.equal(r.status, 200);
  assert.match((await r.json()).user.avatar, /^\/uploads\/avatars\/[A-Za-z0-9]+\.png$/);
  const bad = new FormData(); bad.append('file', new Blob(['<svg onload=alert(1)>'], { type: 'image/png' }), 'x.png');
  assert.equal((await fetch(`${BASE}/api/auth/me/avatar`, { method: 'POST', headers: { Authorization: `Bearer ${c1.accessToken}` }, body: bad })).status, 400);
  const del = await call('DELETE', '/api/auth/me/avatar', { token: c1.accessToken });
  assert.equal(del.body.user.avatar, null);
});
