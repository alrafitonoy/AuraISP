import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { call, login, close, PASSWORDS, db } from './helpers.js';
import { hotp } from '../src/lib/totp.js';

after(close);

const admin = await login('admin@test.local', PASSWORDS.admin);
const staff = await login('support@test.local', PASSWORDS.staff);
const c1 = await login('c1@test.local', PASSWORDS.customer);
const c2 = await login('c2@test.local', PASSWORDS.customer);

// ------------------------------------------------------------------ authentication
test('login rejects wrong password with a generic message', async () => {
  const a = await call('POST', '/api/auth/login', { body: { email: 'admin@test.local', password: 'nope' } });
  const b = await call('POST', '/api/auth/login', { body: { email: 'nobody@test.local', password: 'nope' } });
  assert.equal(a.status, 401); assert.equal(b.status, 401);
  assert.equal(a.body.error, b.body.error, 'no account enumeration');
});

test('desktop app refuses customer logins', async () => {
  const r = await call('POST', '/api/auth/login', { body: { email: 'c1@test.local', password: PASSWORDS.customer, app: 'desktop' } });
  assert.equal(r.status, 403);
});

test('registration enforces password policy and unique email', async () => {
  const weak = await call('POST', '/api/auth/register', { body: { name: 'New', email: 'new@test.local', phone: '+8801711111111', password: 'short' } });
  assert.equal(weak.status, 400);
  const common = await call('POST', '/api/auth/register', { body: { name: 'New', email: 'new@test.local', phone: '+8801711111111', password: 'Password123456' } });
  assert.equal(common.status, 400);
  const ok = await call('POST', '/api/auth/register', { body: { name: 'New', email: 'new@test.local', phone: '+8801711111111', password: 'Gr8-Fiber-Speed', client: 'native' } });
  assert.equal(ok.status, 201);
  assert.equal(ok.body.user.needsVerification, true);
  const dup = await call('POST', '/api/auth/register', { body: { name: 'New', email: 'new@test.local', phone: '+8801711111111', password: 'Gr8-Fiber-Speed' } });
  assert.equal(dup.status, 409);
  // unverified customers cannot buy plans
  const plans = await call('GET', '/api/portal/plans', { token: ok.body.accessToken });
  const buy = await call('POST', '/api/portal/plans/change', { token: ok.body.accessToken, body: { planId: plans.body.plans[0].id } });
  assert.equal(buy.status, 403);
});

test('refresh tokens rotate; reuse after logout revokes the family', async () => {
  const s = await login('c2@test.local', PASSWORDS.customer);
  const noCsrf = await fetch(`${(await import('./helpers.js')).BASE}/api/auth/refresh`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ refreshToken: s.refreshToken }) });
  assert.equal(noCsrf.status, 403, 'anti-CSRF header required');
  const r1 = await call('POST', '/api/auth/refresh', { body: { refreshToken: s.refreshToken } });
  assert.equal(r1.status, 200);
  const concurrent = await call('POST', '/api/auth/refresh', { body: { refreshToken: s.refreshToken } });
  assert.equal(concurrent.status, 200, 'concurrent refresh within grace window is tolerated');
  await call('POST', '/api/auth/logout', { body: { refreshToken: r1.body.refreshToken } });
  const reuse = await call('POST', '/api/auth/refresh', { body: { refreshToken: r1.body.refreshToken } });
  assert.equal(reuse.status, 401);
  const sibling = await call('POST', '/api/auth/refresh', { body: { refreshToken: concurrent.body.refreshToken } });
  assert.equal(sibling.status, 401, 'whole family revoked after reuse');
});

test('account locks after repeated failures', async () => {
  for (let i = 0; i < 5; i++) await call('POST', '/api/auth/login', { body: { email: 'support@test.local', password: `bad${i}` } });
  const locked = await call('POST', '/api/auth/login', { body: { email: 'support@test.local', password: PASSWORDS.staff } });
  assert.equal(locked.status, 423);
  await db().run("UPDATE users SET locked_until = NULL, failed_logins = 0 WHERE email = 'support@test.local'");
});

test('2FA: setup, enable, login challenge, backup code single use', async () => {
  const s = await login('c1@test.local', PASSWORDS.customer);
  const setup = await call('POST', '/api/auth/2fa/setup', { token: s.accessToken });
  assert.equal(setup.status, 200);
  assert.match(setup.body.qr, /^data:image\/png;base64,/);
  const step = Math.floor(Date.now() / 30000);
  const en = await call('POST', '/api/auth/2fa/enable', { token: s.accessToken, body: { code: hotp(setup.body.secret, step) } });
  assert.equal(en.status, 200);
  assert.equal(en.body.backupCodes.length, 10);
  const first = await call('POST', '/api/auth/login', { body: { email: 'c1@test.local', password: PASSWORDS.customer } });
  assert.equal(first.body.mfaRequired, true);
  assert.equal(first.body.accessToken, undefined);
  const replay = await call('POST', '/api/auth/login/mfa', { body: { challenge: first.body.challenge, code: hotp(setup.body.secret, step) } });
  assert.equal(replay.status, 401, 'TOTP code used for enabling cannot be replayed');
  const backup = en.body.backupCodes[0];
  const ok = await call('POST', '/api/auth/login/mfa', { body: { challenge: first.body.challenge, code: backup } });
  assert.equal(ok.status, 200);
  const again = await call('POST', '/api/auth/login', { body: { email: 'c1@test.local', password: PASSWORDS.customer } });
  const reused = await call('POST', '/api/auth/login/mfa', { body: { challenge: again.body.challenge, code: backup } });
  assert.equal(reused.status, 401, 'backup codes are single use');
  await db().run("UPDATE users SET totp_enabled = 0, totp_secret = NULL WHERE email = 'c1@test.local'");
});

// ------------------------------------------------------------------ authorisation
test('role-based access control', async () => {
  assert.equal((await call('GET', '/api/customers', { token: c1.accessToken })).status, 403);
  assert.equal((await call('GET', '/api/settings', { token: staff.accessToken })).status, 403);
  assert.equal((await call('GET', '/api/staff', { token: staff.accessToken })).status, 403);
  assert.equal((await call('GET', '/api/tickets', { token: staff.accessToken })).status, 200);
  assert.equal((await call('POST', '/api/updates/apply', { token: staff.accessToken })).status, 403);
  assert.equal((await call('GET', '/api/dashboard')).status, 401);
});

test('customers cannot read each other\'s data (IDOR)', async () => {
  const c2Inv = await call('POST', '/api/billing/invoices', { token: admin.accessToken, body: { customer_id: 2, items: [{ description: 'Test', quantity: 1, unit_cents: 1000 }] } });
  assert.equal(c2Inv.status, 201);
  assert.equal((await call('GET', `/api/billing/invoices/${c2Inv.body.id}`, { token: c1.accessToken })).status, 404);
  assert.equal((await call('GET', `/api/billing/invoices/${c2Inv.body.id}/html`, { token: c1.accessToken })).status, 404);
  assert.equal((await call('POST', `/api/billing/invoices/${c2Inv.body.id}/pay`, { token: c1.accessToken, body: { gateway: 'stripe' } })).status, 404);
  const list = await call('GET', '/api/billing/invoices', { token: c1.accessToken });
  assert.ok(list.body.rows.every((i) => i.customer_id === 1));
  const t = await call('POST', '/api/tickets', { token: c2.accessToken, body: { subject: 'Private', body: 'secret info' } });
  assert.equal((await call('GET', `/api/tickets/${t.body.id}`, { token: c1.accessToken })).status, 404);
});

test('customers cannot see internal ticket notes', async () => {
  const t = await call('POST', '/api/tickets', { token: c1.accessToken, body: { subject: 'Slow', body: 'evening speeds' } });
  await call('POST', `/api/tickets/${t.body.id}/messages`, { token: staff.accessToken, body: { body: 'INTERNAL: check OLT port', internal: true } });
  const view = await call('GET', `/api/tickets/${t.body.id}`, { token: c1.accessToken });
  assert.ok(view.body.messages.every((m) => !m.body.includes('INTERNAL')));
  const staffView = await call('GET', `/api/tickets/${t.body.id}`, { token: staff.accessToken });
  assert.ok(staffView.body.messages.some((m) => m.body.includes('INTERNAL')));
});

test('non-admin managers cannot escalate privileges', async () => {
  const mgrRole = await call('POST', '/api/staff/roles', { token: admin.accessToken, body: { name: 'Team Lead', permissions: ['staff.manage', 'tickets.view'], dashboard: [] } });
  await call('POST', '/api/staff', { token: admin.accessToken, body: { name: 'Lead', email: 'lead@test.local', role_id: mgrRole.body.id, password: 'Lead#Test2026x' } });
  const lead = await login('lead@test.local', 'Lead#Test2026x');
  const escalate = await call('POST', '/api/staff/roles', { token: lead.accessToken, body: { name: 'Godmode', permissions: ['settings.manage'], dashboard: [] } });
  assert.equal(escalate.status, 403);
  const adminRole = (await call('GET', '/api/staff/roles', { token: admin.accessToken })).body.roles.find((r) => r.slug === 'manager');
  const assign = await call('POST', '/api/staff', { token: lead.accessToken, body: { name: 'Xavier', email: 'x@test.local', role_id: adminRole.id, password: 'Xx#Test2026xyz' } });
  assert.equal(assign.status, 403);
  const makeAdmin = await call('POST', '/api/staff', { token: lead.accessToken, body: { name: 'Yusuf', email: 'y@test.local', role_id: mgrRole.body.id, type: 'admin', password: 'Yy#Test2026xyz' } });
  assert.equal(makeAdmin.status, 403);
  const editOwn = await call('PUT', `/api/staff/roles/${mgrRole.body.id}`, { token: lead.accessToken, body: { permissions: ['staff.manage', 'tickets.view'] } });
  assert.equal(editOwn.status, 403);
});

// ------------------------------------------------------------------ input validation & hardening
test('rejects prototype pollution, malformed JSON and oversized bodies', async () => {
  assert.equal((await call('POST', '/api/public/contact', { body: '{"name":"a","phone":"123456","__proto__":{"x":1}}' })).status, 403);
  assert.equal((await call('POST', '/api/public/contact', { body: '{bad json' })).status, 400);
  assert.equal((await call('POST', '/api/public/contact', { body: JSON.stringify({ name: 'x'.repeat(2_000_000), phone: '1' }) })).status, 413);
});

test('SQL injection attempts are treated as data', async () => {
  const r = await call('GET', `/api/customers?q=${encodeURIComponent("' OR 1=1 --")}&sort=${encodeURIComponent('name; DROP TABLE users')}`, { token: admin.accessToken });
  assert.equal(r.status, 200);
  assert.equal(r.body.total, 0);
  const still = await call('GET', '/api/customers', { token: admin.accessToken });
  assert.ok(still.body.total >= 2);
});

test('diagnostics reject shell metacharacters', async () => {
  for (const target of ['8.8.8.8; rm -rf /', '$(whoami)', '`id`', 'a|b']) {
    const r = await call('POST', '/api/network/diagnostics', { token: admin.accessToken, body: { test: 'ping', target } });
    assert.equal(r.status, 400, target);
  }
});

test('mass assignment is ignored (unknown fields stripped)', async () => {
  const r = await call('PATCH', '/api/auth/me', { token: c2.accessToken, body: { name: 'Renamed', type: 'admin', role_id: 1 } });
  assert.equal(r.status, 200);
  assert.equal(r.body.user.type, 'customer');
});

test('secrets are masked in settings and preserved on save', async () => {
  await call('PUT', '/api/settings/integrations', { token: admin.accessToken, body: { smtp: { host: 'smtp.test', pass: 'super-secret' } } });
  const s = await call('GET', '/api/settings', { token: admin.accessToken });
  assert.equal(s.body.settings.integrations.smtp.pass, '••••••••');
  assert.ok(!JSON.stringify(s.body).includes('super-secret'));
  await call('PUT', '/api/settings/integrations', { token: admin.accessToken, body: { smtp: { host: 'smtp2.test', pass: '••••••••' } } });
  const raw = await db().get("SELECT value FROM settings WHERE setting_key = 'integrations'");
  assert.ok(!raw.value.includes('super-secret'), 'stored encrypted');
  const { getSetting } = await import('../src/lib/settings.js');
  assert.equal((await getSetting('integrations')).smtp.pass, 'super-secret');
});

test('upload rejects SVG and non-images', async () => {
  const { BASE } = await import('./helpers.js');
  const form = new FormData();
  form.append('file', new Blob(['<svg onload="alert(1)"></svg>'], { type: 'image/svg+xml' }), 'x.svg');
  const r = await fetch(`${BASE}/api/settings/upload`, { method: 'POST', headers: { Authorization: `Bearer ${admin.accessToken}` }, body: form });
  assert.equal(r.status, 400);
});

test('security headers are present', async () => {
  const r = await call('GET', '/api/health');
  assert.ok(r.headers.get('content-security-policy'));
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(r.headers.get('x-powered-by'), null);
});

// ------------------------------------------------------------------ business flows
test('upgrade creates prorated invoice; payment applies plan and records sale', async () => {
  const plans = await call('GET', '/api/portal/plans', { token: c2.accessToken });
  const pro = plans.body.plans.find((p) => p.slug === 'pro');
  assert.ok(pro.quote.chargeCents > 0 && pro.quote.chargeCents < pro.price_cents, 'prorated');
  const ch = await call('POST', '/api/portal/plans/change', { token: c2.accessToken, body: { planId: pro.id } });
  assert.equal(ch.body.kind, 'upgrade');
  assert.ok(ch.body.invoice);
  const over = await call('POST', `/api/billing/invoices/${ch.body.invoice.id}/record-payment`, { token: admin.accessToken, body: { amount_cents: ch.body.invoice.total_cents + 1, method: 'cash' } });
  assert.equal(over.status, 400, 'cannot overpay');
  const pay = await call('POST', `/api/billing/invoices/${ch.body.invoice.id}/record-payment`, { token: admin.accessToken, body: { amount_cents: ch.body.invoice.total_cents, method: 'cash' } });
  assert.equal(pay.status, 201);
  const c = await db().get('SELECT plan_id FROM customers WHERE id = 2');
  assert.equal(c.plan_id, pro.id);
  const sale = await db().get("SELECT * FROM sales WHERE customer_id = 2 AND kind = 'upgrade'");
  assert.ok(sale);
});

test('payment completion is idempotent and validates amount', async () => {
  const { completePayment } = await import('../src/billing/service.js');
  const inv = await call('POST', '/api/billing/invoices', { token: admin.accessToken, body: { customer_id: 1, items: [{ description: 'Idem', quantity: 1, unit_cents: 5000 }] } });
  const { insert, now } = await import('../src/db/index.js');
  const p = await insert('payments', { invoice_id: inv.body.id, customer_id: 1, amount_cents: 5000, method: 'stripe', gateway_ref: 'T-IDEM', status: 'pending', created_at: now() });
  await assert.rejects(completePayment(p.id, { gatewayAmountCents: 100 }), /does not match/);
  const p2 = await insert('payments', { invoice_id: inv.body.id, customer_id: 1, amount_cents: 5000, method: 'stripe', gateway_ref: 'T-IDEM-2', status: 'pending', created_at: now() });
  assert.deepEqual(await completePayment(p2.id, { gatewayAmountCents: 5000 }), { ok: true });
  assert.deepEqual(await completePayment(p2.id, { gatewayAmountCents: 5000 }), { alreadyProcessed: true });
  const after = await db().get('SELECT status, paid_cents FROM invoices WHERE id = ?', [inv.body.id]);
  assert.equal(after.status, 'paid'); assert.equal(Number(after.paid_cents), 5000);
});

test('stripe webhook rejects bad signatures', async () => {
  await call('PUT', '/api/settings/integrations', { token: admin.accessToken, body: { payments: { stripe: { enabled: true, secretKey: 'sk_test_x', webhookSecret: 'whsec_test' } } } });
  const r = await call('POST', '/api/billing/webhooks/stripe', { body: { type: 'checkout.session.completed' }, headers: { 'stripe-signature': 't=1,v1=deadbeef' } });
  assert.equal(r.status, 400);
});

test('overdue enforcement suspends and payment reactivates', async () => {
  const { enforceOverdue } = await import('../src/billing/service.js');
  const inv = await call('POST', '/api/billing/invoices', { token: admin.accessToken, body: { customer_id: 1, items: [{ description: 'Old', quantity: 1, unit_cents: 2000 }], due_date: new Date(Date.now() - 30 * 86400000).toISOString() } });
  await enforceOverdue();
  assert.equal((await db().get('SELECT status FROM customers WHERE id = 1')).status, 'suspended');
  await call('POST', `/api/billing/invoices/${inv.body.id}/record-payment`, { token: admin.accessToken, body: { amount_cents: 2000, method: 'cash' } });
  assert.equal((await db().get('SELECT status FROM customers WHERE id = 1')).status, 'active');
});

test('bandwidth override is stored and parental config validated', async () => {
  const bw = await call('POST', '/api/customers/1/bandwidth', { token: admin.accessToken, body: { download_kbps: 15000, upload_kbps: 5000 } });
  assert.equal(bw.status, 200);
  assert.equal((await db().get('SELECT custom_download_kbps FROM customers WHERE id = 1')).custom_download_kbps, 15000);
  const bad = await call('PUT', '/api/portal/parental', { token: c1.accessToken, body: { enabled: true, blockedDomains: ['not a domain'] } });
  assert.equal(bad.status, 400);
  const good = await call('PUT', '/api/portal/parental', { token: c1.accessToken, body: { enabled: true, blockedCategories: ['gaming'], schedules: [{ from: '22:00', to: '23:30', days: ['mon'] }] } });
  assert.equal(good.status, 200);
});

test('remote support requires customer consent', async () => {
  const s = await call('POST', '/api/network/remote-sessions', { token: admin.accessToken, body: { customer_id: 1 } });
  const blocked = await call('POST', `/api/network/remote-sessions/${s.body.id}/action`, { token: admin.accessToken, body: { action: 'status' } });
  assert.equal(blocked.status, 400);
  const other = await call('POST', `/api/portal/remote-sessions/${s.body.id}/approve`, { token: c2.accessToken });
  assert.equal(other.status, 404, 'another customer cannot approve');
  await call('POST', `/api/portal/remote-sessions/${s.body.id}/approve`, { token: c1.accessToken });
  const ok = await call('POST', `/api/network/remote-sessions/${s.body.id}/action`, { token: admin.accessToken, body: { action: 'status' } });
  assert.equal(ok.status, 200);
});

test('modules can be disabled by the admin', async () => {
  await call('PUT', '/api/settings/modules', { token: admin.accessToken, body: { crm: false } });
  assert.equal((await call('GET', '/api/crm/leads', { token: admin.accessToken })).status, 404);
  await call('PUT', '/api/settings/modules', { token: admin.accessToken, body: { crm: true } });
  assert.equal((await call('GET', '/api/crm/leads', { token: admin.accessToken })).status, 200);
});

test('chatbot answers from the FAQ', async () => {
  const r = await call('POST', '/api/public/chatbot', { body: { message: 'how can I upgrade my plan' } });
  assert.match(r.body.matched, /upgrade/i);
});

test('audit log records security events', async () => {
  const r = await call('GET', '/api/audit?action=auth.', { token: admin.accessToken });
  assert.ok(r.body.rows.some((x) => x.action === 'auth.failed'));
  assert.ok(r.body.rows.some((x) => x.action === 'auth.locked'));
});
