// Boots an isolated app instance on a random port against a THROWAWAY database (removed afterwards):
//   TEST_DB_CLIENT=mysql    -> new database aura_t_<random>   (settings from .env.test.mysql)
//   TEST_DB_CLIENT=postgres -> new schema  t_<random>         (settings from .env.test.postgres)
//   TEST_DB_CLIENT=sqlite   -> temp file                      (no server needed)
import os from 'node:os';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const client = (process.env.TEST_DB_CLIENT || 'mysql').toLowerCase();
dotenv.config({ path: path.join(root, `.env.test.${client}`), override: true, quiet: true });
const suffix = crypto.randomBytes(5).toString('hex');
process.env.DB_CLIENT = client;
process.env.APP_KEY = crypto.randomBytes(32).toString('base64');
process.env.NODE_ENV = 'test';
process.env.DISABLE_SCHEDULER = 'true';
process.env.WEB_DIST = path.join(root, 'data', 'no-web');
process.env.RATE_LIMIT_GLOBAL = '100000';
// Uploads/backups made by tests go to a throwaway folder, never into the real server/data.
const testDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'aura-test-data-'));
process.env.DATA_DIR = testDataDir;

let cleanup = async () => {};
if (client === 'sqlite') {
  const file = path.join(os.tmpdir(), `aura-test-${suffix}.db`);
  process.env.SQLITE_FILE = file;
  cleanup = async () => { for (const f of [file, `${file}-wal`, `${file}-shm`]) fs.rmSync(f, { force: true }); };
} else if (client === 'postgres') {
  process.env.DB_SCHEMA = `t_${suffix}`;
  const { default: config } = await import('../src/config.js');
  const { pgOptions } = await import('../src/db/index.js');
  const pg = (await import('pg')).default;
  const admin = new pg.Client(pgOptions({ ...config.db, schema: 'public' }));
  await admin.connect();
  await admin.query(`CREATE SCHEMA t_${suffix}`);
  cleanup = async () => { await admin.query(`DROP SCHEMA t_${suffix} CASCADE`).catch(() => {}); await admin.end().catch(() => {}); };
} else {
  const name = `aura_t_${suffix}`;
  const { default: config } = await import('../src/config.js');
  const { mysqlOptions } = await import('../src/db/index.js');
  const mysql = await import('mysql2/promise');
  const admin = await mysql.createConnection({ ...mysqlOptions({ ...config.db }), database: undefined });
  await admin.query(`CREATE DATABASE ${name} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
  process.env.DB_NAME = name;
  cleanup = async () => { await admin.query(`DROP DATABASE ${name}`).catch(() => {}); await admin.end().catch(() => {}); };
}

// Apply DB_NAME / SQLITE_FILE / DB_SCHEMA set above to the shared config WITHOUT re-reading the real .env.
const { default: cfg, dbConfig } = await import('../src/config.js');
cfg.db = dbConfig();
cfg.appKey = process.env.APP_KEY;
if (cfg.db.client !== client) throw new Error(`Test DB mismatch: expected ${client}, got ${cfg.db.client}`);
if (client !== 'sqlite' && !/^(aura_t_|aura_test$)/.test(cfg.db.database) && !cfg.db.schema?.startsWith('t_')) throw new Error(`Refusing to run tests against non-test database "${cfg.db.database}"`);
const { initDb, db, insert, now, closeDb } = await import('../src/db/index.js');
const { migrate } = await import('../src/db/migrate.js');
const { seedDefaults } = await import('../src/db/seed.js');
const { createApp } = await import('../src/app.js');
const { hashPassword } = await import('../src/lib/crypto.js');

await initDb();
await migrate(() => {});
await seedDefaults();

export const PASSWORDS = { admin: 'Admin#Test2026x', staff: 'Staff#Test2026x', customer: 'Cust#Test2026xx' };
export const DB_CLIENT = client;

const role = async (slug) => (await db().get('SELECT id FROM roles WHERE slug = ?', [slug])).id;
await insert('users', { type: 'admin', role_id: await role('admin'), name: 'Admin', email: 'admin@test.local', password_hash: await hashPassword(PASSWORDS.admin), status: 'active', email_verified_at: now(), created_at: now(), updated_at: now() });
await insert('users', { type: 'staff', role_id: await role('support'), name: 'Support', email: 'support@test.local', password_hash: await hashPassword(PASSWORDS.staff), status: 'active', email_verified_at: now(), created_at: now(), updated_at: now() });
for (const n of [1, 2]) {
  const u = await insert('users', { type: 'customer', role_id: await role('customer'), name: `Customer ${n}`, email: `c${n}@test.local`, phone: '+8801700000000', password_hash: await hashPassword(PASSWORDS.customer), status: 'active', email_verified_at: now(), created_at: now(), updated_at: now() });
  const plan = await db().get("SELECT id FROM plans WHERE slug = 'home'");
  await insert('customers', { user_id: u.id, code: `CT${n}`, status: 'active', plan_id: plan.id, ip_address: `10.9.9.${n}`, next_due_date: new Date(Date.now() + 15 * 86400000).toISOString(), created_at: now(), updated_at: now() });
}

const server = createApp().listen(0);
const port = server.address().port;
export const BASE = `http://127.0.0.1:${port}`;

export async function call(method, p, { body, token, headers = {} } = {}) {
  const res = await fetch(BASE + p, {
    method,
    headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...headers },
    body: body === undefined ? undefined : typeof body === 'string' ? body : JSON.stringify(body),
  });
  const text = await res.text();
  let json; try { json = JSON.parse(text); } catch { json = text; }
  return { status: res.status, body: json, headers: res.headers };
}

export async function login(email, password) {
  const r = await call('POST', '/api/auth/login', { body: { email, password, client: 'native' } });
  if (r.status !== 200) throw new Error(`login failed ${r.status} ${JSON.stringify(r.body)}`);
  return r.body;
}

export { db };
export async function close() {
  server.close();
  await closeDb().catch(() => {});
  await cleanup();
  fs.rmSync(testDataDir, { recursive: true, force: true });
}
