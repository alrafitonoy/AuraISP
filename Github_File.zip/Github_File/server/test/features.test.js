import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { call, login, close, PASSWORDS, db, BASE } from './helpers.js';
import { parseCidr, ipToInt, intToIp } from '../src/network/ipam.js';
import { normalizeFingerprint, pinnedTlsSocket } from '../src/network/drivers.js';

after(close);
const admin = await login('admin@test.local', PASSWORDS.admin);
const staff = await login('support@test.local', PASSWORDS.staff);
const c1 = await login('c1@test.local', PASSWORDS.customer);
const A = admin.accessToken;

async function raw(method, path, { token, body } = {}) {
  return fetch(BASE + path, { method, headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest', ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
}

// ------------------------------------------------------------------ IPAM
test('CIDR math', () => {
  const n = parseCidr('203.0.113.7/29');
  assert.equal(intToIp(n.network), '203.0.113.0');
  assert.equal(intToIp(n.first), '203.0.113.1');
  assert.equal(intToIp(n.last), '203.0.113.6');
  assert.equal(intToIp(ipToInt('255.255.255.255')), '255.255.255.255');
  assert.throws(() => parseCidr('10.0.0.0/8'), /between/);
  assert.throws(() => ipToInt('300.1.1.1'));
});

test('pools: public required for real/dedicated, overlap rejected', async () => {
  const bad = await call('POST', '/api/network/ipam/pools', { token: A, body: { name: 'Bad', kind: 'real', cidr: '10.0.0.0/29' } });
  assert.equal(bad.status, 400);
  const real = await call('POST', '/api/network/ipam/pools', { token: A, body: { name: 'Public /29', kind: 'real', cidr: '203.0.113.0/29', gateway: '203.0.113.1', monthly_price_cents: 30000 } });
  assert.equal(real.status, 201); assert.equal(real.body.hosts, 6);
  const dup = await call('POST', '/api/network/ipam/pools', { token: A, body: { name: 'Overlap', kind: 'dedicated', cidr: '203.0.113.0/30' } });
  assert.equal(dup.status, 409);
  const shared = await call('POST', '/api/network/ipam/pools', { token: A, body: { name: 'CGNAT', kind: 'shared', cidr: '100.64.0.0/28', nat_address: '198.51.100.10' } });
  assert.equal(shared.status, 201);
  const ded = await call('POST', '/api/network/ipam/pools', { token: A, body: { name: 'Dedicated', kind: 'dedicated', cidr: '198.51.100.32/30', monthly_price_cents: 50000 } });
  assert.equal(ded.status, 201);
  const gw = await db().get("SELECT status FROM ip_addresses WHERE address = '203.0.113.1'");
  assert.equal(gw.status, 'reserved', 'gateway is reserved automatically');
});

test('assign, move and release customer IPs (one IP per customer)', async () => {
  const a = await call('POST', '/api/network/ipam/assign', { token: A, body: { customer_id: 1, kind: 'real' } });
  assert.equal(a.status, 200); assert.equal(a.body.address, '203.0.113.2'); assert.equal(a.body.monthlyCents, 30000);
  let c = await db().get('SELECT ip_address, ip_type, ip_addon_cents FROM customers WHERE id = 1');
  assert.deepEqual([c.ip_address, c.ip_type, Number(c.ip_addon_cents)], ['203.0.113.2', 'real', 30000]);
  const taken = await call('POST', '/api/network/ipam/assign', { token: A, body: { customer_id: 2, address: '203.0.113.2' } });
  assert.equal(taken.status, 409, 'cannot steal an assigned address');
  const move = await call('POST', '/api/network/ipam/assign', { token: A, body: { customer_id: 1, kind: 'shared' } });
  assert.equal(move.body.kind, 'shared');
  const old = await db().get("SELECT status FROM ip_addresses WHERE address = '203.0.113.2'");
  assert.equal(old.status, 'free', 'previous address released');
  c = await db().get('SELECT ip_addon_cents FROM customers WHERE id = 1');
  assert.equal(Number(c.ip_addon_cents), 0, 'shared IPs are free');
  await call('POST', '/api/network/ipam/release', { token: A, body: { customer_id: 1 } });
  c = await db().get('SELECT ip_address FROM customers WHERE id = 1');
  assert.equal(c.ip_address, null);
  assert.equal((await call('POST', '/api/network/ipam/assign', { token: staff.accessToken, body: { customer_id: 1, kind: 'real' } })).status, 403);
  assert.equal((await call('GET', '/api/network/ipam/pools', { token: c1.accessToken })).status, 403);
});

test('dedicated IP charge is added to the recurring invoice', async () => {
  await call('POST', '/api/network/ipam/assign', { token: A, body: { customer_id: 2, kind: 'dedicated' } });
  await db().run('UPDATE customers SET next_due_date = ? WHERE id = 2', [new Date(Date.now() + 86400000).toISOString()]);
  const { generateRecurringInvoices } = await import('../src/billing/service.js');
  await generateRecurringInvoices();
  const inv = await db().get('SELECT items FROM invoices WHERE customer_id = 2 ORDER BY id DESC LIMIT 1');
  assert.ok(JSON.parse(inv.items).some((i) => /Dedicated IP/.test(i.description) && i.unit_cents === 50000));
});

test('assigned addresses cannot be blocked without release', async () => {
  const a = await db().get("SELECT id FROM ip_addresses WHERE status = 'assigned' LIMIT 1");
  assert.equal((await call('PATCH', `/api/network/ipam/addresses/${a.id}`, { token: A, body: { status: 'blocked' } })).status, 400);
});

// ------------------------------------------------------------------ capacity / core
test('capacity analysis: detected when unconfigured, configured when links exist', async () => {
  const { insert, now } = await import('../src/db/index.js');
  for (let i = 0; i < 5; i++) await insert('usage_samples', { customer_id: 1, ts: new Date(Date.now() - i * 60000).toISOString(), rx_bps: 90_000_000, tx_bps: 5_000_000 });
  const d = await call('GET', '/api/network/capacity', { token: A });
  assert.equal(d.status, 200); assert.equal(d.body.source, 'detected');
  assert.ok(d.body.capacity.downKbps >= 100000, 'rounded up to a standard circuit');
  assert.ok(d.body.customers.find((x) => x.id === 1).flags.includes('over_limit'), '90 Mbps on a 25 Mbps plan is flagged');
  await call('POST', '/api/network/upstream-links', { token: A, body: { name: 'Transit A', capacity_down_kbps: 1_000_000, capacity_up_kbps: 1_000_000 } });
  const c = await call('GET', '/api/network/capacity', { token: A });
  assert.equal(c.body.source, 'configured'); assert.equal(c.body.capacity.downKbps, 1_000_000);
  assert.ok(c.body.oversubscription > 0);
  void now;
});

test('router discovery and import of existing PPPoE users', async () => {
  const r = await call('POST', '/api/network/routers', { token: A, body: { name: 'Core sim', driver: 'simulator', role: 'core' } });
  const d = await call('POST', `/api/network/routers/${r.body.id}/discover`, { token: A });
  assert.equal(d.status, 200); assert.equal(d.body.wanInterface, 'ether1-wan');
  const imp = await call('POST', `/api/network/routers/${r.body.id}/import`, { token: A, body: { secrets: d.body.pppSecrets.map((s) => ({ name: s.name, remoteAddress: s.remoteAddress, profile: s.profile })) } });
  assert.equal(imp.body.created, 2);
  const again = await call('POST', `/api/network/routers/${r.body.id}/import`, { token: A, body: { secrets: [{ name: 'sim-import-01' }] } });
  assert.equal(again.body.created, 0, 'no duplicates');
  const bad = await call('POST', `/api/network/routers/${r.body.id}/import`, { token: A, body: { secrets: [{ name: "x'; DROP TABLE users;--" }] } });
  assert.equal(bad.status, 400);
});

test('router TLS pinning rejects a wrong certificate before sending credentials', async () => {
  assert.equal(normalizeFingerprint('ab:cd:01'), 'ABCD01');
  const https = await import('node:https');
  const { X509Certificate } = await import('node:crypto');
  const creds = await selfSigned();
  const server = https.createServer(creds, (_q, res) => res.end('{}')).listen(0);
  const port = server.address().port;
  await assert.rejects(pinnedTlsSocket('127.0.0.1', port, 'A'.repeat(64)), /does not match/);
  const realPin = normalizeFingerprint(new X509Certificate(creds.cert).fingerprint256);
  const sock = await pinnedTlsSocket('127.0.0.1', port, realPin);
  assert.ok(sock.encrypted, 'correct pin connects');
  sock.destroy();
  server.close();
});

async function selfSigned() {
  // Tiny fixed test certificate (not secret, test-only) generated for CN=localhost.
  const dir = new URL('./fixtures/', import.meta.url);
  return { key: fs.readFileSync(new URL('test-key.pem', dir)), cert: fs.readFileSync(new URL('test-cert.pem', dir)) };
}

// ------------------------------------------------------------------ PDFs
test('PDF invoice and reports are generated with access control', async () => {
  const inv = await call('POST', '/api/billing/invoices', { token: A, body: { customer_id: 1, items: [{ description: 'Fiber 25 Mbps — month', quantity: 1, unit_cents: 80000 }] } });
  const own = await raw('GET', `/api/pdf/invoices/${inv.body.id}`, { token: c1.accessToken });
  assert.equal(own.status, 200); assert.equal(own.headers.get('content-type'), 'application/pdf');
  assert.equal(Buffer.from(await own.arrayBuffer()).subarray(0, 5).toString(), '%PDF-');
  const other = await call('POST', '/api/billing/invoices', { token: A, body: { customer_id: 2, items: [{ description: 'x', quantity: 1, unit_cents: 100 }] } });
  assert.equal((await raw('GET', `/api/pdf/invoices/${other.body.id}`, { token: c1.accessToken })).status, 404);
  for (const t of ['accounts', 'sales', 'overall']) {
    const r = await raw('GET', `/api/pdf/reports/${t}?from=2020-01-01&to=2030-12-31`, { token: A });
    assert.equal(r.status, 200, t);
    assert.ok((await r.arrayBuffer()).byteLength > 1500);
    assert.equal((await raw('GET', `/api/pdf/reports/${t}`, { token: c1.accessToken })).status, 403, `${t} hidden from customers`);
  }
  const stmt = await raw('GET', '/api/pdf/reports/customer?customer_id=2', { token: c1.accessToken });
  assert.equal(stmt.status, 200, 'customer gets own statement');
  const staffStmt = await raw('GET', '/api/pdf/reports/customer?customer_id=1', { token: A });
  assert.equal(staffStmt.status, 200);
  assert.equal((await raw('GET', '/api/pdf/reports/accounts?from=bad', { token: A })).status, 400);
});

// ------------------------------------------------------------------ backups
test('database backup, encrypted full backup, restore and access control', async () => {
  assert.equal((await call('GET', '/api/backups', { token: staff.accessToken })).status, 403);
  const b = await call('POST', '/api/backups', { token: A, body: { kind: 'database' } });
  assert.equal(b.status, 201); assert.ok(b.body.manifest.counts.users >= 4);
  const envNoPass = await call('POST', '/api/backups', { token: A, body: { kind: 'full', includeEnv: true } });
  assert.equal(envNoPass.status, 400, 'master key never leaves unencrypted');
  const full = await call('POST', '/api/backups', { token: A, body: { kind: 'full', passphrase: 'correct horse battery' } });
  assert.equal(full.status, 201); assert.ok(full.body.file.endsWith('.enc'));

  const noPw = await call('POST', `/api/backups/${b.body.id}/download`, { token: A, body: { password: 'wrong' } });
  assert.equal(noPw.status, 400);
  const dl = await raw('POST', `/api/backups/${b.body.id}/download`, { token: A, body: { password: PASSWORDS.admin } });
  assert.equal(dl.status, 200);
  const bytes = Buffer.from(await dl.arrayBuffer());
  assert.equal(bytes[0], 0x1f); assert.equal(bytes[1], 0x8b);

  // change data, then restore and verify it comes back
  await db().run("UPDATE users SET name = 'CHANGED' WHERE email = 'c1@test.local'");
  const restore = await call('POST', `/api/backups/${b.body.id}/restore`, { token: A, body: { password: PASSWORDS.admin, restoreFiles: false } });
  assert.equal(restore.status, 200, JSON.stringify(restore.body));
  assert.equal((await db().get("SELECT name FROM users WHERE email = 'c1@test.local'")).name, 'Customer 1');
  assert.ok(restore.body.safetyBackup, 'safety backup taken before restore');
  assert.equal(Number((await db().get('SELECT COUNT(*) AS n FROM sessions')).n), 0, 'all sessions revoked after restore');

  const fresh = await login('admin@test.local', PASSWORDS.admin);
  const wrongPass = await call('POST', `/api/backups/${full.body.id}/restore`, { token: fresh.accessToken, body: { password: PASSWORDS.admin, passphrase: 'nope nope nope', restoreFiles: false } });
  assert.equal(wrongPass.status, 400);
  assert.match(wrongPass.body.error, /passphrase/i);
});
