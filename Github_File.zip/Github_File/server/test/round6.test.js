// Round 6: recipients without accounts, billing PDFs (invoice + receipt), diagnostics SSRF guard, connection details,
// branding display mode, website framing.
import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { call, login, close, PASSWORDS, db, BASE } from './helpers.js';
import { insert, now } from '../src/db/index.js';

after(close);
const admin = await login('admin@test.local', PASSWORDS.admin);
const A = admin.accessToken;

test('broadcast to plain email addresses and to CRM leads (no app account) is accepted and logged', async () => {
  const bad = await call('POST', '/api/notifications/send', { token: A, body: { audience: { type: 'emails', value: ['a@example.com'] }, channels: ['push'], subject: 'x', body: 'y' } });
  assert.equal(bad.status, 400, 'push cannot reach people without an account');
  const r = await call('POST', '/api/notifications/send', { token: A, body: { audience: { type: 'emails', value: ['partner@example.com', 'not-an-email', 'PARTNER@example.com'] }, channels: ['email'], subject: 'Hello {{name}}', body: 'Hi' } });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal(r.body.queued, 1, 'invalid and duplicate addresses dropped');
  await insert('leads', { name: 'Lead Six', email: 'lead6@example.com', phone: '01700000006', status: 'new', created_at: now(), updated_at: now() });
  const l = await call('POST', '/api/notifications/send', { token: A, body: { audience: { type: 'leads', value: 'new' }, channels: ['email', 'sms'], subject: 'Offer', body: 'Hi {{name}}' } });
  assert.equal(l.status, 200);
  assert.ok(l.body.queued >= 1);
  await new Promise((res) => setTimeout(res, 300));
  const logged = await db().get("SELECT COUNT(*) AS n FROM notification_log WHERE recipient IN ('partner@example.com', 'lead6@example.com')");
  assert.ok(Number(logged.n) >= 2, 'attempts are logged (they fail without SMTP, which is expected here)');
  const camp = await call('POST', '/api/crm/campaigns', { token: A, body: { name: 'Leads camp', channels: ['email'], audience: { type: 'leads' }, subject: 'S', body: 'B' } });
  assert.equal(camp.status, 201);
  const size = await call('POST', `/api/crm/campaigns/${camp.body.id}/audience-size`, { token: A, body: {} });
  assert.ok(size.body.size >= 1);
});

test('invoice and payment receipt PDFs: rendered for attachments, receipt downloadable by its owner only', async () => {
  const { billingAttachments } = await import('../src/reports/pdf.js');
  const inv = await call('POST', '/api/billing/invoices', { token: A, body: { customer_id: 1, items: [{ description: 'Router', quantity: 1, unit_cents: 50000 }] } });
  assert.equal(inv.status, 201);
  const pay = await call('POST', `/api/billing/invoices/${inv.body.id}/record-payment`, { token: A, body: { amount_cents: 50000, method: 'cash', reference: 'R6' } });
  assert.equal(pay.status, 201);
  const files = await billingAttachments({ invoiceId: inv.body.id, paymentId: pay.body.id });
  assert.equal(files.length, 2);
  for (const f of files) assert.equal(f.content.subarray(0, 5).toString(), '%PDF-', `${f.filename} is a PDF`);
  const c1 = await login('c1@test.local', PASSWORDS.customer);
  const c2 = await login('c2@test.local', PASSWORDS.customer);
  const own = await fetch(`${BASE}/api/pdf/payments/${pay.body.id}`, { headers: { Authorization: `Bearer ${c1.accessToken}` } });
  assert.equal(own.status, 200);
  assert.match(own.headers.get('content-type'), /pdf/);
  const other = await fetch(`${BASE}/api/pdf/payments/${pay.body.id}`, { headers: { Authorization: `Bearer ${c2.accessToken}` } });
  assert.equal(other.status, 404, 'another customer cannot fetch the receipt');
  assert.equal((await call('PUT', '/api/settings/billing', { token: A, body: { emailPdf: false } })).status, 200);
});

test('diagnostics refuse loopback / link-local / metadata targets but allow customer ranges', async () => {
  for (const t of ['127.0.0.1', 'localhost', '169.254.169.254', '0.0.0.0', '::1']) {
    const r = await call('POST', '/api/network/diagnostics', { token: A, body: { test: 'ping', target: t } });
    assert.equal(r.status, 400, `${t} must be refused`);
  }
  const port = await call('POST', '/api/network/diagnostics', { token: A, body: { test: 'port', target: '127.0.0.1:22' } });
  assert.equal(port.status, 400);
  const ok = await call('POST', '/api/network/diagnostics', { token: A, body: { test: 'ping', target: '100.64.0.10' } });
  assert.equal(ok.status, 200, 'CGNAT customer address can be tested');
});

test('customer detail explains the connection from its IP pool', async () => {
  const pool = await call('POST', '/api/network/ipam/pools', { token: A, body: { name: 'CGNAT6', kind: 'shared', cidr: '100.70.0.0/29', gateway: '100.70.0.1', dns: '1.1.1.1', nat_address: '203.0.113.66' } });
  assert.equal(pool.status, 201);
  const a = await call('POST', '/api/network/ipam/assign', { token: A, body: { customer_id: 2, pool_id: pool.body.id } });
  assert.equal(a.status, 200);
  const d = (await call('GET', '/api/customers/2', { token: A })).body;
  assert.equal(d.connection.ipType, 'shared');
  assert.equal(d.connection.pool.natAddress, '203.0.113.66');
  assert.equal(d.connection.pool.gateway, '100.70.0.1');
  assert.equal(d.connection.pool.netmask, '255.255.255.248');
});

test('branding display mode is validated and published; the site may be framed by itself only', async () => {
  assert.equal((await call('PUT', '/api/settings/branding', { token: A, body: { logoDisplay: 'sideways' } })).status, 400);
  assert.equal((await call('PUT', '/api/settings/branding', { token: A, body: { logoDisplay: 'name' } })).status, 200);
  const cfg = await call('GET', '/api/public/config');
  assert.equal(cfg.body.branding.logoDisplay, 'name');
  const res = await fetch(`${BASE}/api/health`);
  assert.match(res.headers.get('content-security-policy'), /frame-ancestors 'self'/);
});
