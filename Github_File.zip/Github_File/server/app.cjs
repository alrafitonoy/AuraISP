// Entry point for cPanel "Setup Node.js App" (Phusion Passenger) and other CommonJS-only launchers.
// Set "Application startup file" to: app.cjs
import('./src/index.js').catch((e) => { console.error(e); process.exit(1); });
