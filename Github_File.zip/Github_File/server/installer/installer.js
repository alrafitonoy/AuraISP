(() => {
  const $ = (id) => document.getElementById(id);
  let token = '';
  let dbOk = false;
  let client = 'mysql';
  const PORTS = { mysql: 3306, postgres: 5432 };
  const ADMIN = { mysql: 'root', postgres: 'postgres' };
  const LABELS = { mysql: 'MySQL / MariaDB', postgres: 'PostgreSQL', sqlite: 'SQLite' };

  function pick(c) {
    client = c; dbOk = false; $('toSite').classList.add('hidden'); $('dbResult').replaceChildren();
    document.querySelectorAll('.dbopt').forEach((b) => { b.classList.toggle('on', b.dataset.client === c); b.setAttribute('aria-pressed', String(b.dataset.client === c)); });
    $('sqliteFields').classList.toggle('hidden', c !== 'sqlite');
    $('serverFields').classList.toggle('hidden', c === 'sqlite');
    if (c !== 'sqlite') { $('dbPort').value = PORTS[c]; $('suUser').value = ADMIN[c]; }
    const w = $('workers');
    w.disabled = c === 'sqlite';
    if (c === 'sqlite') w.value = '1';
  }
  document.querySelectorAll('.dbopt').forEach((b) => b.addEventListener('click', () => pick(b.dataset.client)));

  // Developer credit popup
  $('creditBtn').addEventListener('click', () => $('creditPop').classList.remove('hidden'));
  $('creditClose').addEventListener('click', () => $('creditPop').classList.add('hidden'));
  $('creditPop').addEventListener('click', (e) => { if (e.target === $('creditPop')) $('creditPop').classList.add('hidden'); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') $('creditPop').classList.add('hidden'); });

  const show = (n) => {
    document.querySelectorAll('[data-panel]').forEach((p) => p.classList.toggle('hidden', p.dataset.panel !== String(n)));
    document.querySelectorAll('#steps li').forEach((li) => {
      const s = Number(li.dataset.step);
      li.classList.toggle('on', s === n); li.classList.toggle('done', s < n);
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  const text = (el, t) => { el.textContent = t; return el; };
  const li = (cls, t) => text(Object.assign(document.createElement('li'), { className: cls }), t);
  const msg = (el, cls, t) => { el.replaceChildren(text(Object.assign(document.createElement('div'), { className: cls }), t)); };

  async function call(path, body) {
    const res = await fetch(`/install/api/${path}`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Install-Token': token }, body: JSON.stringify(body || {}) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
    return data;
  }
  const busy = (btn, on) => { btn.disabled = on; };

  // ---- step 1
  $('verify').addEventListener('click', async () => {
    token = $('token').value.trim();
    const list = $('checks'); list.replaceChildren();
    busy($('verify'), true);
    try {
      const s = await call('status');
      const items = [
        [s.nodeOk, `Node.js ${s.node} (20 or newer required)`],
        [s.depsInstalled, 'Server dependencies present (node_modules)'],
        [s.webBuilt, 'Web application files present (web/dist)'],
        [s.dataWritable, 'server/data is writable'],
        [s.envWritable, 'server folder is writable (for the .env file)'],
      ];
      items.forEach(([ok, t]) => list.append(li(ok ? 'ok' : 'bad', t)));
      const allOk = items.every(([ok]) => ok);
      $('toDb').classList.toggle('hidden', !allOk);
      const env = s.environment;
      if (env) {
        const hostingLabel = { shared: 'Shared hosting (cPanel)', vps: 'VPS / dedicated server', container: 'Container (Docker)', small: 'Small server' }[env.hosting];
        list.append(li('ok', `Environment: ${hostingLabel} · ${env.cpus} CPU cores · ${env.memGb} GB RAM · MySQL here: ${env.mysqlLocal ? 'yes' : 'no'} · PostgreSQL here: ${env.pgLocal ? 'yes' : 'no'} · SQLite: ${env.sqliteOk ? 'available' : 'needs Node 22.13+'}`));
        document.querySelectorAll('.dbopt').forEach((b) => b.querySelector('.rec').classList.toggle('hidden', b.dataset.client !== env.recommended));
        if (!env.sqliteOk) document.querySelector('.dbopt[data-client="sqlite"]').setAttribute('disabled', '');
        text($('recBox'), `Recommended for this server: ${LABELS[env.recommended]}. ${env.reason}`);
        pick(env.recommended);
      }
      if (!allOk) list.append(li('bad', 'Fix the items above, then click Verify again.'));
    } catch (e) { list.append(li('bad', e.message)); }
    busy($('verify'), false);
  });
  $('toDb').addEventListener('click', () => show(2));

  // ---- step 2
  $('dbSsl').addEventListener('change', () => $('caWrap').classList.toggle('hidden', $('dbSsl').value === 'disable'));
  $('createDb').addEventListener('change', () => $('adminDb').classList.toggle('hidden', !$('createDb').checked));
  const dbBody = () => (client === 'sqlite' ? { client, sqliteFile: $('sqFile').value.trim() } : {
    client,
    host: $('dbHost').value.trim(), port: Number($('dbPort').value), database: $('dbName').value.trim(), user: $('dbUser').value.trim(),
    password: $('dbPass').value, ssl: $('dbSsl').value, sslCa: $('dbCa').value.trim(),
    createWithAdmin: $('createDb').checked, adminUser: $('suUser').value.trim(), adminPassword: $('suPass').value,
  });
  $('testDb').addEventListener('click', async () => {
    busy($('testDb'), true); dbOk = false;
    try {
      const r = await call('test-db', dbBody());
      if (r.generatedPassword) msg($('dbResult'), 'info', 'Connected. A strong database password will be generated and stored in server/.env.');
      else msg($('dbResult'), 'info', `OK — ${r.version}${r.ssl ? ' over verified TLS' : ''}.${r.created ? ' Database and user created.' : ''}${r.existingTables ? ` Note: the database already has ${r.existingTables} table(s).` : ''}`);
      if (r.superuser) msg($('dbResult'), 'err', 'This database user has ADMIN/superuser rights. For security use a dedicated limited user (tick "Create the database and user for me").');
      else dbOk = true;
    } catch (e) { msg($('dbResult'), 'err', e.message); }
    $('toSite').classList.toggle('hidden', !dbOk);
    busy($('testDb'), false);
  });
  $('back1').addEventListener('click', () => show(1));
  $('toSite').addEventListener('click', () => { if (!$('appUrl').value) $('appUrl').value = location.origin; show(3); });

  // ---- step 3 + 4
  $('back2').addEventListener('click', () => show(2));
  $('install').addEventListener('click', async () => {
    const err = $('siteErr'); err.replaceChildren();
    if ($('aPass').value !== $('aPass2').value) return msg(err, 'err', 'Passwords do not match');
    const body = {
      db: dbBody(),
      site: { appUrl: $('appUrl').value.trim(), companyName: $('company').value.trim(), email: $('email').value.trim(), phone: $('phone').value.trim(), currency: $('currency').value.trim().toUpperCase(), currencySymbol: $('symbol').value.trim(), timezone: $('tz').value.trim(), workers: $('workers').value === 'max' ? 'max' : Number($('workers').value) },
      admin: { name: $('aName').value.trim(), email: $('aEmail').value.trim(), password: $('aPass').value },
    };
    busy($('install'), true);
    show(4);
    const prog = $('progress'); prog.replaceChildren(li('run', 'Installing — this can take up to a minute…'));
    try {
      const r = await call('install', body);
      prog.replaceChildren(...r.steps.map((s) => li('ok', s)));
      if (r.restartForWorkers) prog.append(li('ok', 'Running in single-process mode now. Restart the app once (cPanel "Restart" / pm2 restart) to enable load-balanced workers.'));
      text($('doneTitle'), 'Installed 🎉');
      $('doneBox').classList.remove('hidden');
      ['dbPass', 'suPass', 'aPass', 'aPass2', 'token'].forEach((id) => { $(id).value = ''; });
    } catch (e) {
      prog.replaceChildren(li('bad', e.message));
      busy($('install'), false);
      setTimeout(() => show(3), 2500);
      msg(err, 'err', e.message);
    }
  });
})();
