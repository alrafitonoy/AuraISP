// Branded PDF generation: invoices and Customer / Accounts / Sales / Overall reports.
import PDFDocument from 'pdfkit';
import { PassThrough } from 'node:stream';
import { db, parseJson } from '../db/index.js';
import { getSetting } from '../lib/settings.js';
import { analyse } from '../network/capacity.js';

const fmtDate = (iso) => (iso ? new Date(iso).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '-');
const hexOk = (c, d) => (/^#[0-9a-f]{6}$/i.test(c || '') ? c : d);
const mbps = (kbps) => (Number(kbps) >= 1000 ? `${+(kbps / 1000).toFixed(1)} Mbps` : `${kbps || 0} Kbps`);
const bpsTxt = (v) => { const n = Number(v || 0); return n >= 1e9 ? `${(n / 1e9).toFixed(2)} Gbps` : n >= 1e6 ? `${(n / 1e6).toFixed(1)} Mbps` : `${(n / 1e3).toFixed(0)} Kbps`; };
const bytesTxt = (v) => { let n = Number(v || 0); const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0; while (n >= 1024 && i < 4) { n /= 1024; i++; } return `${n.toFixed(1)} ${u[i]}`; };
// Strip characters outside WinAnsi so the built-in PDF fonts never render garbage.
const safe = (s) => String(s ?? '').replace(/[^\x09\x0A\x0D\x20-\x7E -ÿ]/g, (ch) => ({ '—': '-', '–': '-', '→': '->', '•': '*', '’': "'", '“': '"', '”': '"' }[ch] || '?'));

/** Base document with branding, helpers and page footer. Returns { doc, h } — call h.end() to finish. */
async function createDoc(res, filename, title, subtitle) {
  const [b, c] = await Promise.all([getSetting('branding'), getSetting('company')]);
  const sym = [...String(c.currencySymbol || '')].every((ch) => ch.charCodeAt(0) <= 255) && c.currencySymbol ? c.currencySymbol : `${c.currency} `;
  const money = (cents) => `${sym}${(Number(cents || 0) / 100).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  const primary = hexOk(b.primary, '#7c5cff'); const secondary = hexOk(b.secondary, '#00d4ff');
  const doc = new PDFDocument({ size: 'A4', margin: 48, bufferPages: true, info: { Title: safe(title), Author: safe(b.companyName), Creator: 'AuraISP' } });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${filename.replace(/[^A-Za-z0-9._-]/g, '_')}"`);
  res.setHeader('Cache-Control', 'no-store');
  doc.pipe(res);
  const W = doc.page.width - 96;

  // Header band
  const grad = doc.linearGradient(0, 0, doc.page.width, 0); grad.stop(0, primary).stop(1, secondary);
  doc.rect(0, 0, doc.page.width, 86).fill(grad);
  doc.fillColor('#fff').font('Helvetica-Bold').fontSize(20).text(safe(b.companyName), 48, 26);
  doc.font('Helvetica').fontSize(9).text(safe(`${c.legalName}  |  ${c.address}  |  ${c.phone}  |  ${c.email}`), 48, 54, { width: W });
  doc.fillColor('#16132e').font('Helvetica-Bold').fontSize(18).text(safe(title), 48, 110);
  if (subtitle) doc.font('Helvetica').fontSize(10).fillColor('#5b587a').text(safe(subtitle));
  doc.moveDown(1);

  const h = {
    money, W, primary,
    heading(text) {
      h.ensure(40);
      doc.moveDown(0.6).font('Helvetica-Bold').fontSize(12).fillColor(primary).text(safe(text), 48);
      doc.moveTo(48, doc.y + 2).lineTo(48 + W, doc.y + 2).lineWidth(0.6).strokeColor('#dcd8f5').stroke();
      doc.moveDown(0.5).fillColor('#16132e');
    },
    ensure(space) { if (doc.y + space > doc.page.height - 70) doc.addPage(); },
    kv(pairs, cols = 2) {
      const colW = W / cols; let i = 0; const startY = doc.y;
      let rowY = startY;
      for (const [k, v] of pairs) {
        const x = 48 + (i % cols) * colW;
        if (i % cols === 0 && i) rowY += 30;
        doc.font('Helvetica').fontSize(8).fillColor('#8a87a6').text(safe(k).toUpperCase(), x, rowY, { width: colW - 10 });
        doc.font('Helvetica-Bold').fontSize(10).fillColor('#16132e').text(safe(v), x, rowY + 10, { width: colW - 10 });
        i++;
      }
      doc.y = rowY + 34; doc.x = 48;
    },
    kpis(items) {
      h.ensure(70);
      const n = items.length; const gap = 10; const bw = (W - gap * (n - 1)) / n; const y = doc.y;
      items.forEach(([label, value, sub], i) => {
        const x = 48 + i * (bw + gap);
        doc.roundedRect(x, y, bw, 58, 8).fill('#f3f1ff');
        doc.fillColor('#5b587a').font('Helvetica').fontSize(8).text(safe(label).toUpperCase(), x + 10, y + 9, { width: bw - 20 });
        const v = safe(value);
        doc.fillColor('#16132e').font('Helvetica-Bold').fontSize(v.length > 14 ? 11 : 14).text(v, x + 10, y + 22, { width: bw - 20, lineBreak: false, ellipsis: true });
        if (sub) doc.fillColor('#8a87a6').font('Helvetica').fontSize(7.5).text(safe(sub), x + 10, y + 42, { width: bw - 20 });
      });
      doc.y = y + 70; doc.x = 48;
    },
    table(columns, rows, { empty = 'No records' } = {}) {
      const total = columns.reduce((s, c) => s + (c.w || 1), 0);
      const widths = columns.map((c) => ((c.w || 1) / total) * W);
      const header = () => {
        h.ensure(40);
        const y = doc.y;
        doc.rect(48, y, W, 18).fill('#ece9ff');
        let x = 48;
        columns.forEach((c, i) => { doc.fillColor('#3d3a5c').font('Helvetica-Bold').fontSize(8).text(safe(c.title), x + 4, y + 5, { width: widths[i] - 8, align: c.align || 'left' }); x += widths[i]; });
        doc.y = y + 20;
      };
      header();
      if (!rows.length) { doc.font('Helvetica-Oblique').fontSize(9).fillColor('#8a87a6').text(empty, 52); doc.moveDown(0.5); return; }
      rows.forEach((r, ri) => {
        const cells = columns.map((c) => safe(typeof c.value === 'function' ? c.value(r) : r[c.key] ?? '-'));
        const hRow = Math.max(16, ...cells.map((t, i) => doc.font('Helvetica').fontSize(8.5).heightOfString(t, { width: widths[i] - 8 }) + 6));
        if (doc.y + hRow > doc.page.height - 70) { doc.addPage(); header(); }
        const y = doc.y;
        if (ri % 2) doc.rect(48, y, W, hRow).fill('#faf9ff');
        let x = 48;
        cells.forEach((t, i) => { doc.fillColor('#16132e').font('Helvetica').fontSize(8.5).text(t, x + 4, y + 3, { width: widths[i] - 8, align: columns[i].align || 'left' }); x += widths[i]; });
        doc.y = y + hRow;
      });
      doc.x = 48; doc.moveDown(0.4);
    },
    bars(data, { label, value, fmt = (v) => v, height = 130 }) {
      h.ensure(height + 40);
      if (!data.length) return;
      const max = Math.max(1, ...data.map(value)); const y0 = doc.y; const bw = W / data.length;
      data.forEach((d, i) => {
        const v = value(d); const bh = (v / max) * height; const x = 48 + i * bw;
        doc.rect(x + bw * 0.15, y0 + height - bh, bw * 0.7, bh).fill(i % 2 ? secondary : primary);
        doc.fillColor('#5b587a').font('Helvetica').fontSize(6.5).text(safe(label(d)), x, y0 + height + 3, { width: bw, align: 'center' });
        if (data.length <= 14) doc.fillColor('#16132e').fontSize(6.5).text(safe(fmt(v)), x, y0 + height - bh - 10, { width: bw, align: 'center' });
      });
      doc.y = y0 + height + 20; doc.x = 48;
    },
    paragraph(text, color = '#5b587a') { h.ensure(30); doc.font('Helvetica').fontSize(9).fillColor(color).text(safe(text), 48, doc.y, { width: W }); doc.moveDown(0.4); },
    end() {
      const range = doc.bufferedPageRange();
      for (let i = range.start; i < range.start + range.count; i++) {
        doc.switchToPage(i);
        // Writing inside the bottom margin would make pdfkit start a new page — lift the margin while drawing the footer.
        const bottom = doc.page.margins.bottom;
        doc.page.margins.bottom = 0;
        doc.font('Helvetica').fontSize(7.5).fillColor('#8a87a6')
          .text(safe(`${b.companyName} · Generated ${new Date().toLocaleString('en-GB')} · Page ${i + 1} of ${range.count}`), 48, doc.page.height - 36, { width: W, align: 'center', lineBreak: false });
        doc.page.margins.bottom = bottom;
      }
      doc.end();
    },
  };
  return { doc, h, company: c };
}

const period = (from, to) => `${fmtDate(from)} - ${fmtDate(to)}`;

// ==================================================================== invoice
export async function invoicePdf(res, inv) {
  const { doc, h } = await createDoc(res, `${inv.number}.pdf`, `Invoice ${inv.number}`, `Status: ${String(inv.status).toUpperCase()}`);
  h.kv([['Billed to', inv.customer_name], ['Customer code', inv.customer_code], ['Issued', fmtDate(inv.issued_at)], ['Due', fmtDate(inv.due_date)],
    ['Email', inv.customer_email || '-'], ['Address', inv.customer_address || '-']], 2);
  h.table([
    { title: 'Description', key: 'description', w: 5 },
    { title: 'Qty', key: 'quantity', align: 'right', w: 1 },
    { title: 'Unit', value: (r) => h.money(r.unit_cents), align: 'right', w: 1.6 },
    { title: 'Amount', value: (r) => h.money(r.quantity * r.unit_cents), align: 'right', w: 1.6 },
  ], inv.items);
  const lines = [['Subtotal', inv.subtotal_cents]];
  if (Number(inv.discount_cents)) lines.push(['Discount', -inv.discount_cents]);
  if (Number(inv.tax_cents)) lines.push(['Tax', inv.tax_cents]);
  lines.push(['Total', inv.total_cents], ['Paid', inv.paid_cents], ['Balance due', inv.total_cents - inv.paid_cents]);
  h.ensure(120);
  for (const [k, v] of lines) {
    const bold = ['Total', 'Balance due'].includes(k);
    doc.font(bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(bold ? 11 : 9.5).fillColor('#16132e');
    const y = doc.y;
    doc.text(k, 48 + h.W - 220, y, { width: 110 }); doc.text(h.money(v), 48 + h.W - 110, y, { width: 110, align: 'right' });
    doc.moveDown(0.2);
  }
  if (inv.notes) { doc.moveDown(); h.paragraph(inv.notes); }
  doc.moveDown(2); h.paragraph('Thank you for your business. Pay online from your customer portal or mobile app.');
  h.end();
}

/** Receipt for one completed payment (attached to "payment received" emails, downloadable by the customer). */
export async function paymentReceiptPdf(res, p) {
  const no = `RCPT-${String(p.id).padStart(6, '0')}`;
  const { doc, h } = await createDoc(res, `${no}.pdf`, `Payment receipt ${no}`, 'Thank you for your payment');
  h.kv([['Received from', p.customer_name], ['Customer code', p.customer_code], ['Receipt no.', no], ['Date', fmtDate(p.completed_at || p.created_at)],
    ['Method', String(p.method || '-').replace(/_/g, ' ')], ['Reference', p.gateway_ref || p.reference || '-'], ['For invoice', p.invoice_number || 'Account credit'], ['Status', String(p.status).toUpperCase()]], 2);
  h.ensure(90);
  doc.moveDown();
  doc.font('Helvetica-Bold').fontSize(16).fillColor('#16132e').text(`Amount paid: ${h.money(p.amount_cents)}`, { align: 'right' });
  if (p.invoice_number) {
    doc.moveDown(0.4).font('Helvetica').fontSize(10).fillColor('#55537a')
      .text(`Invoice total ${h.money(p.invoice_total)} · paid to date ${h.money(p.invoice_paid)} · balance due ${h.money(Math.max(0, Number(p.invoice_total) - Number(p.invoice_paid)))}`, { align: 'right' });
  }
  doc.moveDown(2); h.paragraph('This receipt was generated electronically and is valid without a signature.');
  h.end();
}

/** Render a PDF into memory (for email attachments) using the same generators as the download routes. */
export function pdfToBuffer(render) {
  return new Promise((resolve, reject) => {
    const out = new PassThrough(); const chunks = [];
    out.setHeader = () => {}; // createDoc sets download headers on HTTP responses
    out.on('data', (c) => chunks.push(c)); out.on('end', () => resolve(Buffer.concat(chunks))); out.on('error', reject);
    Promise.resolve(render(out)).catch(reject);
  });
}
export const invoiceQuery = `SELECT i.*, u.name AS customer_name, u.email AS customer_email, c.code AS customer_code, c.address AS customer_address
  FROM invoices i JOIN customers c ON c.id = i.customer_id JOIN users u ON u.id = c.user_id WHERE i.id = ?`;
export const paymentQuery = `SELECT p.*, u.name AS customer_name, c.code AS customer_code, i.number AS invoice_number, i.total_cents AS invoice_total, i.paid_cents AS invoice_paid
  FROM payments p JOIN customers c ON c.id = p.customer_id JOIN users u ON u.id = c.user_id LEFT JOIN invoices i ON i.id = p.invoice_id WHERE p.id = ?`;

/** Attachments for an email: { invoiceId?, paymentId? } → nodemailer attachment objects. */
export async function billingAttachments({ invoiceId, paymentId } = {}) {
  const out = [];
  if (invoiceId) {
    const inv = await db().get(invoiceQuery, [invoiceId]);
    if (inv) out.push({ filename: `${inv.number}.pdf`, content: await pdfToBuffer((res) => invoicePdf(res, parseItems(inv))), contentType: 'application/pdf' });
  }
  if (paymentId) {
    const p = await db().get(paymentQuery, [paymentId]);
    if (p) out.push({ filename: `RCPT-${String(p.id).padStart(6, '0')}.pdf`, content: await pdfToBuffer((res) => paymentReceiptPdf(res, p)), contentType: 'application/pdf' });
  }
  return out;
}

// ==================================================================== customer report / statement
export async function customerReport(res, customerId, { from, to }) {
  const c = await db().get(`SELECT c.*, u.name, u.email, u.phone, p.name AS plan_name, p.download_kbps, p.upload_kbps, p.price_cents
    FROM customers c JOIN users u ON u.id = c.user_id LEFT JOIN plans p ON p.id = c.plan_id WHERE c.id = ?`, [customerId]);
  if (!c) return null;
  const [invoices, payments, tickets, usage, plans] = await Promise.all([
    db().all('SELECT * FROM invoices WHERE customer_id = ? AND issued_at BETWEEN ? AND ? ORDER BY issued_at', [c.id, from, to]),
    db().all("SELECT * FROM payments WHERE customer_id = ? AND status = 'success' AND method != 'balance' AND completed_at BETWEEN ? AND ? ORDER BY completed_at", [c.id, from, to]),
    db().all('SELECT number, subject, status, created_at FROM tickets WHERE customer_id = ? AND created_at BETWEEN ? AND ? ORDER BY created_at', [c.id, from, to]),
    db().all("SELECT day, bytes FROM traffic_daily WHERE customer_id = ? AND category = 'total' AND day BETWEEN ? AND ? ORDER BY day", [c.id, from.slice(0, 10), to.slice(0, 10)]),
    db().all('SELECT pc.created_at, pc.kind, f.name AS from_name, t.name AS to_name FROM plan_changes pc LEFT JOIN plans f ON f.id = pc.from_plan_id LEFT JOIN plans t ON t.id = pc.to_plan_id WHERE pc.customer_id = ? AND pc.status = ? ORDER BY pc.id', [c.id, 'applied']),
  ]);
  const billed = invoices.filter((i) => i.status !== 'void').reduce((s, i) => s + Number(i.total_cents), 0);
  const paid = payments.reduce((s, p) => s + Number(p.amount_cents), 0);
  const outstanding = (await db().get("SELECT COALESCE(SUM(total_cents - paid_cents),0) AS v FROM invoices WHERE customer_id = ? AND status IN ('unpaid','partial','overdue')", [c.id])).v;
  const { doc, h } = await createDoc(res, `customer-${c.code}.pdf`, `Customer report - ${c.name}`, period(from, to));
  h.kv([['Customer', `${c.name} (${c.code})`], ['Status', c.status], ['Email', c.email], ['Phone', c.phone || '-'], ['Address', `${c.address || '-'} ${c.area || ''}`], ['Customer since', fmtDate(c.created_at)],
    ['Plan', c.plan_name ? `${c.plan_name} · ${mbps(c.custom_download_kbps || c.download_kbps)}` : 'None'], ['IP', c.ip_address ? `${c.ip_address} (${c.ip_type || 'unmanaged'})` : 'Not assigned'],
    ['Connection', `${String(c.connection_type || '').toUpperCase()} ${c.pppoe_username || ''}`], ['Next due', fmtDate(c.next_due_date)]], 2);
  h.kpis([['Billed', h.money(billed)], ['Paid', h.money(paid)], ['Outstanding', h.money(outstanding)], ['Data used', bytesTxt(usage.reduce((s, u) => s + Number(u.bytes), 0))]]);
  h.heading('Statement of account');
  const before = await db().get(`SELECT
      (SELECT COALESCE(SUM(total_cents),0) FROM invoices WHERE customer_id = ? AND status != 'void' AND issued_at < ?) -
      (SELECT COALESCE(SUM(amount_cents),0) FROM payments WHERE customer_id = ? AND status = 'success' AND method != 'balance' AND completed_at < ?) AS v`, [c.id, from, c.id, from]);
  let bal = Number(before?.v || 0);
  const opening = { d: from, t: 'Opening balance', debit: 0, credit: 0, bal };
  const ledger = [...invoices.filter((i) => i.status !== 'void').map((i) => ({ d: i.issued_at, t: `Invoice ${i.number}`, debit: Number(i.total_cents), credit: 0 })),
    ...payments.map((p) => ({ d: p.completed_at, t: `Payment (${p.method})`, debit: 0, credit: Number(p.amount_cents) }))].sort((a, b) => a.d.localeCompare(b.d))
    .map((l) => { bal += l.debit - l.credit; return { ...l, bal }; });
  ledger.unshift(opening);
  h.table([{ title: 'Date', value: (r) => fmtDate(r.d), w: 1.3 }, { title: 'Description', key: 't', w: 3 }, { title: 'Debit', value: (r) => (r.debit ? h.money(r.debit) : ''), align: 'right', w: 1.4 },
    { title: 'Credit', value: (r) => (r.credit ? h.money(r.credit) : ''), align: 'right', w: 1.4 }, { title: 'Balance', value: (r) => h.money(r.bal), align: 'right', w: 1.4 }], ledger);
  if (usage.length) { h.heading('Daily data usage'); h.bars(usage.slice(-31), { label: (d) => d.day.slice(5), value: (d) => Number(d.bytes), fmt: bytesTxt }); }
  if (plans.length) { h.heading('Plan changes'); h.table([{ title: 'Date', value: (r) => fmtDate(r.created_at) }, { title: 'Change', value: (r) => `${r.from_name || 'None'} -> ${r.to_name}`, w: 3 }, { title: 'Type', key: 'kind' }], plans); }
  h.heading('Support tickets');
  h.table([{ title: 'Ticket', key: 'number', w: 1.4 }, { title: 'Subject', key: 'subject', w: 3 }, { title: 'Status', key: 'status' }, { title: 'Opened', value: (r) => fmtDate(r.created_at) }], tickets, { empty: 'No tickets in this period' });
  h.end();
  return true;
}

// ==================================================================== accounts
export async function accountsReport(res, { from, to }) {
  const [collected, invoiced, byMethod, byMonth, aging, debtors, refunds] = await Promise.all([
    db().get("SELECT COALESCE(SUM(amount_cents),0) AS v, COUNT(*) AS n FROM payments WHERE status = 'success' AND method != 'balance' AND completed_at BETWEEN ? AND ?", [from, to]),
    db().get("SELECT COALESCE(SUM(total_cents),0) AS v, COALESCE(SUM(tax_cents),0) AS tax, COALESCE(SUM(discount_cents),0) AS disc, COUNT(*) AS n FROM invoices WHERE status != 'void' AND issued_at BETWEEN ? AND ?", [from, to]),
    db().all("SELECT method, COUNT(*) AS n, SUM(amount_cents) AS v FROM payments WHERE status = 'success' AND method != 'balance' AND completed_at BETWEEN ? AND ? GROUP BY method ORDER BY v DESC", [from, to]),
    db().all("SELECT SUBSTR(completed_at,1,7) AS m, SUM(amount_cents) AS v FROM payments WHERE status = 'success' AND method != 'balance' AND completed_at BETWEEN ? AND ? GROUP BY SUBSTR(completed_at,1,7) ORDER BY m", [from, to]),
    db().all("SELECT due_date, total_cents - paid_cents AS due FROM invoices WHERE status IN ('unpaid','partial','overdue')"),
    db().all(`SELECT u.name, c.code, SUM(i.total_cents - i.paid_cents) AS due, MIN(i.due_date) AS oldest FROM invoices i JOIN customers c ON c.id = i.customer_id JOIN users u ON u.id = c.user_id
      WHERE i.status IN ('unpaid','partial','overdue') GROUP BY u.name, c.code ORDER BY due DESC LIMIT 25`),
    db().get("SELECT COALESCE(SUM(amount_cents),0) AS v FROM payments WHERE status = 'refunded' AND completed_at BETWEEN ? AND ?", [from, to]),
  ]);
  const buckets = { 'Current': 0, '1-30 days': 0, '31-60 days': 0, '61-90 days': 0, '90+ days': 0 };
  for (const a of aging) {
    const days = Math.floor((Date.now() - new Date(a.due_date).getTime()) / 86400000);
    const k = days <= 0 ? 'Current' : days <= 30 ? '1-30 days' : days <= 60 ? '31-60 days' : days <= 90 ? '61-90 days' : '90+ days';
    buckets[k] += Number(a.due);
  }
  const outstanding = Object.values(buckets).reduce((s, v) => s + v, 0);
  const { h } = await createDoc(res, `accounts-${from.slice(0, 10)}_${to.slice(0, 10)}.pdf`, 'Accounts report', period(from, to));
  h.kpis([['Collected', h.money(collected.v), `${collected.n} payments`], ['Invoiced', h.money(invoiced.v), `${invoiced.n} invoices`],
    ['Collection rate', invoiced.v ? `${Math.round((collected.v / invoiced.v) * 100)}%` : '-'], ['Outstanding (all)', h.money(outstanding)]]);
  h.kpis([['Tax collected (invoiced)', h.money(invoiced.tax)], ['Discounts given', h.money(invoiced.disc)], ['Refunds', h.money(refunds.v)]]);
  h.heading('Collections by month');
  h.bars(byMonth, { label: (d) => d.m, value: (d) => Number(d.v), fmt: (v) => h.money(v).replace(/\.00$/, '') });
  h.heading('Collections by payment method');
  h.table([{ title: 'Method', value: (r) => String(r.method).replace(/_/g, ' '), w: 2 }, { title: 'Payments', key: 'n', align: 'right' }, { title: 'Amount', value: (r) => h.money(r.v), align: 'right', w: 1.5 },
    { title: 'Share', value: (r) => (collected.v ? `${Math.round((r.v / collected.v) * 100)}%` : '-'), align: 'right' }], byMethod);
  h.heading('Receivables aging');
  h.table([{ title: 'Bucket', key: 'k', w: 2 }, { title: 'Amount', value: (r) => h.money(r.v), align: 'right' }, { title: 'Share', value: (r) => (outstanding ? `${Math.round((r.v / outstanding) * 100)}%` : '-'), align: 'right' }],
    Object.entries(buckets).map(([k, v]) => ({ k, v })));
  h.heading('Top debtors');
  h.table([{ title: 'Customer', key: 'name', w: 2.5 }, { title: 'Code', key: 'code' }, { title: 'Oldest due', value: (r) => fmtDate(r.oldest) }, { title: 'Outstanding', value: (r) => h.money(r.due), align: 'right', w: 1.4 }], debtors, { empty: 'No outstanding balances' });
  h.end();
}

// ==================================================================== sales
export async function salesReport(res, { from, to }) {
  const [byKind, byMonth, byStaff, byPlan, funnel, newCustomers, churned, leadsBySource] = await Promise.all([
    db().all('SELECT kind, COUNT(*) AS n, SUM(amount_cents) AS v FROM sales WHERE created_at BETWEEN ? AND ? GROUP BY kind', [from, to]),
    db().all('SELECT SUBSTR(created_at,1,7) AS m, COUNT(*) AS n, SUM(amount_cents) AS v FROM sales WHERE created_at BETWEEN ? AND ? GROUP BY SUBSTR(created_at,1,7) ORDER BY m', [from, to]),
    db().all('SELECT COALESCE(u.name, \'Self-service\') AS staff, COUNT(*) AS n, SUM(s.amount_cents) AS v FROM sales s LEFT JOIN users u ON u.id = s.staff_id WHERE s.created_at BETWEEN ? AND ? GROUP BY u.name ORDER BY v DESC', [from, to]),
    db().all('SELECT COALESCE(p.name, \'-\') AS plan, COUNT(*) AS n, SUM(s.amount_cents) AS v FROM sales s LEFT JOIN plans p ON p.id = s.plan_id WHERE s.created_at BETWEEN ? AND ? GROUP BY p.name ORDER BY n DESC', [from, to]),
    db().all('SELECT status, COUNT(*) AS n FROM leads WHERE created_at BETWEEN ? AND ? GROUP BY status', [from, to]),
    db().get('SELECT COUNT(*) AS n FROM customers WHERE created_at BETWEEN ? AND ?', [from, to]),
    db().get("SELECT COUNT(*) AS n FROM customers WHERE status = 'terminated' AND updated_at BETWEEN ? AND ?", [from, to]),
    db().all('SELECT source, COUNT(*) AS n, SUM(CASE WHEN status = \'won\' THEN 1 ELSE 0 END) AS won FROM leads WHERE created_at BETWEEN ? AND ? GROUP BY source ORDER BY n DESC', [from, to]),
  ]);
  const total = byKind.reduce((s, k) => s + Number(k.v || 0), 0);
  const deals = byKind.reduce((s, k) => s + Number(k.n), 0);
  const leads = funnel.reduce((s, f) => s + Number(f.n), 0);
  const won = Number(funnel.find((f) => f.status === 'won')?.n || 0);
  const { h } = await createDoc(res, `sales-${from.slice(0, 10)}_${to.slice(0, 10)}.pdf`, 'Sales report', period(from, to));
  h.kpis([['Sales value', h.money(total)], ['Deals', String(deals)], ['New customers', String(newCustomers.n)], ['Lead conversion', leads ? `${((won / leads) * 100).toFixed(1)}%` : '-']]);
  h.kpis([['New connections', String(byKind.find((k) => k.kind === 'new')?.n || 0)], ['Upgrades', String(byKind.find((k) => k.kind === 'upgrade')?.n || 0)], ['Downgrades', String(byKind.find((k) => k.kind === 'downgrade')?.n || 0)], ['Terminated', String(churned.n)]]);
  h.heading('Sales by month'); h.bars(byMonth, { label: (d) => d.m, value: (d) => Number(d.v || 0), fmt: (v) => h.money(v).replace(/\.00$/, '') });
  h.heading('By plan'); h.table([{ title: 'Plan', key: 'plan', w: 2 }, { title: 'Deals', key: 'n', align: 'right' }, { title: 'Value', value: (r) => h.money(r.v), align: 'right' }], byPlan);
  h.heading('Leaderboard'); h.table([{ title: 'Staff', key: 'staff', w: 2 }, { title: 'Deals', key: 'n', align: 'right' }, { title: 'Value', value: (r) => h.money(r.v), align: 'right' }], byStaff);
  h.heading('Lead sources'); h.table([{ title: 'Source', key: 'source', w: 2 }, { title: 'Leads', key: 'n', align: 'right' }, { title: 'Won', key: 'won', align: 'right' }, { title: 'Conversion', value: (r) => (r.n ? `${Math.round((r.won / r.n) * 100)}%` : '-'), align: 'right' }], leadsBySource);
  h.heading('Pipeline'); h.table([{ title: 'Stage', key: 'status', w: 2 }, { title: 'Leads', key: 'n', align: 'right' }], ['new', 'contacted', 'qualified', 'proposal', 'won', 'lost'].map((s) => ({ status: s, n: Number(funnel.find((f) => f.status === s)?.n || 0) })));
  h.end();
}

// ==================================================================== overall business
export async function overallReport(res, { from, to }) {
  const [statusRows, mrrRow, revenue, outstanding, tickets, ticketsResolved, areas, plans, cap, newC, churn] = await Promise.all([
    db().all('SELECT status, COUNT(*) AS n FROM customers GROUP BY status'),
    db().get(`SELECT COALESCE(SUM(CASE p.billing_cycle WHEN 'yearly' THEN p.price_cents / 12.0 WHEN 'quarterly' THEN p.price_cents / 3.0 ELSE p.price_cents END + COALESCE(c.ip_addon_cents,0)),0) AS v
      FROM customers c JOIN plans p ON p.id = c.plan_id WHERE c.status = 'active'`),
    db().get("SELECT COALESCE(SUM(amount_cents),0) AS v FROM payments WHERE status = 'success' AND method != 'balance' AND completed_at BETWEEN ? AND ?", [from, to]),
    db().get("SELECT COALESCE(SUM(total_cents - paid_cents),0) AS v FROM invoices WHERE status IN ('unpaid','partial','overdue')"),
    db().get('SELECT COUNT(*) AS n FROM tickets WHERE created_at BETWEEN ? AND ?', [from, to]),
    db().get("SELECT COUNT(*) AS n FROM tickets WHERE closed_at BETWEEN ? AND ? AND status IN ('resolved','closed')", [from, to]),
    db().all("SELECT COALESCE(area,'-') AS area, COUNT(*) AS n FROM customers WHERE status = 'active' GROUP BY area ORDER BY n DESC LIMIT 10"),
    db().all("SELECT p.name, COUNT(c.id) AS n FROM plans p LEFT JOIN customers c ON c.plan_id = p.id AND c.status = 'active' GROUP BY p.id, p.name ORDER BY n DESC"),
    analyse({ days: 7 }).catch(() => null),
    db().get('SELECT COUNT(*) AS n FROM customers WHERE created_at BETWEEN ? AND ?', [from, to]),
    db().get("SELECT COUNT(*) AS n FROM customers WHERE status = 'terminated' AND updated_at BETWEEN ? AND ?", [from, to]),
  ]);
  const status = Object.fromEntries(statusRows.map((s) => [s.status, Number(s.n)]));
  const active = status.active || 0;
  const mrr = Math.round(Number(mrrRow.v));
  const ipRows = await db().all('SELECT p.kind, a.status, COUNT(*) AS n FROM ip_addresses a JOIN ip_pools p ON p.id = a.pool_id GROUP BY p.kind, a.status');
  const { h } = await createDoc(res, `overall-${from.slice(0, 10)}_${to.slice(0, 10)}.pdf`, 'Overall business report', period(from, to));
  h.kpis([['Active customers', String(active), `${status.suspended || 0} suspended · ${status.pending || 0} pending`], ['MRR', h.money(mrr), 'monthly recurring revenue'], ['ARPU', active ? h.money(mrr / active) : '-', 'per active customer'], ['Revenue (period)', h.money(revenue.v)]]);
  h.kpis([['Outstanding', h.money(outstanding.v)], ['New customers', String(newC.n)], ['Churned', String(churn.n), active ? `${((churn.n / (active + churn.n)) * 100).toFixed(1)}% churn` : ''], ['Tickets', `${tickets.n} opened`, `${ticketsResolved.n} resolved`]]);
  if (cap) {
    h.heading('Network capacity (last 7 days)');
    h.kpis([['Upstream capacity', mbps(cap.capacity.downKbps), cap.source], ['Provisioned', mbps(cap.provisioned.downKbps), cap.oversubscription ? `contention 1:${cap.oversubscription}` : ''],
      ['Peak usage', bpsTxt(cap.usage.peakRxBps), cap.usage.peakUtilization != null ? `${cap.usage.peakUtilization}% of capacity` : ''], ['Limit breaches', String(cap.summary.overLimit), 'customers above plan']]);
    for (const r of cap.recommendations) h.paragraph(`* ${r.text}`, r.level === 'bad' ? '#c0262d' : r.level === 'warn' ? '#b26b00' : '#5b587a');
  }
  h.heading('Customers by plan'); h.bars(plans.map((p) => ({ ...p, n: Number(p.n) })), { label: (d) => d.name, value: (d) => d.n });
  h.heading('Top areas'); h.table([{ title: 'Area', key: 'area', w: 3 }, { title: 'Active customers', key: 'n', align: 'right' }], areas);
  if (ipRows.length) {
    h.heading('IP address utilisation');
    const kinds = ['real', 'dedicated', 'shared'].map((k) => {
      const rows = ipRows.filter((r) => r.kind === k); const total = rows.reduce((s, r) => s + Number(r.n), 0);
      const assigned = Number(rows.find((r) => r.status === 'assigned')?.n || 0);
      return { k, total, assigned, pct: total ? `${Math.round((assigned / total) * 100)}%` : '-' };
    }).filter((x) => x.total);
    h.table([{ title: 'Type', key: 'k', w: 2 }, { title: 'Total', key: 'total', align: 'right' }, { title: 'Assigned', key: 'assigned', align: 'right' }, { title: 'Used', key: 'pct', align: 'right' }], kinds);
  }
  h.end();
}

export const parseItems = (inv) => ({ ...inv, items: parseJson(inv.items, []) });
