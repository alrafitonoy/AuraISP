import dotenv from 'dotenv';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
// Always load server/.env regardless of the working directory (Passenger, PM2, systemd, Docker).
dotenv.config({ path: path.join(root, '.env'), quiet: true });
const env = process.env;

/**
 * Where uploads, backups and other runtime files live. DATA_DIR (absolute, or "~/..." for the home folder) keeps them
 * outside the code folder, so hosts that deploy every release into a new folder (Hostinger, Render...) don't lose them.
 * The first time DATA_DIR is used, files from the old server/data folder are copied over (never overwritten).
 */
function resolveDataDir(value) {
  const legacy = path.resolve(root, 'data');
  if (!value) return legacy;
  const dir = path.resolve(value.startsWith('~') ? path.join(os.homedir(), value.slice(1)) : path.resolve(root, value));
  try {
    const fresh = !fs.existsSync(dir) || fs.readdirSync(dir).length === 0;
    fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    if (fresh && dir !== legacy && fs.existsSync(legacy)) {
      fs.cpSync(legacy, dir, { recursive: true, force: false, errorOnExist: false, filter: (p) => !/install-token\.txt$/.test(p) });
    }
  } catch (err) {
    console.error(`DATA_DIR ${dir} is not usable (${err.message}); falling back to ${legacy}`);
    return legacy;
  }
  return dir;
}
const dataDir = resolveDataDir(env.DATA_DIR);

// The built web app: WEB_DIST if it exists, else ../web/dist (repo / installer layout), else ./public
// (hosts such as Hostinger deploy only the server folder, so the installer package also ships the UI in server/public).
function findWebDist(configured) {
  const candidates = [configured, '../web/dist', 'public'].filter(Boolean).map((p) => path.resolve(root, p));
  return candidates.find((p) => fs.existsSync(path.join(p, 'index.html'))) || candidates[0];
}

const list = (v) => (v || '').split(',').map((s) => s.trim()).filter(Boolean);

/**
 * Database settings. DB_CLIENT: mysql (MySQL / MariaDB, default) | postgres | sqlite.
 * DB_SSL: disable (database on the same machine only) | verify-full (default for remote hosts).
 */
export function dbConfig() {
  const e = process.env;
  const raw = (e.DB_CLIENT || 'mysql').toLowerCase();
  const client = ['pg', 'postgres', 'postgresql'].includes(raw) ? 'postgres' : raw === 'sqlite' ? 'sqlite' : 'mysql';
  const host = e.DB_HOST || '127.0.0.1';
  const local = ['127.0.0.1', 'localhost', '::1'].includes(host) || host.startsWith('/');
  return {
    client,
    sqliteFile: e.SQLITE_FILE ? path.resolve(root, e.SQLITE_FILE) : path.join(dataDir, 'aura.db'),
    host,
    port: Number(e.DB_PORT) || (client === 'postgres' ? 5432 : 3306),
    database: e.DB_NAME || 'aura_isp',
    user: e.DB_USER || 'aura_app',
    password: e.DB_PASSWORD || '',
    schema: e.DB_SCHEMA || 'public',
    ssl: (e.DB_SSL || (local ? 'disable' : 'verify-full')).toLowerCase(),
    sslCa: e.DB_SSL_CA ? path.resolve(root, e.DB_SSL_CA) : '',
    poolMax: Number(e.DB_POOL_MAX) || 15,
  };
}

const config = {
  root,
  env: env.NODE_ENV || 'development',
  isProd: env.NODE_ENV === 'production',
  port: Number(env.PORT) || 4000,
  host: env.HOST || '0.0.0.0',
  appUrl: (env.APP_URL || 'http://localhost:4000').replace(/\/$/, ''),
  corsOrigins: list(env.CORS_ORIGINS),
  appKey: env.APP_KEY || '',
  trustProxy: env.TRUST_PROXY ?? 'loopback',
  db: dbConfig(),
  dataDir,
  uploadsDir: path.join(dataDir, 'uploads'),
  webDist: findWebDist(env.WEB_DIST),
  vapid: { publicKey: env.VAPID_PUBLIC_KEY || '', privateKey: env.VAPID_PRIVATE_KEY || '' },
  update: {
    repo: env.UPDATE_REPO || '',
    publicKey: env.UPDATE_PUBLIC_KEY || '',
  },
  disableScheduler: env.DISABLE_SCHEDULER === 'true',
  // Worker processes for the built-in load balancer (Node cluster). 0/1 = single process, "max" = one per CPU core.
  workers: env.WEB_CONCURRENCY === 'max' ? 'max' : Number(env.WEB_CONCURRENCY) || 1,
};

export const isInstalled = () => !!config.appKey && (config.db.client === 'sqlite' || !!config.db.password);

/** Re-read .env after the web installer writes it (mutates the shared config object in place). */
export function reloadConfig() {
  dotenv.config({ path: path.join(root, '.env'), override: true, quiet: true });
  const e = process.env;
  Object.assign(config, {
    env: e.NODE_ENV || 'production', isProd: e.NODE_ENV === 'production', appUrl: (e.APP_URL || config.appUrl).replace(/\/$/, ''),
    corsOrigins: list(e.CORS_ORIGINS), appKey: e.APP_KEY || '', trustProxy: e.TRUST_PROXY ?? 'loopback', db: dbConfig(),
    vapid: { publicKey: e.VAPID_PUBLIC_KEY || '', privateKey: e.VAPID_PRIVATE_KEY || '' },
    update: { repo: e.UPDATE_REPO || '', publicKey: e.UPDATE_PUBLIC_KEY || '' },
  });
  return config;
}

export function assertConfig() {
  if (!config.appKey || Buffer.from(config.appKey, 'base64').length < 32) {
    throw new Error('APP_KEY is missing or shorter than 32 bytes. Run `npm run setup` first.');
  }
}

export default config;
