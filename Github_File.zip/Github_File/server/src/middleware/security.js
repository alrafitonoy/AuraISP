import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import config from '../config.js';
import { forbidden } from '../lib/http.js';
import { PgRateStore } from '../lib/rate-store.js';

export const helmetMw = helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      'default-src': ["'self'"],
      'script-src': ["'self'"],
      'style-src': ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      'font-src': ["'self'", 'https://fonts.gstatic.com', 'data:'],
      'img-src': ["'self'", 'data:', 'blob:', 'https:'],
      'connect-src': ["'self'", ...config.corsOrigins],
      'frame-src': ["'self'"], // admin Website preview embeds our own /site page; nothing else may be framed
      'frame-ancestors': ["'self'"], // only our own admin can embed the site (Website preview)
      'form-action': ["'self'", 'https:'],
      'object-src': ["'none'"],
      'base-uri': ["'self'"],
      'upgrade-insecure-requests': config.isProd ? [] : null,
    },
  },
  crossOriginEmbedderPolicy: false,
  crossOriginResourcePolicy: { policy: 'same-site' },
  referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
  hsts: config.isProd ? { maxAge: 31536000, includeSubDomains: true } : false,
});

const handler = (_req, res) => res.status(429).json({ error: 'Too many requests. Please slow down and try again shortly.' });

const base = { standardHeaders: 'draft-7', legacyHeaders: false, handler, passOnStoreError: true };
// Shared (PostgreSQL) store: security-critical limits hold across every worker and server behind the load balancer.
const shared = (name, opts) => rateLimit({ ...base, ...opts, store: new PgRateStore(name) });

// The general flood limit is per process (cheap, in memory); tune with RATE_LIMIT_GLOBAL for your proxy/NAT setup.
export const globalLimiter = rateLimit({ ...base, windowMs: 60_000, limit: Number(process.env.RATE_LIMIT_GLOBAL) || 600 });
export const authLimiter = shared('auth', { windowMs: 15 * 60_000, limit: 20, skipSuccessfulRequests: true });
// One bucket per code flow (forgot, reset, verify send/confirm, 2FA…) instead of one for all of them, so a couple of
// typos during sign-up verification can't lock the same IP out of password reset. Still 6 tries per flow per IP.
export const otpLimiter = shared('otp', {
  windowMs: 15 * 60_000, limit: 6,
  keyGenerator: (req) => `${req.ip}|${req.baseUrl}${req.route?.path || req.path}`,
});
export const publicFormLimiter = shared('form', { windowMs: 60 * 60_000, limit: 15 });
export const registerLimiter = shared('register', { windowMs: 60 * 60_000, limit: 10 });
export const chatLimiter = shared('chat', { windowMs: 10 * 60_000, limit: 60 });
export const speedtestLimiter = shared('speed', { windowMs: 10 * 60_000, limit: 20 });

/**
 * CSRF defence for cookie-authenticated endpoints (refresh/logout): the refresh cookie is SameSite=Strict
 * AND we require a custom header that cross-site forms cannot send without a CORS preflight.
 */
export function requireXhr(req, _res, next) {
  if (req.get('X-Requested-With') !== 'XMLHttpRequest') throw forbidden('Missing anti-CSRF header');
  next();
}

/** Reject prototype-pollution keys anywhere in a JSON body. */
export function sanitizeBody(req, _res, next) {
  const bad = new Set(['__proto__', 'constructor', 'prototype']);
  const check = (o, depth = 0) => {
    if (depth > 20 || !o || typeof o !== 'object') return;
    for (const k of Object.keys(o)) {
      if (bad.has(k)) throw forbidden('Illegal key in request body');
      check(o[k], depth + 1);
    }
  };
  check(req.body);
  next();
}
