import jwt from 'jsonwebtoken';
import { db, parseJson } from '../db/index.js';
import { jwtSecret } from '../lib/crypto.js';
import { unauthorized, forbidden, HttpError } from '../lib/http.js';
import { moduleEnabled } from '../lib/settings.js';

const ISSUER = 'aura-isp';

export function signAccessToken(user) {
  return jwt.sign({ sub: String(user.id), tv: user.token_version ?? 0, typ: 'access' }, jwtSecret(), {
    algorithm: 'HS256', expiresIn: '15m', issuer: ISSUER,
  });
}

export function signChallengeToken(user, purpose) {
  return jwt.sign({ sub: String(user.id), typ: purpose }, jwtSecret(), { algorithm: 'HS256', expiresIn: '5m', issuer: ISSUER });
}

export function verifyChallengeToken(token, purpose) {
  try {
    const p = jwt.verify(token, jwtSecret(), { algorithms: ['HS256'], issuer: ISSUER });
    if (p.typ !== purpose) return null;
    return Number(p.sub);
  } catch { return null; }
}

export async function loadAuthUser(id) {
  const u = await db().get(
    `SELECT u.id, u.type, u.name, u.email, u.phone, u.status, u.token_version, u.role_id, u.totp_enabled,
            u.email_verified_at, u.phone_verified_at, u.avatar, u.preferences, r.permissions, r.slug AS role_slug, r.name AS role_name, r.dashboard
       FROM users u LEFT JOIN roles r ON r.id = u.role_id WHERE u.id = ?`, [id]);
  if (!u) return null;
  u.permissions = u.type === 'admin' ? ['*'] : parseJson(u.permissions, []);
  u.dashboard = parseJson(u.dashboard, []);
  u.preferences = parseJson(u.preferences, {});
  if (u.type === 'customer') {
    const c = await db().get('SELECT id FROM customers WHERE user_id = ?', [u.id]);
    u.customer_id = c?.id ?? null;
  }
  return u;
}

async function resolve(req) {
  const h = req.headers.authorization || '';
  // Header only — tokens in query strings leak into logs and browser history.
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) return null;
  let payload;
  try {
    payload = jwt.verify(token, jwtSecret(), { algorithms: ['HS256'], issuer: ISSUER });
  } catch { throw unauthorized('Session expired'); }
  if (payload.typ !== 'access') throw unauthorized();
  const user = await loadAuthUser(Number(payload.sub));
  if (!user || user.status !== 'active' || (user.token_version ?? 0) !== payload.tv) throw unauthorized('Session revoked');
  return user;
}

export async function authenticate(req, _res, next) {
  const user = await resolve(req);
  if (!user) throw unauthorized();
  req.user = user;
  next();
}

export async function optionalAuth(req, _res, next) {
  try { req.user = await resolve(req); } catch { req.user = null; }
  next();
}

export function can(user, perm) {
  if (!user) return false;
  if (user.type === 'admin') return true;
  if (user.type !== 'staff') return false;
  const p = user.permissions || [];
  return p.includes('*') || p.includes(perm) || p.includes(`${perm.split('.')[0]}.*`);
}

/** Staff/admin with ANY of the listed permissions. */
export const requirePerm = (...perms) => (req, _res, next) => {
  if (!req.user) throw unauthorized();
  if (!perms.some((p) => can(req.user, p))) throw forbidden();
  next();
};

export const requireStaff = (req, _res, next) => {
  if (!req.user || !['admin', 'staff'].includes(req.user.type)) throw forbidden();
  next();
};

export const requireAdmin = (req, _res, next) => {
  if (req.user?.type !== 'admin') throw forbidden('Administrator only');
  next();
};

export const requireCustomer = (req, _res, next) => {
  if (req.user?.type !== 'customer' || !req.user.customer_id) throw forbidden('Customer account required');
  next();
};

export const requireModule = (...names) => async (_req, _res, next) => {
  for (const n of names) {
    if (!(await moduleEnabled(n))) throw new HttpError(404, `The "${n}" module is disabled`);
  }
  next();
};
