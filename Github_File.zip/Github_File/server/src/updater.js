// Self-updater. Only installs releases that are:
//   1. published GitHub releases (not drafts, not pre-releases)   -> "stable"
//   2. a plain semantic version tag vX.Y.Z (no -beta/-rc suffix)   -> "stable"
//   3. signed with the project's Ed25519 release key                -> "secure"
// A backup is taken before applying, so an update can be rolled back from the admin panel.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import * as tar from 'tar';
import config from './config.js';
import { db, insert, now, withAdvisoryLock } from './db/index.js';
import { getSetting, setSetting } from './lib/settings.js';

const exec = promisify(execFile);
const pkg = JSON.parse(fs.readFileSync(path.join(config.root, 'package.json'), 'utf8'));
export const VERSION = pkg.version;
const INSTALL_ROOT = path.resolve(config.root, '..');
const BACKUP_DIR = path.join(config.dataDir, 'backups');
const STAGE_DIR = path.join(config.dataDir, 'update-stage');

let busy = false;

const SEMVER = /^v?(\d+)\.(\d+)\.(\d+)$/;
export function compareVersions(a, b) {
  const pa = String(a).match(SEMVER); const pb = String(b).match(SEMVER);
  if (!pa || !pb) return 0;
  for (let i = 1; i <= 3; i++) { const d = Number(pa[i]) - Number(pb[i]); if (d) return Math.sign(d); }
  return 0;
}

export async function checkForUpdate() {
  if (!config.update.repo || !/^[\w.-]+\/[\w.-]+$/.test(config.update.repo)) return { configured: false, current: VERSION };
  const res = await fetch(`https://api.github.com/repos/${config.update.repo}/releases?per_page=20`, {
    headers: { Accept: 'application/vnd.github+json', 'User-Agent': 'aura-isp-updater' }, signal: AbortSignal.timeout(15000),
  });
  if (!res.ok) throw new Error(`GitHub API ${res.status}`);
  const releases = await res.json();
  const stable = releases
    .filter((r) => !r.draft && !r.prerelease && SEMVER.test(r.tag_name))
    .sort((a, b) => compareVersions(b.tag_name, a.tag_name));
  const latest = stable[0];
  const info = {
    configured: true,
    current: VERSION,
    latest: latest ? latest.tag_name.replace(/^v/, '') : VERSION,
    available: !!latest && compareVersions(latest.tag_name, VERSION) > 0,
    notes: latest?.body?.slice(0, 5000) || '',
    publishedAt: latest?.published_at || null,
    url: latest?.html_url || null,
  };
  await setSetting('updates', { lastCheckAt: now(), latest: info });
  return { ...info, _release: latest };
}

async function download(url, dest) {
  const res = await fetch(url, { headers: { Accept: 'application/octet-stream', 'User-Agent': 'aura-isp-updater' }, redirect: 'follow', signal: AbortSignal.timeout(300000) });
  if (!res.ok) throw new Error(`Download failed (${res.status})`);
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length > 300 * 1024 * 1024) throw new Error('Release asset too large');
  fs.writeFileSync(dest, buf);
  return buf;
}

export function verifySignature(buf, signatureB64, publicKeyPem = config.update.publicKey) {
  if (!publicKeyPem) throw new Error('UPDATE_PUBLIC_KEY is not configured — refusing to install unsigned code');
  const key = crypto.createPublicKey(publicKeyPem.replace(/\\n/g, '\n'));
  return crypto.verify(null, buf, key, Buffer.from(signatureB64.trim(), 'base64'));
}

async function backupCurrent() {
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
  const file = path.join(BACKUP_DIR, `aura-${VERSION}-${Date.now()}.tgz`);
  const entries = ['server/src', 'server/scripts', 'server/package.json', 'server/package-lock.json', 'web/dist'].filter((p) => fs.existsSync(path.join(INSTALL_ROOT, p)));
  await tar.c({ gzip: true, file, cwd: INSTALL_ROOT, portable: true }, entries);
  // keep the 5 newest backups
  const all = fs.readdirSync(BACKUP_DIR).filter((f) => f.endsWith('.tgz')).sort();
  for (const old of all.slice(0, -5)) fs.rmSync(path.join(BACKUP_DIR, old));
  return file;
}

const SAFE_ENTRY = (p) => !p.includes('..') && !path.isAbsolute(p) && !/(^|\/)(\.env|data|node_modules)(\/|$)/.test(p);

async function installDependencies() {
  const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
  await exec(npm, ['ci', '--omit=dev', '--no-audit', '--no-fund'], { cwd: config.root, timeout: 600000, shell: process.platform === 'win32' });
}

export function scheduleRestart() {
  // Passenger (cPanel shared hosting) restarts when tmp/restart.txt is touched; PM2/systemd/Docker restart on exit.
  try { fs.mkdirSync(path.join(config.root, 'tmp'), { recursive: true }); fs.writeFileSync(path.join(config.root, 'tmp', 'restart.txt'), String(Date.now())); } catch { /* ignore */ }
  // Built-in cluster: ask the primary for a rolling restart of ALL workers (new code everywhere).
  if (process.send) { setTimeout(() => process.send({ cmd: 'aura:restart-all' }), 1000).unref(); return; }
  setTimeout(() => process.exit(0), 1500).unref();
}

export async function applyUpdate(triggeredBy = 'manual') {
  const out = await withAdvisoryLock('aura:update', () => applyUpdateLocked(triggeredBy));
  if (out.busy) throw new Error('An update is already in progress');
  return out.result;
}

async function applyUpdateLocked(triggeredBy) {
  if (busy) throw new Error('An update is already in progress');
  busy = true;
  const from = VERSION;
  try {
    const info = await checkForUpdate();
    if (!info.configured) throw new Error('UPDATE_REPO is not configured');
    if (!info.available) return { updated: false, message: 'Already on the latest stable version' };
    const rel = info._release;
    const asset = rel.assets.find((a) => /^aura-isp-.*\.tar\.gz$/.test(a.name));
    const sigAsset = rel.assets.find((a) => a.name === `${asset?.name}.sig`);
    if (!asset || !sigAsset) throw new Error('Release is missing the package or its signature');
    fs.rmSync(STAGE_DIR, { recursive: true, force: true });
    fs.mkdirSync(STAGE_DIR, { recursive: true });
    const pkgFile = path.join(STAGE_DIR, asset.name);
    const buf = await download(asset.browser_download_url, pkgFile);
    const sig = (await download(sigAsset.browser_download_url, `${pkgFile}.sig`)).toString('utf8');
    if (!verifySignature(buf, sig)) throw new Error('Signature verification FAILED — update rejected');
    const backup = await backupCurrent();
    await tar.x({ file: pkgFile, cwd: INSTALL_ROOT, filter: (p) => SAFE_ENTRY(p), strict: true });
    await installDependencies();
    await insert('update_history', { from_version: from, to_version: info.latest, status: 'success', message: `Backup: ${path.basename(backup)}`, triggered_by: triggeredBy, created_at: now() });
    scheduleRestart();
    return { updated: true, from, to: info.latest, restarting: true };
  } catch (e) {
    await insert('update_history', { from_version: from, to_version: null, status: 'failed', message: e.message, triggered_by: triggeredBy, created_at: now() }).catch(() => {});
    throw e;
  } finally {
    busy = false;
    fs.rmSync(STAGE_DIR, { recursive: true, force: true });
  }
}

export function listBackups() {
  if (!fs.existsSync(BACKUP_DIR)) return [];
  return fs.readdirSync(BACKUP_DIR).filter((f) => f.endsWith('.tgz')).sort().reverse()
    .map((f) => ({ file: f, size: fs.statSync(path.join(BACKUP_DIR, f)).size }));
}

export async function rollback(file) {
  if (!/^aura-[\w.-]+\.tgz$/.test(file)) throw new Error('Invalid backup');
  const full = path.join(BACKUP_DIR, file);
  if (!fs.existsSync(full)) throw new Error('Backup not found');
  await tar.x({ file: full, cwd: INSTALL_ROOT, filter: (p) => SAFE_ENTRY(p), strict: true });
  await installDependencies();
  await insert('update_history', { from_version: VERSION, to_version: file, status: 'rollback', message: 'Rolled back', triggered_by: 'manual', created_at: now() });
  scheduleRestart();
  return { ok: true, restarting: true };
}

export async function autoUpdateTick() {
  const s = await getSetting('updates');
  if (!s.auto) return checkForUpdate().catch(() => null);
  return applyUpdate('auto').catch((e) => console.warn('[updater]', e.message));
}

export async function history() {
  return db().all('SELECT * FROM update_history ORDER BY id DESC LIMIT 50');
}
