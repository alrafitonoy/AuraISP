import { Router } from 'express';
import { z } from 'zod';
import { db, insert, update, now, paginate, parseJson } from '../db/index.js';
import { validate, notFound, badRequest } from '../lib/http.js';
import { authenticate, requirePerm, requireModule } from '../middleware/auth.js';
import { addClient } from '../lib/events.js';
import { vapidPublicKey } from '../lib/channels.js';
import { notify, buildEmailHtml, render } from '../lib/notify.js';
import { sendEmail } from '../lib/channels.js';
import { DESIGNS, emailDesignSchema } from '../lib/email-templates.js';
import { sha256 } from '../lib/crypto.js';
import { audit } from '../lib/audit.js';
import { CHANNELS } from '../lib/catalog.js';
import { resolveAudience, resolveExternal, sendExternal, isExternalAudience } from './crm.js';

const r = Router();
r.use(authenticate);

// ------------------------------------------------------------------ my notifications
r.get('/', async (req, res) => {
  const rows = await db().all('SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 50', [req.user.id]);
  const unread = await db().get('SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND read_at IS NULL', [req.user.id]);
  res.json({ notifications: rows, unread: Number(unread.n) });
});

r.post('/:id/read', async (req, res) => {
  await db().run('UPDATE notifications SET read_at = ? WHERE id = ? AND user_id = ?', [now(), Number(req.params.id), req.user.id]);
  res.json({ ok: true });
});

r.post('/read-all', async (req, res) => {
  await db().run('UPDATE notifications SET read_at = ? WHERE user_id = ? AND read_at IS NULL', [now(), req.user.id]);
  res.json({ ok: true });
});

// Server-Sent Events stream (in-app realtime notifications, live bandwidth).
r.get('/stream', (req, res) => {
  res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
  res.flushHeaders();
  res.write(`event: hello\ndata: {"ok":true}\n\n`);
  const off = addClient(req.user.id, res);
  const ping = setInterval(() => res.write(': ping\n\n'), 25000);
  req.on('close', () => { clearInterval(ping); off(); });
});

r.get('/push/key', (_req, res) => res.json({ publicKey: vapidPublicKey() }));

r.post('/push/subscribe', validate(z.object({
  kind: z.enum(['web', 'fcm']).default('web'),
  endpoint: z.string().min(10).max(2000),
  keys: z.object({ p256dh: z.string().max(200), auth: z.string().max(100) }).optional(),
})), async (req, res) => {
  const { kind, endpoint, keys } = req.body;
  if (kind === 'web' && !/^https:\/\//.test(endpoint)) throw badRequest('Invalid push endpoint');
  const hash = sha256(endpoint);
  await db().run('DELETE FROM push_subscriptions WHERE endpoint_hash = ?', [hash]);
  await insert('push_subscriptions', { user_id: req.user.id, kind, endpoint, keys_json: JSON.stringify(keys || {}), endpoint_hash: hash, created_at: now() });
  res.json({ ok: true });
});

r.post('/push/unsubscribe', validate(z.object({ endpoint: z.string().max(2000) })), async (req, res) => {
  await db().run('DELETE FROM push_subscriptions WHERE endpoint_hash = ? AND user_id = ?', [sha256(req.body.endpoint), req.user.id]);
  res.json({ ok: true });
});

// ------------------------------------------------------------------ admin: templates
const tplSchema = z.object({
  template_key: z.string().regex(/^[a-z0-9_]{2,60}$/).optional(),
  name: z.string().min(2).max(120),
  subject: z.string().max(250).optional().nullable(),
  body: z.string().max(10000),
  sms_body: z.string().max(640).optional().nullable(),
  channels: z.array(z.enum(CHANNELS)).min(1),
  active: z.boolean().optional(),
  email_design: emailDesignSchema.optional().nullable(),
});

r.get('/templates', requirePerm('notifications.manage'), async (_req, res) => {
  const rows = await db().all('SELECT * FROM notification_templates ORDER BY name');
  res.json({ templates: rows.map((t) => ({ ...t, channels: parseJson(t.channels, []), active: !!t.active, email_design: parseJson(t.email_design, null) })) });
});
r.post('/templates', requirePerm('notifications.manage'), validate(tplSchema.required({ template_key: true })), async (req, res) => {
  const out = await insert('notification_templates', { ...req.body, channels: JSON.stringify(req.body.channels), email_design: req.body.email_design ? JSON.stringify(req.body.email_design) : null, updated_at: now() });
  res.status(201).json({ id: out.id });
});
r.put('/templates/:id', requirePerm('notifications.manage'), validate(tplSchema.partial()), async (req, res) => {
  const { template_key, ...rest } = req.body; // keys are immutable (code references them)
  if (rest.channels) rest.channels = JSON.stringify(rest.channels);
  if (rest.email_design !== undefined) rest.email_design = rest.email_design ? JSON.stringify(rest.email_design) : null;
  await update('notification_templates', Number(req.params.id), { ...rest, updated_at: now() });
  res.json({ ok: true });
});

// ------------------------------------------------------------------ admin: email designs (gallery, live preview, test)
const designPerm = requirePerm('notifications.manage', 'crm.manage', 'notifications.send', 'settings.manage');
const previewSchema = z.object({ subject: z.string().max(250).optional(), body: z.string().max(10000).optional(), email_design: emailDesignSchema.optional().nullable() });
// Realistic sample values so previews of templates like "invoice_created" look like the real thing.
const sampleCtx = (u) => ({ name: u.name, user: { name: u.name, email: u.email }, invoice: 'INV-2026-00042', amount: '৳1,200', due_date: '2026-12-01', plan: 'Home 25 Mbps', date: '2026-12-01', days: 3 });
r.get('/email-designs', designPerm, (_req, res) => res.json({ designs: DESIGNS }));
r.post('/email-preview', designPerm, validate(previewSchema), async (req, res) => {
  const ctx = sampleCtx(req.user);
  const subject = render(req.body.subject || 'Your subject line', ctx);
  const text = render(req.body.body || 'Write your message here. Use {{name}} to greet the customer by name.', ctx);
  res.json({ html: await buildEmailHtml({ subject, text, email: req.body.email_design || null, ctx }) });
});
r.post('/email-test', designPerm, validate(previewSchema), async (req, res) => {
  const ctx = sampleCtx(req.user);
  const subject = `[Test] ${render(req.body.subject || 'Email design preview', ctx)}`;
  const text = render(req.body.body || 'This is how your email looks.', ctx);
  try { await sendEmail({ to: req.user.email, subject, text, html: await buildEmailHtml({ subject, text, email: req.body.email_design || null, ctx }) }); }
  catch (e) { throw badRequest(`Could not send the test email: ${e.message}`); }
  res.json({ ok: true, to: req.user.email });
});

// ------------------------------------------------------------------ admin: reminder rules
const ruleSchema = z.object({
  name: z.string().min(2).max(120),
  trigger_event: z.enum(['invoice_due', 'invoice_overdue', 'plan_expiry']),
  offset_days: z.coerce.number().int().min(-60).max(60),
  template_key: z.string().max(60),
  channels: z.array(z.enum(CHANNELS)).min(1),
  active: z.boolean().optional(),
});
r.get('/reminders', requirePerm('notifications.manage'), requireModule('reminders'), async (_req, res) => {
  const rows = await db().all('SELECT * FROM reminder_rules ORDER BY trigger_event, offset_days');
  res.json({ rules: rows.map((x) => ({ ...x, channels: parseJson(x.channels, []), active: !!x.active })) });
});
r.post('/reminders', requirePerm('notifications.manage'), requireModule('reminders'), validate(ruleSchema), async (req, res) => {
  const out = await insert('reminder_rules', { ...req.body, channels: JSON.stringify(req.body.channels), created_at: now() });
  res.status(201).json({ id: out.id });
});
r.put('/reminders/:id', requirePerm('notifications.manage'), requireModule('reminders'), validate(ruleSchema.partial()), async (req, res) => {
  const b = { ...req.body }; if (b.channels) b.channels = JSON.stringify(b.channels);
  await update('reminder_rules', Number(req.params.id), b);
  res.json({ ok: true });
});
r.delete('/reminders/:id', requirePerm('notifications.manage'), async (req, res) => {
  await db().run('DELETE FROM reminder_rules WHERE id = ?', [Number(req.params.id)]);
  res.json({ ok: true });
});

// ------------------------------------------------------------------ admin: custom notification broadcast
r.post('/send', requirePerm('notifications.send'), requireModule('notifications'), validate(z.object({
  audience: z.object({
    type: z.enum(['all_customers', 'status', 'plan', 'area', 'customers', 'staff', 'overdue', 'leads', 'emails']),
    value: z.union([z.string().max(120), z.array(z.coerce.number().int()).max(20000), z.array(z.string().max(190)).max(500)]).optional(),
  }),
  channels: z.array(z.enum(CHANNELS)).min(1),
  subject: z.string().min(1).max(200),
  body: z.string().min(1).max(5000),
  link: z.string().max(300).regex(/^\/[A-Za-z0-9/_?=&-]*$/).optional(),
  email_design: emailDesignSchema.optional().nullable(),
})), async (req, res) => {
  if (isExternalAudience(req.body.audience)) {
    // Leads / plain email addresses: no app account, so only email (and SMS/WhatsApp for leads with a phone).
    const channels = req.body.channels.filter((ch) => ['email', 'sms', 'whatsapp'].includes(ch));
    if (!channels.length) throw badRequest('Choose Email (or SMS/WhatsApp for leads) — push and in-app need a customer account');
    const people = await resolveExternal(req.body.audience);
    if (!people.length) throw badRequest('No recipients match this audience');
    await audit(req, 'notifications.broadcast', null, null, { audience: { type: req.body.audience.type }, channels, count: people.length });
    res.json({ queued: people.length });
    await sendExternal(people, channels, { subject: req.body.subject, body: req.body.body, email: req.body.email_design || null }).catch(() => {});
    return;
  }
  const userIds = await resolveAudience(req.body.audience);
  if (!userIds.length) throw badRequest('No recipients match this audience');
  if (userIds.length > 20000) throw badRequest('Audience too large — use a campaign');
  await audit(req, 'notifications.broadcast', null, null, { audience: req.body.audience, channels: req.body.channels, count: userIds.length });
  res.json({ queued: userIds.length });
  // Fan out after responding.
  for (const id of userIds) {
    await notify({ userId: id, channels: req.body.channels, subject: req.body.subject, body: req.body.body, link: req.body.link, email: req.body.email_design || undefined }).catch(() => {});
  }
});

r.get('/log', requirePerm('notifications.manage'), async (req, res) => {
  const { channel, status, page, pageSize } = req.query;
  const where = []; const params = [];
  if (channel) { where.push('l.channel = ?'); params.push(String(channel)); }
  if (status) { where.push('l.status = ?'); params.push(String(status)); }
  const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const from = `FROM notification_log l LEFT JOIN users u ON u.id = l.user_id ${w}`;
  res.json(await paginate({ base: `SELECT l.id, l.channel, l.recipient, l.subject, l.status, l.error, l.created_at, u.name ${from}`, countBase: `SELECT COUNT(*) AS n ${from}`, params, page, pageSize, defaultSort: 'l.id DESC' }));
});

r.post('/test', requirePerm('settings.manage'), validate(z.object({ channel: z.enum(CHANNELS) })), async (req, res) => {
  const [out] = await notify({ userId: req.user.id, channels: [req.body.channel], subject: 'Test notification', body: `This is a test ${req.body.channel} message from your ISP platform.` });
  if (!out) throw notFound();
  res.json(out);
});

export default r;
