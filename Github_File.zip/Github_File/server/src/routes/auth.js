import { Router } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import multer from 'multer';
import { z } from 'zod';
import QRCode from 'qrcode';
import config from '../config.js';
import { db, insert, now, parseJson } from '../db/index.js';
import { hashPassword, verifyPassword, dummyVerify, randomToken, sha256, encrypt, decrypt, randomDigits, codeHash, safeEqual } from '../lib/crypto.js';
import { generateSecret, verifyTotp, otpauthUrl } from '../lib/totp.js';
import { validate, badRequest, unauthorized, forbidden, clientIp, HttpError } from '../lib/http.js';
import { authenticate, signAccessToken, signChallengeToken, verifyChallengeToken, loadAuthUser } from '../middleware/auth.js';
import { authLimiter, otpLimiter, registerLimiter, requireXhr } from '../middleware/security.js';
import { getSetting } from '../lib/settings.js';
import { sendDirect } from '../lib/notify.js';
import { audit } from '../lib/audit.js';

const r = Router();
const COOKIE = 'aura_rt';

const email = z.string().trim().toLowerCase().email().max(190);
const phone = z.string().trim().regex(/^\+?[0-9\s-]{7,20}$/, 'Invalid phone number').transform((s) => s.replace(/[\s-]/g, ''));

async function passwordSchema() {
  const { passwordMinLength } = await getSetting('security');
  return z.string().min(passwordMinLength || 10, `Password must be at least ${passwordMinLength} characters`).max(128)
    .refine((p) => /[a-z]/.test(p) && /[A-Z]/.test(p) && /\d/.test(p), 'Password needs upper-case, lower-case and a number');
}

export async function assertPassword(pw) {
  const s = await passwordSchema();
  const res = s.safeParse(pw);
  if (!res.success) throw badRequest(res.error.issues[0].message);
  const common = ['password', '12345678', 'qwerty', 'letmein', 'welcome', 'admin123', 'iloveyou'];
  if (common.some((c) => pw.toLowerCase().includes(c))) throw badRequest('Password is too common');
}

function cookieOpts(days) {
  return { httpOnly: true, secure: config.isProd, sameSite: 'strict', path: '/api/auth', maxAge: days * 86400000 };
}

async function issueSession(req, res, user, client = 'web', family = null) {
  const { sessionDays } = await getSetting('security');
  const raw = randomToken(48);
  await insert('sessions', {
    user_id: user.id, token_hash: sha256(raw), family: family || randomToken(12), user_agent: String(req.get('user-agent') || '').slice(0, 250),
    ip: clientIp(req), client, expires_at: new Date(Date.now() + sessionDays * 86400000).toISOString(), created_at: now(), last_used_at: now(),
  });
  const accessToken = signAccessToken(user);
  const out = { accessToken, expiresIn: 900, user: await publicUser(user.id) };
  // Native apps (mobile/desktop) cannot rely on cookies — they keep the refresh token in secure storage.
  if (client === 'native') out.refreshToken = raw;
  else res.cookie(COOKIE, raw, cookieOpts(sessionDays));
  return out;
}

export async function publicUser(id) {
  const u = await loadAuthUser(id);
  if (!u) return null;
  const sec = await getSetting('security');
  return {
    id: u.id, type: u.type, name: u.name, email: u.email, phone: u.phone, avatar: u.avatar,
    role: u.role_slug ? { slug: u.role_slug, name: u.role_name } : null,
    permissions: u.permissions, dashboard: u.dashboard, preferences: u.preferences,
    emailVerified: !!u.email_verified_at, phoneVerified: !!u.phone_verified_at, twoFactor: !!u.totp_enabled,
    customerId: u.customer_id ?? null,
    mustSetup2fa: u.type !== 'customer' && sec.require2faForStaff && !u.totp_enabled,
    needsVerification: u.type === 'customer' && ((sec.requireEmailVerification && !u.email_verified_at) || (sec.requirePhoneVerification && !u.phone_verified_at)),
  };
}

// ------------------------------------------------------------------ registration
const registerSchema = z.object({
  name: z.string().trim().min(2).max(120),
  email,
  phone,
  password: z.string().max(128),
  address: z.string().trim().max(500).optional(),
  area: z.string().trim().max(120).optional(),
  planId: z.coerce.number().int().positive().optional(),
  client: z.enum(['web', 'native']).optional(),
});

r.post('/register', registerLimiter, authLimiter, validate(registerSchema), async (req, res) => {
  const b = req.body;
  await assertPassword(b.password);
  const exists = await db().get('SELECT id FROM users WHERE email = ?', [b.email]);
  if (exists) throw new HttpError(409, 'An account with this email already exists');
  const role = await db().get("SELECT id FROM roles WHERE slug = 'customer'");
  const hash = await hashPassword(b.password);
  const ts = now();
  const user = await db().transaction(async (t) => {
    const u = await insert('users', { type: 'customer', role_id: role?.id, name: b.name, email: b.email, phone: b.phone, password_hash: hash, status: 'active', created_at: ts, updated_at: ts }, t);
    const code = `C${String(u.id).padStart(6, '0')}`;
    await insert('customers', { user_id: u.id, code, address: b.address, area: b.area, status: 'pending', billing_day: new Date().getUTCDate(), created_at: ts, updated_at: ts }, t);
    if (b.planId) {
      const plan = await t.get('SELECT id, name, price_cents FROM plans WHERE id = ? AND active = 1 AND is_public = 1', [b.planId]);
      if (plan) await insert('leads', { name: b.name, email: b.email, phone: b.phone, address: b.address, source: 'signup', status: 'qualified', plan_id: plan.id, value_cents: plan.price_cents, created_at: ts, updated_at: ts }, t);
    }
    return { id: u.id };
  });
  await sendCode(user.id, 'email').catch((e) => console.warn('[auth] email code not sent:', e.message));
  await audit({ ...req, user: { id: user.id } }, 'auth.register', 'user', user.id);
  res.status(201).json(await issueSession(req, res, await loadAuthUser(user.id), b.client));
});

// ------------------------------------------------------------------ login
const loginSchema = z.object({ email, password: z.string().min(1).max(128), client: z.enum(['web', 'native']).optional(), app: z.enum(['web', 'desktop', 'mobile']).optional() });

r.post('/login', authLimiter, validate(loginSchema), async (req, res) => {
  const { email: em, password, client, app } = req.body;
  const sec = await getSetting('security');
  const u = await db().get('SELECT * FROM users WHERE email = ?', [em]);
  if (!u) { await dummyVerify(password); throw unauthorized('Invalid email or password'); }
  if (u.locked_until && u.locked_until > now()) throw new HttpError(423, 'Account temporarily locked after too many failed attempts. Try again later.');
  const ok = await verifyPassword(u.password_hash, password);
  if (!ok) {
    const fails = Number(u.failed_logins || 0) + 1;
    const lock = fails >= sec.maxLoginAttempts ? new Date(Date.now() + sec.lockMinutes * 60000).toISOString() : null;
    await db().run('UPDATE users SET failed_logins = ?, locked_until = ? WHERE id = ?', [lock ? 0 : fails, lock, u.id]);
    await audit({ ...req, user: { id: u.id } }, lock ? 'auth.locked' : 'auth.failed', 'user', u.id);
    throw unauthorized('Invalid email or password');
  }
  if (u.status !== 'active') throw forbidden('This account is disabled. Contact support.');
  if (app === 'desktop' && u.type === 'customer') throw forbidden('The desktop app is for administrators and staff. Please use the web or mobile app.');
  if (app === 'mobile' && u.type !== 'customer') throw forbidden('The mobile app is for customers. Staff and administrators please use the web or desktop app.');
  await db().run('UPDATE users SET failed_logins = 0, locked_until = NULL WHERE id = ?', [u.id]);
  if (u.totp_enabled) {
    return res.json({ mfaRequired: true, challenge: signChallengeToken(u, 'mfa'), client: client || 'web' });
  }
  await db().run('UPDATE users SET last_login_at = ?, last_login_ip = ? WHERE id = ?', [now(), clientIp(req), u.id]);
  await audit({ ...req, user: { id: u.id } }, 'auth.login', 'user', u.id);
  res.json(await issueSession(req, res, u, client));
});

r.post('/login/mfa', authLimiter, validate(z.object({ challenge: z.string().max(1000), code: z.string().trim().min(6).max(20), client: z.enum(['web', 'native']).optional() })), async (req, res) => {
  const id = verifyChallengeToken(req.body.challenge, 'mfa');
  if (!id) throw unauthorized('Challenge expired, please sign in again');
  const u = await db().get('SELECT * FROM users WHERE id = ?', [id]);
  if (!u?.totp_enabled) throw unauthorized();
  if (u.locked_until && u.locked_until > now()) throw new HttpError(423, 'Account temporarily locked after too many failed attempts. Try again later.');
  if (!(await checkSecondFactor(u, req.body.code))) {
    // Second-factor failures count towards the same per-account lockout as passwords (stops distributed brute force).
    const sec = await getSetting('security');
    const fails = Number(u.failed_logins || 0) + 1;
    const lock = fails >= sec.maxLoginAttempts ? new Date(Date.now() + sec.lockMinutes * 60000).toISOString() : null;
    await db().run('UPDATE users SET failed_logins = ?, locked_until = ? WHERE id = ?', [lock ? 0 : fails, lock, u.id]);
    await audit({ ...req, user: { id } }, lock ? 'auth.locked' : 'auth.mfa_failed', 'user', id);
    throw unauthorized('Invalid authentication code');
  }
  await db().run('UPDATE users SET failed_logins = 0 WHERE id = ?', [u.id]);
  await db().run('UPDATE users SET last_login_at = ?, last_login_ip = ? WHERE id = ?', [now(), clientIp(req), u.id]);
  await audit({ ...req, user: { id } }, 'auth.login', 'user', id, { mfa: true });
  res.json(await issueSession(req, res, u, req.body.client));
});

async function checkSecondFactor(u, code) {
  const clean = String(code).replace(/[\s-]/g, '');
  if (/^\d{6}$/.test(clean)) {
    const step = verifyTotp(decrypt(u.totp_secret), clean, { lastStep: Number(u.totp_last_step || 0) });
    if (step) { await db().run('UPDATE users SET totp_last_step = ? WHERE id = ?', [step, u.id]); return true; }
    return false;
  }
  // Backup code (single use)
  const codes = parseJson(u.backup_codes, []);
  const h = codeHash(clean);
  const idx = codes.findIndex((c) => safeEqual(c, h));
  if (idx < 0) return false;
  codes.splice(idx, 1);
  await db().run('UPDATE users SET backup_codes = ? WHERE id = ?', [JSON.stringify(codes), u.id]);
  return true;
}

// ------------------------------------------------------------------ refresh / logout
r.post('/refresh', requireXhr, async (req, res) => {
  const raw = req.cookies?.[COOKIE] || req.body?.refreshToken;
  if (!raw || typeof raw !== 'string') throw unauthorized('No session');
  const s = await db().get('SELECT * FROM sessions WHERE token_hash = ?', [sha256(raw)]);
  if (!s) throw unauthorized('Invalid session');
  const graceMs = 20_000;
  const concurrent = s.revoked_at && s.rotated_at && Date.now() - new Date(s.rotated_at).getTime() < graceMs;
  if (s.revoked_at && !concurrent) {
    // Token reuse outside the grace window => likely theft. Kill the whole token family.
    await db().run('UPDATE sessions SET revoked_at = ? WHERE family = ? AND revoked_at IS NULL', [now(), s.family]);
    await audit({ ...req, user: { id: s.user_id } }, 'auth.token_reuse', 'session', s.id);
    throw unauthorized('Session revoked');
  }
  if (s.expires_at < now()) throw unauthorized('Session expired');
  const u = await db().get('SELECT * FROM users WHERE id = ?', [s.user_id]);
  if (!u || u.status !== 'active') throw unauthorized();
  if (!s.revoked_at) await db().run('UPDATE sessions SET revoked_at = ?, rotated_at = ? WHERE id = ?', [now(), now(), s.id]);
  res.json(await issueSession(req, res, u, s.client === 'native' ? 'native' : 'web', s.family));
});

r.post('/logout', requireXhr, async (req, res) => {
  const raw = req.cookies?.[COOKIE] || req.body?.refreshToken;
  if (raw) await db().run('UPDATE sessions SET revoked_at = ? WHERE token_hash = ? AND revoked_at IS NULL', [now(), sha256(raw)]);
  res.clearCookie(COOKIE, { path: '/api/auth' });
  res.json({ ok: true });
});

r.get('/me', authenticate, async (req, res) => res.json({ user: await publicUser(req.user.id) }));

r.patch('/me', authenticate, validate(z.object({ name: z.string().trim().min(2).max(120).optional(), preferences: z.record(z.string().max(60), z.any()).optional() })), async (req, res) => {
  const patch = { updated_at: now() };
  if (req.body.name) patch.name = req.body.name;
  if (req.body.preferences) patch.preferences = JSON.stringify(req.body.preferences).slice(0, 5000);
  await db().run(`UPDATE users SET ${Object.keys(patch).map((k) => `${k} = ?`).join(', ')} WHERE id = ?`, [...Object.values(patch), req.user.id]);
  res.json({ user: await publicUser(req.user.id) });
});

// ------------------------------------------------------------------ profile picture
const avatarUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 1024 * 1024, files: 1 } });
const IMG = [
  { ext: 'png', test: (b) => b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) },
  { ext: 'jpg', test: (b) => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  { ext: 'webp', test: (b) => b.subarray(0, 4).toString() === 'RIFF' && b.subarray(8, 12).toString() === 'WEBP' },
]; // SVG/GIF rejected (scripts, animation bombs)
const AVATAR_DIR = path.join(config.uploadsDir, 'avatars');
const removeAvatarFile = (url) => {
  const m = /^\/uploads\/avatars\/([A-Za-z0-9]+\.(png|jpg|webp))$/.exec(url || '');
  if (m) fs.rmSync(path.join(AVATAR_DIR, m[1]), { force: true });
};

r.post('/me/avatar', authenticate, avatarUpload.single('file'), async (req, res) => {
  if (!req.file) throw badRequest('No image uploaded');
  const type = IMG.find((t) => t.test(req.file.buffer));
  if (!type) throw badRequest('Use a PNG, JPG or WEBP image (max 1 MB)');
  fs.mkdirSync(AVATAR_DIR, { recursive: true });
  const name = `${randomToken(16).replace(/[^A-Za-z0-9]/g, '')}.${type.ext}`;
  fs.writeFileSync(path.join(AVATAR_DIR, name), req.file.buffer);
  const old = await db().get('SELECT avatar FROM users WHERE id = ?', [req.user.id]);
  await db().run('UPDATE users SET avatar = ?, updated_at = ? WHERE id = ?', [`/uploads/avatars/${name}`, now(), req.user.id]);
  removeAvatarFile(old?.avatar);
  res.json({ user: await publicUser(req.user.id) });
});

r.delete('/me/avatar', authenticate, async (req, res) => {
  const old = await db().get('SELECT avatar FROM users WHERE id = ?', [req.user.id]);
  await db().run('UPDATE users SET avatar = NULL, updated_at = ? WHERE id = ?', [now(), req.user.id]);
  removeAvatarFile(old?.avatar);
  res.json({ user: await publicUser(req.user.id) });
});

// ------------------------------------------------------------------ verification codes (email / phone)
async function sendCode(userId, purpose) {
  const u = await db().get('SELECT id, email, phone FROM users WHERE id = ?', [userId]);
  const code = randomDigits(6);
  await db().run('UPDATE verification_codes SET used_at = ? WHERE user_id = ? AND purpose = ? AND used_at IS NULL', [now(), userId, purpose]);
  await insert('verification_codes', { user_id: userId, purpose, code_hash: codeHash(code), expires_at: new Date(Date.now() + 10 * 60000).toISOString(), created_at: now() });
  const brand = await getSetting('branding');
  const text = `Your ${brand.companyName} verification code is ${code}. It expires in 10 minutes. Never share this code.`;
  try {
    if (purpose === 'email' || purpose === 'reset') await sendDirect('email', u.email, `${brand.companyName} verification code`, text);
    else if (purpose === 'phone') await sendDirect('sms', u.phone, '', text);
  } catch (e) {
    // Only ever print codes on an explicit development install — never in production, staging or tests.
    if (config.env === 'development') console.log(`[dev] ${purpose} code for user ${userId}: ${code} (delivery failed: ${e.message})`);
    else { console.warn(`[auth] ${purpose} code delivery failed: ${e.message}`); throw new HttpError(503, 'We could not send the code right now. Please contact support.'); }
  }
}

async function checkCode(userId, purpose, code) {
  const row = await db().get('SELECT * FROM verification_codes WHERE user_id = ? AND purpose = ? AND used_at IS NULL ORDER BY id DESC LIMIT 1', [userId, purpose]);
  if (!row || row.expires_at < now()) throw badRequest('Code expired. Request a new one.');
  if (row.attempts >= 5) throw badRequest('Too many attempts. Request a new code.');
  if (!safeEqual(row.code_hash, codeHash(code))) {
    await db().run('UPDATE verification_codes SET attempts = attempts + 1 WHERE id = ?', [row.id]);
    throw badRequest('Incorrect code');
  }
  await db().run('UPDATE verification_codes SET used_at = ? WHERE id = ?', [now(), row.id]);
}

r.post('/verify/:channel/send', authenticate, otpLimiter, async (req, res) => {
  const ch = req.params.channel;
  if (!['email', 'phone'].includes(ch)) throw badRequest('Unknown channel');
  if (ch === 'phone' && !req.user.phone) throw badRequest('Add a phone number first');
  await sendCode(req.user.id, ch);
  res.json({ ok: true });
});

r.post('/verify/:channel/confirm', authenticate, otpLimiter, validate(z.object({ code: z.string().trim().regex(/^\d{6}$/) })), async (req, res) => {
  const ch = req.params.channel;
  if (!['email', 'phone'].includes(ch)) throw badRequest('Unknown channel');
  await checkCode(req.user.id, ch, req.body.code);
  await db().run(`UPDATE users SET ${ch === 'email' ? 'email_verified_at' : 'phone_verified_at'} = ? WHERE id = ?`, [now(), req.user.id]);
  await audit(req, `auth.verify_${ch}`, 'user', req.user.id);
  res.json({ user: await publicUser(req.user.id) });
});

// ------------------------------------------------------------------ password reset / change
r.post('/password/forgot', otpLimiter, validate(z.object({ email })), async (req, res) => {
  const u = await db().get('SELECT id FROM users WHERE email = ? AND status = ?', [req.body.email, 'active']);
  if (u) await sendCode(u.id, 'reset').catch((e) => console.warn('[auth] reset mail failed', e.message));
  // Same response either way — no account enumeration.
  res.json({ ok: true, message: 'If that email is registered, a reset code has been sent.' });
});

r.post('/password/reset', otpLimiter, validate(z.object({ email, code: z.string().trim().regex(/^\d{6}$/), password: z.string().max(128) })), async (req, res) => {
  const u = await db().get('SELECT id FROM users WHERE email = ?', [req.body.email]);
  if (!u) throw badRequest('Incorrect code');
  await assertPassword(req.body.password); // first, so a weak password doesn't burn the one-time code
  await checkCode(u.id, 'reset', req.body.code);
  await db().run('UPDATE users SET password_hash = ?, token_version = token_version + 1, failed_logins = 0, locked_until = NULL, updated_at = ? WHERE id = ?', [await hashPassword(req.body.password), now(), u.id]);
  await db().run('UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL', [now(), u.id]);
  await audit({ ...req, user: { id: u.id } }, 'auth.password_reset', 'user', u.id);
  res.json({ ok: true });
});

r.post('/password/change', authenticate, validate(z.object({ current: z.string().max(128), password: z.string().max(128), client: z.enum(['web', 'native']).optional() })), async (req, res) => {
  const u = await db().get('SELECT password_hash FROM users WHERE id = ?', [req.user.id]);
  if (!(await verifyPassword(u.password_hash, req.body.current))) throw badRequest('Current password is incorrect');
  await assertPassword(req.body.password);
  await db().run('UPDATE users SET password_hash = ?, token_version = token_version + 1, updated_at = ? WHERE id = ?', [await hashPassword(req.body.password), now(), req.user.id]);
  await db().run('UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL', [now(), req.user.id]);
  await audit(req, 'auth.password_change', 'user', req.user.id);
  res.json(await issueSession(req, res, await loadAuthUser(req.user.id), req.body.client));
});

// ------------------------------------------------------------------ two-factor (TOTP + backup codes)
function makeBackupCodes() {
  const codes = Array.from({ length: 10 }, () => randomToken(6).replace(/[^A-Za-z0-9]/g, 'X').slice(0, 8).toUpperCase());
  return { plain: codes.map((c) => `${c.slice(0, 4)}-${c.slice(4)}`), hashed: codes.map(codeHash) };
}

r.post('/2fa/setup', authenticate, async (req, res) => {
  if (req.user.totp_enabled) throw badRequest('Two-factor authentication is already enabled');
  const secret = generateSecret();
  await db().run('UPDATE users SET totp_secret = ? WHERE id = ?', [encrypt(secret), req.user.id]);
  const brand = await getSetting('branding');
  const url = otpauthUrl({ secret, label: req.user.email, issuer: brand.companyName });
  res.json({ secret, otpauthUrl: url, qr: await QRCode.toDataURL(url, { margin: 1, width: 240 }) });
});

r.post('/2fa/enable', authenticate, otpLimiter, validate(z.object({ code: z.string().trim().regex(/^\d{6}$/) })), async (req, res) => {
  const u = await db().get('SELECT totp_secret, totp_enabled FROM users WHERE id = ?', [req.user.id]);
  if (u.totp_enabled) throw badRequest('Already enabled');
  const step = verifyTotp(decrypt(u.totp_secret) || '', req.body.code);
  if (!step) throw badRequest('Incorrect code — check your device clock');
  const codes = makeBackupCodes();
  await db().run('UPDATE users SET totp_enabled = 1, totp_last_step = ?, backup_codes = ? WHERE id = ?', [step, JSON.stringify(codes.hashed), req.user.id]);
  await audit(req, 'auth.2fa_enabled', 'user', req.user.id);
  res.json({ backupCodes: codes.plain });
});

r.post('/2fa/disable', authenticate, otpLimiter, validate(z.object({ password: z.string().max(128), code: z.string().trim().min(6).max(20) })), async (req, res) => {
  const u = await db().get('SELECT * FROM users WHERE id = ?', [req.user.id]);
  if (!(await verifyPassword(u.password_hash, req.body.password))) throw badRequest('Password is incorrect');
  if (!(await checkSecondFactor(u, req.body.code))) throw badRequest('Invalid authentication code');
  const sec = await getSetting('security');
  if (u.type !== 'customer' && sec.require2faForStaff) throw forbidden('Your organisation requires two-factor authentication for staff');
  await db().run('UPDATE users SET totp_enabled = 0, totp_secret = NULL, backup_codes = NULL WHERE id = ?', [u.id]);
  await audit(req, 'auth.2fa_disabled', 'user', u.id);
  res.json({ ok: true });
});

r.post('/2fa/backup-codes', authenticate, otpLimiter, validate(z.object({ code: z.string().trim().regex(/^\d{6}$/) })), async (req, res) => {
  const u = await db().get('SELECT * FROM users WHERE id = ?', [req.user.id]);
  if (!u.totp_enabled || !(await checkSecondFactor(u, req.body.code))) throw badRequest('Invalid authentication code');
  const codes = makeBackupCodes();
  await db().run('UPDATE users SET backup_codes = ? WHERE id = ?', [JSON.stringify(codes.hashed), u.id]);
  res.json({ backupCodes: codes.plain });
});

// ------------------------------------------------------------------ sessions
r.get('/sessions', authenticate, async (req, res) => {
  const rows = await db().all('SELECT id, user_agent, ip, client, created_at, last_used_at, expires_at FROM sessions WHERE user_id = ? AND revoked_at IS NULL AND expires_at > ? ORDER BY id DESC LIMIT 50', [req.user.id, now()]);
  res.json({ sessions: rows });
});

r.delete('/sessions/:id', authenticate, async (req, res) => {
  await db().run('UPDATE sessions SET revoked_at = ? WHERE id = ? AND user_id = ?', [now(), Number(req.params.id), req.user.id]);
  res.json({ ok: true });
});

r.post('/sessions/revoke-all', authenticate, async (req, res) => {
  await db().run('UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL', [now(), req.user.id]);
  await db().run('UPDATE users SET token_version = token_version + 1 WHERE id = ?', [req.user.id]);
  res.clearCookie(COOKIE, { path: '/api/auth' });
  res.json({ ok: true });
});

export default r;
