// CRM: leads pipeline, multi-channel marketing campaigns (email/SMS/WhatsApp/push/social), sales tracking, FAQ.
import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import { db, insert, update, now, paginate, parseJson, ciLike } from '../db/index.js';
import { validate, notFound, badRequest } from '../lib/http.js';
import { authenticate, requirePerm, requireModule } from '../middleware/auth.js';
import { notify } from '../lib/notify.js';
import { getSetting } from '../lib/settings.js';
import { audit } from '../lib/audit.js';
import { CHANNELS } from '../lib/catalog.js';
import { parseCsv, toCsv } from '../lib/csv.js';
import { emailDesignSchema } from '../lib/email-templates.js';

const r = Router();

/** Resolve a marketing / broadcast audience to user ids. */
export async function resolveAudience({ type, value }) {
  let rows = [];
  const base = "SELECT u.id FROM users u JOIN customers c ON c.user_id = u.id WHERE u.status = 'active'";
  switch (type) {
    case 'all_customers': rows = await db().all(`${base} AND c.status != 'terminated'`); break;
    case 'status': rows = await db().all(`${base} AND c.status = ?`, [String(value)]); break;
    case 'plan': rows = await db().all(`${base} AND c.plan_id = ?`, [Number(value)]); break;
    case 'area': rows = await db().all(`${base} AND c.area = ?`, [String(value)]); break;
    case 'overdue': rows = await db().all(`${base} AND EXISTS (SELECT 1 FROM invoices i WHERE i.customer_id = c.id AND i.status = 'overdue')`); break;
    case 'customers': {
      const ids = (Array.isArray(value) ? value : []).map(Number).filter(Boolean).slice(0, 5000);
      if (!ids.length) return [];
      rows = await db().all(`${base} AND c.id IN (${ids.map(() => '?').join(',')})`, ids);
      break;
    }
    case 'staff': rows = await db().all("SELECT id FROM users WHERE type IN ('admin','staff') AND status = 'active'"); break;
    default: return [];
  }
  return [...new Set(rows.map((x) => x.id))];
}

/** Recipients without an app account: CRM leads (optionally by stage) or plain email addresses. */
export async function resolveExternal({ type, value }) {
  if (type === 'emails') {
    const list = (Array.isArray(value) ? value : String(value || '').split(/[\s,;]+/))
      .map((e) => String(e).trim().toLowerCase()).filter((e) => z.string().email().max(190).safeParse(e).success);
    return [...new Set(list)].slice(0, 500).map((email) => ({ name: email.split('@')[0], email, phone: null }));
  }
  if (type === 'leads') {
    const rows = value && ['new', 'contacted', 'qualified', 'proposal', 'won', 'lost'].includes(String(value))
      ? await db().all('SELECT id, name, email, phone FROM leads WHERE status = ?', [String(value)])
      : await db().all("SELECT id, name, email, phone FROM leads WHERE status NOT IN ('won','lost')");
    return rows.filter((l) => l.email || l.phone).slice(0, 20000);
  }
  return null;
}
export const isExternalAudience = (a) => ['leads', 'emails'].includes(a?.type);

/** Send to external recipients (email; SMS/WhatsApp when a phone is known). Logged like every other notification. */
export async function sendExternal(recipients, channels, { subject, body, email, ref }) {
  const { buildEmailHtml, render, sendDirect } = await import('../lib/notify.js');
  const { sendEmail } = await import('../lib/channels.js');
  const brand = await getSetting('branding');
  const stats = { recipients: recipients.length, sent: 0, failed: 0, skipped: 0 };
  for (const p of recipients) {
    const ctx = { name: p.name, user: { name: p.name, email: p.email }, company: brand.companyName };
    const subj = render(subject || '', ctx); const text = render(body || '', ctx);
    for (const ch of channels) {
      const to = ch === 'email' ? p.email : ['sms', 'whatsapp'].includes(ch) ? p.phone : null;
      if (!to) { stats.skipped++; continue; }
      let status = 'sent'; let error = null;
      try {
        if (ch === 'email') await sendEmail({ to, subject: subj, text, html: await buildEmailHtml({ subject: subj, text, email, ctx }) });
        else await sendDirect(ch, to, subj, ch === 'whatsapp' ? `*${subj}*\n${text}` : text.slice(0, 640));
      } catch (e) { status = 'failed'; error = e.message; }
      status === 'sent' ? stats.sent++ : stats.failed++;
      await insert('notification_log', { user_id: null, channel: ch, recipient: to, subject: subj.slice(0, 250), body: text.slice(0, 4000), status, error, ref: ref || null, created_at: now() });
    }
  }
  return stats;
}

r.use(authenticate, requireModule('crm'));

// ------------------------------------------------------------------ leads
const leadSchema = z.object({
  name: z.string().trim().min(2).max(120), email: z.string().email().max(190).optional().nullable(), phone: z.string().max(20).optional().nullable(),
  address: z.string().max(500).optional().nullable(), source: z.enum(['website', 'signup', 'chatbot', 'referral', 'facebook', 'whatsapp', 'walk_in', 'phone', 'other']).optional(),
  status: z.enum(['new', 'contacted', 'qualified', 'proposal', 'won', 'lost']).optional(),
  plan_id: z.coerce.number().int().positive().optional().nullable(), assigned_to: z.coerce.number().int().positive().optional().nullable(),
  value_cents: z.coerce.number().int().min(0).optional(), notes: z.string().max(5000).optional().nullable(),
});

r.get('/leads', requirePerm('crm.view'), async (req, res) => {
  const { status, q, page, pageSize } = req.query;
  const where = []; const params = [];
  if (status) { where.push('l.status = ?'); params.push(String(status)); }
  if (q) { where.push(`(l.name ${ciLike()} ? OR l.email ${ciLike()} ? OR l.phone ${ciLike()} ?)`); params.push(...Array(3).fill(`%${String(q).slice(0, 60)}%`)); }
  const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const from = `FROM leads l LEFT JOIN plans p ON p.id = l.plan_id LEFT JOIN users a ON a.id = l.assigned_to ${w}`;
  res.json(await paginate({ base: `SELECT l.*, p.name AS plan_name, a.name AS assignee_name ${from}`, countBase: `SELECT COUNT(*) AS n ${from}`, params, page, pageSize: pageSize || 100, defaultSort: 'l.id DESC' }));
});
r.post('/leads', requirePerm('crm.manage'), validate(leadSchema), async (req, res) => {
  const out = await insert('leads', { ...req.body, created_at: now(), updated_at: now() });
  res.status(201).json({ id: out.id });
});
r.put('/leads/:id', requirePerm('crm.manage'), validate(leadSchema.partial()), async (req, res) => {
  const lead = await db().get('SELECT * FROM leads WHERE id = ?', [Number(req.params.id)]);
  if (!lead) throw notFound();
  await update('leads', lead.id, { ...req.body, updated_at: now() });
  if (req.body.status === 'won' && lead.status !== 'won') {
    await insert('sales', { lead_id: lead.id, plan_id: req.body.plan_id ?? lead.plan_id, staff_id: req.user.id, kind: 'new', amount_cents: req.body.value_cents ?? lead.value_cents, created_at: now() });
  }
  res.json({ ok: true });
});
r.delete('/leads/:id', requirePerm('crm.manage'), async (req, res) => {
  await db().run('DELETE FROM leads WHERE id = ?', [Number(req.params.id)]);
  res.json({ ok: true });
});

// ------------------------------------------------------------------ leads: CSV export / import
const CSV_COLUMNS = ['name', 'email', 'phone', 'address', 'source', 'status', 'plan', 'assigned_to', 'value', 'notes', 'created_at'];
// Accept common header spellings from other CRMs / spreadsheets.
const HEADER_ALIASES = {
  name: ['name', 'full name', 'fullname', 'customer', 'lead', 'lead name', 'contact name'],
  email: ['email', 'e-mail', 'email address', 'mail'],
  phone: ['phone', 'mobile', 'phone number', 'mobile number', 'contact', 'cell', 'whatsapp'],
  address: ['address', 'location', 'area'],
  source: ['source', 'lead source', 'channel'],
  status: ['status', 'stage', 'lead status'],
  plan: ['plan', 'package', 'plan name'],
  assigned_to: ['assigned_to', 'assigned to', 'owner', 'agent', 'assignee'],
  value: ['value', 'amount', 'deal value', 'price'],
  notes: ['notes', 'note', 'comment', 'comments', 'remarks'],
};
const csvUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 2 * 1024 * 1024, files: 1 } });

r.get('/leads/export.csv', requirePerm('crm.view'), async (req, res) => {
  const { status, q } = req.query;
  const where = []; const params = [];
  if (status) { where.push('l.status = ?'); params.push(String(status)); }
  if (q) { where.push(`(l.name ${ciLike()} ? OR l.email ${ciLike()} ? OR l.phone ${ciLike()} ?)`); params.push(...Array(3).fill(`%${String(q).slice(0, 60)}%`)); }
  const rows = await db().all(`SELECT l.*, p.name AS plan_name, a.email AS assignee_email FROM leads l LEFT JOIN plans p ON p.id = l.plan_id
    LEFT JOIN users a ON a.id = l.assigned_to ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY l.id DESC LIMIT 50000`, params);
  const csv = toCsv(CSV_COLUMNS, rows.map((l) => [l.name, l.email, l.phone, l.address, l.source, l.status, l.plan_name, l.assignee_email,
    l.value_cents ? (Number(l.value_cents) / 100).toFixed(2) : '', l.notes, l.created_at]));
  await audit(req, 'crm.leads_export', 'lead', null, { count: rows.length });
  res.set('Content-Type', 'text/csv; charset=utf-8').set('Content-Disposition', `attachment; filename="leads-${new Date().toISOString().slice(0, 10)}.csv"`).send(csv);
});

r.get('/leads/template.csv', requirePerm('crm.manage'), (_req, res) => {
  res.set('Content-Type', 'text/csv; charset=utf-8').set('Content-Disposition', 'attachment; filename="leads-template.csv"')
    .send(toCsv(CSV_COLUMNS.slice(0, -1), [['Rahim Uddin', 'rahim@example.com', '+8801711000000', 'House 5, Road 2, Banani', 'facebook', 'new', 'Home', '', '800', 'Wants installation next week']]));
});

/**
 * Bulk import. dryRun=true validates and previews without saving. Duplicates (same email or phone as an existing
 * lead) are skipped, or updated when onDuplicate=update. Plans match by name/slug, assignees by staff email.
 */
r.post('/leads/import', requirePerm('crm.manage'), csvUpload.single('file'), async (req, res) => {
  if (!req.file) throw badRequest('Choose a .csv file');
  const dryRun = String(req.body?.dryRun) === 'true';
  const onDuplicate = req.body?.onDuplicate === 'update' ? 'update' : 'skip';
  let table;
  try { table = parseCsv(req.file.buffer.toString('utf8'), { maxRows: 5001 }); } catch (e) { throw badRequest(`Could not read the CSV: ${e.message}`); }
  if (table.length < 2) throw badRequest('The file has no data rows (the first row must be the column names)');
  const header = table[0].map((h) => h.trim().toLowerCase().replace(/^﻿/, ''));
  const col = Object.fromEntries(Object.entries(HEADER_ALIASES).map(([k, names]) => [k, header.findIndex((h) => names.includes(h))]));
  if (col.name < 0) throw badRequest(`A "name" column is required. Found columns: ${table[0].join(', ')}`);
  if (col.email < 0 && col.phone < 0) throw badRequest('Add an "email" or "phone" column so leads can be contacted');

  const plans = await db().all('SELECT id, name, slug FROM plans');
  const planBy = new Map(plans.flatMap((p) => [[p.name.toLowerCase(), p.id], [p.slug, p.id]]));
  const staff = await db().all("SELECT id, email FROM users WHERE type IN ('admin','staff')");
  const staffBy = new Map(staff.map((s) => [s.email.toLowerCase(), s.id]));
  const existing = await db().all('SELECT id, email, phone FROM leads');
  const normPhone = (p) => String(p || '').replace(/[^\d]/g, '').slice(-10);
  const byEmail = new Map(existing.filter((l) => l.email).map((l) => [l.email.toLowerCase(), l.id]));
  const byPhone = new Map(existing.filter((l) => normPhone(l.phone)).map((l) => [normPhone(l.phone), l.id]));

  const out = { total: table.length - 1, created: 0, updated: 0, skipped: 0, errors: [], preview: [] };
  const toWrite = [];
  for (let i = 1; i < table.length; i++) {
    const cells = table[i]; const get = (k) => (col[k] >= 0 ? String(cells[col[k]] ?? '').trim() : '');
    const rowNo = i + 1; // spreadsheet row number (header is row 1)
    const value = get('value').replace(/[^\d.]/g, '');
    const planName = get('plan').toLowerCase();
    const assignee = get('assigned_to').toLowerCase();
    const candidate = {
      name: get('name'), email: get('email').toLowerCase() || null, phone: get('phone') || null, address: get('address') || null,
      source: get('source').toLowerCase().replace(/[\s-]+/g, '_') || 'other', status: get('status').toLowerCase() || 'new',
      plan_id: planName ? planBy.get(planName) ?? null : null, assigned_to: assignee ? staffBy.get(assignee) ?? null : null,
      value_cents: value ? Math.round(Number(value) * 100) : 0, notes: get('notes') || null,
    };
    const problems = [];
    if (planName && !candidate.plan_id) problems.push(`unknown plan "${get('plan')}"`);
    if (assignee && !candidate.assigned_to) problems.push(`no staff with email "${get('assigned_to')}"`);
    const parsed = leadSchema.safeParse(candidate);
    if (!parsed.success) {
      const f = parsed.error.flatten().fieldErrors;
      problems.push(...Object.entries(f).map(([k, v]) => `${k}: ${v[0]}`));
    }
    if (!candidate.email && !candidate.phone) problems.push('needs an email or phone');
    if (problems.length) { out.errors.push({ row: rowNo, name: candidate.name, error: problems.join('; ') }); continue; }
    const dupId = (candidate.email && byEmail.get(candidate.email)) || (normPhone(candidate.phone) && byPhone.get(normPhone(candidate.phone)));
    if (dupId && onDuplicate === 'skip') { out.skipped++; continue; }
    // Duplicates inside the same file: the first occurrence wins.
    if (candidate.email) byEmail.set(candidate.email, dupId || -rowNo);
    if (normPhone(candidate.phone)) byPhone.set(normPhone(candidate.phone), dupId || -rowNo);
    if (dupId && dupId < 0) { out.skipped++; continue; }
    toWrite.push({ data: parsed.data, dupId });
    if (out.preview.length < 10) out.preview.push({ row: rowNo, action: dupId ? 'update' : 'create', ...parsed.data });
  }
  out.created = toWrite.filter((w) => !w.dupId).length;
  out.updated = toWrite.filter((w) => w.dupId).length;
  if (!dryRun && toWrite.length) {
    await db().transaction(async (t) => {
      for (const w of toWrite) {
        if (w.dupId) await update('leads', w.dupId, { ...w.data, updated_at: now() }, t);
        else await insert('leads', { ...w.data, created_at: now(), updated_at: now() }, t);
      }
    });
    await audit(req, 'crm.leads_import', 'lead', null, { created: out.created, updated: out.updated, skipped: out.skipped, errors: out.errors.length });
  }
  out.errors = out.errors.slice(0, 200);
  res.json({ ...out, dryRun });
});

// ------------------------------------------------------------------ campaigns
const campaignSchema = z.object({
  name: z.string().trim().min(2).max(120),
  channels: z.array(z.enum([...CHANNELS, 'facebook'])).min(1),
  audience: z.object({ type: z.enum(['all_customers', 'status', 'plan', 'area', 'overdue', 'customers', 'staff', 'leads', 'emails']), value: z.any().optional() }),
  subject: z.string().max(200).optional().nullable(),
  body: z.string().min(1).max(10000),
  social_post: z.string().max(5000).optional().nullable(),
  scheduled_at: z.string().datetime().optional().nullable(),
  email_design: emailDesignSchema.optional().nullable(),
});

r.get('/campaigns', requirePerm('crm.view'), async (_req, res) => {
  const rows = await db().all('SELECT c.*, u.name AS created_by_name FROM campaigns c LEFT JOIN users u ON u.id = c.created_by ORDER BY c.id DESC');
  res.json({ campaigns: rows.map((c) => ({ ...c, channels: parseJson(c.channels, []), audience: parseJson(c.audience, {}), stats: parseJson(c.stats, null), email_design: parseJson(c.email_design, null) })) });
});
r.post('/campaigns', requirePerm('crm.manage'), validate(campaignSchema), async (req, res) => {
  const b = req.body;
  const out = await insert('campaigns', { ...b, channels: JSON.stringify(b.channels), audience: JSON.stringify(b.audience), email_design: b.email_design ? JSON.stringify(b.email_design) : null, status: b.scheduled_at ? 'scheduled' : 'draft', created_by: req.user.id, created_at: now() });
  res.status(201).json({ id: out.id });
});
r.put('/campaigns/:id', requirePerm('crm.manage'), validate(campaignSchema.partial()), async (req, res) => {
  const c = await db().get('SELECT status FROM campaigns WHERE id = ?', [Number(req.params.id)]);
  if (!c) throw notFound();
  if (['sending', 'sent'].includes(c.status)) throw badRequest('Campaign already sent');
  const b = { ...req.body };
  if (b.channels) b.channels = JSON.stringify(b.channels);
  if (b.audience) b.audience = JSON.stringify(b.audience);
  if (b.email_design !== undefined) b.email_design = b.email_design ? JSON.stringify(b.email_design) : null;
  if (b.scheduled_at !== undefined) b.status = b.scheduled_at ? 'scheduled' : 'draft';
  await update('campaigns', Number(req.params.id), b);
  res.json({ ok: true });
});
r.delete('/campaigns/:id', requirePerm('crm.manage'), async (req, res) => {
  await db().run("DELETE FROM campaigns WHERE id = ? AND status != 'sending'", [Number(req.params.id)]);
  res.json({ ok: true });
});
r.post('/campaigns/:id/audience-size', requirePerm('crm.view'), async (req, res) => {
  const c = await db().get('SELECT audience FROM campaigns WHERE id = ?', [Number(req.params.id)]);
  if (!c) throw notFound();
  const a = parseJson(c.audience, {});
  res.json({ size: isExternalAudience(a) ? (await resolveExternal(a)).length : (await resolveAudience(a)).length });
});
r.post('/campaigns/:id/send', requirePerm('crm.manage'), async (req, res) => {
  const c = await db().get('SELECT * FROM campaigns WHERE id = ?', [Number(req.params.id)]);
  if (!c) throw notFound();
  if (['sending', 'sent'].includes(c.status)) throw badRequest('Campaign already sent');
  await audit(req, 'campaign.send', 'campaign', c.id);
  res.json({ ok: true, status: 'sending' });
  await sendCampaign(c.id);
});

async function postToFacebook(message) {
  const { social } = await getSetting('integrations');
  if (!social.facebookPageId || !social.facebookToken) throw new Error('Facebook page is not configured');
  const res = await fetch(`https://graph.facebook.com/v20.0/${encodeURIComponent(social.facebookPageId)}/feed`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: AbortSignal.timeout(15000),
    body: JSON.stringify({ message, access_token: social.facebookToken }),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json?.error?.message || 'Facebook error');
  return json.id;
}

export async function sendCampaign(id) {
  const claimed = await db().run("UPDATE campaigns SET status = 'sending' WHERE id = ? AND status IN ('draft','scheduled')", [id]);
  if (!claimed.changes) return; // someone else is sending it
  const c = await db().get('SELECT * FROM campaigns WHERE id = ?', [id]);
  const channels = parseJson(c.channels, []);
  const stats = { recipients: 0, sent: 0, failed: 0, social: null };
  if (channels.includes('facebook')) {
    try { stats.social = { facebook: await postToFacebook(c.social_post || c.body) }; } catch (e) { stats.social = { error: e.message }; }
  }
  const direct = channels.filter((ch) => ch !== 'facebook');
  if (direct.length) {
    const audience = parseJson(c.audience, {});
    if (isExternalAudience(audience)) {
      const ext = await sendExternal(await resolveExternal(audience), direct.filter((ch) => ['email', 'sms', 'whatsapp'].includes(ch)),
        { subject: c.subject || c.name, body: c.body, email: parseJson(c.email_design, null), ref: `campaign:${c.id}` });
      Object.assign(stats, { recipients: ext.recipients, sent: ext.sent, failed: ext.failed });
    }
    const ids = isExternalAudience(audience) ? [] : await resolveAudience(audience);
    if (ids.length) stats.recipients = ids.length;
    for (const uid of ids) {
      const out = await notify({ userId: uid, channels: direct, subject: c.subject || c.name, body: c.body, ref: `campaign:${c.id}`, kind: 'promo', email: parseJson(c.email_design, null) }).catch(() => []);
      for (const o of out) o.status === 'sent' ? stats.sent++ : stats.failed++;
    }
  }
  await db().run("UPDATE campaigns SET status = 'sent', sent_at = ?, stats = ? WHERE id = ?", [now(), JSON.stringify(stats), id]);
}

// ------------------------------------------------------------------ sales tracking
r.get('/sales', requirePerm('crm.view'), async (req, res) => {
  const days = Math.min(730, Math.max(1, Number(req.query.days) || 90));
  const since = new Date(Date.now() - days * 86400000).toISOString();
  const [recent, byStaff, byKind, byMonth, funnel] = await Promise.all([
    db().all(`SELECT s.*, u.name AS customer_name, p.name AS plan_name, st.name AS staff_name FROM sales s LEFT JOIN customers c ON c.id = s.customer_id
      LEFT JOIN users u ON u.id = c.user_id LEFT JOIN plans p ON p.id = s.plan_id LEFT JOIN users st ON st.id = s.staff_id WHERE s.created_at >= ? ORDER BY s.id DESC LIMIT 100`, [since]),
    db().all('SELECT st.name AS staff, COUNT(*) AS n, SUM(s.amount_cents) AS amount FROM sales s LEFT JOIN users st ON st.id = s.staff_id WHERE s.created_at >= ? GROUP BY st.name ORDER BY amount DESC', [since]),
    db().all('SELECT kind, COUNT(*) AS n, SUM(amount_cents) AS amount FROM sales WHERE created_at >= ? GROUP BY kind', [since]),
    db().all('SELECT SUBSTR(created_at, 1, 7) AS month, COUNT(*) AS n, SUM(amount_cents) AS amount FROM sales WHERE created_at >= ? GROUP BY SUBSTR(created_at, 1, 7) ORDER BY month', [since]),
    db().all('SELECT status, COUNT(*) AS n FROM leads GROUP BY status'),
  ]);
  res.json({ recent, byStaff, byKind, byMonth, funnel });
});

// ------------------------------------------------------------------ FAQ (powers the chatbot)
const faqSchema = z.object({ question: z.string().trim().min(3).max(250), answer: z.string().trim().min(1).max(5000), category: z.string().max(40).optional(), keywords: z.string().max(250).optional().nullable(), sort: z.coerce.number().int().optional(), active: z.boolean().optional() });
r.get('/faqs', requirePerm('crm.view'), async (_req, res) => res.json({ faqs: await db().all('SELECT * FROM faqs ORDER BY sort, id') }));
r.post('/faqs', requirePerm('crm.manage'), validate(faqSchema), async (req, res) => res.status(201).json({ id: (await insert('faqs', { ...req.body, created_at: now() })).id }));
r.put('/faqs/:id', requirePerm('crm.manage'), validate(faqSchema.partial()), async (req, res) => { await update('faqs', Number(req.params.id), req.body); res.json({ ok: true }); });
r.delete('/faqs/:id', requirePerm('crm.manage'), async (req, res) => { await db().run('DELETE FROM faqs WHERE id = ?', [Number(req.params.id)]); res.json({ ok: true }); });

export default r;
