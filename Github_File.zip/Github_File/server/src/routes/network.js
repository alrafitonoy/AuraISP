// Network operations: routers, live bandwidth, traffic analysis, access control / site rules,
// diagnostics (ping/traceroute/DNS), device testing and consent-based remote support.
import { Router } from 'express';
import dns from 'node:dns/promises';
import net from 'node:net';
import { z } from 'zod';
import { db, insert, update, now, parseJson, cascadeDelete } from '../db/index.js';
import { validate, notFound, badRequest } from '../lib/http.js';
import { authenticate, requirePerm, requireModule } from '../middleware/auth.js';
import { encrypt } from '../lib/crypto.js';
import { audit } from '../lib/audit.js';
import { getDriver, CATEGORY_DOMAINS } from '../network/drivers.js';
import { live, syncSiteRules, syncCustomer, customerWithPlan, pollUsage } from '../network/service.js';
import { queueNotify } from '../lib/notify.js';
import { parentalSchema, toStoredParental } from './portal.js';

const r = Router();
r.use(authenticate);

const host = z.string().trim().max(253).regex(/^[A-Za-z0-9.-]+$|^\[?[0-9a-fA-F:]+\]?$/, 'Invalid host');
// Diagnostic targets: hostnames or IPs only — no shell is ever involved, but keep inputs tight anyway.
const target = z.string().trim().min(1).max(253).regex(/^[A-Za-z0-9.:-]+$/, 'Invalid target');

/**
 * Diagnostics must not become a probe of the server itself: loopback, link-local (cloud metadata 169.254.169.254),
 * "this host" (0.0.0.0/8) and multicast targets are refused — hostnames are resolved first so a DNS name pointing
 * there is refused too. Customer/CGNAT/private ranges stay allowed: ISP staff legitimately test those.
 */
function blockedAddress(ip) {
  const v = ip.replace(/^::ffff:/i, '');
  if (net.isIPv4(v)) {
    const [a, b] = v.split('.').map(Number);
    return a === 127 || a === 0 || (a === 169 && b === 254) || a >= 224;
  }
  const l = v.toLowerCase();
  return l === '::1' || l === '::' || l.startsWith('fe80:') || l.startsWith('ff');
}
async function assertSafeTarget(host) {
  const addrs = net.isIP(host) ? [host] : (await dns.lookup(host, { all: true }).catch(() => [])).map((x) => x.address);
  if (addrs.some(blockedAddress) || /^localhost$/i.test(host)) throw badRequest('That target points at the server itself (loopback / link-local) and cannot be tested');
}

// ------------------------------------------------------------------ routers
const routerSchema = z.object({
  name: z.string().trim().min(2).max(80),
  driver: z.enum(['mikrotik', 'simulator']),
  host: host.optional().nullable(),
  port: z.coerce.number().int().min(1).max(65535).optional().nullable(),
  username: z.string().max(64).optional().nullable(),
  password: z.string().max(128).optional().nullable(),
  use_tls: z.boolean().optional(),
  verify_tls: z.boolean().optional(),
  location: z.string().max(120).optional().nullable(),
  role: z.enum(['core', 'nas', 'edge']).optional(),
  tls_fingerprint: z.string().max(200).regex(/^[A-Fa-f0-9: ]*$/).optional().nullable(),
});
const presentRouter = ({ password_enc, ...r }) => ({ ...r, info: parseJson(r.info, null), has_password: !!password_enc, use_tls: !!r.use_tls, verify_tls: !!r.verify_tls });

r.get('/routers', requirePerm('network.view'), async (_req, res) => {
  const rows = await db().all('SELECT r.*, (SELECT COUNT(*) FROM customers c WHERE c.router_id = r.id) AS customers FROM routers r ORDER BY name');
  res.json({ routers: rows.map(presentRouter) });
});
r.post('/routers', requirePerm('network.manage'), validate(routerSchema), async (req, res) => {
  const { password, ...rest } = req.body;
  const out = await insert('routers', { ...rest, password_enc: encrypt(password), created_at: now() });
  await audit(req, 'router.create', 'router', out.id);
  res.status(201).json({ id: out.id });
});
r.put('/routers/:id', requirePerm('network.manage'), validate(routerSchema.partial()), async (req, res) => {
  const { password, ...rest } = req.body;
  await update('routers', Number(req.params.id), { ...rest, ...(password ? { password_enc: encrypt(password) } : {}) });
  await audit(req, 'router.update', 'router', req.params.id);
  res.json({ ok: true });
});
r.delete('/routers/:id', requirePerm('network.manage'), async (req, res) => {
  await cascadeDelete('routers', Number(req.params.id));
  await audit(req, 'router.delete', 'router', req.params.id);
  res.json({ ok: true });
});
r.post('/routers/:id/test', requirePerm('network.manage', 'network.diagnostics'), async (req, res) => {
  const router = await db().get('SELECT * FROM routers WHERE id = ?', [Number(req.params.id)]);
  if (!router) throw notFound();
  try {
    const out = await getDriver(router).test();
    // Merge: keep what discovery stored (wanInterface drives capacity sampling) and drop a stale error.
    const { error: _err, errorAt: _errAt, ...kept } = parseJson(router.info, {}) || {};
    await db().run('UPDATE routers SET status = ?, last_seen_at = ?, info = ? WHERE id = ?', ['online', now(), JSON.stringify({ ...kept, ...out.info }), router.id]);
    res.json(out);
  } catch (e) {
    await db().run('UPDATE routers SET status = ?, info = ? WHERE id = ?', ['offline', JSON.stringify({ ...(parseJson(router.info, {}) || {}), error: e.message, errorAt: now() }), router.id]);
    res.json({ ok: false, error: e.message });
  }
});
r.post('/routers/:id/sync', requirePerm('network.manage'), async (req, res) => {
  const ids = await db().all('SELECT id FROM customers WHERE router_id = ?', [Number(req.params.id)]);
  const results = [];
  for (const { id } of ids) results.push({ id, ...(await syncCustomer(id)) });
  await audit(req, 'router.sync', 'router', req.params.id, { customers: ids.length });
  res.json({ synced: results.filter((x) => x.ok).length, failed: results.filter((x) => !x.ok) });
});

// ------------------------------------------------------------------ live bandwidth
r.get('/live', requirePerm('network.view'), requireModule('bandwidth'), async (_req, res) => {
  const customers = await db().all("SELECT c.id, c.code, u.name, p.name AS plan_name FROM customers c JOIN users u ON u.id = c.user_id LEFT JOIN plans p ON p.id = c.plan_id WHERE c.status IN ('active','suspended')");
  const rows = customers.map((c) => ({ ...c, ...(live.perCustomer.get(c.id) || { rx_bps: 0, tx_bps: 0, online: false }) }))
    .sort((a, b) => b.rx_bps + b.tx_bps - (a.rx_bps + a.tx_bps));
  res.json({ at: live.at, totals: live.totals, customers: rows.slice(0, 200) });
});
r.post('/poll', requirePerm('network.manage'), async (_req, res) => res.json(await pollUsage()));

// ------------------------------------------------------------------ traffic analysis
r.get('/traffic', requirePerm('network.view'), requireModule('traffic'), async (req, res) => {
  const days = Math.min(365, Math.max(1, Number(req.query.days) || 30));
  const since = new Date(Date.now() - days * 86400000).toISOString().slice(0, 10);
  const sinceTs = new Date(Date.now() - Math.min(days, 7) * 86400000).toISOString();
  const [daily, categories, top, byPlan, hourly] = await Promise.all([
    db().all("SELECT day, SUM(bytes) AS bytes FROM traffic_daily WHERE category = 'total' AND day >= ? GROUP BY day ORDER BY day", [since]),
    db().all("SELECT category, SUM(bytes) AS bytes FROM traffic_daily WHERE category != 'total' AND day >= ? GROUP BY category ORDER BY bytes DESC", [since]),
    db().all(`SELECT t.customer_id, u.name, c.code, SUM(t.bytes) AS bytes FROM traffic_daily t JOIN customers c ON c.id = t.customer_id JOIN users u ON u.id = c.user_id
              WHERE t.category = 'total' AND t.day >= ? GROUP BY t.customer_id, u.name, c.code ORDER BY bytes DESC LIMIT 10`, [since]),
    db().all(`SELECT p.name AS plan, SUM(t.bytes) AS bytes FROM traffic_daily t JOIN customers c ON c.id = t.customer_id LEFT JOIN plans p ON p.id = c.plan_id
              WHERE t.category = 'total' AND t.day >= ? GROUP BY p.name ORDER BY bytes DESC`, [since]),
    db().all('SELECT ts, rx_bps, tx_bps FROM usage_samples WHERE ts >= ?', [sinceTs]),
  ]);
  // Hour-of-day x weekday heatmap of average throughput.
  const heat = Array.from({ length: 7 }, () => Array.from({ length: 24 }, () => ({ s: 0, n: 0 })));
  for (const s of hourly) { const d = new Date(s.ts); const cell = heat[d.getUTCDay()][d.getUTCHours()]; cell.s += Number(s.rx_bps) + Number(s.tx_bps); cell.n++; }
  res.json({
    daily, categories, top, byPlan, categoriesEstimated: true,
    heatmap: heat.map((row) => row.map((c) => (c.n ? Math.round(c.s / c.n) : 0))),
  });
});

// ------------------------------------------------------------------ access control / site restrictions
const ruleSchema = z.object({
  scope: z.enum(['global', 'customer']),
  customer_id: z.coerce.number().int().positive().optional().nullable(),
  action: z.enum(['block', 'allow']),
  domain: z.string().trim().toLowerCase().max(253).regex(/^(?!-)[a-z0-9-]{1,63}(\.[a-z0-9-]{1,63})+$/, 'Invalid domain').optional().nullable(),
  category: z.enum(Object.keys(CATEGORY_DOMAINS)).optional().nullable(),
  schedule: z.object({ time: z.string().regex(/^\d{1,2}h(\d{1,2}m)?-\d{1,2}h(\d{1,2}m)?(,(mon|tue|wed|thu|fri|sat|sun))*$/) }).optional().nullable(),
  reason: z.string().max(200).optional().nullable(),
  active: z.boolean().optional(),
}).refine((v) => v.domain || v.category, 'Provide a domain or a category').refine((v) => v.scope === 'global' || v.customer_id, 'Customer rules need a customer');

r.get('/site-rules', requirePerm('network.view'), requireModule('access_control'), async (_req, res) => {
  const rows = await db().all('SELECT s.*, u.name AS customer_name FROM site_rules s LEFT JOIN customers c ON c.id = s.customer_id LEFT JOIN users u ON u.id = c.user_id ORDER BY s.id DESC');
  res.json({ rules: rows.map((x) => ({ ...x, schedule: parseJson(x.schedule, null), active: !!x.active })), categories: Object.keys(CATEGORY_DOMAINS) });
});
r.post('/site-rules', requirePerm('network.manage'), requireModule('access_control'), validate(ruleSchema), async (req, res) => {
  const out = await insert('site_rules', { ...req.body, schedule: req.body.schedule ? JSON.stringify(req.body.schedule) : null, created_by: req.user.id, created_at: now() });
  const sync = await syncSiteRules();
  await audit(req, 'site_rule.create', 'site_rule', out.id, req.body);
  res.status(201).json({ id: out.id, sync });
});
r.patch('/site-rules/:id', requirePerm('network.manage'), validate(z.object({ active: z.boolean() })), async (req, res) => {
  await update('site_rules', Number(req.params.id), { active: req.body.active });
  res.json({ ok: true, sync: await syncSiteRules() });
});
r.delete('/site-rules/:id', requirePerm('network.manage'), async (req, res) => {
  await db().run('DELETE FROM site_rules WHERE id = ?', [Number(req.params.id)]);
  await audit(req, 'site_rule.delete', 'site_rule', req.params.id);
  res.json({ ok: true, sync: await syncSiteRules() });
});

// Staff edit of a customer's parental controls
r.put('/customers/:id/parental', requirePerm('network.manage'), requireModule('parental'), validate(z.object({ parental: parentalSchema })), async (req, res) => {
  const id = Number(req.params.id);
  if (!(await db().get('SELECT id FROM customers WHERE id = ?', [id]))) throw notFound();
  await update('customers', id, { parental: JSON.stringify(toStoredParental(req.body.parental)), updated_at: now() });
  await audit(req, 'customer.parental', 'customer', id);
  res.json({ sync: await syncCustomer(id) });
});

// ------------------------------------------------------------------ diagnostics & device testing
async function routerForCustomerId(customerId) {
  if (!customerId) return null;
  const c = await db().get('SELECT router_id FROM customers WHERE id = ?', [customerId]);
  return c?.router_id ? db().get('SELECT * FROM routers WHERE id = ?', [c.router_id]) : null;
}

async function runTest(test, tgt, router) {
  if (test === 'ping') return getDriver(router).ping(tgt);
  if (test === 'traceroute') return getDriver(router).traceroute(tgt);
  if (test === 'dns') {
    const t0 = performance.now();
    const [a, aaaa] = await Promise.allSettled([dns.resolve4(tgt), dns.resolve6(tgt)]);
    return { ms: +(performance.now() - t0).toFixed(1), A: a.value || [], AAAA: aaaa.value || [], ok: a.status === 'fulfilled' || aaaa.status === 'fulfilled' };
  }
  if (test === 'port') {
    const [h, p] = tgt.split(':');
    const port = Number(p);
    if (!port || port < 1 || port > 65535) throw badRequest('Use host:port');
    return new Promise((resolve) => {
      const t0 = performance.now();
      const sock = net.connect({ host: h, port, timeout: 4000 });
      sock.on('connect', () => { sock.destroy(); resolve({ open: true, ms: +(performance.now() - t0).toFixed(1) }); });
      sock.on('timeout', () => { sock.destroy(); resolve({ open: false, error: 'timeout' }); });
      sock.on('error', (e) => resolve({ open: false, error: e.code }));
    });
  }
  throw badRequest('Unknown test');
}

const testSchema = z.object({
  test: z.enum(['ping', 'traceroute', 'dns', 'port']),
  target,
  customer_id: z.coerce.number().int().positive().optional(),
  device_id: z.coerce.number().int().positive().optional(),
});

r.post('/diagnostics', requirePerm('network.diagnostics'), requireModule('device_testing'), validate(testSchema), async (req, res) => {
  const { test, target: tgt, customer_id, device_id } = req.body;
  await assertSafeTarget(test === 'port' ? tgt.split(':')[0] : tgt);
  const router = await routerForCustomerId(customer_id);
  let result, ok = true;
  try { result = await runTest(test, tgt, router); ok = result.ok !== false && result.open !== false && (result.loss ?? 0) < 100; }
  catch (e) { result = { error: e.message }; ok = false; }
  await insert('device_tests', { device_id: device_id || null, customer_id: customer_id || null, test, target: tgt, result: JSON.stringify(result), ok, run_by: req.user.id, created_at: now() });
  if (device_id) await update('devices', device_id, { last_test: JSON.stringify({ test, ok, at: now() }), status: ok ? 'online' : 'unreachable' });
  res.json({ ok, result });
});

r.get('/diagnostics/history', requirePerm('network.diagnostics'), async (req, res) => {
  const rows = await db().all(`SELECT t.*, u.name AS run_by_name FROM device_tests t LEFT JOIN users u ON u.id = t.run_by ${req.query.customer_id ? 'WHERE t.customer_id = ?' : ''} ORDER BY t.id DESC LIMIT 100`, req.query.customer_id ? [Number(req.query.customer_id)] : []);
  res.json({ tests: rows.map((t) => ({ ...t, result: parseJson(t.result, null) })) });
});

const deviceSchema = z.object({
  customer_id: z.coerce.number().int().positive().optional().nullable(),
  name: z.string().trim().min(1).max(120),
  kind: z.enum(['router', 'onu', 'switch', 'ap', 'olt', 'cpe', 'other']).optional(),
  ip_address: z.string().max(64).optional().nullable(),
  mac_address: z.string().max(32).optional().nullable(),
  model: z.string().max(120).optional().nullable(),
  firmware: z.string().max(60).optional().nullable(),
});
r.get('/devices', requirePerm('network.view'), async (_req, res) => {
  const rows = await db().all('SELECT d.*, u.name AS customer_name FROM devices d LEFT JOIN customers c ON c.id = d.customer_id LEFT JOIN users u ON u.id = c.user_id ORDER BY d.id DESC');
  res.json({ devices: rows.map((d) => ({ ...d, last_test: parseJson(d.last_test, null) })) });
});
r.post('/devices', requirePerm('network.manage'), validate(deviceSchema), async (req, res) => {
  const out = await insert('devices', { ...req.body, created_at: now() });
  res.status(201).json({ id: out.id });
});
r.put('/devices/:id', requirePerm('network.manage'), validate(deviceSchema.partial()), async (req, res) => {
  await update('devices', Number(req.params.id), req.body);
  res.json({ ok: true });
});
r.delete('/devices/:id', requirePerm('network.manage'), async (req, res) => {
  await cascadeDelete('devices', Number(req.params.id));
  res.json({ ok: true });
});

// ------------------------------------------------------------------ remote support (consent-based)
r.get('/remote-sessions', requirePerm('network.diagnostics'), requireModule('remote_support'), async (_req, res) => {
  const rows = await db().all(`SELECT rs.*, u.name AS customer_name, c.code, s.name AS staff_name FROM remote_sessions rs JOIN customers c ON c.id = rs.customer_id
    JOIN users u ON u.id = c.user_id LEFT JOIN users s ON s.id = rs.staff_id ORDER BY rs.id DESC LIMIT 100`);
  res.json({ sessions: rows.map((s) => ({ ...s, actions: parseJson(s.actions, []) })) });
});

r.post('/remote-sessions', requirePerm('network.diagnostics'), requireModule('remote_support'), validate(z.object({ customer_id: z.coerce.number().int().positive(), ticket_id: z.coerce.number().int().positive().optional() })), async (req, res) => {
  const c = await db().get('SELECT id, user_id FROM customers WHERE id = ?', [req.body.customer_id]);
  if (!c) throw notFound();
  const out = await insert('remote_sessions', { customer_id: c.id, ticket_id: req.body.ticket_id || null, staff_id: req.user.id, status: 'requested', actions: '[]', created_at: now() });
  queueNotify({ userId: c.user_id, channels: ['inapp', 'push'], subject: 'Remote support request', body: `${req.user.name} from support would like to run diagnostics on your connection. Approve it in the app.`, link: '/portal/devices', kind: 'warning' });
  await audit(req, 'remote.request', 'remote_session', out.id);
  res.status(201).json({ id: out.id });
});

const REMOTE_ACTIONS = ['status', 'ping_gateway', 'ping_internet', 'dns_check', 'reconnect', 'resync_profile', 'speed_profile_check'];

r.post('/remote-sessions/:id/action', requirePerm('network.diagnostics'), requireModule('remote_support'), validate(z.object({ action: z.enum(REMOTE_ACTIONS) })), async (req, res) => {
  const s = await db().get('SELECT * FROM remote_sessions WHERE id = ?', [Number(req.params.id)]);
  if (!s) throw notFound();
  if (s.status !== 'active') throw badRequest('The customer has not approved this session (or it is closed)');
  const c = await customerWithPlan(s.customer_id);
  const router = c.router_id ? await db().get('SELECT * FROM routers WHERE id = ?', [c.router_id]) : null;
  const drv = getDriver(router);
  let result;
  try {
    switch (req.body.action) {
      case 'status': result = { status: c.status, live: live.perCustomer.get(c.id) || null, plan: c.plan_name, ip: c.ip_address, pppoe: c.pppoe_username }; break;
      case 'ping_gateway': result = await drv.ping(c.ip_address || '10.0.0.1'); break;
      case 'ping_internet': result = await drv.ping('8.8.8.8'); break;
      case 'dns_check': result = await runTest('dns', 'google.com', router); break;
      case 'reconnect': result = await drv.kick(c); break;
      case 'resync_profile': result = await syncCustomer(c.id); break;
      case 'speed_profile_check': result = { expectedDownKbps: c.custom_download_kbps || c.download_kbps, expectedUpKbps: c.custom_upload_kbps || c.upload_kbps, live: live.perCustomer.get(c.id) || null }; break;
      default: throw badRequest('Unknown action');
    }
  } catch (e) { result = { error: e.message }; }
  const actions = parseJson(s.actions, []);
  actions.push({ action: req.body.action, at: now(), by: req.user.name, result });
  await db().run('UPDATE remote_sessions SET actions = ? WHERE id = ?', [JSON.stringify(actions.slice(-100)), s.id]);
  await audit(req, 'remote.action', 'remote_session', s.id, { action: req.body.action });
  res.json({ result });
});

r.post('/remote-sessions/:id/close', requirePerm('network.diagnostics'), async (req, res) => {
  await db().run("UPDATE remote_sessions SET status = 'closed', closed_at = ? WHERE id = ?", [now(), Number(req.params.id)]);
  res.json({ ok: true });
});

export default r;
