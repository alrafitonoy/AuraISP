import { Router } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import multer from 'multer';
import { z } from 'zod';
import config from '../config.js';
import { validate, badRequest, notFound } from '../lib/http.js';
import { authenticate, requirePerm } from '../middleware/auth.js';
import { getSetting, setSetting, maskSecrets, DEFAULTS } from '../lib/settings.js';
import { randomToken } from '../lib/crypto.js';
import { audit } from '../lib/audit.js';
import { MODULES } from '../lib/catalog.js';
import { emailDesignSchema } from '../lib/email-templates.js';

const r = Router();
r.use(authenticate, requirePerm('settings.manage'));

const hex = z.string().regex(/^#[0-9a-fA-F]{6}$/, 'Use a #RRGGBB colour');
const url = z.string().max(500).refine((v) => v === '' || /^https:\/\//.test(v) || /^\/uploads\/[A-Za-z0-9._-]+$/.test(v), 'Must be an https:// URL or an uploaded file');

const schemas = {
  branding: z.object({
    companyName: z.string().trim().min(1).max(80), tagline: z.string().max(160), logoUrl: url, faviconUrl: url,
    primary: hex, secondary: hex, accent: hex, defaultTheme: z.enum(['light', 'dark', 'system']), logoDisplay: z.enum(['both', 'logo', 'name']),
  }).partial(),
  company: z.object({
    legalName: z.string().max(160), email: z.string().email().or(z.literal('')), phone: z.string().max(40), address: z.string().max(300),
    website: z.string().max(200), taxId: z.string().max(60), currency: z.string().regex(/^[A-Z]{3}$/), currencySymbol: z.string().max(5),
    locale: z.string().max(20), timezone: z.string().max(60), invoicePrefix: z.string().regex(/^[A-Z0-9]{1,10}$/), taxPercent: z.coerce.number().min(0).max(100),
  }).partial(),
  modules: z.object(Object.fromEntries(Object.keys(MODULES).map((k) => [k, z.boolean()]))).partial(),
  billing: z.object({
    graceDays: z.coerce.number().int().min(0).max(90), autoSuspend: z.boolean(), generateDaysBefore: z.coerce.number().int().min(0).max(30),
    prorate: z.boolean(), dueDays: z.coerce.number().int().min(0).max(90),
    suspendMinOverdueInvoices: z.coerce.number().int().min(1).max(24), suspendMinOverdueCents: z.coerce.number().int().min(0),
    warnBeforeSuspendDays: z.coerce.number().int().min(0).max(30), terminateAfterDays: z.coerce.number().int().min(0).max(365), emailPdf: z.boolean(),
  }).partial(),
  enforcement: z.object({
    strictSpeed: z.boolean(), speedTolerancePct: z.coerce.number().int().min(0).max(50),
    dataCapAction: z.enum(['throttle', 'suspend']), throttleKbps: z.coerce.number().int().min(64).max(100000),
  }).partial(),
  security: z.object({
    passwordMinLength: z.coerce.number().int().min(8).max(64), maxLoginAttempts: z.coerce.number().int().min(3).max(20),
    lockMinutes: z.coerce.number().int().min(1).max(1440), requireEmailVerification: z.boolean(), requirePhoneVerification: z.boolean(),
    require2faForStaff: z.boolean(), sessionDays: z.coerce.number().int().min(1).max(365),
  }).partial(),
  integrations: z.object({
    smtp: z.object({ host: z.string().max(200), port: z.coerce.number().int().min(1).max(65535), secure: z.boolean(), user: z.string().max(200), pass: z.string().max(500), from: z.string().max(200) }).partial(),
    sms: z.object({ provider: z.enum(['none', 'twilio', 'http']), twilioSid: z.string().max(100), twilioToken: z.string().max(200), from: z.string().max(40), httpUrl: z.string().max(1000), httpMethod: z.enum(['GET', 'POST']), httpBody: z.string().max(2000), httpApiKey: z.string().max(500) }).partial(),
    whatsapp: z.object({ provider: z.enum(['none', 'twilio', 'meta']), twilioSid: z.string().max(100), twilioToken: z.string().max(200), from: z.string().max(40), metaPhoneId: z.string().max(60), metaToken: z.string().max(1000) }).partial(),
    push: z.object({ fcmServiceAccount: z.string().max(10000) }).partial(),
    payments: z.object({
      stripe: z.object({ enabled: z.boolean(), publishableKey: z.string().max(300), secretKey: z.string().max(300), webhookSecret: z.string().max(300) }).partial(),
      sslcommerz: z.object({ enabled: z.boolean(), sandbox: z.boolean(), storeId: z.string().max(100), storePassword: z.string().max(200) }).partial(),
      bkash: z.object({ enabled: z.boolean(), sandbox: z.boolean(), appKey: z.string().max(200), appSecret: z.string().max(300), username: z.string().max(100), password: z.string().max(200) }).partial(),
      manual: z.object({ enabled: z.boolean(), instructions: z.string().max(2000) }).partial(),
    }).partial(),
    social: z.object({ facebookPageId: z.string().max(60), facebookToken: z.string().max(1000) }).partial(),
  }).partial(),
  website: z.object({
    hero: z.object({ title: z.string().max(120), subtitle: z.string().max(300), cta: z.string().max(40) }).partial(),
    features: z.array(z.object({ icon: z.string().max(40), title: z.string().max(60), text: z.string().max(200) })).max(12),
    coverageAreas: z.array(z.string().max(60)).max(200),
    announcement: z.string().max(300),
    social: z.object({ facebook: z.string().max(200), instagram: z.string().max(200), youtube: z.string().max(200), whatsapp: z.string().max(40) }).partial(),
  }).partial(),
  email: emailDesignSchema,
  updates: z.object({ auto: z.boolean() }).partial(),
};

r.get('/', async (_req, res) => {
  const out = {};
  for (const k of Object.keys(schemas)) out[k] = maskSecrets(await getSetting(k));
  res.json({ settings: out, modulesCatalog: MODULES, appUrl: config.appUrl });
});

r.put('/:key', async (req, res) => {
  const key = req.params.key;
  const schema = schemas[key];
  if (!schema) throw notFound('Unknown settings group');
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) throw badRequest('Validation failed', parsed.error.flatten());
  if (key === 'integrations' && parsed.data.push?.fcmServiceAccount && !parsed.data.push.fcmServiceAccount.startsWith('•')) {
    try { const sa = JSON.parse(parsed.data.push.fcmServiceAccount); if (!sa.client_email || !sa.private_key || !sa.project_id) throw new Error(); }
    catch { throw badRequest('FCM service account must be the JSON key file from Firebase'); }
  }
  const saved = await setSetting(key, parsed.data);
  await audit(req, 'settings.update', 'settings', key, { fields: Object.keys(parsed.data) });
  res.json({ [key]: maskSecrets(saved) });
});

r.post('/:key/reset', async (req, res) => {
  const key = req.params.key;
  if (!schemas[key] || key === 'integrations') throw badRequest('This group cannot be reset');
  const saved = await setSetting(key, DEFAULTS[key], { merge: false });
  await audit(req, 'settings.reset', 'settings', key);
  res.json({ [key]: saved });
});

// ------------------------------------------------------------------ file upload (logo / favicon)
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 2 * 1024 * 1024, files: 1 } });
const MAGIC = [
  { ext: 'png', test: (b) => b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) },
  { ext: 'jpg', test: (b) => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  { ext: 'webp', test: (b) => b.subarray(0, 4).toString() === 'RIFF' && b.subarray(8, 12).toString() === 'WEBP' },
  { ext: 'ico', test: (b) => b[0] === 0 && b[1] === 0 && b[2] === 1 && b[3] === 0 },
]; // SVG deliberately not allowed (can carry scripts)

r.post('/upload', upload.single('file'), async (req, res) => {
  if (!req.file) throw badRequest('No file');
  const type = MAGIC.find((m) => m.test(req.file.buffer));
  if (!type) throw badRequest('Only PNG, JPG, WEBP or ICO images are allowed');
  fs.mkdirSync(config.uploadsDir, { recursive: true });
  const name = `${randomToken(12).replace(/[^A-Za-z0-9]/g, '')}.${type.ext}`;
  fs.writeFileSync(path.join(config.uploadsDir, name), req.file.buffer);
  await audit(req, 'settings.upload', 'file', name);
  res.status(201).json({ url: `/uploads/${name}` });
});

export default r;
