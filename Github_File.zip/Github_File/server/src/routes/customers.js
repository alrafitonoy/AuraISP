import { Router } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import config from '../config.js';
import { z } from 'zod';
import { db, insert, update, now, paginate, parseJson, ciLike, cascadeDelete } from '../db/index.js';
import { validate, notFound, badRequest, conflict, HttpError } from '../lib/http.js';
import { authenticate, requirePerm } from '../middleware/auth.js';
import { hashPassword, encrypt, decrypt, randomToken } from '../lib/crypto.js';
import { audit } from '../lib/audit.js';
import { syncCustomer, live, customerWithPlan } from '../network/service.js';
import { getDriver } from '../network/drivers.js';
import { addCycle, createInvoice, notifyInvoice } from '../billing/service.js';
import { queueNotify } from '../lib/notify.js';

const r = Router();
r.use(authenticate);

const ip = z.string().trim().regex(/^(\d{1,3}\.){3}\d{1,3}(\/\d{1,2})?$/, 'Invalid IPv4 address').or(z.literal('')).optional().nullable();
const mac = z.string().trim().regex(/^([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$/, 'Invalid MAC').or(z.literal('')).optional().nullable();

const base = {
  address: z.string().trim().max(500).optional().nullable(),
  area: z.string().trim().max(120).optional().nullable(),
  national_id: z.string().trim().max(40).optional().nullable(),
  connection_type: z.enum(['pppoe', 'static', 'hotspot', 'dhcp']).optional(),
  pppoe_username: z.string().trim().max(64).regex(/^[A-Za-z0-9_.@-]*$/).optional().nullable(),
  pppoe_password: z.string().max(64).optional().nullable(),
  ip_address: ip,
  mac_address: mac,
  router_id: z.coerce.number().int().positive().optional().nullable(),
  plan_id: z.coerce.number().int().positive().optional().nullable(),
  status: z.enum(['pending', 'active', 'suspended', 'terminated']).optional(),
  custom_download_kbps: z.coerce.number().int().min(0).max(100_000_000).optional().nullable(),
  custom_upload_kbps: z.coerce.number().int().min(0).max(100_000_000).optional().nullable(),
  billing_day: z.coerce.number().int().min(1).max(28).optional(),
  zone_id: z.coerce.number().int().positive().optional().nullable(),
  next_due_date: z.string().datetime().optional().nullable(),
  notes: z.string().max(5000).optional().nullable(),
  lat: z.string().max(32).optional().nullable(),
  lng: z.string().max(32).optional().nullable(),
};

const createSchema = z.object({
  name: z.string().trim().min(2).max(120),
  email: z.string().trim().toLowerCase().email().max(190),
  phone: z.string().trim().max(20).optional().nullable(),
  password: z.string().min(10).max(128).optional(),
  createInvoice: z.boolean().optional(),
  ...base,
});
const updateSchema = z.object({
  name: z.string().trim().min(2).max(120).optional(),
  phone: z.string().trim().max(20).optional().nullable(),
  ...base,
});

function present(row) {
  if (!row) return row;
  const { pppoe_password_enc, ...rest } = row;
  return { ...rest, has_pppoe_password: !!pppoe_password_enc, parental: parseJson(row.parental, null), live: live.perCustomer.get(row.id) || null };
}

r.get('/', requirePerm('customers.view'), async (req, res) => {
  const { q, status, plan_id, area, zone_id, page, pageSize, sort } = req.query;
  const where = []; const params = [];
  if (q) { where.push(`(u.name ${ciLike()} ? OR u.email ${ciLike()} ? OR u.phone ${ciLike()} ? OR c.code ${ciLike()} ? OR c.ip_address ${ciLike()} ? OR c.pppoe_username ${ciLike()} ?)`); params.push(...Array(6).fill(`%${String(q).slice(0, 80)}%`)); }
  if (status) { where.push('c.status = ?'); params.push(String(status)); }
  if (plan_id) { where.push('c.plan_id = ?'); params.push(Number(plan_id)); }
  if (area) { where.push('c.area = ?'); params.push(String(area)); }
  if (zone_id === 'none') where.push('c.zone_id IS NULL');
  else if (zone_id && Number(zone_id) > 0) { where.push('c.zone_id = ?'); params.push(Number(zone_id)); }
  const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const from = `FROM customers c JOIN users u ON u.id = c.user_id LEFT JOIN plans p ON p.id = c.plan_id LEFT JOIN zones zn ON zn.id = c.zone_id ${w}`;
  const out = await paginate({
    base: `SELECT c.*, u.name, u.email, u.phone, p.name AS plan_name, p.download_kbps, p.upload_kbps, zn.name AS zone_name ${from}`,
    countBase: `SELECT COUNT(*) AS n ${from}`, params, page, pageSize, sort,
    sortable: { name: 'u.name', code: 'c.code', status: 'c.status', created_at: 'c.created_at', next_due_date: 'c.next_due_date', balance_cents: 'c.balance_cents' },
    defaultSort: 'c.id DESC',
  });
  res.json({ ...out, rows: out.rows.map(present) });
});

r.get('/areas', requirePerm('customers.view'), async (_req, res) => {
  const rows = await db().all("SELECT area, COUNT(*) AS n FROM customers WHERE area IS NOT NULL AND area != '' GROUP BY area ORDER BY n DESC");
  res.json({ areas: rows });
});

r.get('/:id', requirePerm('customers.view'), async (req, res) => {
  const c = await customerWithPlan(Number(req.params.id));
  if (!c) throw notFound();
  const [invoices, payments, tickets, devices] = await Promise.all([
    db().all('SELECT * FROM invoices WHERE customer_id = ? ORDER BY id DESC LIMIT 20', [c.id]),
    db().all('SELECT * FROM payments WHERE customer_id = ? ORDER BY id DESC LIMIT 20', [c.id]),
    db().all('SELECT * FROM tickets WHERE customer_id = ? ORDER BY id DESC LIMIT 20', [c.id]),
    db().all('SELECT * FROM devices WHERE customer_id = ? ORDER BY id DESC', [c.id]),
  ]);
  // How the customer is connected, derived from the assigned IP (pool kind, gateway, DNS, NAT address) and the router.
  const ipRow = c.ip_address ? await db().get(`SELECT a.address, a.ptr, p.name AS pool_name, p.kind, p.cidr, p.gateway, p.dns, p.nat_address
      FROM ip_addresses a JOIN ip_pools p ON p.id = a.pool_id WHERE a.address = ?`, [c.ip_address]) : null;
  const router = c.router_id ? await db().get('SELECT id, name, host, status FROM routers WHERE id = ?', [c.router_id]) : null;
  let netmask = null;
  if (ipRow?.cidr) { const prefix = Number(ipRow.cidr.split('/')[1]); netmask = [24, 16, 8, 0].map((s) => ((((0xffffffff << (32 - prefix)) >>> 0) >>> s) & 255)).join('.'); }
  const connection = {
    ipType: c.ip_type || ipRow?.kind || null, pool: ipRow ? { name: ipRow.pool_name, cidr: ipRow.cidr, gateway: ipRow.gateway, dns: ipRow.dns, natAddress: ipRow.nat_address, netmask, ptr: ipRow.ptr } : null,
    router, managedByIpam: !!ipRow,
  };
  res.json({ customer: present(c), invoices, payments, tickets, devices, connection });
});

r.get('/:id/pppoe-password', requirePerm('customers.edit'), async (req, res) => {
  const c = await db().get('SELECT pppoe_password_enc FROM customers WHERE id = ?', [Number(req.params.id)]);
  if (!c) throw notFound();
  await audit(req, 'customer.reveal_pppoe', 'customer', req.params.id);
  res.json({ password: decrypt(c.pppoe_password_enc) });
});

/** Two customers with the same PPPoE login or IP address break router provisioning for both (router import already
 *  refuses duplicates; manual create/edit must too). */
async function assertUniqueNetworkIds({ pppoe, ip }, exceptId = 0) {
  if (pppoe && await db().get('SELECT id FROM customers WHERE pppoe_username = ? AND id != ?', [pppoe, exceptId])) throw conflict(`PPPoE username "${pppoe}" is already used by another customer`);
  if (ip && await db().get('SELECT id FROM customers WHERE ip_address = ? AND id != ?', [ip, exceptId])) throw conflict(`IP address ${ip} is already assigned to another customer`);
}

r.post('/', requirePerm('customers.create'), validate(createSchema), async (req, res) => {
  const b = req.body;
  if (await db().get('SELECT id FROM users WHERE email = ?', [b.email])) throw conflict('Email already in use');
  await assertUniqueNetworkIds({ pppoe: b.pppoe_username, ip: b.ip_address });
  const role = await db().get("SELECT id FROM roles WHERE slug = 'customer'");
  const ts = now();
  const tempPassword = b.password || `${randomToken(9)}A1`;
  const plan = b.plan_id ? await db().get('SELECT * FROM plans WHERE id = ?', [b.plan_id]) : null;
  const id = await db().transaction(async (t) => {
    const u = await insert('users', { type: 'customer', role_id: role?.id, name: b.name, email: b.email, phone: b.phone, password_hash: await hashPassword(tempPassword), status: 'active', email_verified_at: ts, created_at: ts, updated_at: ts }, t);
    const c = await insert('customers', {
      user_id: u.id, code: `C${String(u.id).padStart(6, '0')}`, address: b.address, area: b.area, national_id: b.national_id,
      connection_type: b.connection_type || 'pppoe', pppoe_username: b.pppoe_username, pppoe_password_enc: encrypt(b.pppoe_password),
      ip_address: b.ip_address || null, mac_address: b.mac_address || null, router_id: b.router_id, plan_id: b.plan_id,
      status: b.status || (plan ? 'active' : 'pending'), custom_download_kbps: b.custom_download_kbps, custom_upload_kbps: b.custom_upload_kbps,
      billing_day: b.billing_day || Math.min(28, new Date().getUTCDate()),
      next_due_date: plan ? addCycle(new Date(), plan.billing_cycle).toISOString() : null,
      notes: b.notes, lat: b.lat, lng: b.lng, zone_id: b.zone_id ?? null, created_at: ts, updated_at: ts,
    }, t);
    if (plan) await insert('sales', { customer_id: c.id, plan_id: plan.id, staff_id: req.user.id, kind: 'new', amount_cents: plan.price_cents + Number(plan.setup_fee_cents || 0), created_at: ts }, t);
    return c.id;
  });
  if (plan && b.createInvoice !== false) {
    const items = [{ description: `${plan.name} — first ${plan.billing_cycle} period`, quantity: 1, unit_cents: plan.price_cents }];
    if (Number(plan.setup_fee_cents)) items.push({ description: 'Installation / setup fee', quantity: 1, unit_cents: plan.setup_fee_cents });
    const first = await createInvoice({ customerId: id, items, periodStart: ts, periodEnd: addCycle(new Date(), plan.billing_cycle).toISOString() });
    await notifyInvoice(first.id);
  }
  const sync = await syncCustomer(id);
  const user = await db().get('SELECT user_id FROM customers WHERE id = ?', [id]);
  // Email only — credentials must never be stored in the in-app notifications table.
  queueNotify({ userId: user.user_id, channels: ['email'], templateKey: 'welcome', vars: { email: b.email, password: b.password ? '(the password you were given)' : tempPassword } });
  await audit(req, 'customer.create', 'customer', id);
  // Returned once so staff can hand it over if email is not configured; it is not stored anywhere in clear text.
  res.status(201).json({ id, sync, tempPassword: b.password ? undefined : tempPassword });
});

r.put('/:id', requirePerm('customers.edit'), validate(updateSchema), async (req, res) => {
  const id = Number(req.params.id);
  const c = await db().get('SELECT * FROM customers WHERE id = ?', [id]);
  if (!c) throw notFound();
  const { name, phone, pppoe_password, ...rest } = req.body;
  await assertUniqueNetworkIds({ pppoe: rest.pppoe_username, ip: rest.ip_address }, id);
  // Only touch the fields that were sent (editing just the name used to wipe the phone number).
  const userPatch = { ...(name ? { name } : {}), ...(phone !== undefined ? { phone: phone || null } : {}) };
  if (Object.keys(userPatch).length) await update('users', c.user_id, { ...userPatch, updated_at: now() });
  const patch = { ...rest, updated_at: now() };
  if (pppoe_password) patch.pppoe_password_enc = encrypt(pppoe_password);
  if (patch.ip_address === '') patch.ip_address = null;
  if (patch.mac_address === '') patch.mac_address = null;
  await update('customers', id, patch);
  const sync = await syncCustomer(id);
  await audit(req, 'customer.update', 'customer', id, { fields: Object.keys(req.body) });
  res.json({ ok: true, sync });
});

// Admin sets bandwidth per customer (overrides plan speeds).
r.post('/:id/bandwidth', requirePerm('network.manage', 'customers.edit'), validate(z.object({
  download_kbps: z.coerce.number().int().min(0).max(100_000_000).nullable(),
  upload_kbps: z.coerce.number().int().min(0).max(100_000_000).nullable(),
})), async (req, res) => {
  const id = Number(req.params.id);
  if (!(await db().get('SELECT id FROM customers WHERE id = ?', [id]))) throw notFound();
  await update('customers', id, { custom_download_kbps: req.body.download_kbps || null, custom_upload_kbps: req.body.upload_kbps || null, updated_at: now() });
  const sync = await syncCustomer(id);
  await audit(req, 'customer.bandwidth', 'customer', id, req.body);
  res.json({ ok: sync.ok, sync });
});

r.post('/:id/status', requirePerm('customers.edit'), validate(z.object({ status: z.enum(['active', 'suspended', 'terminated', 'pending']), reason: z.string().max(300).optional() })), async (req, res) => {
  const id = Number(req.params.id);
  const c = await db().get('SELECT * FROM customers WHERE id = ?', [id]);
  if (!c) throw notFound();
  // Manual action always wins (manual override). A manual suspension is not lifted automatically by payments.
  await update('customers', id, { status: req.body.status, suspended_reason: req.body.status === 'suspended' ? 'manual' : null, updated_at: now() });
  const sync = await syncCustomer(id);
  if (req.body.status === 'suspended') queueNotify({ userId: c.user_id, templateKey: 'service_suspended', vars: { reason: req.body.reason || '' }, kind: 'warning' });
  if (req.body.status === 'active' && c.status !== 'active') queueNotify({ userId: c.user_id, templateKey: 'service_activated', vars: {}, kind: 'success' });
  await audit(req, `customer.${req.body.status}`, 'customer', id, { reason: req.body.reason, previous: c.status, previous_reason: c.suspended_reason });
  res.json({ ok: true, sync });
});

// Billing-rule override: keep a customer connected despite overdue invoices (until a date, or indefinitely).
r.post('/:id/override', requirePerm('billing.manage', 'customers.edit'), validate(z.object({
  mode: z.enum(['none', 'never_suspend']),
  until: z.string().datetime().optional().nullable(),
  reason: z.string().trim().max(250).optional().nullable(),
  reactivate: z.boolean().optional(),
})), async (req, res) => {
  const id = Number(req.params.id);
  const c = await db().get('SELECT * FROM customers WHERE id = ?', [id]);
  if (!c) throw notFound();
  if (req.body.mode === 'never_suspend' && !req.body.reason) throw badRequest('Give a reason for the override (kept in the audit log)');
  const patch = { billing_override: req.body.mode, override_until: req.body.mode === 'none' ? null : req.body.until || null, override_reason: req.body.mode === 'none' ? null : req.body.reason, updated_at: now() };
  if (req.body.reactivate && c.status === 'suspended') Object.assign(patch, { status: 'active', suspended_reason: null });
  await update('customers', id, patch);
  const sync = await syncCustomer(id);
  await audit(req, 'customer.billing_override', 'customer', id, req.body);
  res.json({ ok: true, sync });
});

r.post('/:id/reconnect', requirePerm('network.manage', 'network.diagnostics'), async (req, res) => {
  const c = await customerWithPlan(Number(req.params.id));
  if (!c) throw notFound();
  const router = c.router_id ? await db().get('SELECT * FROM routers WHERE id = ?', [c.router_id]) : null;
  let out;
  try { out = await getDriver(router).kick(c); }
  catch (e) { throw new HttpError(502, `Could not reach the router: ${e.message}`); } // offline router ≠ server error
  await audit(req, 'customer.reconnect', 'customer', c.id);
  res.json(out);
});

r.get('/:id/usage', requirePerm('customers.view', 'network.view'), async (req, res) => {
  const hours = Math.min(24 * 31, Math.max(1, Number(req.query.hours) || 24));
  const since = new Date(Date.now() - hours * 3600000).toISOString();
  const samples = await db().all('SELECT ts, rx_bps, tx_bps, rx_bytes, tx_bytes FROM usage_samples WHERE customer_id = ? AND ts >= ? ORDER BY ts', [Number(req.params.id), since]);
  res.json({ samples: downsample(samples, 240), live: live.perCustomer.get(Number(req.params.id)) || null });
});

r.delete('/:id', requirePerm('customers.delete'), async (req, res) => {
  const c = await db().get('SELECT * FROM customers WHERE id = ?', [Number(req.params.id)]);
  if (!c) throw notFound();
  const unpaid = await db().get("SELECT COUNT(*) AS n FROM invoices WHERE customer_id = ? AND status IN ('unpaid','overdue','partial')", [c.id]);
  if (Number(unpaid.n) && req.query.force !== 'true') throw badRequest('Customer has unpaid invoices. Terminate instead, or pass force=true.');
  await update('customers', c.id, { status: 'terminated' });
  await syncCustomer(c.id);
  const docs = await db().all('SELECT file FROM customer_documents WHERE customer_id = ?', [c.id]).catch(() => []);
  await cascadeDelete('users', c.user_id); // removes the customer, its records and frees its IP on every database
  for (const d of docs) if (/^[A-Za-z0-9_-]+\.(jpg|png|webp|pdf)$/i.test(String(d.file))) fs.rmSync(path.join(config.dataDir, 'private', 'kyc', d.file), { force: true }); // private KYC files
  await audit(req, 'customer.delete', 'customer', c.id, { code: c.code });
  res.json({ ok: true });
});

export function downsample(rows, max) {
  if (rows.length <= max) return rows;
  const step = rows.length / max;
  return Array.from({ length: max }, (_, i) => rows[Math.floor(i * step)]);
}

export default r;
