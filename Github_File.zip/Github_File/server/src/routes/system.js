// Dashboard data (role-defined widgets), updates, audit log, speed-test endpoints, health.
import { Router } from 'express';
import crypto from 'node:crypto';
import { z } from 'zod';
import express from 'express';
import { db, paginate, parseJson } from '../db/index.js';
import { validate, badRequest } from '../lib/http.js';
import { authenticate, requirePerm, requireAdmin, can } from '../middleware/auth.js';
import { WIDGETS } from '../lib/catalog.js';
import { speedtestLimiter } from '../middleware/security.js';
import { live } from '../network/service.js';
import { audit } from '../lib/audit.js';
import { getSetting, setSetting, moduleEnabled } from '../lib/settings.js';
import { VERSION, checkForUpdate, applyUpdate, history, listBackups, rollback } from '../updater.js';
import { financeKpis } from './finance.js';
import { inventorySummary } from './inventory.js';

const r = Router();

r.get('/health', async (_req, res) => {
  await db().get('SELECT 1 AS ok');
  res.json({ ok: true, version: VERSION, time: new Date().toISOString() });
});

// ------------------------------------------------------------------ speed test (browser-based)
const CHUNK = crypto.randomBytes(1024 * 1024);
r.get('/speedtest/download', authenticate, speedtestLimiter, (req, res) => {
  const mb = Math.min(50, Math.max(1, Number(req.query.mb) || 10));
  res.set({ 'Content-Type': 'application/octet-stream', 'Cache-Control': 'no-store', 'Content-Length': String(mb * CHUNK.length), 'Content-Encoding': 'identity' });
  let sent = 0;
  const pump = () => {
    while (sent < mb) { sent++; if (!res.write(CHUNK)) return res.once('drain', pump); }
    res.end();
  };
  pump();
});
r.post('/speedtest/upload', authenticate, speedtestLimiter, express.raw({ type: '*/*', limit: '30mb' }), (req, res) => res.json({ bytes: req.body?.length || 0 }));
r.get('/speedtest/ping', authenticate, (_req, res) => res.set('Cache-Control', 'no-store').json({ t: Date.now() }));

// ------------------------------------------------------------------ dashboard
r.get('/dashboard', authenticate, async (req, res) => {
  if (req.user.type === 'customer') throw badRequest('Use /api/portal/overview');
  const defaults = Object.keys(WIDGETS);
  const wanted = req.user.type === 'admin' ? (req.user.preferences?.dashboard || defaults) : (req.user.dashboard?.length ? req.user.dashboard : ['kpi_tickets', 'recent_tickets']);
  const widgets = wanted.filter((w) => WIDGETS[w] && can(req.user, WIDGETS[w].permission));
  const data = {};
  const monthStart = new Date(); monthStart.setUTCDate(1); monthStart.setUTCHours(0, 0, 0, 0);
  const prevStart = new Date(monthStart); prevStart.setUTCMonth(prevStart.getUTCMonth() - 1);
  for (const w of widgets) {
    switch (w) {
      case 'kpi_customers': {
        const rows = await db().all('SELECT status, COUNT(*) AS n FROM customers GROUP BY status');
        const newThisMonth = await db().get('SELECT COUNT(*) AS n FROM customers WHERE created_at >= ?', [monthStart.toISOString()]);
        data[w] = { byStatus: Object.fromEntries(rows.map((x) => [x.status, Number(x.n)])), newThisMonth: Number(newThisMonth.n) };
        break;
      }
      case 'kpi_revenue': {
        const cur = await db().get("SELECT COALESCE(SUM(amount_cents),0) AS v FROM payments WHERE status = 'success' AND method != 'balance' AND completed_at >= ?", [monthStart.toISOString()]);
        const prev = await db().get("SELECT COALESCE(SUM(amount_cents),0) AS v FROM payments WHERE status = 'success' AND method != 'balance' AND completed_at >= ? AND completed_at < ?", [prevStart.toISOString(), monthStart.toISOString()]);
        data[w] = { current: Number(cur.v), previous: Number(prev.v) };
        break;
      }
      case 'kpi_due': {
        const v = await db().get("SELECT COALESCE(SUM(total_cents - paid_cents),0) AS v, COUNT(*) AS n FROM invoices WHERE status IN ('unpaid','partial','overdue')");
        const o = await db().get("SELECT COUNT(*) AS n FROM invoices WHERE status = 'overdue'");
        data[w] = { amount: Number(v.v), count: Number(v.n), overdue: Number(o.n) };
        break;
      }
      case 'finance_profit': { if (await moduleEnabled('finance')) data[w] = await financeKpis(); break; }
      case 'inventory_stock': { if (await moduleEnabled('inventory')) data[w] = await inventorySummary(); break; }
      case 'jobs_today': {
        if (!(await moduleEnabled('jobs'))) break;
        const day = new Date().toISOString().slice(0, 10);
        const rows = await db().all("SELECT status, COUNT(*) AS n FROM jobs WHERE status NOT IN ('done','cancelled') GROUP BY status");
        const today = await db().get('SELECT COUNT(*) AS n FROM jobs WHERE SUBSTR(scheduled_at,1,10) = ?', [day]);
        const overdue = await db().get("SELECT COUNT(*) AS n FROM jobs WHERE scheduled_at < ? AND status NOT IN ('done','cancelled','failed')", [new Date().toISOString()]);
        data[w] = { open: rows.reduce((s, r) => s + Number(r.n), 0), today: Number(today.n), overdue: Number(overdue.n) };
        break;
      }
      case 'kpi_tickets': {
        const rows = await db().all("SELECT priority, COUNT(*) AS n FROM tickets WHERE status NOT IN ('closed','resolved') GROUP BY priority");
        data[w] = { byPriority: Object.fromEntries(rows.map((x) => [x.priority, Number(x.n)])), total: rows.reduce((s, x) => s + Number(x.n), 0) };
        break;
      }
      case 'revenue_chart': {
        const since = new Date(monthStart); since.setUTCMonth(since.getUTCMonth() - 11);
        const paid = await db().all("SELECT SUBSTR(completed_at,1,7) AS month, SUM(amount_cents) AS v FROM payments WHERE status = 'success' AND method != 'balance' AND completed_at >= ? GROUP BY SUBSTR(completed_at,1,7)", [since.toISOString()]);
        const billed = await db().all("SELECT SUBSTR(issued_at,1,7) AS month, SUM(total_cents) AS v FROM invoices WHERE status != 'void' AND issued_at >= ? GROUP BY SUBSTR(issued_at,1,7)", [since.toISOString()]);
        const months = Array.from({ length: 12 }, (_, i) => { const d = new Date(since); d.setUTCMonth(d.getUTCMonth() + i); return d.toISOString().slice(0, 7); });
        data[w] = months.map((m) => ({ month: m, collected: Number(paid.find((x) => x.month === m)?.v || 0), billed: Number(billed.find((x) => x.month === m)?.v || 0) }));
        break;
      }
      case 'live_bandwidth': {
        const since = new Date(Date.now() - 6 * 3600000).toISOString();
        const series = await db().all('SELECT ts, SUM(rx_bps) AS rx, SUM(tx_bps) AS tx FROM usage_samples WHERE ts >= ? GROUP BY ts ORDER BY ts', [since]);
        data[w] = { totals: live.totals, at: live.at, series: series.map((s) => ({ ts: s.ts, rx: Number(s.rx), tx: Number(s.tx) })) };
        break;
      }
      case 'top_users': {
        const ids = [...live.perCustomer.values()].sort((a, b) => b.rx_bps + b.tx_bps - a.rx_bps - a.tx_bps).slice(0, 8);
        const names = ids.length ? await db().all(`SELECT c.id, c.code, u.name FROM customers c JOIN users u ON u.id = c.user_id WHERE c.id IN (${ids.map(() => '?').join(',')})`, ids.map((x) => x.customer_id)) : [];
        data[w] = ids.map((x) => ({ ...x, ...(names.find((n) => n.id === x.customer_id) || {}) }));
        break;
      }
      case 'plan_distribution':
        data[w] = await db().all("SELECT p.name, COUNT(c.id) AS n FROM plans p LEFT JOIN customers c ON c.plan_id = p.id AND c.status = 'active' GROUP BY p.id, p.name ORDER BY n DESC");
        break;
      case 'recent_tickets':
        data[w] = await db().all('SELECT t.id, t.number, t.subject, t.priority, t.status, t.updated_at, u.name AS customer_name FROM tickets t LEFT JOIN customers c ON c.id = t.customer_id LEFT JOIN users u ON u.id = c.user_id ORDER BY t.updated_at DESC LIMIT 6');
        break;
      case 'recent_payments':
        data[w] = await db().all("SELECT p.id, p.amount_cents, p.method, p.completed_at, u.name AS customer_name FROM payments p JOIN customers c ON c.id = p.customer_id JOIN users u ON u.id = c.user_id WHERE p.status = 'success' AND p.method != 'balance' ORDER BY p.completed_at DESC LIMIT 6");
        break;
      case 'sales_funnel':
        data[w] = await db().all('SELECT status, COUNT(*) AS n FROM leads GROUP BY status');
        break;
      case 'network_status':
        data[w] = await db().all('SELECT id, name, driver, status, last_seen_at, location FROM routers ORDER BY name');
        break;
      default: break;
    }
  }
  res.json({ widgets, data });
});

// Admin can choose their own widget layout; role layouts are set in Staff & Roles.
r.put('/dashboard/layout', authenticate, requireAdmin, validate(z.object({ widgets: z.array(z.enum(Object.keys(WIDGETS))).max(30) })), async (req, res) => {
  const prefs = { ...(req.user.preferences || {}), dashboard: req.body.widgets };
  await db().run('UPDATE users SET preferences = ? WHERE id = ?', [JSON.stringify(prefs), req.user.id]);
  res.json({ ok: true });
});

// ------------------------------------------------------------------ updates (admin only)
r.get('/updates', authenticate, requirePerm('updates.manage'), async (_req, res) => {
  const s = await getSetting('updates');
  res.json({ current: VERSION, settings: s, history: await history(), backups: listBackups() });
});
r.post('/updates/check', authenticate, requirePerm('updates.manage'), async (_req, res) => {
  const { _release, ...info } = await checkForUpdate();
  res.json(info);
});
r.post('/updates/apply', authenticate, requireAdmin, async (req, res) => {
  await audit(req, 'updates.apply');
  res.json(await applyUpdate(`manual:${req.user.email}`));
});
r.post('/updates/rollback', authenticate, requireAdmin, validate(z.object({ file: z.string().max(200) })), async (req, res) => {
  await audit(req, 'updates.rollback', null, null, { file: req.body.file });
  res.json(await rollback(req.body.file));
});
r.put('/updates/settings', authenticate, requireAdmin, validate(z.object({ auto: z.boolean() })), async (req, res) => {
  await setSetting('updates', { auto: req.body.auto });
  await audit(req, 'updates.settings', null, null, req.body);
  res.json({ ok: true });
});

// ------------------------------------------------------------------ audit log
r.get('/audit', authenticate, requirePerm('audit.view'), async (req, res) => {
  const { action, user_id, page, pageSize } = req.query;
  const where = []; const params = [];
  if (action) { where.push('a.action LIKE ?'); params.push(`${String(action).slice(0, 40)}%`); }
  if (user_id) { where.push('a.user_id = ?'); params.push(Number(user_id)); }
  const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const from = `FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id ${w}`;
  const out = await paginate({ base: `SELECT a.*, u.name AS user_name, u.email AS user_email ${from}`, countBase: `SELECT COUNT(*) AS n ${from}`, params, page, pageSize, defaultSort: 'a.id DESC' });
  res.json({ ...out, rows: out.rows.map((x) => ({ ...x, meta: parseJson(x.meta, null) })) });
});

export default r;
