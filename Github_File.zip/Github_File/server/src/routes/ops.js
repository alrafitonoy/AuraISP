// Operations: network map (customers + sites), KYC documents (private uploads + verification), session / IP log (BTRC).
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import config from '../config.js';
import { db, insert, update, now, paginate, ciLike } from '../db/index.js';
import { validate, notFound, badRequest, forbidden, HttpError } from '../lib/http.js';
import { authenticate, requirePerm, requireModule, requireCustomer, can } from '../middleware/auth.js';
import { audit } from '../lib/audit.js';
import { toCsv } from '../lib/csv.js';
import { live } from '../network/service.js';

const r = Router();
r.use(authenticate);

const idParam = (req) => { const id = Number(req.params.id); if (!Number.isInteger(id) || id <= 0) throw notFound(); return id; };
const num = (v) => { if (v === null || v === undefined || String(v).trim() === '') return null; const n = Number(v); return Number.isFinite(n) ? n : null; };
const validCoord = (lat, lng) => lat !== null && lng !== null && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180 && !(lat === 0 && lng === 0);

// =================================================================== (A) Network map
const MAP = [requireModule('network_map')];
const SITE_TYPES = ['pop', 'tower', 'box', 'splitter', 'olt', 'office'];
const lat = z.coerce.number().finite().min(-90).max(90);
const lng = z.coerce.number().finite().min(-180).max(180);
const siteSchema = z.object({
  name: z.string().trim().min(1).max(120),
  type: z.enum(SITE_TYPES).default('pop'),
  lat, lng,
  zone_id: z.coerce.number().int().positive().optional().nullable(),
  notes: z.string().trim().max(1000).optional().nullable(),
});
const coord6 = (n) => String(Math.round(Number(n) * 1e6) / 1e6);

async function checkZone(zoneId) {
  if (zoneId && !(await db().get('SELECT id FROM zones WHERE id = ?', [zoneId]))) throw badRequest('Unknown zone');
}
const presentSite = (s) => ({ ...s, lat: Number(s.lat), lng: Number(s.lng) });

r.get('/sites', ...MAP, requirePerm('network.view'), async (_req, res) => {
  const rows = await db().all('SELECT s.*, z.name AS zone_name FROM network_sites s LEFT JOIN zones z ON z.id = s.zone_id ORDER BY s.name ASC');
  res.json({ rows: rows.map(presentSite) });
});

r.post('/sites', ...MAP, requirePerm('network.manage'), validate(siteSchema), async (req, res) => {
  await checkZone(req.body.zone_id);
  const b = req.body;
  const out = await insert('network_sites', { name: b.name, type: b.type, lat: coord6(b.lat), lng: coord6(b.lng), zone_id: b.zone_id ?? null, notes: b.notes ?? null, created_at: now() });
  await audit(req, 'network_map.site_create', 'network_site', out.id, { name: b.name, type: b.type });
  res.status(201).json({ id: out.id });
});

r.put('/sites/:id', ...MAP, requirePerm('network.manage'), validate(siteSchema.partial()), async (req, res) => {
  const id = idParam(req);
  if (!(await db().get('SELECT id FROM network_sites WHERE id = ?', [id]))) throw notFound();
  await checkZone(req.body.zone_id);
  const b = { ...req.body };
  if (b.lat !== undefined) b.lat = coord6(b.lat);
  if (b.lng !== undefined) b.lng = coord6(b.lng);
  await update('network_sites', id, b);
  await audit(req, 'network_map.site_update', 'network_site', id);
  res.json({ ok: true });
});

r.delete('/sites/:id', ...MAP, requirePerm('network.manage'), async (req, res) => {
  const id = idParam(req);
  const out = await db().run('DELETE FROM network_sites WHERE id = ?', [id]);
  if (!out.changes) throw notFound();
  await audit(req, 'network_map.site_delete', 'network_site', id);
  res.json({ ok: true });
});

/** Everything the map draws: located customers (with live/overdue state), how many still need a location, and sites. */
r.get('/map', ...MAP, requirePerm('network.view'), async (_req, res) => {
  const rows = await db().all(
    `SELECT c.id, c.code, c.status, c.lat, c.lng, c.address, c.area, c.ip_address, c.zone_id, u.name, u.phone, p.name AS plan_name,
            (SELECT COUNT(*) FROM invoices i WHERE i.customer_id = c.id AND i.status = 'overdue') AS overdue_count
       FROM customers c JOIN users u ON u.id = c.user_id LEFT JOIN plans p ON p.id = c.plan_id
      WHERE c.status != 'terminated'`);
  const customers = []; let unplaced = 0;
  for (const c of rows) {
    const la = num(c.lat); const ln = num(c.lng);
    if (!validCoord(la, ln)) { unplaced++; continue; }
    customers.push({
      id: c.id, code: c.code, name: c.name, phone: c.phone, status: c.status, plan_name: c.plan_name, address: c.address, area: c.area,
      ip_address: c.ip_address, zone_id: c.zone_id, lat: la, lng: ln,
      online: !!live.perCustomer.get(c.id)?.online, overdue: Number(c.overdue_count) > 0,
    });
  }
  const sites = (await db().all('SELECT * FROM network_sites ORDER BY name ASC')).map(presentSite);
  res.json({ customers, sites, unplaced, liveAt: live.at });
});

const locationSchema = z.object({ lat: lat.nullable(), lng: lng.nullable() })
  .refine((v) => (v.lat === null) === (v.lng === null), 'Give both latitude and longitude, or clear both');
r.put('/customers/:id/location', ...MAP, requirePerm('customers.edit'), validate(locationSchema), async (req, res) => {
  const id = idParam(req);
  if (!(await db().get('SELECT id FROM customers WHERE id = ?', [id]))) throw notFound('Customer not found');
  const { lat: la, lng: ln } = req.body;
  await db().run('UPDATE customers SET lat = ?, lng = ?, updated_at = ? WHERE id = ?', [la === null ? null : coord6(la), ln === null ? null : coord6(ln), now(), id]);
  await audit(req, 'customers.location', 'customer', id, { lat: la, lng: ln });
  res.json({ ok: true });
});

// =================================================================== (B) KYC documents
const KYC = [requireModule('kyc')];
const KYC_DIR = path.join(config.dataDir, 'private', 'kyc');
const DOC_TYPES = ['nid_front', 'nid_back', 'photo', 'passport', 'birth_certificate', 'agreement', 'trade_license', 'other'];
const MAX_DOCS_PER_CUSTOMER = 40;
const KINDS = [
  { mime: 'image/jpeg', ext: 'jpg', test: (b) => b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  { mime: 'image/png', ext: 'png', test: (b) => b.length > 8 && b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) },
  { mime: 'image/webp', ext: 'webp', test: (b) => b.length > 12 && b.subarray(0, 4).toString('latin1') === 'RIFF' && b.subarray(8, 12).toString('latin1') === 'WEBP' },
  { mime: 'application/pdf', ext: 'pdf', test: (b) => b.length > 5 && b.subarray(0, 5).toString('latin1') === '%PDF-' },
];
const ALLOWED_MIME = new Set(KINDS.map((k) => k.mime).concat('image/jpg', 'image/pjpeg'));
const FILE_RE = /^[a-f0-9]{48}\.(jpg|png|webp|pdf)$/;

const kycUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024, files: 1, fields: 10 },
  fileFilter: (_req, file, cb) => (ALLOWED_MIME.has(file.mimetype) ? cb(null, true) : cb(badRequest('Only JPEG, PNG, WEBP or PDF files are accepted'))),
});
const uploadOne = (req, res, next) => kycUpload.single('file')(req, res, (err) => {
  if (!err) return next();
  if (err instanceof HttpError) return next(err);
  if (err.code === 'LIMIT_FILE_SIZE') return next(new HttpError(413, 'File too large (max 5 MB)'));
  return next(badRequest(err.message || 'Upload failed'));
});

const docSchema = z.object({ type: z.enum(DOC_TYPES), number: z.string().trim().max(64).optional().nullable().transform((v) => v || null) });

const filePath = (name) => { if (!FILE_RE.test(String(name || ''))) throw notFound('File missing'); return path.join(KYC_DIR, name); };
const removeFile = (name) => { if (FILE_RE.test(String(name || ''))) fs.rmSync(path.join(KYC_DIR, name), { force: true }); };
const presentDoc = ({ file, ...d }) => ({ ...d, has_file: !!file });

async function storeDocument(req, customerId) {
  if (!req.file?.buffer?.length) throw badRequest('Choose a file to upload');
  const kind = KINDS.find((k) => k.test(req.file.buffer));
  if (!kind) throw badRequest('The file content is not a valid JPEG, PNG, WEBP or PDF');
  const count = await db().get('SELECT COUNT(*) AS n FROM customer_documents WHERE customer_id = ?', [customerId]);
  if (Number(count?.n || 0) >= MAX_DOCS_PER_CUSTOMER) throw badRequest(`At most ${MAX_DOCS_PER_CUSTOMER} documents per customer — delete old ones first`);
  fs.mkdirSync(KYC_DIR, { recursive: true, mode: 0o700 });
  const name = `${crypto.randomBytes(24).toString('hex')}.${kind.ext}`;
  fs.writeFileSync(path.join(KYC_DIR, name), req.file.buffer, { mode: 0o600 });
  try {
    const out = await insert('customer_documents', {
      customer_id: customerId, type: req.body.type, number: req.body.number, file: name, mime: kind.mime,
      status: 'pending', uploaded_by: req.user.id, created_at: now(),
    });
    return out.id;
  } catch (e) { removeFile(name); throw e; }
}

const listDocs = async (customerId) => (await db().all(
  `SELECT d.*, v.name AS verified_by_name, up.name AS uploaded_by_name FROM customer_documents d
     LEFT JOIN users v ON v.id = d.verified_by LEFT JOIN users up ON up.id = d.uploaded_by
    WHERE d.customer_id = ? ORDER BY d.id DESC`, [customerId])).map(presentDoc);

async function customerExists(id) {
  if (!(await db().get('SELECT id FROM customers WHERE id = ?', [id]))) throw notFound('Customer not found');
}

// ---- staff
r.get('/documents', ...KYC, requirePerm('kyc.view'), async (req, res) => {
  const { status, type, q, customer_id: cid, page, pageSize } = req.query;
  const where = []; const params = [];
  if (status && ['pending', 'verified', 'rejected'].includes(String(status))) { where.push('d.status = ?'); params.push(String(status)); }
  if (type && DOC_TYPES.includes(String(type))) { where.push('d.type = ?'); params.push(String(type)); }
  if (cid && Number(cid)) { where.push('d.customer_id = ?'); params.push(Number(cid)); }
  if (q) { where.push(`(u.name ${ciLike()} ? OR c.code ${ciLike()} ? OR d.number ${ciLike()} ? OR u.phone ${ciLike()} ?)`); params.push(...Array(4).fill(`%${String(q).slice(0, 60)}%`)); }
  const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const from = `FROM customer_documents d JOIN customers c ON c.id = d.customer_id JOIN users u ON u.id = c.user_id LEFT JOIN users v ON v.id = d.verified_by ${w}`;
  const out = await paginate({
    base: `SELECT d.*, c.code AS customer_code, u.name AS customer_name, u.phone AS customer_phone, v.name AS verified_by_name ${from}`,
    countBase: `SELECT COUNT(*) AS n ${from}`, params, page, pageSize: pageSize || 50, defaultSort: status === 'pending' ? 'd.id ASC' : 'd.id DESC',
  });
  const counts = await db().all('SELECT status, COUNT(*) AS n FROM customer_documents GROUP BY status');
  res.json({ ...out, rows: out.rows.map(presentDoc), counts: Object.fromEntries(counts.map((x) => [x.status, Number(x.n)])) });
});

r.get('/customers/:id/documents', ...KYC, requirePerm('kyc.view'), async (req, res) => {
  const id = idParam(req);
  await customerExists(id);
  res.json({ rows: await listDocs(id) });
});

r.post('/customers/:id/documents', ...KYC, requirePerm('kyc.verify', 'customers.edit'), uploadOne, validate(docSchema), async (req, res) => {
  const id = idParam(req);
  await customerExists(id);
  const docId = await storeDocument(req, id);
  await audit(req, 'kyc.upload', 'customer_document', docId, { customer_id: id, type: req.body.type });
  res.status(201).json({ id: docId });
});

const verifySchema = z.object({ status: z.enum(['verified', 'rejected', 'pending']), note: z.string().trim().max(500).optional().nullable() })
  .refine((v) => v.status !== 'rejected' || (v.note && v.note.length >= 3), { message: 'Give a reason when rejecting', path: ['note'] });
r.post('/documents/:id/verify', ...KYC, requirePerm('kyc.verify'), validate(verifySchema), async (req, res) => {
  const id = idParam(req);
  const doc = await db().get('SELECT id, customer_id FROM customer_documents WHERE id = ?', [id]);
  if (!doc) throw notFound();
  const { status, note } = req.body;
  await db().run('UPDATE customer_documents SET status = ?, note = ?, verified_by = ?, verified_at = ? WHERE id = ?',
    [status, note || null, status === 'pending' ? null : req.user.id, status === 'pending' ? null : now(), id]);
  await audit(req, `kyc.${status === 'pending' ? 'reopen' : status === 'verified' ? 'verify' : 'reject'}`, 'customer_document', id, { customer_id: doc.customer_id, note: note || undefined });
  res.json({ ok: true });
});

r.delete('/documents/:id', ...KYC, requirePerm('kyc.verify'), async (req, res) => {
  const id = idParam(req);
  const doc = await db().get('SELECT id, customer_id, file FROM customer_documents WHERE id = ?', [id]);
  if (!doc) throw notFound();
  await db().run('DELETE FROM customer_documents WHERE id = ?', [id]);
  removeFile(doc.file);
  await audit(req, 'kyc.delete', 'customer_document', id, { customer_id: doc.customer_id });
  res.json({ ok: true });
});

/** Streams the private file: staff with kyc.view, or the customer who owns it. Always an attachment, never sniffed. */
r.get('/documents/:id/file', ...KYC, async (req, res) => {
  const id = idParam(req);
  const doc = await db().get('SELECT d.id, d.customer_id, d.type, d.file, d.mime, c.code FROM customer_documents d JOIN customers c ON c.id = d.customer_id WHERE d.id = ?', [id]);
  const owner = req.user.type === 'customer' && doc && req.user.customer_id === Number(doc.customer_id);
  if (!owner && !can(req.user, 'kyc.view')) throw (req.user.type === 'customer' ? notFound() : forbidden());
  if (!doc) throw notFound();
  const p = filePath(doc.file);
  if (!fs.existsSync(p)) throw notFound('File missing');
  const ext = doc.file.split('.').pop();
  const safeCode = String(doc.code || 'customer').replace(/[^A-Za-z0-9_-]/g, '');
  if (!owner) await audit(req, 'kyc.download', 'customer_document', id, { customer_id: doc.customer_id });
  res.set({
    'Content-Type': KINDS.find((k) => k.ext === ext)?.mime || 'application/octet-stream',
    'Content-Disposition': `attachment; filename="${safeCode}-${doc.type}-${doc.id}.${ext}"`,
    'X-Content-Type-Options': 'nosniff',
    'Cache-Control': 'private, no-store',
    'Content-Security-Policy': "default-src 'none'; sandbox",
  });
  fs.createReadStream(p).on('error', () => res.destroy()).pipe(res);
});

// ---- customer self-service
r.get('/my/documents', ...KYC, requireCustomer, async (req, res) => {
  res.json({ rows: await listDocs(req.user.customer_id) });
});

r.post('/my/documents', ...KYC, requireCustomer, uploadOne, validate(docSchema), async (req, res) => {
  const pending = await db().get("SELECT COUNT(*) AS n FROM customer_documents WHERE customer_id = ? AND status = 'pending'", [req.user.customer_id]);
  if (Number(pending?.n || 0) >= 10) throw badRequest('You already have 10 documents waiting for review');
  const docId = await storeDocument(req, req.user.customer_id);
  await audit(req, 'kyc.self_upload', 'customer_document', docId, { type: req.body.type });
  res.status(201).json({ id: docId });
});

r.delete('/my/documents/:id', ...KYC, requireCustomer, async (req, res) => {
  const id = idParam(req);
  const doc = await db().get('SELECT id, file, status FROM customer_documents WHERE id = ? AND customer_id = ?', [id, req.user.customer_id]);
  if (!doc) throw notFound();
  if (doc.status === 'verified') throw forbidden('Verified documents can only be removed by our staff');
  await db().run('DELETE FROM customer_documents WHERE id = ?', [id]);
  removeFile(doc.file);
  await audit(req, 'kyc.self_delete', 'customer_document', id);
  res.json({ ok: true });
});

// =================================================================== (C) Session & IP log
const SLOG = [requireModule('session_log'), requirePerm('kyc.view')];
const isoTime = z.string().trim().max(40).refine((v) => !Number.isNaN(Date.parse(v)), 'Invalid date/time').transform((v) => new Date(v).toISOString());
const sessionQuery = z.object({
  ip: z.string().trim().max(64).optional(),
  q: z.string().trim().max(80).optional(),
  customer_id: z.coerce.number().int().positive().optional(),
  at: isoTime.optional(),
  from: isoTime.optional(),
  to: isoTime.optional(),
  open: z.enum(['1', 'true']).optional(),
  page: z.coerce.number().int().positive().optional(),
  pageSize: z.coerce.number().int().positive().max(200).optional(),
}).refine((v) => !(v.from && v.to) || v.from <= v.to, { message: '"from" must be before "to"', path: ['from'] });

/**
 * A session matches a moment T when started_at <= T and (ended_at IS NULL OR ended_at >= T).
 * A range [from, to] matches every session that overlapped it. `at` is shorthand for from = to = at.
 */
function sessionWhere(f) {
  const where = []; const params = [];
  const from = f.at || f.from; const to = f.at || f.to;
  if (f.ip) { where.push('s.ip = ?'); params.push(f.ip); }
  if (f.customer_id) { where.push('s.customer_id = ?'); params.push(f.customer_id); }
  if (f.q) { where.push(`(s.username ${ciLike()} ? OR s.mac ${ciLike()} ? OR c.code ${ciLike()} ? OR u.name ${ciLike()} ?)`); params.push(...Array(4).fill(`%${f.q}%`)); }
  if (to) { where.push('s.started_at <= ?'); params.push(to); }
  if (from) { where.push('(s.ended_at IS NULL OR s.ended_at >= ?)'); params.push(from); }
  if (f.open) where.push('s.ended_at IS NULL');
  return { w: where.length ? `WHERE ${where.join(' AND ')}` : '', params };
}
const SESSION_FROM = 'FROM session_logs s LEFT JOIN customers c ON c.id = s.customer_id LEFT JOIN users u ON u.id = c.user_id LEFT JOIN routers rt ON rt.id = s.router_id';
const SESSION_COLS = `s.*, c.code AS customer_code, u.name AS customer_name, u.phone AS customer_phone, c.address AS customer_address,
  c.national_id AS customer_nid, rt.name AS router_name`;

r.get('/sessions', ...SLOG, validate(sessionQuery, 'query'), async (req, res) => {
  const { w, params } = sessionWhere(req.query);
  const out = await paginate({
    base: `SELECT ${SESSION_COLS} ${SESSION_FROM} ${w}`, countBase: `SELECT COUNT(*) AS n ${SESSION_FROM} ${w}`,
    params, page: req.query.page, pageSize: req.query.pageSize || 50, defaultSort: 's.started_at DESC, s.id DESC',
  });
  if (req.query.ip || req.query.at) await audit(req, 'session_log.search', 'session_log', null, { ip: req.query.ip, at: req.query.at, from: req.query.from, to: req.query.to });
  res.json(out);
});

r.get('/sessions.csv', ...SLOG, validate(sessionQuery, 'query'), async (req, res) => {
  const { w, params } = sessionWhere(req.query);
  const rows = await db().all(`SELECT ${SESSION_COLS} ${SESSION_FROM} ${w} ORDER BY s.started_at DESC, s.id DESC LIMIT 100000`, params);
  const csv = toCsv(
    ['session_id', 'ip', 'username', 'mac', 'customer_code', 'customer_name', 'phone', 'national_id', 'address', 'router', 'started_at', 'ended_at', 'last_seen_at', 'bytes_in', 'bytes_out'],
    rows.map((s) => [s.id, s.ip, s.username, s.mac, s.customer_code, s.customer_name, s.customer_phone, s.customer_nid, s.customer_address, s.router_name,
      s.started_at, s.ended_at, s.last_seen_at, s.bytes_in, s.bytes_out]));
  await audit(req, 'session_log.export', 'session_log', null, { count: rows.length, ip: req.query.ip, at: req.query.at, from: req.query.from, to: req.query.to });
  res.set('Content-Type', 'text/csv; charset=utf-8').set('Content-Disposition', `attachment; filename="session-log-${new Date().toISOString().slice(0, 10)}.csv"`)
    .set('X-Content-Type-Options', 'nosniff').set('Cache-Control', 'private, no-store').send(csv);
});

export default r;
