import { Router } from 'express';
import { z } from 'zod';
import { db, insert, update, now, parseJson, cascadeDelete } from '../db/index.js';
import { validate, notFound, badRequest, conflict } from '../lib/http.js';
import { authenticate, requirePerm } from '../middleware/auth.js';
import { audit } from '../lib/audit.js';

const r = Router();

export const presentPlan = (p) => p && ({ ...p, features: parseJson(p.features, []), is_default: !!p.is_default, is_public: !!p.is_public, is_featured: !!p.is_featured, active: !!p.active });

const schema = z.object({
  name: z.string().trim().min(2).max(80),
  slug: z.string().trim().toLowerCase().regex(/^[a-z0-9-]{2,60}$/).optional(),
  description: z.string().max(2000).optional().nullable(),
  download_kbps: z.coerce.number().int().min(64).max(100_000_000),
  upload_kbps: z.coerce.number().int().min(64).max(100_000_000),
  burst_kbps: z.coerce.number().int().min(0).max(100_000_000).optional(),
  data_cap_mb: z.coerce.number().int().min(0).optional(),
  price_cents: z.coerce.number().int().min(0).max(10_000_000_00),
  setup_fee_cents: z.coerce.number().int().min(0).optional(),
  billing_cycle: z.enum(['monthly', 'quarterly', 'yearly']).optional(),
  features: z.array(z.string().max(120)).max(20).optional(),
  is_default: z.boolean().optional(),
  is_public: z.boolean().optional(),
  is_featured: z.boolean().optional(),
  active: z.boolean().optional(),
  sort: z.coerce.number().int().optional(),
});

r.get('/', authenticate, requirePerm('plans.view', 'customers.view'), async (_req, res) => {
  const rows = await db().all(`SELECT p.*, (SELECT COUNT(*) FROM customers c WHERE c.plan_id = p.id AND c.status = 'active') AS subscribers FROM plans p ORDER BY sort, price_cents`);
  res.json({ plans: rows.map(presentPlan) });
});

r.post('/', authenticate, requirePerm('plans.manage'), validate(schema), async (req, res) => {
  const b = req.body;
  const slug = b.slug || b.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  if (await db().get('SELECT id FROM plans WHERE slug = ?', [slug])) throw conflict('A plan with this slug exists');
  if (b.is_default) await db().run('UPDATE plans SET is_default = 0');
  const out = await insert('plans', { ...b, slug, features: JSON.stringify(b.features || []), created_at: now(), updated_at: now() });
  await audit(req, 'plan.create', 'plan', out.id);
  res.status(201).json({ id: out.id });
});

r.put('/:id', authenticate, requirePerm('plans.manage'), validate(schema.partial()), async (req, res) => {
  const id = Number(req.params.id);
  if (!(await db().get('SELECT id FROM plans WHERE id = ?', [id]))) throw notFound();
  const b = { ...req.body, updated_at: now() };
  if (b.features) b.features = JSON.stringify(b.features);
  if (b.is_default) await db().run('UPDATE plans SET is_default = 0');
  await update('plans', id, b);
  await audit(req, 'plan.update', 'plan', id);
  res.json({ ok: true });
});

r.delete('/:id', authenticate, requirePerm('plans.manage'), async (req, res) => {
  const id = Number(req.params.id);
  const used = await db().get('SELECT COUNT(*) AS n FROM customers WHERE plan_id = ?', [id]);
  if (Number(used.n)) throw badRequest('Plan has subscribers — deactivate it instead');
  await cascadeDelete('plans', id);
  await audit(req, 'plan.delete', 'plan', id);
  res.json({ ok: true });
});

export default r;
