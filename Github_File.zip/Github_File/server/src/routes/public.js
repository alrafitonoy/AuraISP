// Unauthenticated endpoints for the public website, guests and the chatbot.
import { Router } from 'express';
import { z } from 'zod';
import config from '../config.js';
import { db, insert, now } from '../db/index.js';
import { validate } from '../lib/http.js';
import { getSetting } from '../lib/settings.js';
import { optionalAuth } from '../middleware/auth.js';
import { publicFormLimiter, chatLimiter } from '../middleware/security.js';
import { presentPlan } from './plans.js';
import { notifyStaff } from './tickets.js';
import { VERSION } from '../updater.js';

const r = Router();

r.get('/config', async (_req, res) => {
  const [branding, company, modules, website] = await Promise.all(['branding', 'company', 'modules', 'website'].map(getSetting));
  const { payments } = await getSetting('integrations');
  res.json({
    version: VERSION,
    branding,
    company: { name: company.legalName, email: company.email, phone: company.phone, address: company.address, currency: company.currency, currencySymbol: company.currencySymbol, locale: company.locale },
    modules,
    website,
    vapidPublicKey: config.vapid.publicKey || null,
    paymentMethods: Object.entries(payments || {}).filter(([, v]) => v?.enabled).map(([k]) => k),
  });
});

r.get('/plans', async (_req, res) => {
  const rows = await db().all('SELECT * FROM plans WHERE active = 1 AND is_public = 1 ORDER BY sort, price_cents');
  res.json({ plans: rows.map(presentPlan) });
});

r.get('/faqs', async (_req, res) => {
  res.json({ faqs: await db().all('SELECT id, question, answer, category FROM faqs WHERE active = 1 ORDER BY sort, id') });
});

r.post('/contact', publicFormLimiter, validate(z.object({
  name: z.string().trim().min(2).max(120), email: z.string().email().max(190).optional().or(z.literal('')),
  phone: z.string().trim().min(6).max(20), address: z.string().max(500).optional(), planId: z.coerce.number().int().positive().optional(),
  message: z.string().max(2000).optional(), website: z.string().max(0).optional(), // honeypot: bots fill hidden fields
})), async (req, res) => {
  if (req.body.website) return res.json({ ok: true });
  const plan = req.body.planId ? await db().get('SELECT id, price_cents FROM plans WHERE id = ?', [req.body.planId]) : null;
  const out = await insert('leads', {
    name: req.body.name, email: req.body.email || null, phone: req.body.phone, address: req.body.address || null, source: 'website',
    status: 'new', plan_id: plan?.id ?? null, value_cents: plan?.price_cents ?? 0, notes: req.body.message || null, created_at: now(), updated_at: now(),
  });
  await notifyStaff('crm.view', { title: 'New website lead', body: `${req.body.name} · ${req.body.phone}`, link: '/admin/crm' });
  res.status(201).json({ ok: true, id: out.id });
});

r.post('/coverage', publicFormLimiter, validate(z.object({ area: z.string().trim().min(2).max(80) })), async (req, res) => {
  const { coverageAreas } = await getSetting('website');
  const q = req.body.area.toLowerCase();
  const match = coverageAreas.find((a) => a.toLowerCase().includes(q) || q.includes(a.toLowerCase()));
  res.json({ covered: !!match, area: match || null });
});

// ------------------------------------------------------------------ chatbot (FAQ retrieval + intents)
const STOP = new Set(['the', 'a', 'an', 'is', 'are', 'to', 'of', 'and', 'or', 'my', 'i', 'do', 'how', 'can', 'what', 'for', 'in', 'on', 'it', 'you', 'your', 'me', 'with', 'be', 'does']);
const tokens = (s) => String(s).toLowerCase().replace(/[^a-z0-9ঀ-৿\s]/g, ' ').split(/\s+/).filter((w) => w.length > 1 && !STOP.has(w));

function score(q, faq) {
  const qt = tokens(q);
  if (!qt.length) return 0;
  const hay = new Set([...tokens(faq.question), ...tokens(faq.keywords || ''), ...tokens(faq.answer).slice(0, 40)]);
  const strong = new Set([...tokens(faq.question), ...tokens(faq.keywords || '')]);
  let s = 0;
  for (const w of qt) { if (strong.has(w)) s += 2; else if (hay.has(w)) s += 0.5; else if ([...strong].some((h) => h.startsWith(w) || w.startsWith(h))) s += 1; }
  return s / qt.length;
}

r.post('/chatbot', chatLimiter, optionalAuth, validate(z.object({ message: z.string().trim().min(1).max(500) })), async (req, res) => {
  const msg = req.body.message;
  const lower = msg.toLowerCase();
  const actions = [];
  if (/\b(human|agent|person|staff|support|ticket)\b/.test(lower)) actions.push({ type: 'link', label: req.user ? 'Open a support ticket' : 'Sign in for support', to: req.user ? '/portal/support' : '/login' });
  if (/\b(plan|package|price|speed|upgrade|mbps)\b/.test(lower)) actions.push({ type: 'link', label: 'View plans', to: req.user?.type === 'customer' ? '/portal/plans' : '/plans' });
  if (/\b(pay|bill|invoice|due)\b/.test(lower)) actions.push({ type: 'link', label: 'Pay my bill', to: req.user ? '/portal/billing' : '/login' });
  if (/\b(slow|down|not working|no internet|disconnect|offline)\b/.test(lower)) actions.push({ type: 'link', label: 'Run a speed test', to: req.user ? '/portal/devices' : '/login' });

  const faqs = await db().all('SELECT id, question, answer, keywords FROM faqs WHERE active = 1');
  const ranked = faqs.map((f) => ({ f, s: score(msg, f) })).sort((a, b) => b.s - a.s);
  const best = ranked[0];
  if (best && best.s >= 0.9) {
    return res.json({ reply: best.f.answer, matched: best.f.question, suggestions: ranked.slice(1, 4).filter((x) => x.s > 0.4).map((x) => x.f.question), actions });
  }
  if (/^(hi|hello|hey|salam|assalamu)/.test(lower)) {
    const { companyName } = await getSetting('branding');
    return res.json({ reply: `Hi! I'm the ${companyName} assistant. Ask me about plans, billing, speed issues or your account.`, suggestions: faqs.slice(0, 3).map((f) => f.question), actions });
  }
  res.json({
    reply: "I'm not sure about that one. You can open a support ticket and our team will help you quickly.",
    suggestions: ranked.slice(0, 3).filter((x) => x.s > 0).map((x) => x.f.question),
    actions: actions.length ? actions : [{ type: 'link', label: req.user ? 'Open a support ticket' : 'Contact us', to: req.user ? '/portal/support' : '/#contact' }],
  });
});

export default r;
