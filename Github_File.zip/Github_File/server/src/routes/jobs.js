// Field jobs / work orders: installation, repair, survey, relocation, disconnection and maintenance visits.
// jobs.view sees everything, jobs.manage creates/edits/assigns/deletes, jobs.work (technicians) sees ONLY the jobs
// assigned to them and may move them through the workflow, tick checklist items and record the result.
import { Router } from 'express';
import { z } from 'zod';
import { db, insert, update, now, paginate, parseJson, ciLike } from '../db/index.js';
import { validate, notFound, badRequest, conflict, forbidden } from '../lib/http.js';
import { authenticate, requirePerm, requireModule, can } from '../middleware/auth.js';
import { queueNotify } from '../lib/notify.js';
import { audit } from '../lib/audit.js';

const r = Router();

export const JOB_TYPES = ['installation', 'repair', 'survey', 'relocation', 'disconnection', 'maintenance'];
export const JOB_STATUSES = ['new', 'scheduled', 'en_route', 'on_site', 'done', 'failed', 'cancelled'];
export const JOB_PRIORITIES = ['low', 'normal', 'high', 'urgent'];
const OPEN = ['new', 'scheduled', 'en_route', 'on_site'];
const CLOSED = ['done', 'failed', 'cancelled'];

/** Allowed workflow moves. Re-opening (failed → scheduled, cancelled → new) and cancelling are manager-only. */
export const TRANSITIONS = {
  new: ['scheduled', 'cancelled'],
  scheduled: ['en_route', 'new', 'cancelled'],
  en_route: ['on_site', 'scheduled', 'cancelled'],
  on_site: ['done', 'failed'],
  done: [],
  failed: ['scheduled'],
  cancelled: ['new'],
};
const MANAGER_ONLY = new Set(['cancelled', 'failed->scheduled', 'cancelled->new', 'scheduled->new']);

export const DEFAULT_CHECKLISTS = {
  installation: ['Survey site', 'Run cable', 'Install ONU/router', 'Configure PPPoE', 'Speed test', 'Customer sign-off'],
  repair: ['Check signal / link lights', 'Inspect cable & connectors', 'Replace faulty part', 'Speed test', 'Customer sign-off'],
  survey: ['Check line of sight / cable route', 'Measure distance to nearest box', 'Check signal level', 'Photograph site', 'Record findings'],
  relocation: ['Disconnect at old address', 'Recover equipment', 'Run cable at new address', 'Install & configure', 'Speed test', 'Customer sign-off'],
  disconnection: ['Disconnect service', 'Recover ONU/router', 'Recover cable if possible', 'Customer sign-off'],
  maintenance: ['Inspect equipment', 'Clean / re-terminate connectors', 'Check power backup', 'Record readings'],
};
const defaultChecklist = (type) => (DEFAULT_CHECKLISTS[type] || []).map((label) => ({ label, done: false }));

r.use(authenticate, requireModule('jobs'));

// ------------------------------------------------------------------ helpers
const seesAll = (u) => can(u, 'jobs.view') || can(u, 'jobs.manage');
const isManager = (u) => can(u, 'jobs.manage');
const anyJobPerm = requirePerm('jobs.view', 'jobs.manage', 'jobs.work');

const emptyToNull = (v) => (v === '' ? null : v);
const isoDate = z.preprocess(emptyToNull, z.string().datetime({ offset: true }).transform((s) => new Date(s).toISOString()).nullable().optional());
const coord = (min, max) => z.preprocess(emptyToNull, z.coerce.number().min(min).max(max).transform((n) => String(n)).nullable().optional());
const fk = z.preprocess(emptyToNull, z.coerce.number().int().positive().nullable().optional());
const checklistSchema = z.array(z.object({ label: z.string().trim().min(1).max(200), done: z.boolean().optional().default(false) })).max(50);

const jobSchema = z.object({
  type: z.enum(JOB_TYPES),
  title: z.string().trim().min(2).max(200),
  customer_id: fk, lead_id: fk, ticket_id: fk, zone_id: fk, assigned_to: fk,
  address: z.preprocess(emptyToNull, z.string().trim().max(500).nullable().optional()),
  lat: coord(-90, 90), lng: coord(-180, 180),
  scheduled_at: isoDate,
  duration_min: z.coerce.number().int().min(5).max(24 * 60).optional(),
  priority: z.enum(JOB_PRIORITIES).optional(),
  notes: z.preprocess(emptyToNull, z.string().max(5000).nullable().optional()),
  checklist: checklistSchema.optional(),
});

const SELECT = `SELECT j.*, cu.name AS customer_name, cu.phone AS customer_phone, c.code AS customer_code, c.user_id AS customer_user_id,
  a.name AS assignee_name, z.name AS zone_name`;
const FROM = `FROM jobs j LEFT JOIN customers c ON c.id = j.customer_id LEFT JOIN users cu ON cu.id = c.user_id
  LEFT JOIN users a ON a.id = j.assigned_to LEFT JOIN zones z ON z.id = j.zone_id`;

function shape(j) {
  const checklist = parseJson(j.checklist, []);
  const { customer_user_id: _u, ...rest } = j;
  return { ...rest, checklist, checklist_total: checklist.length, checklist_done: checklist.filter((i) => i.done).length };
}

/** Load a job the current user may see; technicians get a 404 for jobs that are not theirs. */
async function loadJob(req, id) {
  const j = await db().get(`${SELECT}, t.number AS ticket_number, l.name AS lead_name, cb.name AS created_by_name ${FROM}
    LEFT JOIN tickets t ON t.id = j.ticket_id LEFT JOIN leads l ON l.id = j.lead_id LEFT JOIN users cb ON cb.id = j.created_by
    WHERE j.id = ?`, [Number(id)]);
  if (!j) throw notFound('Job not found');
  if (!seesAll(req.user) && Number(j.assigned_to) !== Number(req.user.id)) throw notFound('Job not found');
  return j;
}

/** May the current user work on (status/checklist/result) this job? */
function assertCanWork(req, job) {
  if (isManager(req.user)) return;
  if (can(req.user, 'jobs.work') && Number(job.assigned_to) === Number(req.user.id)) return;
  throw forbidden('Only the assigned technician or a jobs manager can update this job');
}

async function assertTechnician(id) {
  if (!id) return;
  const u = await db().get("SELECT id FROM users WHERE id = ? AND type IN ('admin','staff') AND status = 'active'", [id]);
  if (!u) throw badRequest('Assignee must be an active staff member');
}

async function assertExists(table, id, what) {
  if (!id) return null;
  const row = await db().get(`SELECT * FROM ${table} WHERE id = ?`, [id]);
  if (!row) throw badRequest(`${what} not found`);
  return row;
}

/** Validate links and fill address / coordinates / zone from the linked customer (or lead) when left empty. */
async function resolveLinks(data, current = {}) {
  const merged = { ...current, ...data };
  const customer = await assertExists('customers', data.customer_id, 'Customer');
  const lead = await assertExists('leads', data.lead_id, 'Lead');
  await assertExists('tickets', data.ticket_id, 'Ticket');
  await assertExists('zones', data.zone_id, 'Zone');
  await assertTechnician(data.assigned_to);
  if (customer && !merged.address) {
    data.address = customer.address || null;
    if (!merged.lat && !merged.lng && customer.lat && customer.lng) { data.lat = String(customer.lat); data.lng = String(customer.lng); }
  } else if (lead && !merged.address && lead.address) data.address = lead.address;
  if (customer && !merged.zone_id && customer.zone_id) data.zone_id = customer.zone_id;
  return data;
}

async function nextNumber() {
  const prefix = `JOB-${new Date().getUTCFullYear()}-`;
  const row = await db().get('SELECT number FROM jobs WHERE number LIKE ? ORDER BY number DESC LIMIT 1', [`${prefix}%`]);
  const n = row ? (Number(row.number.slice(prefix.length)) || 0) + 1 : 1;
  return `${prefix}${String(n).padStart(5, '0')}`;
}

/** Insert with a unique JOB-YYYY-NNNNN number; concurrent creates race for a number, the UNIQUE index catches it. */
async function createJob(row) {
  for (let attempt = 0; ; attempt++) {
    const number = await nextNumber();
    try {
      const out = await insert('jobs', { ...row, number });
      return { id: out.id, number };
    } catch (e) {
      if (attempt >= 6 || !/unique|duplicate/i.test(e.message)) throw e;
    }
  }
}

const whenText = (iso) => (iso ? new Date(iso).toUTCString().replace(':00 GMT', ' UTC') : 'to be scheduled');

function notifyAssignee(req, job) {
  if (!job.assigned_to || Number(job.assigned_to) === Number(req.user.id)) return;
  queueNotify({
    userId: job.assigned_to, channels: ['inapp', 'push'], kind: 'info', link: `/admin/jobs?job=${job.id}`,
    subject: `Job assigned: ${job.number}`,
    body: `${job.title} (${job.type}) — ${whenText(job.scheduled_at)}${job.address ? ` at ${job.address}` : ''}`,
  });
}

async function notifyCustomer(job, status) {
  if (!job.customer_id || !['scheduled', 'en_route'].includes(status)) return;
  const c = await db().get('SELECT user_id FROM customers WHERE id = ?', [job.customer_id]);
  if (!c?.user_id) return;
  const subject = status === 'scheduled' ? `Visit scheduled: ${job.number}` : `Technician on the way: ${job.number}`;
  const body = status === 'scheduled'
    ? `Your ${job.type} visit "${job.title}" is scheduled for ${whenText(job.scheduled_at)}.`
    : `Our technician is on the way for "${job.title}".`;
  queueNotify({ userId: c.user_id, channels: ['inapp', 'sms'], subject, body, link: '/portal', ref: `job:${job.id}:${status}:${job.scheduled_at || ''}` });
}

/** Shared WHERE builder for list / calendar / summary, always scoped for technicians. */
function buildWhere(req, q = {}) {
  const where = []; const params = [];
  if (!seesAll(req.user) || q.mine === '1' || q.mine === 'true') { where.push('j.assigned_to = ?'); params.push(req.user.id); }
  if (q.status) {
    const list = String(q.status).split(',').filter((s) => JOB_STATUSES.includes(s));
    if (list.length) { where.push(`j.status IN (${list.map(() => '?').join(',')})`); params.push(...list); }
  }
  if (q.type && JOB_TYPES.includes(String(q.type))) { where.push('j.type = ?'); params.push(String(q.type)); }
  if (q.priority && JOB_PRIORITIES.includes(String(q.priority))) { where.push('j.priority = ?'); params.push(String(q.priority)); }
  if (q.assigned_to === 'none') where.push('j.assigned_to IS NULL');
  else if (q.assigned_to && Number(q.assigned_to)) { where.push('j.assigned_to = ?'); params.push(Number(q.assigned_to)); }
  if (q.customer_id && Number(q.customer_id)) { where.push('j.customer_id = ?'); params.push(Number(q.customer_id)); }
  if (q.ticket_id && Number(q.ticket_id)) { where.push('j.ticket_id = ?'); params.push(Number(q.ticket_id)); }
  if (q.zone_id && Number(q.zone_id)) { where.push('j.zone_id = ?'); params.push(Number(q.zone_id)); }
  const from = parseIso(q.from); const to = parseIso(q.to);
  if (from) { where.push('j.scheduled_at >= ?'); params.push(from); }
  if (to) { where.push('j.scheduled_at < ?'); params.push(to); }
  if (q.overdue === '1' || q.overdue === 'true') {
    where.push("j.scheduled_at < ? AND j.status IN ('new','scheduled','en_route')"); params.push(now());
  }
  if (q.q) {
    const like = `%${String(q.q).slice(0, 60)}%`;
    where.push(`(j.number ${ciLike()} ? OR j.title ${ciLike()} ? OR j.address ${ciLike()} ? OR cu.name ${ciLike()} ? OR c.code ${ciLike()} ?)`);
    params.push(like, like, like, like, like);
  }
  return { where, params };
}
function parseIso(v) {
  if (!v) return null;
  const t = Date.parse(String(v));
  if (Number.isNaN(t)) throw badRequest(`Invalid date: ${String(v).slice(0, 40)}`);
  return new Date(t).toISOString();
}
/** Client timezone as JS getTimezoneOffset() minutes (e.g. -360 for UTC+6); used to group by local day. */
const tzOffset = (v) => Math.max(-840, Math.min(840, Number.parseInt(v, 10) || 0));
const localDay = (iso, tz) => new Date(Date.parse(iso) - tz * 60000).toISOString().slice(0, 10);

// ------------------------------------------------------------------ lookups
r.get('/meta', anyJobPerm, async (_req, res) => {
  const zones = await db().all('SELECT id, name FROM zones ORDER BY name');
  res.json({ types: JOB_TYPES, statuses: JOB_STATUSES, priorities: JOB_PRIORITIES, transitions: TRANSITIONS, checklists: DEFAULT_CHECKLISTS, zones });
});

r.get('/technicians', requirePerm('jobs.view', 'jobs.manage'), async (_req, res) => {
  const rows = await db().all(`SELECT u.id, u.name, u.type, r.permissions FROM users u LEFT JOIN roles r ON r.id = u.role_id
    WHERE u.type IN ('admin','staff') AND u.status = 'active' ORDER BY u.name`);
  const out = rows.map((u) => {
    const p = parseJson(u.permissions, []);
    return { id: u.id, name: u.name, technician: u.type === 'admin' || p.includes('*') || p.includes('jobs.work') || p.includes('jobs.*') };
  });
  out.sort((a, b) => Number(b.technician) - Number(a.technician) || a.name.localeCompare(b.name));
  res.json({ technicians: out });
});

/** Small search for linking a job to a customer, lead or ticket (jobs managers may lack customers.view). */
r.get('/lookup', requirePerm('jobs.manage'), async (req, res) => {
  const kind = ['customer', 'lead', 'ticket'].includes(req.query.kind) ? req.query.kind : 'customer';
  const like = `%${String(req.query.q || '').slice(0, 60)}%`;
  let rows;
  if (kind === 'customer') {
    rows = await db().all(`SELECT c.id, c.code, u.name, u.phone, c.address FROM customers c JOIN users u ON u.id = c.user_id
      WHERE u.name ${ciLike()} ? OR c.code ${ciLike()} ? OR u.phone ${ciLike()} ? ORDER BY u.name LIMIT 20`, [like, like, like]);
    rows = rows.map((x) => ({ id: x.id, label: `${x.name} (${x.code})`, sub: [x.phone, x.address].filter(Boolean).join(' · ') }));
  } else if (kind === 'lead') {
    rows = await db().all(`SELECT id, name, phone, address FROM leads WHERE name ${ciLike()} ? OR phone ${ciLike()} ? ORDER BY id DESC LIMIT 20`, [like, like]);
    rows = rows.map((x) => ({ id: x.id, label: x.name, sub: [x.phone, x.address].filter(Boolean).join(' · ') }));
  } else {
    rows = await db().all(`SELECT id, number, subject, status FROM tickets WHERE number ${ciLike()} ? OR subject ${ciLike()} ? ORDER BY id DESC LIMIT 20`, [like, like]);
    rows = rows.map((x) => ({ id: x.id, label: `${x.number} — ${x.subject}`, sub: x.status }));
  }
  res.json({ results: rows });
});

// ------------------------------------------------------------------ list / calendar / summary
r.get('/', anyJobPerm, async (req, res) => {
  const { where, params } = buildWhere(req, req.query);
  const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const out = await paginate({
    base: `${SELECT} ${FROM} ${w}`, countBase: `SELECT COUNT(*) AS n ${FROM} ${w}`, params,
    page: req.query.page, pageSize: req.query.pageSize || 50, sort: req.query.sort, defaultSort: 'j.id DESC',
    sortable: { number: 'j.number', scheduled_at: 'j.scheduled_at', created_at: 'j.created_at', status: 'j.status', priority: 'j.priority', type: 'j.type' },
  });
  res.json({ ...out, rows: out.rows.map(shape) });
});

r.get('/calendar', anyJobPerm, async (req, res) => {
  const from = parseIso(req.query.from); const to = parseIso(req.query.to);
  if (!from || !to) throw badRequest('from and to are required');
  if (to <= from) throw badRequest('to must be after from');
  if (Date.parse(to) - Date.parse(from) > 93 * 86400000) throw badRequest('The range can be at most 93 days');
  const tz = tzOffset(req.query.tz);
  const { where, params } = buildWhere(req, { ...req.query, from, to, overdue: undefined });
  const rows = await db().all(`${SELECT} ${FROM} WHERE ${where.join(' AND ')} ORDER BY j.scheduled_at ASC, j.id ASC LIMIT 3000`, params);
  const days = {};
  for (const j of rows) (days[localDay(j.scheduled_at, tz)] ||= []).push(shape(j));
  res.json({ from, to, total: rows.length, days });
});

r.get('/summary', anyJobPerm, async (req, res) => {
  const tz = tzOffset(req.query.tz);
  const today = localDay(now(), tz);
  const start = new Date(Date.parse(`${today}T00:00:00.000Z`) + tz * 60000).toISOString();
  const end = new Date(Date.parse(start) + 86400000).toISOString();
  const scope = buildWhere(req, {});
  const and = (extra) => [...scope.where, extra].filter(Boolean).join(' AND ');
  const grouped = await db().all(`SELECT j.status, COUNT(*) AS n ${FROM} WHERE ${and('1 = 1')} GROUP BY j.status`, scope.params);
  const byStatus = Object.fromEntries(JOB_STATUSES.map((s) => [s, 0]));
  for (const g of grouped) if (g.status in byStatus) byStatus[g.status] = Number(g.n);
  const todayRows = await db().all(`${SELECT} ${FROM} WHERE ${and('j.scheduled_at >= ? AND j.scheduled_at < ?')} ORDER BY j.scheduled_at ASC LIMIT 50`, [...scope.params, start, end]);
  const overdue = await db().get(`SELECT COUNT(*) AS n ${FROM} WHERE ${and("j.scheduled_at < ? AND j.status IN ('new','scheduled','en_route')")}`, [...scope.params, now()]);
  const unassigned = await db().get(`SELECT COUNT(*) AS n ${FROM} WHERE ${and("j.assigned_to IS NULL AND j.status IN ('new','scheduled','en_route','on_site')")}`, scope.params);
  res.json({
    byStatus, open: OPEN.reduce((s, k) => s + byStatus[k], 0), overdue: Number(overdue?.n || 0), unassigned: Number(unassigned?.n || 0),
    today: { count: todayRows.length, jobs: todayRows.map(shape) },
  });
});

r.get('/:id', anyJobPerm, async (req, res) => {
  const j = await loadJob(req, req.params.id);
  const canWork = isManager(req.user) || (can(req.user, 'jobs.work') && Number(j.assigned_to) === Number(req.user.id));
  res.json({ job: { ...shape(j), allowed: allowedFor(req, j), can_work: canWork } });
});

function allowedFor(req, j) {
  const canWork = isManager(req.user) || (can(req.user, 'jobs.work') && Number(j.assigned_to) === Number(req.user.id));
  if (!canWork) return [];
  return (TRANSITIONS[j.status] || []).filter((to) => isManager(req.user) || !(MANAGER_ONLY.has(to) || MANAGER_ONLY.has(`${j.status}->${to}`)));
}

// ------------------------------------------------------------------ create / edit / delete (managers)
r.post('/', requirePerm('jobs.manage'), validate(jobSchema), async (req, res) => {
  const b = await resolveLinks({ ...req.body });
  const ts = now();
  const status = b.scheduled_at ? 'scheduled' : 'new';
  const row = {
    type: b.type, title: b.title, customer_id: b.customer_id ?? null, lead_id: b.lead_id ?? null, ticket_id: b.ticket_id ?? null,
    zone_id: b.zone_id ?? null, address: b.address ?? null, lat: b.lat ?? null, lng: b.lng ?? null, scheduled_at: b.scheduled_at ?? null,
    duration_min: b.duration_min ?? 60, assigned_to: b.assigned_to ?? null, status, priority: b.priority || 'normal', notes: b.notes ?? null,
    checklist: JSON.stringify(b.checklist ?? defaultChecklist(b.type)), created_by: req.user.id, created_at: ts, updated_at: ts,
  };
  const { id, number } = await createJob(row);
  const job = { ...row, id, number };
  notifyAssignee(req, job);
  if (status === 'scheduled') await notifyCustomer(job, 'scheduled');
  await audit(req, 'jobs.create', 'job', id, { number, type: b.type, assigned_to: row.assigned_to });
  res.status(201).json({ id, number });
});

r.post('/from-ticket/:ticketId', requirePerm('jobs.manage'), validate(z.object({
  type: z.enum(JOB_TYPES).optional(), scheduled_at: isoDate, assigned_to: fk, priority: z.enum(JOB_PRIORITIES).optional(),
})), async (req, res) => {
  const t = await db().get('SELECT * FROM tickets WHERE id = ?', [Number(req.params.ticketId)]);
  if (!t) throw notFound('Ticket not found');
  const open = await db().get(`SELECT id, number FROM jobs WHERE ticket_id = ? AND status IN ('new','scheduled','en_route','on_site')`, [t.id]);
  if (open) throw conflict(`Ticket already has an open job (${open.number})`);
  const type = req.body.type || 'repair';
  const b = await resolveLinks({ customer_id: t.customer_id || null, ticket_id: t.id, assigned_to: req.body.assigned_to ?? null });
  const ts = now();
  const scheduled = req.body.scheduled_at ?? null;
  const row = {
    type, title: String(t.subject).slice(0, 200), customer_id: b.customer_id, lead_id: null, ticket_id: t.id, zone_id: b.zone_id ?? null,
    address: b.address ?? null, lat: b.lat ?? null, lng: b.lng ?? null, scheduled_at: scheduled, duration_min: 60,
    assigned_to: b.assigned_to ?? null, status: scheduled ? 'scheduled' : 'new',
    priority: req.body.priority || (JOB_PRIORITIES.includes(t.priority) ? t.priority : 'normal'),
    notes: `Created from ticket ${t.number}`, checklist: JSON.stringify(defaultChecklist(type)), created_by: req.user.id, created_at: ts, updated_at: ts,
  };
  const { id, number } = await createJob(row);
  await insert('ticket_messages', { ticket_id: t.id, user_id: req.user.id, body: `Field job ${number} created for this ticket.`, internal: 1, created_at: ts });
  const job = { ...row, id, number };
  notifyAssignee(req, job);
  if (scheduled) await notifyCustomer(job, 'scheduled');
  await audit(req, 'jobs.create_from_ticket', 'job', id, { number, ticket: t.number });
  res.status(201).json({ id, number });
});

r.put('/:id', requirePerm('jobs.manage'), validate(jobSchema.partial()), async (req, res) => {
  const job = await loadJob(req, req.params.id);
  const b = await resolveLinks({ ...req.body }, job);
  const patch = { ...b, updated_at: now() };
  if (b.checklist) patch.checklist = JSON.stringify(b.checklist);
  else if (b.type && b.type !== job.type) {
    // Switching type swaps in the new default checklist, unless someone already ticked or customised the old one.
    const current = parseJson(job.checklist, []);
    const untouched = !current.some((i) => i.done) && JSON.stringify(current.map((i) => i.label)) === JSON.stringify(DEFAULT_CHECKLISTS[job.type] || []);
    if (untouched) patch.checklist = JSON.stringify(defaultChecklist(b.type));
  }
  let newStatus = null;
  if (job.status === 'new' && b.scheduled_at) newStatus = 'scheduled';
  if (job.status === 'scheduled' && b.scheduled_at === null) newStatus = 'new';
  if (newStatus) patch.status = newStatus;
  await update('jobs', job.id, patch);
  const fresh = { ...job, ...patch };
  if (b.assigned_to && Number(b.assigned_to) !== Number(job.assigned_to)) notifyAssignee(req, fresh);
  const rescheduled = b.scheduled_at && b.scheduled_at !== job.scheduled_at && fresh.status === 'scheduled';
  if (newStatus === 'scheduled' || rescheduled) await notifyCustomer(fresh, 'scheduled');
  await audit(req, 'jobs.update', 'job', job.id, { fields: Object.keys(req.body) });
  res.json({ ok: true });
});

r.delete('/:id', requirePerm('jobs.manage'), async (req, res) => {
  const job = await loadJob(req, req.params.id);
  await db().run('DELETE FROM jobs WHERE id = ?', [job.id]);
  await audit(req, 'jobs.delete', 'job', job.id, { number: job.number });
  res.json({ ok: true });
});

// ------------------------------------------------------------------ technician actions (assigned technician or manager)
r.post('/:id/status', requirePerm('jobs.manage', 'jobs.work'), validate(z.object({
  status: z.enum(JOB_STATUSES),
  result: z.preprocess(emptyToNull, z.string().trim().max(5000).nullable().optional()),
  scheduled_at: isoDate,
})), async (req, res) => {
  const job = await loadJob(req, req.params.id);
  assertCanWork(req, job);
  const to = req.body.status;
  if (!(TRANSITIONS[job.status] || []).includes(to)) throw badRequest(`Cannot move a job from "${job.status}" to "${to}"`);
  if (!isManager(req.user) && (MANAGER_ONLY.has(to) || MANAGER_ONLY.has(`${job.status}->${to}`))) throw forbidden('Only a jobs manager can do that');
  const ts = now();
  const patch = { status: to, updated_at: ts };
  if (req.body.result) patch.result = req.body.result;
  if (['done', 'failed'].includes(to) && !(patch.result || job.result)) throw badRequest('A result note is required to close the job');
  if (to === 'scheduled') {
    if (req.body.scheduled_at) patch.scheduled_at = req.body.scheduled_at;
    if (!(patch.scheduled_at || job.scheduled_at)) throw badRequest('Set a scheduled time first');
  }
  patch.completed_at = to === 'done' ? ts : (CLOSED.includes(to) ? job.completed_at : null);
  await update('jobs', job.id, patch);
  await notifyCustomer({ ...job, ...patch }, to);
  await audit(req, 'jobs.status', 'job', job.id, { from: job.status, to });
  res.json({ ok: true, status: to, completed_at: patch.completed_at });
});

r.patch('/:id/checklist/:index', requirePerm('jobs.manage', 'jobs.work'), validate(z.object({ done: z.boolean() })), async (req, res) => {
  const job = await loadJob(req, req.params.id);
  assertCanWork(req, job);
  if (['done', 'cancelled'].includes(job.status)) throw badRequest('This job is closed');
  const list = parseJson(job.checklist, []);
  const i = Number(req.params.index);
  if (!Number.isInteger(i) || i < 0 || i >= list.length) throw badRequest('No such checklist item');
  list[i] = { ...list[i], done: req.body.done };
  await update('jobs', job.id, { checklist: JSON.stringify(list), updated_at: now() });
  res.json({ ok: true, checklist: list });
});

r.patch('/:id/result', requirePerm('jobs.manage', 'jobs.work'), validate(z.object({ result: z.string().trim().min(1).max(5000) })), async (req, res) => {
  const job = await loadJob(req, req.params.id);
  assertCanWork(req, job);
  if (job.status === 'cancelled') throw badRequest('This job is cancelled');
  await update('jobs', job.id, { result: req.body.result, updated_at: now() });
  await audit(req, 'jobs.result', 'job', job.id);
  res.json({ ok: true });
});

export default r;
