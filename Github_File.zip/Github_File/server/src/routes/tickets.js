import { Router } from 'express';
import { z } from 'zod';
import { db, insert, now, paginate, ciLike } from '../db/index.js';
import { validate, notFound, forbidden } from '../lib/http.js';
import { authenticate, requireModule, can } from '../middleware/auth.js';
import { queueNotify } from '../lib/notify.js';
import { audit } from '../lib/audit.js';

const r = Router();

/** In-app notification to every staff member holding a permission. */
export async function notifyStaff(perm, { title, body, link }) {
  const staff = await db().all("SELECT u.id, u.type, r.permissions FROM users u LEFT JOIN roles r ON r.id = u.role_id WHERE u.type IN ('admin','staff') AND u.status = 'active'");
  for (const s of staff) {
    const perms = JSON.parse(s.permissions || '[]');
    if (s.type === 'admin' || perms.includes('*') || perms.includes(perm)) {
      queueNotify({ userId: s.id, channels: ['inapp', 'push'], subject: title, body, link });
    }
  }
}

r.use(authenticate, requireModule('support'));

const isStaff = (u) => u.type !== 'customer';

async function loadTicket(req, id) {
  const t = await db().get(`SELECT t.*, u.name AS customer_name, c.code AS customer_code, c.user_id AS customer_user_id, a.name AS assignee_name
    FROM tickets t LEFT JOIN customers c ON c.id = t.customer_id LEFT JOIN users u ON u.id = c.user_id LEFT JOIN users a ON a.id = t.assigned_to WHERE t.id = ?`, [id]);
  if (!t) throw notFound();
  if (req.user.type === 'customer' ? t.customer_id !== req.user.customer_id : !can(req.user, 'tickets.view')) throw notFound();
  return t;
}

r.get('/', async (req, res) => {
  const { status, priority, assigned, q, page, pageSize } = req.query;
  const where = []; const params = [];
  if (req.user.type === 'customer') { where.push('t.customer_id = ?'); params.push(req.user.customer_id); }
  else if (!can(req.user, 'tickets.view')) throw forbidden();
  if (status) { where.push('t.status = ?'); params.push(String(status)); }
  if (priority) { where.push('t.priority = ?'); params.push(String(priority)); }
  if (assigned === 'me') { where.push('t.assigned_to = ?'); params.push(req.user.id); }
  if (assigned === 'none') where.push('t.assigned_to IS NULL');
  if (q) { where.push(`(t.subject ${ciLike()} ? OR t.number ${ciLike()} ? OR u.name ${ciLike()} ?)`); params.push(...Array(3).fill(`%${String(q).slice(0, 60)}%`)); }
  const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const from = `FROM tickets t LEFT JOIN customers c ON c.id = t.customer_id LEFT JOIN users u ON u.id = c.user_id LEFT JOIN users a ON a.id = t.assigned_to ${w}`;
  res.json(await paginate({ base: `SELECT t.*, u.name AS customer_name, c.code AS customer_code, a.name AS assignee_name ${from}`, countBase: `SELECT COUNT(*) AS n ${from}`, params, page, pageSize, defaultSort: 't.updated_at DESC' }));
});

r.post('/', validate(z.object({
  subject: z.string().trim().min(3).max(200), body: z.string().trim().min(3).max(10000),
  category: z.enum(['general', 'billing', 'technical', 'connection', 'speed', 'installation', 'plan', 'other']).optional(),
  priority: z.enum(['low', 'normal', 'high', 'urgent']).optional(),
  customer_id: z.coerce.number().int().positive().optional(),
})), async (req, res) => {
  const customerId = req.user.type === 'customer' ? req.user.customer_id : req.body.customer_id ?? null;
  if (isStaff(req.user) && !can(req.user, 'tickets.manage')) throw forbidden();
  const ts = now();
  const max = await db().get('SELECT MAX(id) AS n FROM tickets');
  const number = `T-${String(Number(max.n || 0) + 1001).padStart(6, '0')}-${Math.random().toString(36).slice(2, 5).toUpperCase()}`;
  const t = await insert('tickets', { number, customer_id: customerId, created_by: req.user.id, subject: req.body.subject, category: req.body.category || 'general', priority: req.body.priority || 'normal', status: 'open', created_at: ts, updated_at: ts });
  await insert('ticket_messages', { ticket_id: t.id, user_id: req.user.id, body: req.body.body, internal: 0, created_at: ts });
  if (req.user.type === 'customer') await notifyStaff('tickets.view', { title: `New ticket ${number}`, body: req.body.subject, link: `/admin/tickets/${t.id}` });
  res.status(201).json({ id: t.id, number });
});

r.get('/:id', async (req, res) => {
  const t = await loadTicket(req, Number(req.params.id));
  const messages = await db().all(`SELECT m.id, m.body, m.internal, m.created_at, m.user_id, u.name, u.type, u.avatar FROM ticket_messages m LEFT JOIN users u ON u.id = m.user_id
    WHERE m.ticket_id = ? ${isStaff(req.user) ? '' : 'AND m.internal = 0'} ORDER BY m.id`, [t.id]);
  res.json({ ticket: t, messages });
});

r.post('/:id/messages', validate(z.object({ body: z.string().trim().min(1).max(10000), internal: z.boolean().optional() })), async (req, res) => {
  const t = await loadTicket(req, Number(req.params.id));
  if (isStaff(req.user) && !can(req.user, 'tickets.manage')) throw forbidden();
  const internal = isStaff(req.user) && !!req.body.internal;
  await insert('ticket_messages', { ticket_id: t.id, user_id: req.user.id, body: req.body.body, internal, created_at: now() });
  const status = isStaff(req.user) ? (internal ? t.status : 'awaiting_customer') : 'open';
  await db().run('UPDATE tickets SET updated_at = ?, status = ? WHERE id = ?', [now(), ['closed', 'resolved'].includes(t.status) && !isStaff(req.user) ? 'open' : status, t.id]);
  if (isStaff(req.user) && !internal && t.customer_user_id) {
    queueNotify({ userId: t.customer_user_id, templateKey: 'ticket_reply', vars: { ticket: t.number, subject: t.subject }, link: `/portal/support/${t.id}` });
  } else if (!isStaff(req.user)) {
    if (t.assigned_to) queueNotify({ userId: t.assigned_to, channels: ['inapp', 'push'], subject: `Reply on ${t.number}`, body: req.body.body.slice(0, 200), link: `/admin/tickets/${t.id}` });
    else await notifyStaff('tickets.view', { title: `Reply on ${t.number}`, body: req.body.body.slice(0, 200), link: `/admin/tickets/${t.id}` });
  }
  res.status(201).json({ ok: true });
});

r.patch('/:id', validate(z.object({
  status: z.enum(['open', 'in_progress', 'awaiting_customer', 'resolved', 'closed']).optional(),
  priority: z.enum(['low', 'normal', 'high', 'urgent']).optional(),
  assigned_to: z.coerce.number().int().positive().nullable().optional(),
  category: z.string().max(40).optional(),
})), async (req, res) => {
  const t = await loadTicket(req, Number(req.params.id));
  if (req.user.type === 'customer') {
    // Customers may only close/resolve their own ticket.
    if (Object.keys(req.body).some((k) => k !== 'status') || !['closed', 'resolved'].includes(req.body.status)) throw forbidden();
  } else if (!can(req.user, 'tickets.manage')) throw forbidden();
  if (req.body.assigned_to) {
    const staff = await db().get("SELECT id FROM users WHERE id = ? AND type IN ('admin','staff')", [req.body.assigned_to]);
    if (!staff) throw notFound('Assignee not found');
  }
  const patch = { ...req.body, updated_at: now() };
  if (['closed', 'resolved'].includes(req.body.status)) patch.closed_at = now();
  const keys = Object.keys(patch);
  await db().run(`UPDATE tickets SET ${keys.map((k) => `${k} = ?`).join(', ')} WHERE id = ?`, [...keys.map((k) => patch[k]), t.id]);
  if (req.body.assigned_to && req.body.assigned_to !== req.user.id) {
    queueNotify({ userId: req.body.assigned_to, channels: ['inapp', 'push'], subject: `Ticket ${t.number} assigned to you`, body: t.subject, link: `/admin/tickets/${t.id}` });
  }
  await audit(req, 'ticket.update', 'ticket', t.id, req.body);
  res.json({ ok: true });
});

export default r;
