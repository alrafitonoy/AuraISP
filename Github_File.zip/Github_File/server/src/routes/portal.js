// Customer self-service: overview, live bandwidth, usage, plan upgrade, parental controls, devices, remote-support consent.
import { Router } from 'express';
import { z } from 'zod';
import { db, insert, now, parseJson, update } from '../db/index.js';
import { validate, notFound, badRequest, forbidden } from '../lib/http.js';
import { authenticate, requireCustomer, requireModule } from '../middleware/auth.js';
import { getSetting } from '../lib/settings.js';
import { live, customerWithPlan, effectiveBandwidth, syncCustomer } from '../network/service.js';
import { CATEGORY_DOMAINS } from '../network/drivers.js';
import { prorationQuote, createInvoice, applyPlanChange, addCycle } from '../billing/service.js';
import { presentPlan } from './plans.js';
import { downsample } from './customers.js';
import { audit } from '../lib/audit.js';
import { notifyStaff } from './tickets.js';

const r = Router();
r.use(authenticate, requireCustomer);

// Block money-moving actions until the account is verified (if the admin requires it).
async function requireVerified(req, _res, next) {
  const sec = await getSetting('security');
  if (sec.requireEmailVerification && !req.user.email_verified_at) throw forbidden('Please verify your email address first');
  if (sec.requirePhoneVerification && !req.user.phone_verified_at) throw forbidden('Please verify your phone number first');
  next();
}

r.get('/overview', async (req, res) => {
  const c = await customerWithPlan(req.user.customer_id);
  const [due, lastPayment, openTickets, month] = await Promise.all([
    db().get("SELECT COALESCE(SUM(total_cents - paid_cents),0) AS v, MIN(due_date) AS next FROM invoices WHERE customer_id = ? AND status IN ('unpaid','partial','overdue')", [c.id]),
    db().get("SELECT amount_cents, completed_at, method FROM payments WHERE customer_id = ? AND status = 'success' ORDER BY id DESC LIMIT 1", [c.id]),
    db().get("SELECT COUNT(*) AS n FROM tickets WHERE customer_id = ? AND status NOT IN ('closed','resolved')", [c.id]),
    db().get('SELECT COALESCE(SUM(bytes),0) AS v FROM traffic_daily WHERE customer_id = ? AND category = ? AND day >= ?', [c.id, 'total', new Date().toISOString().slice(0, 8) + '01']),
  ]);
  res.json({
    customer: {
      id: c.id, code: c.code, status: c.status, plan_id: c.plan_id, plan_name: c.plan_name, address: c.address, area: c.area,
      next_due_date: c.next_due_date, balance_cents: c.balance_cents, connection_type: c.connection_type, ip_address: c.ip_address,
      data_cap_mb: c.data_cap_mb, cap_exceeded: !!c.cap_exceeded, suspended_reason: c.suspended_reason, bandwidth: effectiveBandwidth(c),
    },
    live: live.perCustomer.get(c.id) || null,
    dueCents: Number(due.v), nextDueDate: due.next, lastPayment, openTickets: Number(openTickets.n), monthUsageBytes: Number(month.v),
  });
});

r.get('/usage', requireModule('bandwidth'), async (req, res) => {
  const hours = Math.min(24 * 31, Math.max(1, Number(req.query.hours) || 24));
  const since = new Date(Date.now() - hours * 3600000).toISOString();
  const samples = await db().all('SELECT ts, rx_bps, tx_bps FROM usage_samples WHERE customer_id = ? AND ts >= ? ORDER BY ts', [req.user.customer_id, since]);
  const daily = await db().all('SELECT day, category, bytes FROM traffic_daily WHERE customer_id = ? AND day >= ? ORDER BY day', [req.user.customer_id, new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10)]);
  res.json({ samples: downsample(samples, 240), daily, live: live.perCustomer.get(req.user.customer_id) || null });
});

// ------------------------------------------------------------------ plans
r.get('/plans', requireModule('plan_sales'), async (req, res) => {
  const c = await db().get('SELECT * FROM customers WHERE id = ?', [req.user.customer_id]);
  const current = c.plan_id ? await db().get('SELECT * FROM plans WHERE id = ?', [c.plan_id]) : null;
  const plans = await db().all('SELECT * FROM plans WHERE active = 1 AND is_public = 1 ORDER BY sort, price_cents');
  const out = [];
  for (const p of plans) out.push({ ...presentPlan(p), quote: p.id === c.plan_id ? null : await prorationQuote(c, current, p) });
  const pending = await db().get("SELECT * FROM plan_changes WHERE customer_id = ? AND status IN ('pending','awaiting_payment') ORDER BY id DESC LIMIT 1", [c.id]);
  res.json({ currentPlanId: c.plan_id, plans: out, pending });
});

r.post('/plans/change', requireModule('plan_sales'), requireVerified, validate(z.object({ planId: z.coerce.number().int().positive() })), async (req, res) => {
  const c = await db().get('SELECT * FROM customers WHERE id = ?', [req.user.customer_id]);
  if (c.status === 'terminated') throw forbidden('Account terminated');
  const to = await db().get('SELECT * FROM plans WHERE id = ? AND active = 1 AND is_public = 1', [req.body.planId]);
  if (!to) throw notFound('Plan not available');
  if (to.id === c.plan_id) throw badRequest('You are already on this plan');
  const from = c.plan_id ? await db().get('SELECT * FROM plans WHERE id = ?', [c.plan_id]) : null;
  // Cancel stale pending requests, and void their still-unpaid quote invoices — an abandoned upgrade is not a debt
  // (left alone it would turn overdue and count towards automatic suspension).
  await db().run(`UPDATE invoices SET status = 'void' WHERE paid_cents = 0 AND status IN ('unpaid','overdue') AND id IN
    (SELECT invoice_id FROM plan_changes WHERE customer_id = ? AND status = 'awaiting_payment' AND invoice_id IS NOT NULL)`, [c.id]);
  await db().run("UPDATE plan_changes SET status = 'cancelled' WHERE customer_id = ? AND status IN ('pending','awaiting_payment')", [c.id]);
  const kind = !from ? 'new' : to.price_cents > from.price_cents ? 'upgrade' : 'downgrade';
  const quote = await prorationQuote(c, from, to);
  const ch = await insert('plan_changes', { customer_id: c.id, from_plan_id: from?.id ?? null, to_plan_id: to.id, kind, prorated_cents: quote.chargeCents, status: 'pending', requested_by: req.user.id, created_at: now() });
  let invoice = null;
  if (quote.chargeCents > 0) {
    const items = [{ description: from ? `Upgrade ${from.name} → ${to.name} (prorated ${Math.round(quote.ratio * 100)}% of cycle, credit applied)` : `${to.name} — first ${to.billing_cycle} period`, quantity: 1, unit_cents: quote.chargeCents }];
    if (!from && Number(to.setup_fee_cents)) items.push({ description: 'Installation / setup fee', quantity: 1, unit_cents: to.setup_fee_cents });
    invoice = await createInvoice({
      customerId: c.id, items, dueDate: now(),
      ...(from ? {} : { periodStart: now(), periodEnd: addCycle(new Date(), to.billing_cycle).toISOString() }),
    });
    await db().run("UPDATE plan_changes SET status = 'awaiting_payment', invoice_id = ? WHERE id = ?", [invoice.id, ch.id]);
  } else {
    // Downgrades apply immediately (no refund; credit could be added to balance by policy).
    await applyPlanChange(ch.id);
  }
  await audit(req, 'portal.plan_change', 'customer', c.id, { from: from?.id, to: to.id, kind });
  await notifyStaff('crm.view', { title: `Plan ${kind}: ${req.user.name}`, body: `${from?.name || 'No plan'} → ${to.name}`, link: `/admin/customers/${c.id}` });
  res.json({ kind, quote, invoice, applied: !invoice });
});

// ------------------------------------------------------------------ parental controls
const timeRe = /^([01]\d|2[0-3]):[0-5]\d$/;
export const parentalSchema = z.object({
  enabled: z.boolean(),
  safeSearch: z.boolean().optional(),
  blockedCategories: z.array(z.enum(Object.keys(CATEGORY_DOMAINS))).max(10).optional(),
  blockedDomains: z.array(z.string().trim().toLowerCase().max(253).regex(/^(?!-)[a-z0-9-]{1,63}(\.[a-z0-9-]{1,63})+$/, 'Invalid domain')).max(100).optional(),
  schedules: z.array(z.object({
    label: z.string().max(40).optional(),
    from: z.string().regex(timeRe), to: z.string().regex(timeRe),
    days: z.array(z.enum(['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'])).min(1),
  })).max(10).optional(),
});

r.get('/parental', requireModule('parental'), async (req, res) => {
  const c = await db().get('SELECT parental FROM customers WHERE id = ?', [req.user.customer_id]);
  res.json({ parental: parseJson(c.parental, { enabled: false, safeSearch: false, blockedCategories: [], blockedDomains: [], schedules: [] }), categories: Object.keys(CATEGORY_DOMAINS) });
});

r.put('/parental', requireModule('parental'), validate(parentalSchema), async (req, res) => {
  await update('customers', req.user.customer_id, { parental: JSON.stringify(toStoredParental(req.body)), updated_at: now() });
  const sync = await syncCustomer(req.user.customer_id);
  await audit(req, 'portal.parental', 'customer', req.user.customer_id);
  res.json({ ok: true, sync });
});
const toRos = (hhmm) => { const [h, m] = hhmm.split(':'); return `${Number(h)}h${Number(m)}m`; };
/** Store HH:MM labels for the UI plus RouterOS "22h30m" values for the router driver. */
export const toStoredParental = (p) => ({ ...p, schedules: (p.schedules || []).map((s) => ({ ...s, from: toRos(s.from), to: toRos(s.to), fromLabel: s.from, toLabel: s.to })) });

// ------------------------------------------------------------------ devices & remote support consent
r.get('/devices', requireModule('device_testing'), async (req, res) => {
  const devices = await db().all('SELECT * FROM devices WHERE customer_id = ? ORDER BY id DESC', [req.user.customer_id]);
  const tests = await db().all('SELECT * FROM device_tests WHERE customer_id = ? ORDER BY id DESC LIMIT 20', [req.user.customer_id]);
  res.json({ devices: devices.map((d) => ({ ...d, last_test: parseJson(d.last_test, null) })), tests: tests.map((t) => ({ ...t, result: parseJson(t.result, null) })) });
});

r.post('/speedtest-result', requireModule('device_testing'), validate(z.object({ downMbps: z.number().min(0).max(100000), upMbps: z.number().min(0).max(100000), pingMs: z.number().min(0).max(100000) })), async (req, res) => {
  await insert('device_tests', { customer_id: req.user.customer_id, test: 'speedtest', target: 'browser', result: JSON.stringify(req.body), ok: 1, run_by: req.user.id, created_at: now() });
  res.json({ ok: true });
});

r.get('/remote-sessions', requireModule('remote_support'), async (req, res) => {
  const rows = await db().all(`SELECT rs.*, u.name AS staff_name FROM remote_sessions rs LEFT JOIN users u ON u.id = rs.staff_id WHERE rs.customer_id = ? ORDER BY rs.id DESC LIMIT 20`, [req.user.customer_id]);
  res.json({ sessions: rows.map((s) => ({ ...s, actions: parseJson(s.actions, []) })) });
});

r.post('/remote-sessions/:id/:decision', requireModule('remote_support'), async (req, res) => {
  const s = await db().get('SELECT * FROM remote_sessions WHERE id = ? AND customer_id = ?', [Number(req.params.id), req.user.customer_id]);
  if (!s) throw notFound();
  if (s.status !== 'requested') throw badRequest('This request is no longer pending');
  const approve = req.params.decision === 'approve';
  if (!approve && req.params.decision !== 'deny') throw notFound();
  await db().run('UPDATE remote_sessions SET status = ?, consent_at = ? WHERE id = ?', [approve ? 'active' : 'denied', approve ? now() : null, s.id]);
  await audit(req, `remote.${approve ? 'approved' : 'denied'}`, 'remote_session', s.id);
  res.json({ ok: true });
});

export default r;
