// Expenses & profit and loss: expense categories, expenses (with private receipt attachments) and P&L reports.
// Income = completed customer payments (status 'success'), excluding 'balance' payments — those apply prepaid credit
// that was already counted as income when it was paid in, so counting them again would double the revenue.
import fs from 'node:fs';
import path from 'node:path';
import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import config from '../config.js';
import { db, insert, update, now, paginate, ciLike } from '../db/index.js';
import { validate, notFound, badRequest, conflict, HttpError } from '../lib/http.js';
import { authenticate, requirePerm, requireModule } from '../middleware/auth.js';
import { audit } from '../lib/audit.js';
import { randomToken } from '../lib/crypto.js';
import { toCsv } from '../lib/csv.js';

const r = Router();
r.use(authenticate, requireModule('finance'));

export const DEFAULT_CATEGORIES = ['Bandwidth / IIG', 'Staff salary', 'Office rent', 'Electricity', 'Fuel & generator', 'Equipment purchase',
  'Fiber & cable', 'Transport', 'Marketing', 'BTRC & licence fees', 'Maintenance', 'Other'];
export const METHODS = ['cash', 'bank', 'bkash', 'nagad', 'card', 'other'];

const RECEIPT_DIR = () => path.join(config.dataDir, 'private', 'receipts');
const RECEIPT_MAX = 5 * 1024 * 1024;
const RECEIPT_TYPES = [
  { ext: 'pdf', mime: 'application/pdf', test: (b) => b.subarray(0, 5).toString('latin1') === '%PDF-' },
  { ext: 'png', mime: 'image/png', test: (b) => b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) },
  { ext: 'jpg', mime: 'image/jpeg', test: (b) => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  { ext: 'webp', mime: 'image/webp', test: (b) => b.subarray(0, 4).toString('latin1') === 'RIFF' && b.subarray(8, 12).toString('latin1') === 'WEBP' },
];
const ALLOWED_MIME = new Set(RECEIPT_TYPES.map((t) => t.mime));
const RECEIPT_NAME = /^[A-Za-z0-9]{16,64}\.(pdf|png|jpg|webp)$/;

const receiptUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: RECEIPT_MAX, files: 1, fields: 5 },
  fileFilter: (_req, file, cb) => (ALLOWED_MIME.has(file.mimetype) ? cb(null, true) : cb(badRequest('Receipts must be a PDF, PNG, JPG or WEBP file'))),
});
const uploadReceipt = (req, res, next) => receiptUpload.single('file')(req, res, (err) => {
  if (!err) return next();
  if (err instanceof HttpError) return next(err);
  if (err.code === 'LIMIT_FILE_SIZE') return next(new HttpError(413, 'Receipts must be 5 MB or smaller'));
  return next(badRequest(err.message || 'Upload failed'));
});

const removeReceiptFile = (name) => {
  if (name && RECEIPT_NAME.test(name)) fs.rmSync(path.join(RECEIPT_DIR(), name), { force: true });
};

// ------------------------------------------------------------------ helpers
const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use YYYY-MM-DD')
  .refine((s) => { const d = new Date(`${s}T00:00:00.000Z`); return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s; }, 'Invalid date');
const pid = (req) => { const n = Number(req.params.id); if (!Number.isInteger(n) || n <= 0) throw notFound(); return n; };
const optId = z.preprocess((v) => (v === '' ? null : v), z.coerce.number().int().positive().optional().nullable());
const optText = (max) => z.preprocess((v) => (typeof v === 'string' && v.trim() === '' ? null : v), z.string().trim().max(max).optional().nullable());

const monthKey = (d) => d.toISOString().slice(0, 7);
const today = () => new Date().toISOString().slice(0, 10);
const startOfDay = (d) => `${d}T00:00:00.000Z`;
const endOfDay = (d) => `${d}T23:59:59.999Z`;
/** Months 'YYYY-MM' from `from` to `to` inclusive. */
function monthsBetween(from, to) {
  const out = []; const d = new Date(`${from.slice(0, 7)}-01T00:00:00.000Z`); const end = to.slice(0, 7);
  while (monthKey(d) <= end && out.length < 600) { out.push(monthKey(d)); d.setUTCMonth(d.getUTCMonth() + 1); }
  return out;
}
const margin = (income, profit) => (income > 0 ? Math.round((profit / income) * 1000) / 10 : null);

async function assertRef(table, id, what) {
  if (id == null) return;
  if (!(await db().get(`SELECT id FROM ${table === 'zones' ? 'zones' : 'expense_categories'} WHERE id = ?`, [id]))) throw badRequest(`Unknown ${what}`);
}

async function ensureDefaultCategories() {
  const n = Number((await db().get('SELECT COUNT(*) AS n FROM expense_categories'))?.n || 0);
  if (n > 0) return;
  await db().transaction(async (t) => {
    // Re-check inside the transaction so two first requests cannot both seed.
    if (Number((await t.get('SELECT COUNT(*) AS n FROM expense_categories'))?.n || 0) > 0) return;
    for (const name of DEFAULT_CATEGORIES) await insert('expense_categories', { name, created_at: now() }, t);
  });
}

// ------------------------------------------------------------------ categories
const categorySchema = z.object({ name: z.string().trim().min(2).max(80) });

r.get('/categories', requirePerm('finance.view', 'finance.manage'), async (_req, res) => {
  await ensureDefaultCategories();
  const rows = await db().all(`SELECT c.id, c.name, c.created_at, COUNT(e.id) AS expense_count, COALESCE(SUM(e.amount_cents), 0) AS total_cents
    FROM expense_categories c LEFT JOIN expenses e ON e.category_id = c.id GROUP BY c.id, c.name, c.created_at ORDER BY c.name`);
  res.json({ categories: rows.map((c) => ({ ...c, expense_count: Number(c.expense_count), total_cents: Number(c.total_cents) })) });
});

async function assertUniqueCategory(name, exceptId = null) {
  const dup = await db().get('SELECT id FROM expense_categories WHERE LOWER(name) = LOWER(?) AND id != ?', [name, exceptId ?? 0]);
  if (dup) throw conflict('A category with that name already exists');
}

r.post('/categories', requirePerm('finance.manage'), validate(categorySchema), async (req, res) => {
  await assertUniqueCategory(req.body.name);
  const out = await insert('expense_categories', { name: req.body.name, created_at: now() });
  await audit(req, 'finance.category_create', 'expense_category', out.id, { name: req.body.name });
  res.status(201).json({ id: out.id });
});

r.put('/categories/:id', requirePerm('finance.manage'), validate(categorySchema), async (req, res) => {
  const cat = await db().get('SELECT * FROM expense_categories WHERE id = ?', [pid(req)]);
  if (!cat) throw notFound('Category not found');
  await assertUniqueCategory(req.body.name, cat.id);
  await update('expense_categories', cat.id, { name: req.body.name });
  await audit(req, 'finance.category_update', 'expense_category', cat.id, { from: cat.name, to: req.body.name });
  res.json({ ok: true });
});

r.delete('/categories/:id', requirePerm('finance.manage'), async (req, res) => {
  const cat = await db().get('SELECT * FROM expense_categories WHERE id = ?', [pid(req)]);
  if (!cat) throw notFound('Category not found');
  // Explicit SET NULL: MySQL ignores inline REFERENCES, so do not rely on ON DELETE.
  const moved = await db().transaction(async (t) => {
    const u = await t.run('UPDATE expenses SET category_id = NULL WHERE category_id = ?', [cat.id]);
    await t.run('DELETE FROM expense_categories WHERE id = ?', [cat.id]);
    return u.changes;
  });
  await audit(req, 'finance.category_delete', 'expense_category', cat.id, { name: cat.name, uncategorised: moved });
  res.json({ ok: true, uncategorised: moved });
});

// ------------------------------------------------------------------ expenses
const expenseSchema = z.object({
  amount_cents: z.coerce.number().int().positive().max(1e13),
  spent_on: isoDate,
  category_id: optId,
  zone_id: optId,
  vendor: optText(190),
  method: z.enum(METHODS).optional().nullable(),
  reference: optText(64),
  notes: optText(250),
});

const listQuery = z.object({
  from: isoDate.optional().or(z.literal('')), to: isoDate.optional().or(z.literal('')),
  category_id: z.union([z.literal('none'), z.coerce.number().int().positive()]).optional().or(z.literal('')),
  zone_id: z.union([z.literal('none'), z.coerce.number().int().positive()]).optional().or(z.literal('')),
  method: z.enum(METHODS).optional().or(z.literal('')),
  q: z.string().max(80).optional(),
  page: z.coerce.number().int().positive().optional(), pageSize: z.coerce.number().int().positive().max(200).optional(),
  sort: z.string().max(40).optional(),
});

function expenseFilter(q) {
  const where = []; const params = [];
  if (q.from) { where.push('e.spent_on >= ?'); params.push(q.from); }
  if (q.to) { where.push('e.spent_on <= ?'); params.push(q.to); }
  if (q.from && q.to && q.from > q.to) throw badRequest('"from" must be on or before "to"');
  if (q.category_id === 'none') where.push('e.category_id IS NULL');
  else if (q.category_id) { where.push('e.category_id = ?'); params.push(q.category_id); }
  if (q.zone_id === 'none') where.push('e.zone_id IS NULL');
  else if (q.zone_id) { where.push('e.zone_id = ?'); params.push(q.zone_id); }
  if (q.method) { where.push('e.method = ?'); params.push(q.method); }
  if (q.q) {
    const like = `%${q.q.trim()}%`;
    where.push(`(e.vendor ${ciLike()} ? OR e.reference ${ciLike()} ? OR e.notes ${ciLike()} ?)`); params.push(like, like, like);
  }
  return { w: where.length ? `WHERE ${where.join(' AND ')}` : '', params };
}

const presentExpense = (e) => {
  if (!e) return e;
  const { attachment, ...rest } = e;
  return { ...rest, amount_cents: Number(e.amount_cents), has_receipt: !!attachment };
};

r.get('/expenses', requirePerm('finance.view', 'finance.manage'), validate(listQuery, 'query'), async (req, res) => {
  const { w, params } = expenseFilter(req.query);
  const from = `FROM expenses e LEFT JOIN expense_categories c ON c.id = e.category_id LEFT JOIN zones z ON z.id = e.zone_id
    LEFT JOIN users u ON u.id = e.created_by ${w}`;
  const out = await paginate({
    base: `SELECT e.*, c.name AS category_name, z.name AS zone_name, u.name AS created_by_name ${from}`,
    countBase: `SELECT COUNT(*) AS n ${from}`, params, page: req.query.page, pageSize: req.query.pageSize || 25, sort: req.query.sort,
    sortable: { spent_on: 'e.spent_on', amount_cents: 'e.amount_cents', vendor: 'e.vendor', created_at: 'e.created_at' },
    defaultSort: 'e.spent_on DESC, e.id DESC',
  });
  const totals = await db().get(`SELECT COUNT(*) AS n, COALESCE(SUM(e.amount_cents), 0) AS v FROM expenses e ${w}`, params);
  res.json({ ...out, rows: out.rows.map(presentExpense), totals: { count: Number(totals.n), amount_cents: Number(totals.v) } });
});

r.get('/expenses/:id', requirePerm('finance.view', 'finance.manage'), async (req, res) => {
  const e = await db().get(`SELECT e.*, c.name AS category_name, z.name AS zone_name FROM expenses e
    LEFT JOIN expense_categories c ON c.id = e.category_id LEFT JOIN zones z ON z.id = e.zone_id WHERE e.id = ?`, [pid(req)]);
  if (!e) throw notFound('Expense not found');
  res.json({ expense: presentExpense(e) });
});

r.post('/expenses', requirePerm('finance.manage'), validate(expenseSchema), async (req, res) => {
  await assertRef('expense_categories', req.body.category_id, 'category');
  await assertRef('zones', req.body.zone_id, 'zone');
  const out = await insert('expenses', { ...req.body, created_by: req.user.id, created_at: now() });
  await audit(req, 'finance.expense_create', 'expense', out.id, { amount_cents: req.body.amount_cents, spent_on: req.body.spent_on });
  res.status(201).json({ id: out.id });
});

r.put('/expenses/:id', requirePerm('finance.manage'), validate(expenseSchema.partial()), async (req, res) => {
  const e = await db().get('SELECT * FROM expenses WHERE id = ?', [pid(req)]);
  if (!e) throw notFound('Expense not found');
  await assertRef('expense_categories', req.body.category_id, 'category');
  await assertRef('zones', req.body.zone_id, 'zone');
  await update('expenses', e.id, req.body);
  await audit(req, 'finance.expense_update', 'expense', e.id, { fields: Object.keys(req.body) });
  res.json({ ok: true });
});

r.delete('/expenses/:id', requirePerm('finance.manage'), async (req, res) => {
  const e = await db().get('SELECT * FROM expenses WHERE id = ?', [pid(req)]);
  if (!e) throw notFound('Expense not found');
  await db().run('DELETE FROM expenses WHERE id = ?', [e.id]);
  removeReceiptFile(e.attachment);
  await audit(req, 'finance.expense_delete', 'expense', e.id, { amount_cents: Number(e.amount_cents), spent_on: e.spent_on, vendor: e.vendor });
  res.json({ ok: true });
});

// ------------------------------------------------------------------ receipts (private files)
r.post('/expenses/:id/receipt', requirePerm('finance.manage'), uploadReceipt, async (req, res) => {
  const e = await db().get('SELECT * FROM expenses WHERE id = ?', [pid(req)]);
  if (!e) throw notFound('Expense not found');
  if (!req.file) throw badRequest('Choose a receipt file');
  // Trust the bytes, not the declared type.
  const type = RECEIPT_TYPES.find((t) => t.test(req.file.buffer));
  if (!type) throw badRequest('Receipts must be a PDF, PNG, JPG or WEBP file');
  fs.mkdirSync(RECEIPT_DIR(), { recursive: true });
  const name = `${randomToken(18).replace(/[^A-Za-z0-9]/g, '').padEnd(16, '0')}.${type.ext}`;
  fs.writeFileSync(path.join(RECEIPT_DIR(), name), req.file.buffer, { mode: 0o600 });
  await update('expenses', e.id, { attachment: name });
  removeReceiptFile(e.attachment);
  await audit(req, 'finance.receipt_upload', 'expense', e.id, { type: type.ext, size: req.file.size });
  res.status(201).json({ ok: true, has_receipt: true });
});

r.get('/expenses/:id/receipt', requirePerm('finance.view', 'finance.manage'), async (req, res) => {
  const e = await db().get('SELECT id, attachment FROM expenses WHERE id = ?', [pid(req)]);
  if (!e?.attachment || !RECEIPT_NAME.test(e.attachment)) throw notFound('No receipt attached');
  const file = path.join(RECEIPT_DIR(), e.attachment);
  if (!fs.existsSync(file)) throw notFound('Receipt file is missing');
  const type = RECEIPT_TYPES.find((t) => e.attachment.endsWith(`.${t.ext}`));
  res.set({
    'Content-Type': type.mime,
    'Content-Disposition': `attachment; filename="receipt-${e.id}.${type.ext}"`,
    'X-Content-Type-Options': 'nosniff',
    'Cache-Control': 'private, no-store',
  });
  fs.createReadStream(file).on('error', () => res.destroy()).pipe(res);
});

r.delete('/expenses/:id/receipt', requirePerm('finance.manage'), async (req, res) => {
  const e = await db().get('SELECT id, attachment FROM expenses WHERE id = ?', [pid(req)]);
  if (!e) throw notFound('Expense not found');
  if (e.attachment) {
    await db().run('UPDATE expenses SET attachment = NULL WHERE id = ?', [e.id]);
    removeReceiptFile(e.attachment);
    await audit(req, 'finance.receipt_delete', 'expense', e.id);
  }
  res.json({ ok: true });
});

// ------------------------------------------------------------------ profit & loss
const pnlQuery = z.object({
  from: isoDate.optional().or(z.literal('')), to: isoDate.optional().or(z.literal('')),
  group: z.enum(['month', 'zone']).optional().or(z.literal('')),
});

function pnlRange(q) {
  const to = q.to || today();
  let from = q.from;
  if (!from) { const d = new Date(`${to.slice(0, 7)}-01T00:00:00.000Z`); d.setUTCMonth(d.getUTCMonth() - 11); from = d.toISOString().slice(0, 10); }
  if (from > to) throw badRequest('"from" must be on or before "to"');
  if (monthsBetween(from, to).length > 120) throw badRequest('The range can be at most 10 years');
  return { from, to };
}

const INCOME_WHERE = "p.status = 'success' AND p.method != 'balance' AND p.completed_at >= ? AND p.completed_at <= ?";

/** KPIs for the current calendar month (UTC) plus the previous month for comparison. */
export async function financeKpis() {
  const start = new Date(); start.setUTCDate(1); start.setUTCHours(0, 0, 0, 0);
  const prev = new Date(start); prev.setUTCMonth(prev.getUTCMonth() - 1);
  const m = monthKey(start); const pm = monthKey(prev);
  const [inc, pinc, exp, pexp, active] = await Promise.all([
    db().get(`SELECT COALESCE(SUM(p.amount_cents), 0) AS v FROM payments p WHERE ${INCOME_WHERE}`, [start.toISOString(), endOfDay(today())]),
    db().get(`SELECT COALESCE(SUM(p.amount_cents), 0) AS v FROM payments p WHERE p.status = 'success' AND p.method != 'balance' AND p.completed_at >= ? AND p.completed_at < ?`, [prev.toISOString(), start.toISOString()]),
    db().get('SELECT COALESCE(SUM(amount_cents), 0) AS v FROM expenses WHERE spent_on >= ? AND spent_on <= ?', [`${m}-01`, `${m}-31`]),
    db().get('SELECT COALESCE(SUM(amount_cents), 0) AS v FROM expenses WHERE spent_on >= ? AND spent_on <= ?', [`${pm}-01`, `${pm}-31`]),
    db().get("SELECT COUNT(*) AS n FROM customers WHERE status = 'active'"),
  ]);
  const income = Number(inc.v); const expense = Number(exp.v); const activeCustomers = Number(active.n);
  const prevIncome = Number(pinc.v); const prevExpense = Number(pexp.v);
  return {
    month: m, income_cents: income, expense_cents: expense, profit_cents: income - expense, margin: margin(income, income - expense),
    active_customers: activeCustomers, arpu_cents: activeCustomers ? Math.round(income / activeCustomers) : 0,
    previous: { month: pm, income_cents: prevIncome, expense_cents: prevExpense, profit_cents: prevIncome - prevExpense },
  };
}

export async function buildPnl({ from, to, group = 'month' }) {
  const fromTs = startOfDay(from); const toTs = endOfDay(to);
  let periods;
  if (group === 'zone') {
    const [inc, exp, zones] = await Promise.all([
      db().all(`SELECT c.zone_id AS k, COALESCE(SUM(p.amount_cents), 0) AS v FROM payments p LEFT JOIN customers c ON c.id = p.customer_id
        WHERE ${INCOME_WHERE} GROUP BY c.zone_id`, [fromTs, toTs]),
      db().all('SELECT zone_id AS k, COALESCE(SUM(amount_cents), 0) AS v FROM expenses WHERE spent_on >= ? AND spent_on <= ? GROUP BY zone_id', [from, to]),
      db().all('SELECT id, name FROM zones ORDER BY name'),
    ]);
    const val = (rows, k) => Number(rows.find((x) => (x.k == null ? null : Number(x.k)) === k)?.v || 0);
    periods = [...zones.map((z) => ({ key: String(z.id), zone_id: z.id, label: z.name })), { key: 'none', zone_id: null, label: 'Unassigned' }]
      .map((p) => ({ ...p, income_cents: val(inc, p.zone_id), expense_cents: val(exp, p.zone_id) }));
  } else {
    const [inc, exp] = await Promise.all([
      db().all(`SELECT SUBSTR(p.completed_at, 1, 7) AS k, COALESCE(SUM(p.amount_cents), 0) AS v FROM payments p WHERE ${INCOME_WHERE}
        GROUP BY SUBSTR(p.completed_at, 1, 7)`, [fromTs, toTs]),
      db().all('SELECT SUBSTR(spent_on, 1, 7) AS k, COALESCE(SUM(amount_cents), 0) AS v FROM expenses WHERE spent_on >= ? AND spent_on <= ? GROUP BY SUBSTR(spent_on, 1, 7)', [from, to]),
    ]);
    const val = (rows, k) => Number(rows.find((x) => x.k === k)?.v || 0);
    periods = monthsBetween(from, to).map((m) => ({ key: m, label: m, income_cents: val(inc, m), expense_cents: val(exp, m) }));
  }
  periods = periods.map((p) => ({ ...p, profit_cents: p.income_cents - p.expense_cents, margin: margin(p.income_cents, p.income_cents - p.expense_cents) }));
  const income = periods.reduce((s, p) => s + p.income_cents, 0);
  const expense = periods.reduce((s, p) => s + p.expense_cents, 0);
  const byCategory = (await db().all(`SELECT e.category_id, c.name, COALESCE(SUM(e.amount_cents), 0) AS v, COUNT(*) AS n FROM expenses e
    LEFT JOIN expense_categories c ON c.id = e.category_id WHERE e.spent_on >= ? AND e.spent_on <= ? GROUP BY e.category_id, c.name`, [from, to]))
    .map((c) => ({ category_id: c.category_id ?? null, name: c.name || 'Uncategorised', amount_cents: Number(c.v), count: Number(c.n), share: expense ? Math.round((Number(c.v) / expense) * 1000) / 10 : 0 }))
    .sort((a, b) => b.amount_cents - a.amount_cents);
  return {
    from, to, group, periods, by_category: byCategory,
    totals: { income_cents: income, expense_cents: expense, profit_cents: income - expense, margin: margin(income, income - expense) },
  };
}

r.get('/pnl', requirePerm('finance.view', 'finance.manage'), validate(pnlQuery, 'query'), async (req, res) => {
  const range = pnlRange(req.query);
  const [pnl, kpis] = await Promise.all([buildPnl({ ...range, group: req.query.group || 'month' }), financeKpis()]);
  res.json({ ...pnl, kpis });
});

r.get('/kpis', requirePerm('finance.view', 'finance.manage'), async (_req, res) => {
  res.json(await financeKpis());
});

r.get('/pnl.csv', requirePerm('finance.view', 'finance.manage'), validate(pnlQuery, 'query'), async (req, res) => {
  const range = pnlRange(req.query);
  const pnl = await buildPnl({ ...range, group: req.query.group || 'month' });
  // Amounts are plain decimals; negatives are written as "(123.45)" so the CSV formula guard never mangles them.
  const amt = (c) => { const s = (Math.abs(c) / 100).toFixed(2); return c < 0 ? `(${s})` : s; };
  const rows = pnl.periods.map((p) => [p.label, amt(p.income_cents), amt(p.expense_cents), amt(p.profit_cents), p.margin == null ? '' : `${p.margin}%`]);
  rows.push(['Total', amt(pnl.totals.income_cents), amt(pnl.totals.expense_cents), amt(pnl.totals.profit_cents), pnl.totals.margin == null ? '' : `${pnl.totals.margin}%`]);
  rows.push([]);
  rows.push(['Expense category', 'Amount', 'Share', 'Entries', '']);
  for (const c of pnl.by_category) rows.push([c.name, amt(c.amount_cents), `${c.share}%`, String(c.count), '']);
  await audit(req, 'finance.pnl_export', 'report', null, { ...range, group: pnl.group });
  res.set('Content-Type', 'text/csv; charset=utf-8')
    .set('Content-Disposition', `attachment; filename="profit-loss-${range.from}-to-${range.to}.csv"`)
    .set('X-Content-Type-Options', 'nosniff')
    .send(toCsv([pnl.group === 'zone' ? 'Zone' : 'Month', 'Income', 'Expenses', 'Profit', 'Margin'], rows));
});

export default r;
