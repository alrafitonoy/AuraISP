import { Router } from 'express';
import { z } from 'zod';
import { db, insert, update, now, paginate, parseJson, ciLike, cascadeDelete } from '../db/index.js';
import { validate, notFound, badRequest, HttpError } from '../lib/http.js';
import { authenticate, requirePerm, requireModule } from '../middleware/auth.js';
import { audit } from '../lib/audit.js';
import { hashPassword, randomToken } from '../lib/crypto.js';
import { createPool, assignIp, releaseIp, reconcileAssignments, IP_KINDS } from '../network/ipam.js';
import { analyse } from '../network/capacity.js';
import { getDriver, fetchCertificateFingerprint, normalizeFingerprint } from '../network/drivers.js';
import { syncCustomer } from '../network/service.js';
import { addCycle } from '../billing/service.js';

const r = Router();
r.use(authenticate);

const ipv4 = z.string().trim().regex(/^(\d{1,3}\.){3}\d{1,3}$/, 'Invalid IPv4 address');
const host = z.string().trim().max(253).regex(/^[A-Za-z0-9.-]+$/, 'Invalid host');

// ------------------------------------------------------------------ pools
const poolSchema = z.object({
  name: z.string().trim().min(2).max(80),
  kind: z.enum(IP_KINDS),
  cidr: z.string().trim().max(18),
  gateway: ipv4.optional().nullable(),
  dns: z.string().trim().max(120).regex(/^[\d., ]*$/, 'Comma separated IPs').optional().nullable(),
  nat_address: ipv4.optional().nullable(),
  router_id: z.coerce.number().int().positive().optional().nullable(),
  monthly_price_cents: z.coerce.number().int().min(0).max(1e9).optional(),
  description: z.string().max(250).optional().nullable(),
  active: z.boolean().optional(),
});

r.get('/ipam/summary', requirePerm('network.view'), requireModule('ipam'), async (_req, res) => {
  const byKind = await db().all(`SELECT p.kind, a.status, COUNT(*) AS n FROM ip_addresses a JOIN ip_pools p ON p.id = a.pool_id GROUP BY p.kind, a.status`);
  const customersWithoutIp = await db().get("SELECT COUNT(*) AS n FROM customers WHERE status = 'active' AND (ip_address IS NULL OR ip_address = '')");
  const revenue = await db().get("SELECT COALESCE(SUM(ip_addon_cents),0) AS v FROM customers WHERE status = 'active'");
  res.json({ byKind, customersWithoutIp: Number(customersWithoutIp.n), ipAddonMonthlyCents: Number(revenue.v) });
});

r.get('/ipam/pools', requirePerm('network.view'), requireModule('ipam'), async (_req, res) => {
  const rows = await db().all(`SELECT p.*, r.name AS router_name,
      (SELECT COUNT(*) FROM ip_addresses a WHERE a.pool_id = p.id) AS total,
      (SELECT COUNT(*) FROM ip_addresses a WHERE a.pool_id = p.id AND a.status = 'assigned') AS assigned,
      (SELECT COUNT(*) FROM ip_addresses a WHERE a.pool_id = p.id AND a.status = 'free') AS free
    FROM ip_pools p LEFT JOIN routers r ON r.id = p.router_id ORDER BY p.kind, p.name`);
  res.json({ pools: rows.map((p) => ({ ...p, active: !!p.active })) });
});

r.post('/ipam/pools', requirePerm('network.manage'), requireModule('ipam'), validate(poolSchema), async (req, res) => {
  const out = await createPool(req.body);
  await audit(req, 'ipam.pool_create', 'ip_pool', out.id, { cidr: req.body.cidr, kind: req.body.kind });
  res.status(201).json(out);
});

r.put('/ipam/pools/:id', requirePerm('network.manage'), requireModule('ipam'), validate(poolSchema.omit({ cidr: true, kind: true }).partial()), async (req, res) => {
  await update('ip_pools', Number(req.params.id), req.body);
  await audit(req, 'ipam.pool_update', 'ip_pool', req.params.id);
  res.json({ ok: true });
});

r.delete('/ipam/pools/:id', requirePerm('network.manage'), async (req, res) => {
  const used = await db().get("SELECT COUNT(*) AS n FROM ip_addresses WHERE pool_id = ? AND status = 'assigned'", [Number(req.params.id)]);
  if (Number(used.n)) throw badRequest(`${used.n} address(es) are assigned — release them first`);
  await cascadeDelete('ip_pools', Number(req.params.id)); // also removes the pool's addresses (MySQL 8 ignores inline FKs)
  await audit(req, 'ipam.pool_delete', 'ip_pool', req.params.id);
  res.json({ ok: true });
});

r.post('/ipam/pools/:id/apply', requirePerm('network.manage'), async (req, res) => {
  const pool = await db().get('SELECT * FROM ip_pools WHERE id = ?', [Number(req.params.id)]);
  if (!pool) throw notFound();
  const router = pool.router_id ? await db().get('SELECT * FROM routers WHERE id = ?', [pool.router_id]) : null;
  try { await getDriver(router).ensurePool(pool); res.json({ ok: true }); }
  catch (e) { res.json({ ok: false, error: e.message }); }
});

// ------------------------------------------------------------------ addresses
r.get('/ipam/addresses', requirePerm('network.view'), requireModule('ipam'), async (req, res) => {
  const { pool_id, status, kind, q, page, pageSize } = req.query;
  const where = []; const params = [];
  if (pool_id) { where.push('a.pool_id = ?'); params.push(Number(pool_id)); }
  if (status) { where.push('a.status = ?'); params.push(String(status)); }
  if (kind) { where.push('p.kind = ?'); params.push(String(kind)); }
  if (q) { where.push(`(a.address ${ciLike()} ? OR u.name ${ciLike()} ? OR c.code ${ciLike()} ?)`); params.push(...Array(3).fill(`%${String(q).slice(0, 60)}%`)); }
  const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const from = `FROM ip_addresses a JOIN ip_pools p ON p.id = a.pool_id LEFT JOIN customers c ON c.id = a.customer_id LEFT JOIN users u ON u.id = c.user_id ${w}`;
  res.json(await paginate({ base: `SELECT a.*, p.kind, p.name AS pool_name, c.code AS customer_code, u.name AS customer_name ${from}`, countBase: `SELECT COUNT(*) AS n ${from}`, params, page, pageSize: pageSize || 100, defaultSort: 'a.ip_int ASC' }));
});

r.patch('/ipam/addresses/:id', requirePerm('network.manage'), validate(z.object({
  status: z.enum(['free', 'reserved', 'blocked']).optional(), notes: z.string().max(250).optional().nullable(),
  ptr: z.string().max(253).regex(/^[A-Za-z0-9.-]*$/).optional().nullable(),
})), async (req, res) => {
  const a = await db().get('SELECT * FROM ip_addresses WHERE id = ?', [Number(req.params.id)]);
  if (!a) throw notFound();
  if (req.body.status && a.status === 'assigned') throw badRequest('Release this address from its customer first');
  await update('ip_addresses', a.id, req.body);
  await audit(req, 'ipam.address_update', 'ip_address', a.address, req.body);
  res.json({ ok: true });
});

r.post('/ipam/assign', requirePerm('network.manage', 'customers.edit'), requireModule('ipam'), validate(z.object({
  customer_id: z.coerce.number().int().positive(), kind: z.enum(IP_KINDS).optional(),
  pool_id: z.coerce.number().int().positive().optional(), address: ipv4.optional(),
})), async (req, res) => {
  const out = await assignIp(req.body.customer_id, { kind: req.body.kind, poolId: req.body.pool_id, address: req.body.address });
  await audit(req, 'ipam.assign', 'customer', req.body.customer_id, { address: out.address, kind: out.kind });
  res.json(out);
});

r.post('/ipam/release', requirePerm('network.manage', 'customers.edit'), validate(z.object({ customer_id: z.coerce.number().int().positive() })), async (req, res) => {
  const out = await releaseIp(req.body.customer_id);
  await audit(req, 'ipam.release', 'customer', req.body.customer_id);
  res.json(out);
});

r.post('/ipam/reconcile', requirePerm('network.manage'), async (req, res) => res.json({ fixed: await reconcileAssignments() }));

// ------------------------------------------------------------------ capacity & upstream links
r.get('/capacity', requirePerm('network.view'), requireModule('bandwidth'), async (req, res) => {
  res.json(await analyse({ days: Math.min(30, Math.max(1, Number(req.query.days) || 7)) }));
});

const linkSchema = z.object({
  name: z.string().trim().min(2).max(80), provider: z.string().max(120).optional().nullable(),
  router_id: z.coerce.number().int().positive().optional().nullable(), interface: z.string().max(60).regex(/^[A-Za-z0-9._/-]*$/).optional().nullable(),
  capacity_down_kbps: z.coerce.number().int().min(1).max(1e9), capacity_up_kbps: z.coerce.number().int().min(1).max(1e9),
  monthly_cost_cents: z.coerce.number().int().min(0).optional(), active: z.boolean().optional(),
});
r.get('/upstream-links', requirePerm('network.view'), async (_req, res) => res.json({ links: (await db().all('SELECT * FROM upstream_links ORDER BY name')).map((l) => ({ ...l, active: !!l.active })) }));
r.post('/upstream-links', requirePerm('network.manage'), validate(linkSchema), async (req, res) => {
  const out = await insert('upstream_links', { ...req.body, created_at: now() });
  await audit(req, 'capacity.link_create', 'upstream_link', out.id);
  res.status(201).json({ id: out.id });
});
r.put('/upstream-links/:id', requirePerm('network.manage'), validate(linkSchema.partial()), async (req, res) => { await update('upstream_links', Number(req.params.id), req.body); res.json({ ok: true }); });
r.delete('/upstream-links/:id', requirePerm('network.manage'), async (req, res) => { await db().run('DELETE FROM upstream_links WHERE id = ?', [Number(req.params.id)]); res.json({ ok: true }); });

// ------------------------------------------------------------------ core router: certificate pin, discovery, import
r.post('/routers/fingerprint', requirePerm('network.manage'), validate(z.object({ host, port: z.coerce.number().int().min(1).max(65535) })), async (req, res) => {
  try { res.json(await fetchCertificateFingerprint(req.body.host, req.body.port)); }
  catch (e) { throw badRequest(`Could not read certificate: ${e.message}`); }
});

r.post('/routers/:id/discover', requirePerm('network.manage'), async (req, res) => {
  const router = await db().get('SELECT * FROM routers WHERE id = ?', [Number(req.params.id)]);
  if (!router) throw notFound();
  let d;
  try { d = await getDriver(router).discover(); }
  catch (e) {
    // An unreachable or misconfigured router is an expected situation, not a server error: say what went wrong.
    await db().run('UPDATE routers SET status = ?, info = ? WHERE id = ?', ['offline', JSON.stringify({ ...(parseJson(router.info, {}) || {}), error: e.message, errorAt: now() }), router.id]);
    throw new HttpError(502, `Could not reach the router: ${e.message}`);
  }
  const known = new Set((await db().all("SELECT pppoe_username FROM customers WHERE pppoe_username IS NOT NULL AND pppoe_username != ''")).map((x) => x.pppoe_username));
  const info = { ...parseJson(router.info, {}), ...d.router, wanInterface: d.wanInterface };
  await db().run('UPDATE routers SET info = ?, status = ?, last_seen_at = ? WHERE id = ?', [JSON.stringify(info), 'online', now(), router.id]);
  const plans = await db().all('SELECT id, name, download_kbps FROM plans WHERE active = 1 ORDER BY price_cents');
  res.json({
    ...d,
    pppSecrets: d.pppSecrets.map((s) => ({ ...s, known: known.has(s.name) })),
    unknownSessions: d.activeSessions.filter((a) => !known.has(a.name)),
    profiles: [...new Set(d.pppSecrets.map((s) => s.profile).filter(Boolean))],
    plans,
  });
});

r.post('/routers/:id/import', requirePerm('network.manage'), validate(z.object({
  secrets: z.array(z.object({ name: z.string().min(1).max(64).regex(/^[A-Za-z0-9_.@-]+$/), remoteAddress: ipv4.optional().nullable(), profile: z.string().max(64).optional().nullable() })).min(1).max(5000),
  planMap: z.record(z.string().max(64), z.coerce.number().int().positive()).optional(),
  defaultPlanId: z.coerce.number().int().positive().optional(),
})), async (req, res) => {
  const router = await db().get('SELECT * FROM routers WHERE id = ?', [Number(req.params.id)]);
  if (!router) throw notFound();
  const role = await db().get("SELECT id FROM roles WHERE slug = 'customer'");
  const unusable = await hashPassword(randomToken(24)); // imported customers set a password via "Forgot password"
  let created = 0; const skipped = [];
  for (const s of req.body.secrets) {
    if (await db().get('SELECT id FROM customers WHERE pppoe_username = ?', [s.name])) { skipped.push(s.name); continue; }
    const planId = req.body.planMap?.[s.profile] || req.body.defaultPlanId || null;
    const plan = planId ? await db().get('SELECT * FROM plans WHERE id = ?', [planId]) : null;
    const ts = now();
    const email = `${s.name.toLowerCase().replace(/[^a-z0-9._-]/g, '-')}@imported.invalid`;
    if (await db().get('SELECT id FROM users WHERE email = ?', [email])) { skipped.push(s.name); continue; }
    await db().transaction(async (t) => {
      const u = await insert('users', { type: 'customer', role_id: role?.id, name: s.name, email, password_hash: unusable, status: 'active', created_at: ts, updated_at: ts }, t);
      await insert('customers', {
        user_id: u.id, code: `C${String(u.id).padStart(6, '0')}`, connection_type: 'pppoe', pppoe_username: s.name, ip_address: s.remoteAddress || null,
        router_id: router.id, plan_id: plan?.id ?? null, status: 'active', billing_day: Math.min(28, new Date().getUTCDate()),
        next_due_date: plan ? addCycle(new Date(), plan.billing_cycle).toISOString() : null, notes: `Imported from ${router.name}`, created_at: ts, updated_at: ts,
      }, t);
    });
    created++;
  }
  const fixed = await reconcileAssignments();
  await audit(req, 'router.import', 'router', router.id, { created, skipped: skipped.length });
  res.json({ created, skipped, ipReconciled: fixed });
});

r.post('/routers/:id/pin', requirePerm('network.manage'), validate(z.object({ fingerprint: z.string().min(32).max(200) })), async (req, res) => {
  const fp = normalizeFingerprint(req.body.fingerprint);
  if (!/^[A-F0-9]{64}$/.test(fp)) throw badRequest('Expected a SHA-256 fingerprint (64 hex characters)');
  await db().run('UPDATE routers SET tls_fingerprint = ?, verify_tls = 0 WHERE id = ?', [fp, Number(req.params.id)]);
  await audit(req, 'router.pin_certificate', 'router', req.params.id, { fingerprint: fp });
  res.json({ ok: true });
});

// Re-push one customer's speed + IP to the router (bandwidth & IP setup in one click)
r.post('/customers/:id/provision', requirePerm('network.manage'), async (req, res) => {
  const c = await db().get('SELECT id, ip_address FROM customers WHERE id = ?', [Number(req.params.id)]);
  if (!c) throw notFound();
  const sync = await syncCustomer(c.id);
  let ip = null;
  if (c.ip_address) ip = await assignIp(c.id, { address: c.ip_address }).catch((e) => ({ error: e.message }));
  res.json({ sync, ip });
});

export default r;
