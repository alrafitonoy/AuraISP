// Inventory & equipment: product catalogue, warehouses, serialised units and bulk lots, stock movements and the
// equipment each customer holds. Every change of an item writes an inv_movements row (the audit trail of stock).
//
// Item states:
//   in_stock    in a warehouse, available
//   with_staff  issued to a technician / staff member (van stock)
//   assigned    installed at a customer, ISP-owned, free of charge
//   rented      installed at a customer, ISP-owned, billed as rent
//   sold        sold to a customer (customer-owned)
//   faulty      in a warehouse, not usable until repaired
//   written_off scrapped / lost (terminal)
import { Router } from 'express';
import { z } from 'zod';
import { db, insert, update, now, paginate, ciLike } from '../db/index.js';
import { validate, notFound, badRequest, conflict } from '../lib/http.js';
import { authenticate, requirePerm, requireModule } from '../middleware/auth.js';
import { audit } from '../lib/audit.js';

const r = Router();
r.use(authenticate, requireModule('inventory'));

const VIEW = requirePerm('inventory.view', 'inventory.manage');
const MANAGE = requirePerm('inventory.manage');

export const CATEGORIES = ['router', 'onu', 'olt', 'switch', 'cable', 'splitter', 'connector', 'media_converter', 'sfp', 'tool', 'accessory', 'other'];
export const STATUSES = ['in_stock', 'with_staff', 'assigned', 'rented', 'sold', 'faulty', 'written_off'];
export const MOVEMENT_TYPES = ['receive', 'issue', 'issue_staff', 'return', 'transfer', 'faulty', 'write_off', 'edit'];
const AT_CUSTOMER = ['assigned', 'rented', 'sold'];
const MAX_UNITS = 1000;

const id = z.coerce.number().int().positive();
const optId = id.optional().nullable();
// Query strings: an empty value (e.g. "?status=") means "no filter".
const blank = (schema) => z.preprocess((v) => (v === '' ? undefined : v), schema);
const money = z.coerce.number().int().min(0).max(1e12);
const note = z.string().trim().max(250).optional().nullable();
const num = (v) => Number(v || 0);

/** Normalise a MAC address to AA:BB:CC:DD:EE:FF, or return null when it is not one. */
export function normMac(v) {
  const hex = String(v || '').replace(/[^0-9a-f]/gi, '');
  if (hex.length !== 12 || /[^0-9a-f]/i.test(String(v).replace(/[\s:.-]/g, ''))) return null;
  return hex.toUpperCase().match(/../g).join(':');
}

const conflictMsg = 'This item was changed by someone else a moment ago — reload and try again';

// ------------------------------------------------------------------ helpers
async function getProduct(pid, conn = db()) {
  const p = await conn.get('SELECT * FROM inv_products WHERE id = ?', [pid]);
  if (!p) throw notFound('Product not found');
  return p;
}
async function getWarehouse(wid, conn = db()) {
  const w = await conn.get('SELECT * FROM inv_warehouses WHERE id = ?', [wid]);
  if (!w) throw badRequest('Warehouse not found');
  return w;
}
async function getCustomer(cid, conn = db()) {
  const c = await conn.get('SELECT c.id, c.code, u.name FROM customers c JOIN users u ON u.id = c.user_id WHERE c.id = ?', [cid]);
  if (!c) throw badRequest('Customer not found');
  return c;
}
async function getStaff(uid, conn = db()) {
  const s = await conn.get("SELECT id, name FROM users WHERE id = ? AND type IN ('admin','staff') AND status = 'active'", [uid]);
  if (!s) throw badRequest('Staff member not found or inactive');
  return s;
}
async function checkJob(jid, conn = db()) {
  if (!jid) return null;
  const j = await conn.get('SELECT id FROM jobs WHERE id = ?', [jid]);
  if (!j) throw badRequest('Job not found');
  return j.id;
}
async function getItem(iid, conn = db()) {
  const it = await conn.get('SELECT i.*, p.name AS product_name, p.track_serial, p.unit FROM inv_items i JOIN inv_products p ON p.id = i.product_id WHERE i.id = ?', [iid]);
  if (!it) throw notFound('Item not found');
  return it;
}
const itemLabel = (it) => (it.serial ? `${it.product_name} ${it.serial}` : `${it.qty} ${it.unit || 'pcs'} of ${it.product_name}`);

function move(conn, { product_id, item_id = null, qty = 1, type, warehouse_id = null, customer_id = null, job_id = null, user_id = null, note: n = null }) {
  return insert('inv_movements', { product_id, item_id, qty, type, warehouse_id, customer_id, job_id, user_id, note: n ? String(n).slice(0, 250) : null, created_at: now() }, conn);
}

/**
 * Take `qty` units out of an item for a state change. A whole item moves as is; part of a bulk lot is split off into
 * a new row (same product / cost). The source row is updated conditionally on its current status and quantity so two
 * concurrent actions on the same lot can never both succeed. Returns the id of the row that now holds the units.
 */
async function take(conn, it, qty, changes) {
  const stamp = now();
  if (qty === num(it.qty)) {
    const cols = Object.keys(changes);
    const out = await conn.run(`UPDATE inv_items SET ${cols.map((c) => `${c} = ?`).join(', ')}, updated_at = ? WHERE id = ? AND status = ? AND qty = ?`,
      [...cols.map((c) => changes[c]), stamp, it.id, it.status, it.qty]);
    if (!out.changes) throw conflict(conflictMsg);
    return it.id;
  }
  const dec = await conn.run('UPDATE inv_items SET qty = qty - ?, updated_at = ? WHERE id = ? AND status = ? AND qty = ?', [qty, stamp, it.id, it.status, it.qty]);
  if (!dec.changes) throw conflict(conflictMsg);
  const row = {
    product_id: it.product_id, serial: null, mac: null, qty, status: it.status, warehouse_id: it.warehouse_id, customer_id: it.customer_id,
    staff_id: it.staff_id, cost_cents: it.cost_cents, notes: it.notes, created_at: stamp, updated_at: stamp, ...changes,
  };
  return (await insert('inv_items', row, conn)).id;
}

function qtyFor(it, qty) {
  const q = qty ?? num(it.qty);
  if (it.serial || num(it.track_serial) === 1) {
    if (q !== 1) throw badRequest('Serialised items move one unit at a time');
    return 1;
  }
  if (q > num(it.qty)) throw badRequest(`Only ${it.qty} ${it.unit || 'pcs'} left in this lot`);
  return q;
}

function requireStatus(it, allowed, action) {
  if (!allowed.includes(it.status)) {
    throw badRequest(`Cannot ${action}: ${itemLabel(it)} is ${it.status.replace(/_/g, ' ')} (must be ${allowed.map((s) => s.replace(/_/g, ' ')).join(' or ')})`);
  }
}

// ------------------------------------------------------------------ lookups (for pickers)
r.get('/lookups', VIEW, async (_req, res) => {
  const [products, warehouses, zones] = await Promise.all([
    db().all('SELECT id, name, sku, category, unit, track_serial, buy_cents, sell_cents, rent_cents, active FROM inv_products ORDER BY name'),
    db().all('SELECT id, name FROM inv_warehouses ORDER BY name'),
    db().all('SELECT id, name FROM zones ORDER BY name').catch(() => []),
  ]);
  res.json({ products, warehouses, zones, categories: CATEGORIES, statuses: STATUSES });
});

r.get('/lookup/customers', MANAGE, async (req, res) => {
  const q = String(req.query.q || '').trim().slice(0, 60);
  if (!q) return res.json({ rows: [] });
  const like = `%${q}%`;
  const rows = await db().all(`SELECT c.id, c.code, u.name, u.phone FROM customers c JOIN users u ON u.id = c.user_id
    WHERE (u.name ${ciLike()} ? OR c.code ${ciLike()} ? OR u.phone ${ciLike()} ? OR u.email ${ciLike()} ?) ORDER BY u.name LIMIT 10`, [like, like, like, like]);
  res.json({ rows });
});

r.get('/lookup/staff', MANAGE, async (_req, res) => {
  res.json({ rows: await db().all("SELECT id, name, email FROM users WHERE type IN ('admin','staff') AND status = 'active' ORDER BY name LIMIT 500") });
});

// ------------------------------------------------------------------ products
const productSchema = z.object({
  name: z.string().trim().min(2).max(120),
  sku: z.string().trim().max(60).optional().nullable().transform((v) => v || null),
  category: z.enum(CATEGORIES).default('other'),
  unit: z.string().trim().min(1).max(20).default('pcs'),
  buy_cents: money.default(0), sell_cents: money.default(0), rent_cents: money.default(0),
  track_serial: z.boolean().default(true),
  min_stock: z.coerce.number().int().min(0).max(1e9).default(0),
  active: z.boolean().default(true),
});
const productPatch = z.object({
  name: z.string().trim().min(2).max(120).optional(),
  sku: z.string().trim().max(60).optional().nullable(),
  category: z.enum(CATEGORIES).optional(),
  unit: z.string().trim().min(1).max(20).optional(),
  buy_cents: money.optional(), sell_cents: money.optional(), rent_cents: money.optional(),
  track_serial: z.boolean().optional(),
  min_stock: z.coerce.number().int().min(0).max(1e9).optional(),
  active: z.boolean().optional(),
});

async function skuFree(sku, exceptId = 0) {
  if (!sku) return;
  const dup = await db().get('SELECT id FROM inv_products WHERE UPPER(sku) = UPPER(?) AND id != ?', [sku, exceptId]);
  if (dup) throw conflict(`SKU "${sku}" is already used by another product`);
}

r.get('/products', VIEW, async (req, res) => {
  const where = []; const params = [];
  if (req.query.category) { where.push('category = ?'); params.push(String(req.query.category)); }
  if (req.query.active === '1' || req.query.active === '0') { where.push('active = ?'); params.push(Number(req.query.active)); }
  if (req.query.q) { where.push(`(name ${ciLike()} ? OR sku ${ciLike()} ?)`); params.push(...Array(2).fill(`%${String(req.query.q).slice(0, 60)}%`)); }
  const rows = await db().all(`SELECT * FROM inv_products ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY name`, params);
  const counts = await db().all('SELECT product_id, COUNT(*) AS n FROM inv_items GROUP BY product_id');
  const by = new Map(counts.map((c) => [c.product_id, num(c.n)]));
  res.json({ products: rows.map((p) => ({ ...p, item_rows: by.get(p.id) || 0 })) });
});

r.post('/products', MANAGE, validate(productSchema), async (req, res) => {
  await skuFree(req.body.sku);
  const out = await insert('inv_products', { ...req.body, track_serial: req.body.track_serial ? 1 : 0, active: req.body.active ? 1 : 0, created_at: now() });
  await audit(req, 'inventory.product_create', 'inv_product', out.id, { name: req.body.name });
  res.status(201).json({ id: out.id });
});

r.put('/products/:id', MANAGE, validate(productPatch), async (req, res) => {
  const p = await getProduct(Number(req.params.id));
  const b = { ...req.body };
  if (b.sku !== undefined) { b.sku = b.sku || null; await skuFree(b.sku, p.id); }
  if (b.track_serial !== undefined && (b.track_serial ? 1 : 0) !== num(p.track_serial)) {
    const has = await db().get('SELECT id FROM inv_items WHERE product_id = ?', [p.id]);
    if (has) throw badRequest('Serial tracking cannot be changed once the product has stock — create a new product instead');
  }
  if (b.track_serial !== undefined) b.track_serial = b.track_serial ? 1 : 0;
  if (b.active !== undefined) b.active = b.active ? 1 : 0;
  await update('inv_products', p.id, b);
  await audit(req, 'inventory.product_update', 'inv_product', p.id, b);
  res.json({ ok: true });
});

r.delete('/products/:id', MANAGE, async (req, res) => {
  const p = await getProduct(Number(req.params.id));
  const n = num((await db().get('SELECT COUNT(*) AS n FROM inv_items WHERE product_id = ?', [p.id])).n);
  if (n) throw badRequest(`"${p.name}" has ${n} stock record(s) and history — deactivate it instead of deleting`);
  await db().transaction(async (t) => {
    await t.run('DELETE FROM inv_movements WHERE product_id = ?', [p.id]);
    await t.run('DELETE FROM inv_products WHERE id = ?', [p.id]);
  });
  await audit(req, 'inventory.product_delete', 'inv_product', p.id, { name: p.name });
  res.json({ ok: true });
});

// ------------------------------------------------------------------ warehouses
const warehouseSchema = z.object({
  name: z.string().trim().min(2).max(120),
  zone_id: optId,
  address: z.string().trim().max(250).optional().nullable(),
});

async function checkZone(zid) {
  if (!zid) return;
  if (!(await db().get('SELECT id FROM zones WHERE id = ?', [zid]))) throw badRequest('Zone not found');
}

r.get('/warehouses', VIEW, async (_req, res) => {
  const rows = await db().all('SELECT w.*, z.name AS zone_name FROM inv_warehouses w LEFT JOIN zones z ON z.id = w.zone_id ORDER BY w.name');
  const stock = await db().all("SELECT warehouse_id, SUM(qty) AS units, SUM(qty * cost_cents) AS value FROM inv_items WHERE status IN ('in_stock','faulty') AND warehouse_id IS NOT NULL GROUP BY warehouse_id");
  const by = new Map(stock.map((s) => [s.warehouse_id, s]));
  res.json({ warehouses: rows.map((w) => ({ ...w, units: num(by.get(w.id)?.units), value_cents: num(by.get(w.id)?.value) })) });
});

r.post('/warehouses', MANAGE, validate(warehouseSchema), async (req, res) => {
  await checkZone(req.body.zone_id);
  const out = await insert('inv_warehouses', { ...req.body, created_at: now() });
  await audit(req, 'inventory.warehouse_create', 'inv_warehouse', out.id, { name: req.body.name });
  res.status(201).json({ id: out.id });
});

r.put('/warehouses/:id', MANAGE, validate(warehouseSchema.partial()), async (req, res) => {
  const w = await db().get('SELECT id FROM inv_warehouses WHERE id = ?', [Number(req.params.id)]);
  if (!w) throw notFound('Warehouse not found');
  if (req.body.zone_id) await checkZone(req.body.zone_id);
  await update('inv_warehouses', w.id, req.body);
  await audit(req, 'inventory.warehouse_update', 'inv_warehouse', w.id, req.body);
  res.json({ ok: true });
});

r.delete('/warehouses/:id', MANAGE, async (req, res) => {
  const w = await db().get('SELECT * FROM inv_warehouses WHERE id = ?', [Number(req.params.id)]);
  if (!w) throw notFound('Warehouse not found');
  const n = num((await db().get("SELECT COUNT(*) AS n FROM inv_items WHERE warehouse_id = ? AND status IN ('in_stock','faulty')", [w.id])).n);
  if (n) throw badRequest(`"${w.name}" still holds ${n} stock record(s) — transfer them to another warehouse first`);
  await db().transaction(async (t) => {
    // MySQL ignores inline FKs: clear references explicitly so every database behaves the same.
    await t.run('UPDATE inv_items SET warehouse_id = NULL WHERE warehouse_id = ?', [w.id]);
    await t.run('DELETE FROM inv_warehouses WHERE id = ?', [w.id]);
  });
  await audit(req, 'inventory.warehouse_delete', 'inv_warehouse', w.id, { name: w.name });
  res.json({ ok: true });
});

// ------------------------------------------------------------------ receive stock
const receiveSchema = z.object({
  product_id: id,
  warehouse_id: id,
  unit_cost_cents: money.optional(),
  units: z.array(z.object({ serial: z.string().trim().min(1).max(64), mac: z.string().trim().max(32).optional().nullable() })).max(MAX_UNITS).optional(),
  qty: z.coerce.number().int().positive().max(1e9).optional(),
  note,
});

r.post('/receive', MANAGE, validate(receiveSchema), async (req, res) => {
  const b = req.body;
  const p = await getProduct(b.product_id);
  if (!num(p.active)) throw badRequest(`"${p.name}" is inactive — activate it before receiving stock`);
  await getWarehouse(b.warehouse_id);
  const cost = b.unit_cost_cents ?? num(p.buy_cents);
  const stamp = now();
  const base = { product_id: p.id, status: 'in_stock', warehouse_id: b.warehouse_id, cost_cents: cost, created_at: stamp, updated_at: stamp };

  if (num(p.track_serial)) {
    const units = b.units || [];
    if (!units.length) throw badRequest('Enter at least one serial number (one per line)');
    const problems = [];
    const seenS = new Set(); const seenM = new Set();
    const clean = units.map((u, i) => {
      const serial = u.serial.trim();
      const mac = u.mac ? normMac(u.mac) : null;
      if (u.mac && !mac) problems.push(`Line ${i + 1}: "${u.mac}" is not a valid MAC address`);
      const sk = serial.toUpperCase();
      if (seenS.has(sk)) problems.push(`Line ${i + 1}: serial ${serial} is repeated in the list`);
      seenS.add(sk);
      if (mac) { if (seenM.has(mac)) problems.push(`Line ${i + 1}: MAC ${mac} is repeated in the list`); seenM.add(mac); }
      return { serial, mac };
    });
    // Existing duplicates: serials are unique per product, MACs are unique everywhere. Checked in chunks.
    for (let i = 0; i < clean.length; i += 200) {
      const chunk = clean.slice(i, i + 200);
      const ph = chunk.map(() => '?').join(',');
      const dupS = await db().all(`SELECT serial FROM inv_items WHERE product_id = ? AND UPPER(serial) IN (${ph})`, [p.id, ...chunk.map((c) => c.serial.toUpperCase())]);
      for (const d of dupS) problems.push(`Serial ${d.serial} already exists for ${p.name}`);
      const macs = chunk.map((c) => c.mac).filter(Boolean);
      if (macs.length) {
        const dupM = await db().all(`SELECT mac FROM inv_items WHERE mac IN (${macs.map(() => '?').join(',')})`, macs);
        for (const d of dupM) problems.push(`MAC ${d.mac} is already registered`);
      }
    }
    if (problems.length) throw badRequest(`Nothing was received: ${problems.length} problem(s) — ${problems.slice(0, 5).join('; ')}${problems.length > 5 ? '; …' : ''}`, { problems: problems.slice(0, 200) });
    const ids = await db().transaction(async (t) => {
      const out = [];
      for (const u of clean) {
        const it = await insert('inv_items', { ...base, serial: u.serial, mac: u.mac, qty: 1 }, t);
        await move(t, { product_id: p.id, item_id: it.id, qty: 1, type: 'receive', warehouse_id: b.warehouse_id, user_id: req.user.id, note: b.note });
        out.push(it.id);
      }
      return out;
    });
    await audit(req, 'inventory.receive', 'inv_product', p.id, { units: ids.length, warehouse_id: b.warehouse_id, cost });
    return res.status(201).json({ received: ids.length, ids });
  }

  if (!b.qty) throw badRequest(`Enter the quantity (${p.unit || 'pcs'}) received`);
  const itemId = await db().transaction(async (t) => {
    const it = await insert('inv_items', { ...base, qty: b.qty }, t);
    await move(t, { product_id: p.id, item_id: it.id, qty: b.qty, type: 'receive', warehouse_id: b.warehouse_id, user_id: req.user.id, note: b.note });
    return it.id;
  });
  await audit(req, 'inventory.receive', 'inv_product', p.id, { qty: b.qty, warehouse_id: b.warehouse_id, cost });
  res.status(201).json({ received: b.qty, ids: [itemId] });
});

// ------------------------------------------------------------------ stock overview & summary
async function stockRows() {
  return db().all(`SELECT i.product_id, i.warehouse_id, i.status, SUM(i.qty) AS units, SUM(i.qty * i.cost_cents) AS value
    FROM inv_items i GROUP BY i.product_id, i.warehouse_id, i.status`);
}

r.get('/stock', VIEW, async (req, res) => {
  const [products, warehouses, rows] = await Promise.all([
    db().all('SELECT * FROM inv_products ORDER BY name'), db().all('SELECT id, name FROM inv_warehouses ORDER BY name'), stockRows(),
  ]);
  const wName = new Map(warehouses.map((w) => [w.id, w.name]));
  const by = new Map(products.map((p) => [p.id, {
    id: p.id, name: p.name, sku: p.sku, category: p.category, unit: p.unit, min_stock: num(p.min_stock), active: num(p.active), track_serial: num(p.track_serial),
    in_stock: 0, with_staff: 0, deployed: 0, sold: 0, faulty: 0, value_cents: 0, warehouses: new Map(),
  }]));
  for (const s of rows) {
    const p = by.get(s.product_id); if (!p) continue;
    const units = num(s.units); const value = num(s.value);
    if (s.status === 'in_stock') {
      p.in_stock += units; p.value_cents += value;
      const key = s.warehouse_id ?? 0;
      const w = p.warehouses.get(key) || { warehouse_id: s.warehouse_id, name: wName.get(s.warehouse_id) || 'Unassigned', qty: 0, value_cents: 0 };
      w.qty += units; w.value_cents += value; p.warehouses.set(key, w);
    } else if (s.status === 'with_staff') { p.with_staff += units; p.value_cents += value; }
    else if (s.status === 'assigned' || s.status === 'rented') p.deployed += units;
    else if (s.status === 'sold') p.sold += units;
    else if (s.status === 'faulty') p.faulty += units;
  }
  let list = [...by.values()].map((p) => ({ ...p, warehouses: [...p.warehouses.values()], low: p.active === 1 && p.min_stock > 0 && p.in_stock < p.min_stock }));
  const wid = Number(req.query.warehouse_id) || 0;
  if (wid) list = list.map((p) => { const w = p.warehouses.find((x) => x.warehouse_id === wid); return { ...p, in_stock: w?.qty || 0, value_cents: w?.value_cents || 0, warehouses: w ? [w] : [] }; });
  if (req.query.low === '1') list = list.filter((p) => p.low);
  if (req.query.category) list = list.filter((p) => p.category === req.query.category);
  if (req.query.active !== 'all') list = list.filter((p) => p.active === 1 || p.in_stock + p.deployed + p.with_staff + p.faulty > 0);
  const totals = list.reduce((a, p) => ({ value_cents: a.value_cents + p.value_cents, in_stock: a.in_stock + p.in_stock, low: a.low + (p.low ? 1 : 0) }), { value_cents: 0, in_stock: 0, low: 0 });
  res.json({ products: list, warehouses, totals });
});

/** Compact numbers for a dashboard widget. */
export async function inventorySummary() {
  const [rows, products] = await Promise.all([stockRows(), db().all('SELECT id, min_stock, active FROM inv_products')]);
  const out = { stock_value_cents: 0, units_in_stock: 0, items_deployed: 0, with_staff: 0, faulty: 0, sold: 0, low_stock_count: 0, products: products.length };
  const inStock = new Map();
  for (const s of rows) {
    const u = num(s.units);
    if (s.status === 'in_stock') { out.units_in_stock += u; out.stock_value_cents += num(s.value); inStock.set(s.product_id, (inStock.get(s.product_id) || 0) + u); }
    else if (s.status === 'with_staff') { out.with_staff += u; out.stock_value_cents += num(s.value); }
    else if (s.status === 'assigned' || s.status === 'rented') out.items_deployed += u;
    else if (s.status === 'faulty') out.faulty += u;
    else if (s.status === 'sold') out.sold += u;
  }
  out.low_stock_count = products.filter((p) => num(p.active) && num(p.min_stock) > 0 && (inStock.get(p.id) || 0) < num(p.min_stock)).length;
  return out;
}
r.get('/summary', VIEW, async (_req, res) => res.json(await inventorySummary()));

// ------------------------------------------------------------------ items
const ITEM_SELECT = `SELECT i.*, p.name AS product_name, p.sku, p.category, p.unit, p.track_serial, p.rent_cents, p.sell_cents,
  w.name AS warehouse_name, c.code AS customer_code, cu.name AS customer_name, s.name AS staff_name`;
const ITEM_FROM = `FROM inv_items i JOIN inv_products p ON p.id = i.product_id LEFT JOIN inv_warehouses w ON w.id = i.warehouse_id
  LEFT JOIN customers c ON c.id = i.customer_id LEFT JOIN users cu ON cu.id = c.user_id LEFT JOIN users s ON s.id = i.staff_id`;

const itemQuery = z.object({
  product_id: blank(optId), warehouse_id: blank(optId), customer_id: blank(optId), staff_id: blank(optId),
  status: blank(z.enum(STATUSES).optional()), q: z.string().trim().max(60).optional(),
  page: z.coerce.number().int().min(1).optional(), pageSize: z.coerce.number().int().min(1).max(200).optional(), sort: z.string().max(30).optional(),
});

r.get('/items', VIEW, validate(itemQuery, 'query'), async (req, res) => {
  const f = req.query; const where = []; const params = [];
  for (const k of ['product_id', 'warehouse_id', 'customer_id', 'staff_id']) if (f[k]) { where.push(`i.${k} = ?`); params.push(f[k]); }
  if (f.status) { where.push('i.status = ?'); params.push(f.status); }
  if (f.q) {
    where.push(`(i.serial ${ciLike()} ? OR i.mac ${ciLike()} ? OR cu.name ${ciLike()} ? OR c.code ${ciLike()} ? OR s.name ${ciLike()} ?)`);
    const like = `%${f.q}%`; params.push(like, like, like, like, like);
  }
  const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
  res.json(await paginate({
    base: `${ITEM_SELECT} ${ITEM_FROM} ${w}`, countBase: `SELECT COUNT(*) AS n ${ITEM_FROM} ${w}`, params, page: f.page, pageSize: f.pageSize || 25,
    sort: f.sort, sortable: { id: 'i.id', serial: 'i.serial', status: 'i.status', product: 'p.name', updated_at: 'i.updated_at', qty: 'i.qty' }, defaultSort: 'i.id DESC',
  }));
});

r.get('/items/:id', VIEW, async (req, res) => {
  const item = await db().get(`${ITEM_SELECT} ${ITEM_FROM} WHERE i.id = ?`, [Number(req.params.id)]);
  if (!item) throw notFound('Item not found');
  const movements = await db().all(`SELECT m.*, w.name AS warehouse_name, cu.name AS customer_name, u.name AS user_name FROM inv_movements m
    LEFT JOIN inv_warehouses w ON w.id = m.warehouse_id LEFT JOIN customers c ON c.id = m.customer_id LEFT JOIN users cu ON cu.id = c.user_id
    LEFT JOIN users u ON u.id = m.user_id WHERE m.item_id = ? ORDER BY m.id DESC LIMIT 200`, [item.id]);
  res.json({ item, movements });
});

const itemEdit = z.object({
  serial: z.string().trim().min(1).max(64).optional(),
  mac: z.string().trim().max(32).optional().nullable(),
  cost_cents: money.optional(),
  notes: z.string().trim().max(250).optional().nullable(),
});
r.put('/items/:id', MANAGE, validate(itemEdit), async (req, res) => {
  const it = await getItem(Number(req.params.id));
  const b = { ...req.body };
  if (b.serial !== undefined) {
    if (!num(it.track_serial)) throw badRequest('This product is not serial-tracked');
    if (await db().get('SELECT id FROM inv_items WHERE product_id = ? AND UPPER(serial) = UPPER(?) AND id != ?', [it.product_id, b.serial, it.id])) throw conflict(`Serial ${b.serial} already exists for ${it.product_name}`);
  }
  if (b.mac !== undefined) {
    if (b.mac) {
      b.mac = normMac(b.mac);
      if (!b.mac) throw badRequest('Not a valid MAC address');
      if (await db().get('SELECT id FROM inv_items WHERE mac = ? AND id != ?', [b.mac, it.id])) throw conflict(`MAC ${b.mac} is already registered`);
    } else b.mac = null;
  }
  await db().transaction(async (t) => {
    await update('inv_items', it.id, { ...b, updated_at: now() }, t);
    const changed = Object.keys(b).filter((k) => String(b[k] ?? '') !== String(it[k] ?? ''));
    if (changed.length) await move(t, { product_id: it.product_id, item_id: it.id, qty: num(it.qty), type: 'edit', warehouse_id: it.warehouse_id, customer_id: it.customer_id, user_id: req.user.id, note: `Edited ${changed.join(', ')}` });
  });
  await audit(req, 'inventory.item_update', 'inv_item', it.id, b);
  res.json({ ok: true });
});

// ---- actions
const issueSchema = z.object({
  customer_id: id, mode: z.enum(['assigned', 'rented', 'sold']).default('assigned'),
  qty: z.coerce.number().int().positive().optional(), job_id: optId, note,
});
const issueStaffSchema = z.object({ staff_id: id, qty: z.coerce.number().int().positive().optional(), job_id: optId, note });
const returnSchema = z.object({ warehouse_id: id, condition: z.enum(['good', 'faulty']).default('good'), qty: z.coerce.number().int().positive().optional(), job_id: optId, note });
const transferSchema = z.object({ warehouse_id: id, qty: z.coerce.number().int().positive().optional(), note });
const simpleSchema = z.object({ qty: z.coerce.number().int().positive().optional(), note });

/** Core of every item action, shared by the per-item endpoints and the by-product issue endpoint. */
const ACTIONS = {
  async issue(t, it, b, req) {
    requireStatus(it, ['in_stock', 'with_staff'], 'issue to a customer');
    const c = await getCustomer(b.customer_id, t);
    const job = await checkJob(b.job_id, t);
    const qty = qtyFor(it, b.qty);
    const nid = await take(t, it, qty, { status: b.mode, customer_id: c.id, staff_id: null, warehouse_id: null });
    await move(t, { product_id: it.product_id, item_id: nid, qty, type: 'issue', warehouse_id: it.warehouse_id, customer_id: c.id, job_id: job, user_id: req.user.id,
      note: [b.mode !== 'assigned' ? b.mode : null, it.status === 'with_staff' ? `from ${it.staff_name || 'staff'}` : null, b.note].filter(Boolean).join(' · ') || null });
    return { id: nid, qty, audit: { customer_id: c.id, mode: b.mode } };
  },
  async issue_staff(t, it, b, req) {
    requireStatus(it, ['in_stock'], 'issue to staff');
    const s = await getStaff(b.staff_id, t);
    const job = await checkJob(b.job_id, t);
    const qty = qtyFor(it, b.qty);
    const nid = await take(t, it, qty, { status: 'with_staff', staff_id: s.id, customer_id: null, warehouse_id: null });
    await move(t, { product_id: it.product_id, item_id: nid, qty, type: 'issue_staff', warehouse_id: it.warehouse_id, job_id: job, user_id: req.user.id, note: [`to ${s.name}`, b.note].filter(Boolean).join(' · ') });
    return { id: nid, qty, audit: { staff_id: s.id } };
  },
  async return(t, it, b, req) {
    requireStatus(it, ['assigned', 'rented', 'with_staff', 'faulty'], 'return to a warehouse');
    const w = await getWarehouse(b.warehouse_id, t);
    const job = await checkJob(b.job_id, t);
    const qty = qtyFor(it, b.qty);
    const status = b.condition === 'faulty' ? 'faulty' : 'in_stock';
    const nid = await take(t, it, qty, { status, warehouse_id: w.id, customer_id: null, staff_id: null });
    await move(t, { product_id: it.product_id, item_id: nid, qty, type: 'return', warehouse_id: w.id, customer_id: it.customer_id, job_id: job, user_id: req.user.id,
      note: [it.status === 'faulty' ? 'repaired' : null, status === 'faulty' ? 'returned faulty' : null, b.note].filter(Boolean).join(' · ') || null });
    return { id: nid, qty, audit: { warehouse_id: w.id, condition: b.condition } };
  },
  async faulty(t, it, b, req) {
    requireStatus(it, ['in_stock', 'with_staff'], 'mark as faulty');
    const qty = qtyFor(it, b.qty);
    if (it.status === 'with_staff' && !b.warehouse_id) throw badRequest('Choose the warehouse the faulty item goes back to');
    const wid = b.warehouse_id || it.warehouse_id;
    if (b.warehouse_id) await getWarehouse(b.warehouse_id, t);
    const nid = await take(t, it, qty, { status: 'faulty', warehouse_id: wid, staff_id: null });
    await move(t, { product_id: it.product_id, item_id: nid, qty, type: 'faulty', warehouse_id: wid, user_id: req.user.id, note: b.note });
    return { id: nid, qty, audit: {} };
  },
  async transfer(t, it, b, req) {
    requireStatus(it, ['in_stock', 'faulty'], 'transfer');
    const w = await getWarehouse(b.warehouse_id, t);
    if (w.id === it.warehouse_id) throw badRequest(`${itemLabel(it)} is already in ${w.name}`);
    const from = it.warehouse_id ? (await t.get('SELECT name FROM inv_warehouses WHERE id = ?', [it.warehouse_id]))?.name : null;
    const qty = qtyFor(it, b.qty);
    const nid = await take(t, it, qty, { warehouse_id: w.id });
    await move(t, { product_id: it.product_id, item_id: nid, qty, type: 'transfer', warehouse_id: w.id, user_id: req.user.id, note: [`from ${from || 'unassigned'} to ${w.name}`, b.note].filter(Boolean).join(' · ') });
    return { id: nid, qty, audit: { from: it.warehouse_id, to: w.id } };
  },
  async write_off(t, it, b, req) {
    requireStatus(it, ['in_stock', 'faulty', 'with_staff'], 'write off');
    const qty = qtyFor(it, b.qty);
    const nid = await take(t, it, qty, { status: 'written_off', staff_id: null });
    await move(t, { product_id: it.product_id, item_id: nid, qty, type: 'write_off', warehouse_id: it.warehouse_id, user_id: req.user.id, note: b.note });
    return { id: nid, qty, audit: {} };
  },
};

async function runAction(req, action, itemId) {
  const out = await db().transaction(async (t) => {
    const it = await t.get(`SELECT i.*, p.name AS product_name, p.track_serial, p.unit, s.name AS staff_name FROM inv_items i JOIN inv_products p ON p.id = i.product_id
      LEFT JOIN users s ON s.id = i.staff_id WHERE i.id = ?`, [itemId]);
    if (!it) throw notFound('Item not found');
    const res = await ACTIONS[action](t, it, req.body, req);
    return { ...res, product_id: it.product_id };
  });
  await audit(req, `inventory.${action}`, 'inv_item', out.id, { qty: out.qty, source_item: itemId, ...out.audit });
  return { ok: true, item_id: out.id, qty: out.qty };
}

const faultySchema = simpleSchema.extend({ warehouse_id: optId });
for (const [path, action, schema] of [
  ['issue', 'issue', issueSchema], ['issue-staff', 'issue_staff', issueStaffSchema], ['return', 'return', returnSchema],
  ['faulty', 'faulty', faultySchema], ['transfer', 'transfer', transferSchema], ['write-off', 'write_off', simpleSchema],
]) {
  r.post(`/items/:id/${path}`, MANAGE, validate(schema), async (req, res) => res.json(await runAction(req, action, Number(req.params.id))));
}

/**
 * Issue by product: serialised products need the unit (item_id or serial); bulk products draw `qty` from the in-stock
 * lots of one warehouse, oldest first, splitting the last lot as needed.
 */
const issueByProduct = z.object({
  product_id: id, item_id: optId, serial: z.string().trim().max(64).optional().nullable(), warehouse_id: optId,
  customer_id: optId, staff_id: optId, mode: z.enum(['assigned', 'rented', 'sold']).default('assigned'),
  qty: z.coerce.number().int().positive().max(1e9).optional(), job_id: optId, note,
}).refine((b) => !!b.customer_id !== !!b.staff_id, { message: 'Choose either a customer or a staff member', path: ['customer_id'] });

r.post('/issue', MANAGE, validate(issueByProduct), async (req, res) => {
  const b = req.body;
  const p = await getProduct(b.product_id);
  const action = b.customer_id ? 'issue' : 'issue_staff';
  if (num(p.track_serial)) {
    let itemId = b.item_id;
    if (!itemId && b.serial) itemId = (await db().get('SELECT id FROM inv_items WHERE product_id = ? AND UPPER(serial) = UPPER(?)', [p.id, b.serial]))?.id;
    if (!itemId) throw badRequest(b.serial ? `No ${p.name} with serial ${b.serial}` : 'Choose the unit (serial number) to issue');
    const own = await db().get('SELECT product_id FROM inv_items WHERE id = ?', [itemId]);
    if (!own || own.product_id !== p.id) throw badRequest('That unit does not belong to this product');
    req.body = { ...b, qty: undefined };
    return res.json(await runAction(req, action, itemId));
  }
  if (!b.qty) throw badRequest(`Enter the quantity (${p.unit || 'pcs'}) to issue`);
  if (!b.warehouse_id) throw badRequest('Choose the warehouse to issue from');
  const result = await db().transaction(async (t) => {
    const lots = await t.all(`SELECT i.*, p.name AS product_name, p.track_serial, p.unit FROM inv_items i JOIN inv_products p ON p.id = i.product_id
      WHERE i.product_id = ? AND i.warehouse_id = ? AND i.status = 'in_stock' ORDER BY i.id`, [p.id, b.warehouse_id]);
    const available = lots.reduce((a, l) => a + num(l.qty), 0);
    if (available < b.qty) throw badRequest(`Only ${available} ${p.unit || 'pcs'} of ${p.name} in stock in that warehouse`);
    let left = b.qty; const ids = [];
    for (const lot of lots) {
      if (!left) break;
      const q = Math.min(left, num(lot.qty));
      const out = await ACTIONS[action](t, lot, { ...b, qty: q }, req);
      ids.push(out.id); left -= q;
    }
    return ids;
  });
  await audit(req, `inventory.${action}`, 'inv_product', p.id, { qty: b.qty, warehouse_id: b.warehouse_id, customer_id: b.customer_id, staff_id: b.staff_id });
  res.json({ ok: true, item_ids: result, qty: b.qty });
});

// ------------------------------------------------------------------ movements
const movementQuery = z.object({
  product_id: blank(optId), item_id: blank(optId), customer_id: blank(optId), warehouse_id: blank(optId), type: blank(z.enum(MOVEMENT_TYPES).optional()),
  from: z.string().max(32).optional(), to: z.string().max(32).optional(),
  page: z.coerce.number().int().min(1).optional(), pageSize: z.coerce.number().int().min(1).max(200).optional(),
});
r.get('/movements', VIEW, validate(movementQuery, 'query'), async (req, res) => {
  const f = req.query; const where = []; const params = [];
  for (const k of ['product_id', 'item_id', 'customer_id', 'warehouse_id']) if (f[k]) { where.push(`m.${k} = ?`); params.push(f[k]); }
  if (f.type) { where.push('m.type = ?'); params.push(f.type); }
  if (f.from) { where.push('m.created_at >= ?'); params.push(f.from); }
  if (f.to) { where.push('m.created_at <= ?'); params.push(f.to.length <= 10 ? `${f.to}T23:59:59.999Z` : f.to); }
  const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const from = `FROM inv_movements m LEFT JOIN inv_products p ON p.id = m.product_id LEFT JOIN inv_items i ON i.id = m.item_id
    LEFT JOIN inv_warehouses w ON w.id = m.warehouse_id LEFT JOIN customers c ON c.id = m.customer_id LEFT JOIN users cu ON cu.id = c.user_id
    LEFT JOIN users u ON u.id = m.user_id ${w}`;
  res.json(await paginate({
    base: `SELECT m.*, p.name AS product_name, p.unit, i.serial, i.mac, w.name AS warehouse_name, c.code AS customer_code, cu.name AS customer_name, u.name AS user_name ${from}`,
    countBase: `SELECT COUNT(*) AS n ${from}`, params, page: f.page, pageSize: f.pageSize || 50, defaultSort: 'm.id DESC',
  }));
});

// ------------------------------------------------------------------ customer equipment
r.get('/customers/:id/equipment', VIEW, async (req, res) => {
  const cid = Number(req.params.id);
  if (!Number.isInteger(cid) || cid <= 0) throw badRequest('Invalid customer id');
  const c = await db().get('SELECT c.id, c.code, u.name FROM customers c JOIN users u ON u.id = c.user_id WHERE c.id = ?', [cid]);
  if (!c) throw notFound('Customer not found');
  const items = await db().all(`${ITEM_SELECT} ${ITEM_FROM} WHERE i.customer_id = ? AND i.status IN (${AT_CUSTOMER.map(() => '?').join(',')}) ORDER BY i.updated_at DESC, i.id DESC`, [cid, ...AT_CUSTOMER]);
  const monthly_rent_cents = items.filter((i) => i.status === 'rented').reduce((a, i) => a + num(i.rent_cents) * num(i.qty), 0);
  res.json({ customer: c, items, monthly_rent_cents });
});

export default r;
