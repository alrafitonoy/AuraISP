// Staff accounts & role-based access control. Admin defines roles, their permissions and their dashboards.
import { Router } from 'express';
import { z } from 'zod';
import { db, insert, update, now, parseJson, cascadeDelete } from '../db/index.js';
import { validate, notFound, badRequest, conflict, forbidden } from '../lib/http.js';
import { authenticate, requirePerm } from '../middleware/auth.js';
import { hashPassword } from '../lib/crypto.js';
import { audit } from '../lib/audit.js';
import { PERMISSIONS, ALL_PERMISSIONS, WIDGETS, MODULES } from '../lib/catalog.js';
import { assertPassword } from './auth.js';

const r = Router();
r.use(authenticate, requirePerm('staff.manage'));

/** Prevent privilege escalation: non-admin managers can only hand out permissions they hold. */
function assertGrantable(user, perms) {
  if (user.type === 'admin') return;
  if ((perms || []).some((p) => !user.permissions.includes(p) && !user.permissions.includes('*'))) throw forbidden('You cannot grant permissions you do not have');
}
async function assertRoleAssignable(user, roleId) {
  const role = await db().get("SELECT * FROM roles WHERE id = ? AND slug != 'customer'", [roleId]);
  if (!role) throw badRequest('Invalid role');
  assertGrantable(user, parseJson(role.permissions, []));
}

r.get('/catalog', (_req, res) => res.json({ permissions: PERMISSIONS, widgets: WIDGETS, modules: MODULES }));

// ------------------------------------------------------------------ roles
const roleSchema = z.object({
  name: z.string().trim().min(2).max(60),
  description: z.string().max(250).optional().nullable(),
  permissions: z.array(z.enum(ALL_PERMISSIONS)).max(ALL_PERMISSIONS.length),
  dashboard: z.array(z.enum(Object.keys(WIDGETS))).max(30),
});

r.get('/roles', async (_req, res) => {
  const rows = await db().all("SELECT r.*, (SELECT COUNT(*) FROM users u WHERE u.role_id = r.id) AS members FROM roles r WHERE r.slug != 'customer' ORDER BY r.is_system DESC, r.name");
  res.json({ roles: rows.map((x) => ({ ...x, permissions: parseJson(x.permissions, []), dashboard: parseJson(x.dashboard, []), is_system: !!x.is_system })) });
});

r.post('/roles', validate(roleSchema), async (req, res) => {
  const slug = req.body.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '').slice(0, 50);
  if (['admin', 'customer'].includes(slug) || (await db().get('SELECT id FROM roles WHERE slug = ?', [slug]))) throw conflict('Role name already in use');
  assertGrantable(req.user, req.body.permissions);
  const out = await insert('roles', { ...req.body, slug, permissions: JSON.stringify(req.body.permissions), dashboard: JSON.stringify(req.body.dashboard), is_system: 0, created_at: now() });
  await audit(req, 'role.create', 'role', out.id, req.body);
  res.status(201).json({ id: out.id });
});

r.put('/roles/:id', validate(roleSchema.partial()), async (req, res) => {
  const role = await db().get('SELECT * FROM roles WHERE id = ?', [Number(req.params.id)]);
  if (!role) throw notFound();
  if (['admin', 'customer'].includes(role.slug)) throw forbidden('This role cannot be edited');
  // Non-admin staff managers cannot grant permissions they do not hold themselves.
  assertGrantable(req.user, req.body.permissions);
  if (req.user.type !== 'admin' && req.user.role_id === role.id) throw forbidden('You cannot edit your own role');
  const b = { ...req.body };
  if (b.permissions) b.permissions = JSON.stringify(b.permissions);
  if (b.dashboard) b.dashboard = JSON.stringify(b.dashboard);
  await update('roles', role.id, b);
  await audit(req, 'role.update', 'role', role.id, req.body);
  res.json({ ok: true });
});

r.delete('/roles/:id', async (req, res) => {
  const role = await db().get('SELECT * FROM roles WHERE id = ?', [Number(req.params.id)]);
  if (!role) throw notFound();
  if (role.is_system) throw forbidden('System roles cannot be deleted');
  const n = await db().get('SELECT COUNT(*) AS n FROM users WHERE role_id = ?', [role.id]);
  if (Number(n.n)) throw badRequest('Reassign members before deleting this role');
  await cascadeDelete('roles', role.id);
  await audit(req, 'role.delete', 'role', role.id);
  res.json({ ok: true });
});

// ------------------------------------------------------------------ staff users
const staffSchema = z.object({
  name: z.string().trim().min(2).max(120),
  email: z.string().trim().toLowerCase().email().max(190),
  phone: z.string().max(20).optional().nullable(),
  role_id: z.coerce.number().int().positive(),
  password: z.string().max(128).optional(),
  type: z.enum(['staff', 'admin']).optional(),
  status: z.enum(['active', 'disabled']).optional(),
});

r.get('/', async (_req, res) => {
  const rows = await db().all(`SELECT u.id, u.type, u.name, u.email, u.phone, u.status, u.totp_enabled, u.last_login_at, u.created_at, u.role_id, r.name AS role_name
    FROM users u LEFT JOIN roles r ON r.id = u.role_id WHERE u.type IN ('admin','staff') ORDER BY u.type, u.name`);
  res.json({ users: rows.map((u) => ({ ...u, totp_enabled: !!u.totp_enabled })) });
});

r.post('/', validate(staffSchema.required({ password: true })), async (req, res) => {
  const b = req.body;
  if (b.type === 'admin' && req.user.type !== 'admin') throw forbidden('Only administrators can create administrators');
  await assertPassword(b.password);
  if (await db().get('SELECT id FROM users WHERE email = ?', [b.email])) throw conflict('Email already in use');
  await assertRoleAssignable(req.user, b.role_id);
  const out = await insert('users', { type: b.type || 'staff', role_id: b.role_id, name: b.name, email: b.email, phone: b.phone, password_hash: await hashPassword(b.password), status: 'active', email_verified_at: now(), created_at: now(), updated_at: now() });
  await audit(req, 'staff.create', 'user', out.id, { email: b.email, role: b.role_id, type: b.type });
  res.status(201).json({ id: out.id });
});

r.put('/:id', validate(staffSchema.partial()), async (req, res) => {
  const u = await db().get("SELECT * FROM users WHERE id = ? AND type IN ('admin','staff')", [Number(req.params.id)]);
  if (!u) throw notFound();
  if ((u.type === 'admin' || req.body.type === 'admin') && req.user.type !== 'admin') throw forbidden('Only administrators can modify administrators');
  if (u.id === req.user.id && (req.body.status === 'disabled' || (req.body.type && req.body.type !== u.type))) throw badRequest('You cannot disable or demote yourself');
  if (u.type === 'admin' && (req.body.type === 'staff' || req.body.status === 'disabled')) {
    const admins = await db().get("SELECT COUNT(*) AS n FROM users WHERE type = 'admin' AND status = 'active'");
    if (Number(admins.n) <= 1) throw badRequest('At least one active administrator is required');
  }
  if (req.body.role_id) await assertRoleAssignable(req.user, req.body.role_id);
  if (req.user.type !== 'admin') {
    // Managers cannot modify staff who hold permissions beyond their own.
    const current = await db().get('SELECT permissions FROM roles WHERE id = ?', [u.role_id]);
    assertGrantable(req.user, parseJson(current?.permissions, []));
  }
  const { password, ...rest } = req.body;
  const patch = { ...rest, updated_at: now() };
  if (password) { await assertPassword(password); patch.password_hash = await hashPassword(password); }
  if (password || rest.status === 'disabled' || rest.role_id || rest.type) patch.token_version = Number(u.token_version || 0) + 1; // force re-login
  await update('users', u.id, patch);
  if (patch.token_version) await db().run('UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL', [now(), u.id]);
  await audit(req, 'staff.update', 'user', u.id, { fields: Object.keys(req.body) });
  res.json({ ok: true });
});

r.post('/:id/reset-2fa', async (req, res) => {
  if (req.user.type !== 'admin') throw forbidden();
  await db().run('UPDATE users SET totp_enabled = 0, totp_secret = NULL, backup_codes = NULL, token_version = token_version + 1 WHERE id = ?', [Number(req.params.id)]);
  await audit(req, 'staff.reset_2fa', 'user', req.params.id);
  res.json({ ok: true });
});

r.delete('/:id', async (req, res) => {
  const u = await db().get("SELECT * FROM users WHERE id = ? AND type IN ('admin','staff')", [Number(req.params.id)]);
  if (!u) throw notFound();
  if (u.id === req.user.id) throw badRequest('You cannot delete yourself');
  if (u.type === 'admin' && req.user.type !== 'admin') throw forbidden();
  if (u.type === 'admin') {
    const admins = await db().get("SELECT COUNT(*) AS n FROM users WHERE type = 'admin'");
    if (Number(admins.n) <= 1) throw badRequest('Cannot delete the last administrator');
  }
  await cascadeDelete('users', u.id);
  await audit(req, 'staff.delete', 'user', u.id, { email: u.email });
  res.json({ ok: true });
});

export default r;
