import { Router } from 'express';
import express from 'express';
import { z } from 'zod';
import config from '../config.js';
import { db, insert, now, paginate, parseJson, ciLike } from '../db/index.js';
import { validate, notFound, badRequest, forbidden } from '../lib/http.js';
import { authenticate, requirePerm, requireModule, can } from '../middleware/auth.js';
import { createInvoice, completePayment, generateRecurringInvoices, enforceOverdue, notifyInvoice } from '../billing/service.js';
import { GATEWAYS, enabledGateways, stripe, sslcommerz, bkash } from '../billing/gateways.js';
import { getSetting } from '../lib/settings.js';
import { randomToken } from '../lib/crypto.js';
import { audit } from '../lib/audit.js';
import { renderInvoiceHtml } from '../billing/invoice-html.js';

const r = Router();
const presentInvoice = (i) => i && ({ ...i, items: parseJson(i.items, []) });

// ------------------------------------------------------------------ gateway callbacks (public, verified server-to-server)
const back = (status, extra = '') => `${config.appUrl}/portal/billing?payment=${status}${extra}`;

r.post('/webhooks/stripe', express.raw({ type: 'application/json', limit: '256kb' }), async (req, res) => {
  let event;
  try { event = await stripe.verifyWebhook(req.body.toString('utf8'), req.get('stripe-signature')); }
  catch (e) { return res.status(400).json({ error: e.message }); }
  if (event.type === 'checkout.session.completed' && event.data.object.payment_status === 'paid') {
    const s = event.data.object;
    const pid = Number(s.metadata?.payment_id);
    await completePayment(pid, { gatewayAmountCents: s.amount_total, gatewayRef: s.metadata?.ref, meta: { session: s.id, intent: s.payment_intent } }).catch((e) => console.warn('[stripe]', e.message));
  }
  res.json({ received: true });
});

r.get('/return/stripe', async (req, res) => {
  try {
    const pid = Number(req.query.pid);
    const s = await stripe.retrieve(String(req.query.session_id || ''));
    if (Number(s.metadata?.payment_id) !== pid) throw new Error('Mismatch');
    if (s.payment_status !== 'paid') return res.redirect(back('pending'));
    await completePayment(pid, { gatewayAmountCents: s.amount_total, gatewayRef: s.metadata?.ref, meta: { session: s.id } });
    res.redirect(back('success'));
  } catch { res.redirect(back('failed')); }
});

async function handleSsl(req, res, redirect) {
  const valId = req.body?.val_id || req.query?.val_id;
  const tranId = req.body?.tran_id || req.query?.tran_id;
  try {
    if (!valId) throw new Error('No validation id');
    const v = await sslcommerz.validate(String(valId));
    if (tranId && v.tranId !== tranId) throw new Error('Mismatch');
    const p = await db().get('SELECT id, currency FROM payments WHERE method = ? AND gateway_ref = ?', ['sslcommerz', v.tranId]);
    if (!p) throw new Error('Unknown transaction');
    if (p.currency && v.currency && p.currency !== v.currency) throw new Error('Currency mismatch');
    await completePayment(p.id, { gatewayAmountCents: v.amountCents, meta: { bank_tran_id: v.bankTranId, val_id: valId } });
    return redirect ? res.redirect(back('success')) : res.json({ ok: true });
  } catch (e) {
    if (tranId) await db().run("UPDATE payments SET status = 'failed' WHERE method = 'sslcommerz' AND gateway_ref = ? AND status = 'pending'", [String(tranId)]);
    return redirect ? res.redirect(back('failed')) : res.status(400).json({ error: e.message });
  }
}
r.post('/return/sslcommerz', express.urlencoded({ extended: false, limit: '64kb' }), (req, res) => handleSsl(req, res, true));
r.post('/webhooks/sslcommerz', express.urlencoded({ extended: false, limit: '64kb' }), (req, res) => handleSsl(req, res, false));

r.get('/return/bkash', async (req, res) => {
  const { paymentID, status } = req.query;
  if (status !== 'success' || !paymentID) return res.redirect(back(status === 'cancel' ? 'cancelled' : 'failed'));
  try {
    const out = await bkash.execute(String(paymentID));
    const p = await db().get('SELECT id FROM payments WHERE method = ? AND gateway_ref = ?', ['bkash', out.ref]);
    if (!p) throw new Error('Unknown transaction');
    await completePayment(p.id, { gatewayAmountCents: out.amountCents, meta: { trxID: out.trxID, paymentID } });
    res.redirect(back('success'));
  } catch { res.redirect(back('failed')); }
});

// ------------------------------------------------------------------ authenticated
r.use(authenticate, requireModule('billing'));

r.get('/gateways', async (_req, res) => res.json({ gateways: await enabledGateways() }));

r.get('/invoices', async (req, res) => {
  const { status, customer_id, q, page, pageSize, sort } = req.query;
  const where = []; const params = [];
  if (req.user.type === 'customer') { where.push('i.customer_id = ?'); params.push(req.user.customer_id); }
  else if (!can(req.user, 'billing.view')) throw forbidden();
  else if (customer_id) { where.push('i.customer_id = ?'); params.push(Number(customer_id)); }
  if (status) { where.push('i.status = ?'); params.push(String(status)); }
  if (q) { where.push(`(i.number ${ciLike()} ? OR u.name ${ciLike()} ? OR c.code ${ciLike()} ?)`); params.push(...Array(3).fill(`%${String(q).slice(0, 60)}%`)); }
  const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const from = `FROM invoices i JOIN customers c ON c.id = i.customer_id JOIN users u ON u.id = c.user_id ${w}`;
  const out = await paginate({
    base: `SELECT i.*, u.name AS customer_name, c.code AS customer_code ${from}`, countBase: `SELECT COUNT(*) AS n ${from}`,
    params, page, pageSize, sort, sortable: { number: 'i.number', total_cents: 'i.total_cents', due_date: 'i.due_date', status: 'i.status', issued_at: 'i.issued_at' }, defaultSort: 'i.id DESC',
  });
  res.json({ ...out, rows: out.rows.map(presentInvoice) });
});

async function loadInvoiceFor(req, id) {
  const inv = await db().get(`SELECT i.*, u.name AS customer_name, u.email AS customer_email, u.phone AS customer_phone, c.code AS customer_code, c.address AS customer_address, c.user_id
    FROM invoices i JOIN customers c ON c.id = i.customer_id JOIN users u ON u.id = c.user_id WHERE i.id = ?`, [id]);
  if (!inv) throw notFound();
  if (req.user.type === 'customer' ? inv.customer_id !== req.user.customer_id : !can(req.user, 'billing.view')) throw notFound();
  return inv;
}

r.get('/invoices/:id', async (req, res) => {
  const inv = await loadInvoiceFor(req, Number(req.params.id));
  const payments = await db().all('SELECT id, amount_cents, method, status, created_at, completed_at FROM payments WHERE invoice_id = ? ORDER BY id DESC', [inv.id]);
  res.json({ invoice: presentInvoice(inv), payments });
});

r.get('/invoices/:id/html', async (req, res) => {
  const inv = await loadInvoiceFor(req, Number(req.params.id));
  res.type('html').set('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'; img-src https: data:").send(await renderInvoiceHtml(presentInvoice(inv)));
});

const itemsSchema = z.array(z.object({ description: z.string().min(1).max(200), quantity: z.coerce.number().int().min(1).max(10000), unit_cents: z.coerce.number().int().min(0) })).min(1).max(50);

r.post('/invoices', requirePerm('billing.manage'), validate(z.object({
  customer_id: z.coerce.number().int().positive(), items: itemsSchema, due_date: z.string().datetime().optional(),
  discount_cents: z.coerce.number().int().min(0).optional(), notes: z.string().max(2000).optional(), notify: z.boolean().optional(),
})), async (req, res) => {
  if (!(await db().get('SELECT id FROM customers WHERE id = ?', [req.body.customer_id]))) throw notFound('Customer not found');
  const inv = await createInvoice({ customerId: req.body.customer_id, items: req.body.items, dueDate: req.body.due_date, discountCents: req.body.discount_cents, notes: req.body.notes });
  await audit(req, 'invoice.create', 'invoice', inv.id);
  if (req.body.notify !== false) await notifyInvoice(inv.id);
  res.status(201).json(inv);
});

r.post('/invoices/:id/void', requirePerm('billing.manage'), async (req, res) => {
  const inv = await db().get('SELECT * FROM invoices WHERE id = ?', [Number(req.params.id)]);
  if (!inv) throw notFound();
  if (Number(inv.paid_cents) > 0) throw badRequest('Invoice has payments; refund them first');
  await db().run("UPDATE invoices SET status = 'void' WHERE id = ?", [inv.id]);
  await audit(req, 'invoice.void', 'invoice', inv.id);
  res.json({ ok: true });
});

// Staff records an offline payment (cash, bank, mobile money).
r.post('/invoices/:id/record-payment', requirePerm('billing.collect', 'billing.manage'), validate(z.object({
  amount_cents: z.coerce.number().int().positive(), method: z.enum(['cash', 'bank', 'bkash_manual', 'nagad', 'rocket', 'card_pos', 'other']),
  reference: z.string().max(120).optional(),
})), async (req, res) => {
  const inv = await db().get('SELECT * FROM invoices WHERE id = ?', [Number(req.params.id)]);
  if (!inv) throw notFound();
  if (['paid', 'void'].includes(inv.status)) throw badRequest(`Invoice is ${inv.status}`);
  const remaining = Number(inv.total_cents) - Number(inv.paid_cents);
  if (req.body.amount_cents > remaining) throw badRequest('Amount exceeds the outstanding balance');
  const company = await getSetting('company');
  const p = await insert('payments', {
    invoice_id: inv.id, customer_id: inv.customer_id, amount_cents: req.body.amount_cents, currency: company.currency,
    method: req.body.method, gateway_ref: req.body.reference ? `${req.body.reference}`.slice(0, 120) : null, status: 'pending',
    received_by: req.user.id, meta: JSON.stringify({ recorded_by: req.user.name }), created_at: now(),
  });
  await completePayment(p.id);
  await audit(req, 'payment.record', 'payment', p.id, { invoice: inv.number, amount: req.body.amount_cents, method: req.body.method });
  res.status(201).json({ id: p.id });
});

// Customer (or staff on behalf) starts an online payment.
r.post('/invoices/:id/pay', requireModule('payments_online'), validate(z.object({ gateway: z.enum(['stripe', 'sslcommerz', 'bkash']) })), async (req, res) => {
  const inv = await loadInvoiceFor(req, Number(req.params.id));
  if (!['unpaid', 'overdue', 'partial'].includes(inv.status)) throw badRequest('This invoice cannot be paid');
  const amount = Number(inv.total_cents) - Number(inv.paid_cents);
  const company = await getSetting('company');
  const ref = `AURA-${inv.id}-${randomToken(9).replace(/[^A-Za-z0-9]/g, '')}`;
  const pay = await insert('payments', { invoice_id: inv.id, customer_id: inv.customer_id, amount_cents: amount, currency: company.currency, method: req.body.gateway, gateway_ref: ref, status: 'pending', created_at: now() });
  const customer = { name: inv.customer_name, email: inv.customer_email, phone: inv.customer_phone, address: inv.customer_address };
  try {
    const out = await GATEWAYS[req.body.gateway].init({ id: pay.id, amount_cents: amount, gateway_ref: ref, customer_id: inv.customer_id }, { invoice: inv, customer, currency: company.currency });
    await db().run('UPDATE payments SET meta = ? WHERE id = ?', [JSON.stringify({ init: { ...out, redirectUrl: undefined } }), pay.id]);
    res.json({ redirectUrl: out.redirectUrl, paymentId: pay.id });
  } catch (e) {
    await db().run("UPDATE payments SET status = 'failed', meta = ? WHERE id = ?", [JSON.stringify({ error: e.message }), pay.id]);
    throw badRequest(`Payment gateway error: ${e.message}`);
  }
});

r.get('/payments', async (req, res) => {
  const { status, method, customer_id, page, pageSize } = req.query;
  const where = []; const params = [];
  if (req.user.type === 'customer') { where.push('p.customer_id = ?'); params.push(req.user.customer_id); }
  else if (!can(req.user, 'billing.view')) throw forbidden();
  else if (customer_id) { where.push('p.customer_id = ?'); params.push(Number(customer_id)); }
  if (status) { where.push('p.status = ?'); params.push(String(status)); }
  if (method) { where.push('p.method = ?'); params.push(String(method)); }
  const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const from = `FROM payments p JOIN customers c ON c.id = p.customer_id JOIN users u ON u.id = c.user_id LEFT JOIN invoices i ON i.id = p.invoice_id ${w}`;
  const out = await paginate({ base: `SELECT p.id, p.invoice_id, p.customer_id, p.amount_cents, p.currency, p.method, p.status, p.gateway_ref, p.created_at, p.completed_at, u.name AS customer_name, c.code AS customer_code, i.number AS invoice_number ${from}`, countBase: `SELECT COUNT(*) AS n ${from}`, params, page, pageSize, defaultSort: 'p.id DESC' });
  res.json(out);
});

r.post('/run/:job', requirePerm('billing.manage'), async (req, res) => {
  if (req.params.job === 'generate') return res.json({ created: await generateRecurringInvoices() });
  if (req.params.job === 'overdue') return res.json({ suspended: await enforceOverdue() });
  throw notFound();
});

r.get('/summary', requirePerm('billing.view'), async (_req, res) => {
  const monthStart = new Date(); monthStart.setUTCDate(1); monthStart.setUTCHours(0, 0, 0, 0);
  const [collected, outstanding, overdue, byMethod] = await Promise.all([
    db().get("SELECT COALESCE(SUM(amount_cents),0) AS v FROM payments WHERE status = 'success' AND method != 'balance' AND completed_at >= ?", [monthStart.toISOString()]),
    db().get("SELECT COALESCE(SUM(total_cents - paid_cents),0) AS v, COUNT(*) AS n FROM invoices WHERE status IN ('unpaid','partial','overdue')"),
    db().get("SELECT COALESCE(SUM(total_cents - paid_cents),0) AS v, COUNT(*) AS n FROM invoices WHERE status = 'overdue'"),
    db().all("SELECT method, COALESCE(SUM(amount_cents),0) AS v, COUNT(*) AS n FROM payments WHERE status = 'success' AND method != 'balance' AND completed_at >= ? GROUP BY method", [monthStart.toISOString()]),
  ]);
  res.json({ collectedThisMonth: Number(collected.v), outstanding: Number(outstanding.v), outstandingCount: Number(outstanding.n), overdue: Number(overdue.v), overdueCount: Number(overdue.n), byMethod });
});

export default r;
