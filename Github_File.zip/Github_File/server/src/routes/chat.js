// Live chat: visitors/customers hand off from the chatbot to a human agent; agents work from the CRM inbox.
// Visitors are authenticated per conversation by a random token (hashed at rest); signed-in customers by session.
import { Router } from 'express';
import { z } from 'zod';
import { db, insert, now, paginate } from '../db/index.js';
import { validate, notFound, badRequest, forbidden } from '../lib/http.js';
import { authenticate, optionalAuth, requirePerm, requireModule, can } from '../middleware/auth.js';
import { randomToken, sha256, safeEqual } from '../lib/crypto.js';
import { sendToUser } from '../lib/events.js';
import { queueNotify } from '../lib/notify.js';
import { chatLimiter } from '../middleware/security.js';
import { audit } from '../lib/audit.js';

const r = Router();
const body = z.string().trim().min(1).max(2000);

/** Notify every active agent (chat.handle) — realtime + push. */
async function notifyAgents(title, text, conversationId, onlyUserId = null) {
  const staff = onlyUserId ? [{ id: onlyUserId, type: 'staff', permissions: '["chat.handle"]' }]
    : await db().all("SELECT u.id, u.type, r.permissions FROM users u LEFT JOIN roles r ON r.id = u.role_id WHERE u.type IN ('admin','staff') AND u.status = 'active'");
  for (const s of staff) {
    const perms = JSON.parse(s.permissions || '[]');
    if (s.type !== 'admin' && !perms.includes('*') && !perms.includes('chat.handle')) continue;
    sendToUser(s.id, 'chat', { conversationId, title, body: text.slice(0, 200) });
    queueNotify({ userId: s.id, channels: ['push'], subject: title, body: text.slice(0, 200), link: `/admin/chat?c=${conversationId}` });
  }
}

const publicMessages = (rows) => rows.map((m) => ({ id: m.id, sender: m.sender, body: m.body, name: m.sender === 'agent' ? m.agent_name || 'Agent' : null, avatar: m.sender === 'agent' ? m.agent_avatar : null, created_at: m.created_at }));

async function loadForVisitor(req, id) {
  if (!Number.isInteger(id) || id <= 0) throw notFound();
  const c = await db().get('SELECT * FROM chat_conversations WHERE id = ?', [id]);
  if (!c) throw notFound();
  const tok = String(req.get('x-chat-token') || '');
  const owner = req.user && c.user_id && req.user.id === c.user_id;
  if (!owner && !(tok && safeEqual(sha256(tok), c.token_hash))) throw notFound();
  return c;
}

// ------------------------------------------------------------------ visitor / customer side
r.post('/start', chatLimiter, requireModule('livechat'), optionalAuth, validate(z.object({
  name: z.string().trim().min(2).max(80).optional(), contact: z.string().trim().min(5).max(120).optional(),
  topic: z.string().trim().max(120).optional(), message: body, website: z.string().max(0).optional(),
})), async (req, res) => {
  if (req.body.website) return res.json({ ok: true }); // honeypot
  const u = req.user?.type === 'customer' ? req.user : null; // only customers are linked to their account
  if (!u && (!req.body.name || !req.body.contact)) throw badRequest('Please tell us your name and phone or email');
  const token = randomToken(24);
  const ts = now();
  const customer = u?.type === 'customer' ? u.customer_id : null;
  const conv = await insert('chat_conversations', {
    customer_id: customer, user_id: u?.id || null, guest_name: u ? u.name : req.body.name, guest_contact: u ? (u.phone || u.email) : req.body.contact,
    token_hash: sha256(token), status: 'waiting', topic: req.body.topic || null, unread_staff: 1, last_message_at: ts, created_at: ts,
  });
  await insert('chat_messages', { conversation_id: conv.id, sender: 'visitor', user_id: u?.id || null, body: req.body.message, created_at: ts });
  await insert('chat_messages', { conversation_id: conv.id, sender: 'system', body: 'Thanks! An agent will join shortly. You can keep typing.', created_at: ts });
  await notifyAgents(`New chat from ${u ? u.name : req.body.name}`, req.body.message, conv.id);
  res.status(201).json({ id: conv.id, token });
});

r.get('/:id/messages', chatLimiter, optionalAuth, async (req, res) => {
  const c = await loadForVisitor(req, Number(req.params.id));
  const after = Number(req.query.after) || 0;
  const rows = await db().all(`SELECT m.*, u.name AS agent_name, u.avatar AS agent_avatar FROM chat_messages m LEFT JOIN users u ON u.id = m.user_id
    WHERE m.conversation_id = ? AND m.id > ? ORDER BY m.id LIMIT 200`, [c.id, after]);
  if (c.unread_visitor) await db().run('UPDATE chat_conversations SET unread_visitor = 0 WHERE id = ?', [c.id]);
  const agent = c.assigned_to ? await db().get('SELECT name, avatar FROM users WHERE id = ?', [c.assigned_to]) : null;
  res.json({ status: c.status, agent, messages: publicMessages(rows) });
});

r.post('/:id/messages', chatLimiter, optionalAuth, validate(z.object({ body })), async (req, res) => {
  const c = await loadForVisitor(req, Number(req.params.id));
  if (c.status === 'closed') throw badRequest('This chat has ended — start a new one');
  const ts = now();
  const m = await insert('chat_messages', { conversation_id: c.id, sender: 'visitor', user_id: req.user?.id || null, body: req.body.body, created_at: ts });
  await db().run('UPDATE chat_conversations SET unread_staff = unread_staff + 1, last_message_at = ? WHERE id = ?', [ts, c.id]);
  await notifyAgents(`Message from ${c.guest_name}`, req.body.body, c.id, c.assigned_to || null);
  res.status(201).json({ id: m.id });
});

r.post('/:id/end', chatLimiter, optionalAuth, async (req, res) => {
  const c = await loadForVisitor(req, Number(req.params.id));
  await db().run("UPDATE chat_conversations SET status = 'closed', closed_at = ? WHERE id = ?", [now(), c.id]);
  await insert('chat_messages', { conversation_id: c.id, sender: 'system', body: 'The visitor ended the chat.', created_at: now() });
  res.json({ ok: true });
});

// ------------------------------------------------------------------ agent side (CRM inbox)
const agent = [authenticate, requireModule('livechat'), requirePerm('chat.handle', 'crm.manage')];

r.get('/conversations', ...agent, async (req, res) => {
  const { status, mine, page } = req.query;
  const where = []; const params = [];
  if (status === 'open') where.push("c.status IN ('waiting','active')");
  else if (status) { where.push('c.status = ?'); params.push(String(status)); }
  if (mine === '1') { where.push('c.assigned_to = ?'); params.push(req.user.id); }
  const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const from = `FROM chat_conversations c LEFT JOIN users a ON a.id = c.assigned_to LEFT JOIN customers cu ON cu.id = c.customer_id ${w}`;
  const out = await paginate({ base: `SELECT c.id, c.customer_id, c.guest_name, c.guest_contact, c.status, c.topic, c.assigned_to, c.unread_staff, c.last_message_at, c.created_at, c.lead_id, c.ticket_id, a.name AS agent_name, cu.code AS customer_code ${from}`, countBase: `SELECT COUNT(*) AS n ${from}`, params, page, pageSize: 50, defaultSort: 'c.last_message_at DESC' });
  const waiting = await db().get("SELECT COUNT(*) AS n FROM chat_conversations WHERE status = 'waiting'");
  res.json({ ...out, waiting: Number(waiting.n) });
});

async function loadForAgent(id) {
  const c = await db().get('SELECT * FROM chat_conversations WHERE id = ?', [id]);
  if (!c) throw notFound();
  return c;
}

r.get('/conversations/:id', ...agent, async (req, res) => {
  const c = await loadForAgent(Number(req.params.id));
  const messages = await db().all('SELECT m.id, m.sender, m.body, m.created_at, u.name, u.avatar FROM chat_messages m LEFT JOIN users u ON u.id = m.user_id WHERE m.conversation_id = ? ORDER BY m.id', [c.id]);
  await db().run('UPDATE chat_conversations SET unread_staff = 0 WHERE id = ?', [c.id]);
  const customer = c.customer_id ? await db().get(`SELECT c.id, c.code, c.status, c.area, u.email, u.phone, p.name AS plan_name FROM customers c JOIN users u ON u.id = c.user_id LEFT JOIN plans p ON p.id = c.plan_id WHERE c.id = ?`, [c.customer_id]) : null;
  const { token_hash, ...safe } = c;
  res.json({ conversation: safe, messages, customer });
});

r.post('/conversations/:id/claim', ...agent, async (req, res) => {
  const c = await loadForAgent(Number(req.params.id));
  if (c.assigned_to && c.assigned_to !== req.user.id && req.user.type !== 'admin') throw forbidden('Another agent is handling this chat');
  await db().run("UPDATE chat_conversations SET assigned_to = ?, status = 'active' WHERE id = ?", [req.user.id, c.id]);
  await insert('chat_messages', { conversation_id: c.id, sender: 'system', body: `${req.user.name} joined the chat.`, created_at: now() });
  if (c.user_id) sendToUser(c.user_id, 'chat', { conversationId: c.id });
  res.json({ ok: true });
});

r.post('/conversations/:id/reply', ...agent, validate(z.object({ body })), async (req, res) => {
  const c = await loadForAgent(Number(req.params.id));
  if (c.status === 'closed') throw badRequest('Chat is closed');
  const ts = now();
  if (!c.assigned_to) {
    await db().run("UPDATE chat_conversations SET assigned_to = ?, status = 'active' WHERE id = ?", [req.user.id, c.id]);
    await insert('chat_messages', { conversation_id: c.id, sender: 'system', body: `${req.user.name} joined the chat.`, created_at: ts });
  }
  const m = await insert('chat_messages', { conversation_id: c.id, sender: 'agent', user_id: req.user.id, body: req.body.body, created_at: ts });
  await db().run('UPDATE chat_conversations SET unread_visitor = unread_visitor + 1, last_message_at = ? WHERE id = ?', [ts, c.id]);
  if (c.user_id) { sendToUser(c.user_id, 'chat', { conversationId: c.id }); queueNotify({ userId: c.user_id, channels: ['push'], subject: `${req.user.name} replied`, body: req.body.body.slice(0, 160) }); }
  res.status(201).json({ id: m.id });
});

r.post('/conversations/:id/close', ...agent, async (req, res) => {
  const c = await loadForAgent(Number(req.params.id));
  await db().run("UPDATE chat_conversations SET status = 'closed', closed_at = ? WHERE id = ?", [now(), c.id]);
  await insert('chat_messages', { conversation_id: c.id, sender: 'system', body: `${req.user.name} ended the chat. Thank you for contacting us!`, created_at: now() });
  if (c.user_id) sendToUser(c.user_id, 'chat', { conversationId: c.id });
  res.json({ ok: true });
});

// Turn a sales conversation into a CRM lead (or a support conversation into a ticket).
r.post('/conversations/:id/lead', ...agent, async (req, res) => {
  const c = await loadForAgent(Number(req.params.id));
  if (c.lead_id) return res.json({ id: c.lead_id });
  // Visitors type free text as their contact. Only a real email/phone goes into those fields (the lead form validates
  // them, so anything else would make the lead impossible to save); the raw text is kept in the notes.
  const raw = String(c.guest_contact || '').trim();
  const email = z.string().email().max(190).safeParse(raw).success ? raw.toLowerCase() : null;
  const phone = !email && /^\+?[\d\s().-]{6,20}$/.test(raw) ? raw : null;
  const first = await db().get("SELECT body FROM chat_messages WHERE conversation_id = ? AND sender = 'visitor' ORDER BY id LIMIT 1", [c.id]);
  const l = await insert('leads', { name: c.guest_name || 'Chat visitor', email, phone, source: 'chatbot', status: 'contacted', assigned_to: req.user.id, notes: `From live chat #${c.id}${raw && !email && !phone ? ` (contact: ${raw})` : ''}: ${first?.body || ''}`.slice(0, 2000), created_at: now(), updated_at: now() });
  await db().run('UPDATE chat_conversations SET lead_id = ? WHERE id = ?', [l.id, c.id]);
  await audit(req, 'chat.to_lead', 'lead', l.id, { conversation: c.id });
  res.status(201).json({ id: l.id });
});

r.post('/conversations/:id/ticket', ...agent, async (req, res) => {
  const c = await loadForAgent(Number(req.params.id));
  if (c.ticket_id) return res.json({ id: c.ticket_id });
  if (!c.customer_id) throw badRequest('Only signed-in customers can have a ticket — convert to a lead instead');
  const msgs = await db().all('SELECT sender, body FROM chat_messages WHERE conversation_id = ? ORDER BY id', [c.id]);
  const max = await db().get('SELECT MAX(id) AS n FROM tickets');
  const number = `T-${String(Number(max.n || 0) + 1001).padStart(6, '0')}-C${c.id}`;
  const t = await insert('tickets', { number, customer_id: c.customer_id, created_by: req.user.id, subject: c.topic || `Live chat #${c.id}`, category: 'general', priority: 'normal', status: 'open', assigned_to: req.user.id, created_at: now(), updated_at: now() });
  await insert('ticket_messages', { ticket_id: t.id, user_id: req.user.id, body: msgs.map((m) => `[${m.sender}] ${m.body}`).join('\n').slice(0, 10000), internal: 1, created_at: now() });
  await db().run('UPDATE chat_conversations SET ticket_id = ? WHERE id = ?', [t.id, c.id]);
  res.status(201).json({ id: t.id });
});

export const chatHandles = (u) => can(u, 'chat.handle') || can(u, 'crm.manage');
export default r;
