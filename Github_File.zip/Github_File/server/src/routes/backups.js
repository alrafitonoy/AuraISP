import { Router } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import multer from 'multer';
import { z } from 'zod';
import config from '../config.js';
import { db, parseJson, withAdvisoryLock } from '../db/index.js';
import { validate, notFound, badRequest } from '../lib/http.js';
import { authenticate, requirePerm, requireAdmin } from '../middleware/auth.js';
import { verifyPassword } from '../lib/crypto.js';
import { audit } from '../lib/audit.js';
import { getSetting, setSetting } from '../lib/settings.js';
import { createBackup, restoreBackup, registerUpload, backupPath, BACKUP_DIR, KINDS } from '../backup.js';

const r = Router();
r.use(authenticate, requirePerm('backups.manage'));

/** Sensitive actions (download, restore, delete) require the admin to re-enter their password. */
async function confirmPassword(req) {
  const u = await db().get('SELECT password_hash FROM users WHERE id = ?', [req.user.id]);
  if (!req.body?.password || !(await verifyPassword(u.password_hash, req.body.password))) throw badRequest('Password is incorrect');
}
const present = (b) => ({ ...b, encrypted: !!b.encrypted, manifest: parseJson(b.manifest, null), exists: fs.existsSync(path.join(BACKUP_DIR, b.file)) });

// Cluster-wide mutual exclusion (any worker / server): only one backup or restore at a time.
const exclusive = async (fn) => {
  const out = await withAdvisoryLock('aura:backup', fn);
  if (out.busy) throw badRequest('Another backup or restore is running');
  return out.result;
};

r.get('/', async (_req, res) => {
  const rows = await db().all('SELECT * FROM backups ORDER BY id DESC LIMIT 200');
  res.json({ backups: rows.map(present), settings: await getSetting('backup'), kinds: KINDS });
});

r.post('/', validate(z.object({
  kind: z.enum(KINDS), includeEnv: z.boolean().optional(),
  passphrase: z.string().max(200).optional().refine((p) => !p || p.length >= 12, 'Passphrase must be at least 12 characters'),
})), async (req, res) => {
  if (req.body.includeEnv && req.user.type !== 'admin') throw badRequest('Only administrators can include the master key');
  if (req.body.includeEnv && !req.body.passphrase) throw badRequest('A passphrase is required when the .env (master key) is included');
  const out = await exclusive(() => createBackup({ ...req.body, trigger: `manual:${req.user.email}` }));
  await audit(req, 'backup.create', 'backup', out.id, { kind: out.kind, encrypted: out.encrypted, includeEnv: !!req.body.includeEnv });
  res.status(201).json(present(out));
});

r.put('/settings', validate(z.object({
  auto: z.boolean(), kind: z.enum(KINDS), hour: z.coerce.number().int().min(0).max(23), keep: z.coerce.number().int().min(1).max(365),
})), async (req, res) => {
  await setSetting('backup', req.body);
  await audit(req, 'backup.settings', null, null, req.body);
  res.json({ ok: true });
});

r.post('/:id/download', validate(z.object({ password: z.string().max(128) })), async (req, res) => {
  await confirmPassword(req);
  const b = await db().get('SELECT * FROM backups WHERE id = ?', [Number(req.params.id)]);
  if (!b) throw notFound();
  const full = backupPath(b.file);
  if (!fs.existsSync(full)) throw notFound('Backup file is missing');
  await audit(req, 'backup.download', 'backup', b.id);
  res.download(full, b.file);
});

r.post('/:id/restore', requireAdmin, validate(z.object({
  password: z.string().max(128), passphrase: z.string().max(200).optional(), restoreFiles: z.boolean().optional(), restoreEnv: z.boolean().optional(),
})), async (req, res) => {
  await confirmPassword(req);
  const b = await db().get('SELECT * FROM backups WHERE id = ?', [Number(req.params.id)]);
  if (!b) throw notFound();
  await audit(req, 'backup.restore_start', 'backup', b.id);
  let out;
  try {
    out = await exclusive(() => restoreBackup(b, { passphrase: req.body.passphrase, restoreFiles: req.body.restoreFiles !== false, restoreEnv: !!req.body.restoreEnv }));
  } catch (e) {
    await audit(req, 'backup.restore_failed', 'backup', b.id, { error: e.message });
    throw badRequest(`Restore failed: ${e.message}`);
  }
  await audit({ ...req }, 'backup.restored', 'backup', b.id, { restored: out.restored, safety: out.safetyBackup });
  res.json(out);
});

r.delete('/:id', validate(z.object({ password: z.string().max(128) })), async (req, res) => {
  await confirmPassword(req);
  const b = await db().get('SELECT * FROM backups WHERE id = ?', [Number(req.params.id)]);
  if (!b) throw notFound();
  fs.rmSync(backupPath(b.file), { force: true });
  await db().run('DELETE FROM backups WHERE id = ?', [b.id]);
  await audit(req, 'backup.delete', 'backup', b.id, { file: b.file });
  res.json({ ok: true });
});

const upload = multer({
  storage: multer.diskStorage({ destination: (_q, _f, cb) => { fs.mkdirSync(BACKUP_DIR, { recursive: true }); cb(null, BACKUP_DIR); }, filename: (_q, _f, cb) => cb(null, `.upload-${Date.now()}-${Math.random().toString(36).slice(2)}`) }),
  limits: { fileSize: 2 * 1024 * 1024 * 1024, files: 1 },
});
r.post('/upload', requireAdmin, upload.single('file'), async (req, res) => {
  if (!req.file) throw badRequest('No file uploaded');
  const out = await registerUpload(req.file.path, req.file.originalname);
  await audit(req, 'backup.upload', 'backup', out.id, { size: out.size });
  res.status(201).json(present(out));
});

export default r;
