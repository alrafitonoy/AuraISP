// Zones / areas (POPs, regions): a tree of zones that customers, routers, warehouses, jobs, expenses and map sites belong to.
import { Router } from 'express';
import { z } from 'zod';
import { db, insert, update, now, paginate, ciLike } from '../db/index.js';
import { validate, notFound, badRequest, conflict } from '../lib/http.js';
import { authenticate, requirePerm, requireModule } from '../middleware/auth.js';
import { audit } from '../lib/audit.js';

const r = Router();
r.use(authenticate, requireModule('zones'));

// Read access also for customers.view so zone pickers / filters work on the customer pages.
const canRead = requirePerm('zones.manage', 'customers.view');
const canManage = requirePerm('zones.manage');

const pid = (req) => { const n = Number(req.params.id); if (!Number.isInteger(n) || n <= 0) throw notFound('Zone not found'); return n; };
const optId = z.preprocess((v) => (v === '' ? null : v), z.coerce.number().int().positive().optional().nullable());
const optText = (max) => z.preprocess((v) => (typeof v === 'string' && v.trim() === '' ? null : v), z.string().trim().max(max).optional().nullable());
const OPEN_INVOICE = "('unpaid','partial','overdue')";
// Tables (other than customers/routers) whose zone_id must be cleared when a zone is deleted. Fixed list, never user input.
const OTHER_ZONE_REFS = ['inv_warehouses', 'jobs', 'expenses', 'network_sites'];

async function getZone(id, conn = db()) {
  const zone = await conn.get('SELECT * FROM zones WHERE id = ?', [id]);
  if (!zone) throw notFound('Zone not found');
  return zone;
}

/** Per-zone statistics keyed by zone id ('none' = not in any zone). */
async function zoneStats() {
  const [cust, revenue, routers, dues] = await Promise.all([
    db().all("SELECT zone_id, COUNT(*) AS n, SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS a FROM customers GROUP BY zone_id"),
    db().all("SELECT c.zone_id, COALESCE(SUM(p.price_cents), 0) AS v FROM customers c JOIN plans p ON p.id = c.plan_id WHERE c.status = 'active' GROUP BY c.zone_id"),
    db().all('SELECT zone_id, COUNT(*) AS n FROM routers GROUP BY zone_id'),
    db().all(`SELECT c.zone_id, COALESCE(SUM(i.total_cents - i.paid_cents), 0) AS v, COUNT(*) AS n FROM invoices i JOIN customers c ON c.id = i.customer_id
      WHERE i.status IN ${OPEN_INVOICE} GROUP BY c.zone_id`),
  ]);
  const map = new Map();
  const get = (k) => {
    const key = k == null ? 'none' : String(Number(k));
    if (!map.has(key)) map.set(key, { customers: 0, active_customers: 0, routers: 0, expected_revenue_cents: 0, outstanding_cents: 0, open_invoices: 0 });
    return map.get(key);
  };
  for (const x of cust) { const s = get(x.zone_id); s.customers = Number(x.n); s.active_customers = Number(x.a || 0); }
  for (const x of revenue) get(x.zone_id).expected_revenue_cents = Number(x.v);
  for (const x of routers) get(x.zone_id).routers = Number(x.n);
  for (const x of dues) { const s = get(x.zone_id); s.outstanding_cents = Number(x.v); s.open_invoices = Number(x.n); }
  return { of: (k) => ({ ...get(k) }) };
}

const STAT_KEYS = ['customers', 'active_customers', 'routers', 'expected_revenue_cents', 'outstanding_cents', 'open_invoices'];

/** Attach own stats and subtree totals (zone + all descendants) to every zone. */
function withTotals(zones, stats) {
  const byParent = new Map();
  for (const z of zones) { const k = z.parent_id ?? 0; if (!byParent.has(k)) byParent.set(k, []); byParent.get(k).push(z); }
  const out = new Map(zones.map((z) => [z.id, { ...z, stats: stats.of(z.id) }]));
  const memo = new Map();
  const total = (id, seen = new Set()) => {
    if (memo.has(id)) return memo.get(id);
    if (seen.has(id)) return Object.fromEntries(STAT_KEYS.map((k) => [k, 0])); // defensive: never loop on bad data
    seen.add(id);
    const t = { ...out.get(id).stats };
    for (const child of byParent.get(id) || []) { const c = total(child.id, seen); for (const k of STAT_KEYS) t[k] += c[k]; }
    memo.set(id, t);
    return t;
  };
  return zones.map((z) => ({ ...out.get(z.id), totals: total(z.id), children: (byParent.get(z.id) || []).length }));
}

/** Throws if making `parentId` the parent of zone `id` would create a cycle (or the parent does not exist). */
async function assertParent(id, parentId) {
  if (parentId == null) return;
  if (id != null && parentId === id) throw badRequest('A zone cannot be its own parent');
  const rows = await db().all('SELECT id, parent_id FROM zones');
  const parentOf = new Map(rows.map((x) => [Number(x.id), x.parent_id == null ? null : Number(x.parent_id)]));
  if (!parentOf.has(parentId)) throw badRequest('Unknown parent zone');
  let cur = parentId; const seen = new Set();
  while (cur != null && !seen.has(cur)) {
    if (cur === id) throw badRequest('That parent is inside this zone — it would create a loop');
    seen.add(cur); cur = parentOf.get(cur) ?? null;
  }
}

async function assertManager(managerId) {
  if (managerId == null) return;
  const u = await db().get("SELECT id FROM users WHERE id = ? AND type IN ('admin','staff')", [managerId]);
  if (!u) throw badRequest('The manager must be a staff user');
}

async function assertUniqueName(name, exceptId = null) {
  if (await db().get('SELECT id FROM zones WHERE LOWER(name) = LOWER(?) AND id != ?', [name, exceptId ?? 0])) throw conflict('A zone with that name already exists');
}

// ------------------------------------------------------------------ read
r.get('/', canRead, async (req, res) => {
  const zones = await db().all(`SELECT z.id, z.name, z.parent_id, z.manager_id, z.notes, z.created_at, u.name AS manager_name
    FROM zones z LEFT JOIN users u ON u.id = z.manager_id ORDER BY z.name`);
  if (req.query.lite === '1' || req.query.lite === 'true') {
    return res.json({ zones: zones.map(({ id, name, parent_id }) => ({ id, name, parent_id })) });
  }
  const stats = await zoneStats();
  res.json({ zones: withTotals(zones, stats), unassigned: stats.of(null) });
});

// Distinct customer "area" values with how many customers are in each and how many are not yet in a zone.
r.get('/areas', canManage, async (_req, res) => {
  const rows = await db().all(`SELECT area, COUNT(*) AS n, SUM(CASE WHEN zone_id IS NULL THEN 1 ELSE 0 END) AS unassigned FROM customers
    WHERE area IS NOT NULL AND area != '' GROUP BY area ORDER BY area`);
  res.json({ areas: rows.map((a) => ({ area: a.area, customers: Number(a.n), unassigned: Number(a.unassigned || 0) })) });
});

// Staff users that can manage a zone (for the manager picker; zones.manage may not include staff.manage).
r.get('/staff', canManage, async (_req, res) => {
  const rows = await db().all("SELECT id, name, email FROM users WHERE type IN ('admin','staff') AND status = 'active' ORDER BY name");
  res.json({ staff: rows });
});

r.get('/routers', canManage, async (_req, res) => {
  const rows = await db().all('SELECT r.id, r.name, r.location, r.status, r.zone_id, z.name AS zone_name FROM routers r LEFT JOIN zones z ON z.id = r.zone_id ORDER BY r.name');
  res.json({ routers: rows });
});

r.get('/:id', canRead, async (req, res) => {
  const zone = await db().get('SELECT z.*, u.name AS manager_name, p.name AS parent_name FROM zones z LEFT JOIN users u ON u.id = z.manager_id LEFT JOIN zones p ON p.id = z.parent_id WHERE z.id = ?', [pid(req)]);
  if (!zone) throw notFound('Zone not found');
  const all = await db().all('SELECT id, name, parent_id, manager_id, notes, created_at FROM zones');
  const enriched = withTotals(all, await zoneStats()).find((x) => x.id === zone.id);
  const routers = await db().all('SELECT id, name, location, status FROM routers WHERE zone_id = ? ORDER BY name', [zone.id]);
  res.json({ zone: { ...zone, stats: enriched.stats, totals: enriched.totals, children: enriched.children }, routers });
});

const customersQuery = z.object({
  q: z.string().max(80).optional(), status: z.enum(['pending', 'active', 'suspended', 'terminated']).optional().or(z.literal('')),
  page: z.coerce.number().int().positive().optional(), pageSize: z.coerce.number().int().positive().max(200).optional(),
});
r.get('/:id/customers', canRead, validate(customersQuery, 'query'), async (req, res) => {
  const zone = await getZone(pid(req));
  const where = ['c.zone_id = ?']; const params = [zone.id];
  if (req.query.status) { where.push('c.status = ?'); params.push(req.query.status); }
  if (req.query.q) {
    const like = `%${req.query.q.trim()}%`;
    where.push(`(u.name ${ciLike()} ? OR u.phone ${ciLike()} ? OR c.code ${ciLike()} ? OR c.area ${ciLike()} ?)`); params.push(like, like, like, like);
  }
  const from = `FROM customers c JOIN users u ON u.id = c.user_id LEFT JOIN plans p ON p.id = c.plan_id WHERE ${where.join(' AND ')}`;
  const out = await paginate({
    base: `SELECT c.id, c.code, c.status, c.area, c.address, c.next_due_date, u.name, u.phone, u.email, p.name AS plan_name, p.price_cents,
      (SELECT COALESCE(SUM(i.total_cents - i.paid_cents), 0) FROM invoices i WHERE i.customer_id = c.id AND i.status IN ${OPEN_INVOICE}) AS due_cents ${from}`,
    countBase: `SELECT COUNT(*) AS n ${from}`, params, page: req.query.page, pageSize: req.query.pageSize || 25, defaultSort: 'u.name ASC',
  });
  res.json({ ...out, rows: out.rows.map((x) => ({ ...x, due_cents: Number(x.due_cents || 0), price_cents: x.price_cents == null ? null : Number(x.price_cents) })) });
});

// ------------------------------------------------------------------ write
const zoneSchema = z.object({
  name: z.string().trim().min(2).max(120),
  parent_id: optId,
  manager_id: optId,
  notes: optText(250),
});

r.post('/', canManage, validate(zoneSchema), async (req, res) => {
  await assertUniqueName(req.body.name);
  await assertParent(null, req.body.parent_id ?? null);
  await assertManager(req.body.manager_id ?? null);
  const out = await insert('zones', { ...req.body, created_at: now() });
  await audit(req, 'zones.create', 'zone', out.id, { name: req.body.name });
  res.status(201).json({ id: out.id });
});

r.put('/:id', canManage, validate(zoneSchema.partial()), async (req, res) => {
  const zone = await getZone(pid(req));
  if (req.body.name !== undefined) await assertUniqueName(req.body.name, zone.id);
  if (req.body.parent_id !== undefined) await assertParent(zone.id, req.body.parent_id);
  if (req.body.manager_id !== undefined) await assertManager(req.body.manager_id);
  await update('zones', zone.id, req.body);
  await audit(req, 'zones.update', 'zone', zone.id, { fields: Object.keys(req.body) });
  res.json({ ok: true });
});

// Members (customers, routers, warehouses, jobs, expenses, map sites) are kept and simply leave the zone;
// sub-zones move up to the deleted zone's parent. Explicit UPDATEs because MySQL ignores inline ON DELETE rules.
r.delete('/:id', canManage, async (req, res) => {
  const zone = await getZone(pid(req));
  const moved = await db().transaction(async (t) => {
    const c = await t.run('UPDATE customers SET zone_id = NULL WHERE zone_id = ?', [zone.id]);
    const ro = await t.run('UPDATE routers SET zone_id = NULL WHERE zone_id = ?', [zone.id]);
    for (const table of OTHER_ZONE_REFS) await t.run(`UPDATE ${table} SET zone_id = NULL WHERE zone_id = ?`, [zone.id]);
    const sub = await t.run('UPDATE zones SET parent_id = ? WHERE parent_id = ?', [zone.parent_id ?? null, zone.id]);
    await t.run('DELETE FROM zones WHERE id = ?', [zone.id]);
    return { customers: c.changes, routers: ro.changes, subzones: sub.changes };
  });
  await audit(req, 'zones.delete', 'zone', zone.id, { name: zone.name, ...moved });
  res.json({ ok: true, ...moved });
});

const idsSchema = (key) => z.object({ [key]: z.array(z.coerce.number().int().positive()).min(1).max(5000) });
const inList = (ids) => ids.map(() => '?').join(',');

r.post('/:id/customers', canManage, validate(idsSchema('customer_ids')), async (req, res) => {
  const zone = await getZone(pid(req));
  const ids = [...new Set(req.body.customer_ids)];
  const out = await db().run(`UPDATE customers SET zone_id = ?, updated_at = ? WHERE id IN (${inList(ids)})`, [zone.id, now(), ...ids]);
  await audit(req, 'zones.assign_customers', 'zone', zone.id, { requested: ids.length, updated: out.changes });
  res.json({ ok: true, updated: out.changes });
});

r.post('/:id/customers/remove', canManage, validate(idsSchema('customer_ids')), async (req, res) => {
  const zone = await getZone(pid(req));
  const ids = [...new Set(req.body.customer_ids)];
  const out = await db().run(`UPDATE customers SET zone_id = NULL, updated_at = ? WHERE zone_id = ? AND id IN (${inList(ids)})`, [now(), zone.id, ...ids]);
  await audit(req, 'zones.remove_customers', 'zone', zone.id, { removed: out.changes });
  res.json({ ok: true, removed: out.changes });
});

r.post('/:id/assign-area', canManage, validate(z.object({ area: z.string().trim().min(1).max(120), only_unassigned: z.boolean().optional() })), async (req, res) => {
  const zone = await getZone(pid(req));
  const params = [zone.id, now(), req.body.area];
  const out = await db().run(`UPDATE customers SET zone_id = ?, updated_at = ? WHERE LOWER(TRIM(area)) = LOWER(?)${req.body.only_unassigned ? ' AND zone_id IS NULL' : ''}`, params);
  await audit(req, 'zones.assign_area', 'zone', zone.id, { area: req.body.area, updated: out.changes });
  res.json({ ok: true, updated: out.changes });
});

r.post('/:id/routers', canManage, validate(z.object({ router_ids: z.array(z.coerce.number().int().positive()).max(1000) })), async (req, res) => {
  const zone = await getZone(pid(req));
  const ids = [...new Set(req.body.router_ids)];
  // Replace the zone's router set: selected routers join, routers no longer selected leave.
  const out = await db().transaction(async (t) => {
    const removed = ids.length
      ? await t.run(`UPDATE routers SET zone_id = NULL WHERE zone_id = ? AND id NOT IN (${inList(ids)})`, [zone.id, ...ids])
      : await t.run('UPDATE routers SET zone_id = NULL WHERE zone_id = ?', [zone.id]);
    const added = ids.length ? await t.run(`UPDATE routers SET zone_id = ? WHERE id IN (${inList(ids)})`, [zone.id, ...ids]) : { changes: 0 };
    return { removed: removed.changes, assigned: added.changes };
  });
  await audit(req, 'zones.routers', 'zone', zone.id, out);
  res.json({ ok: true, ...out });
});

export default r;
