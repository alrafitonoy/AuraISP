import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db/index.js';
import { validate, notFound, forbidden } from '../lib/http.js';
import { authenticate, requirePerm, requireModule, can } from '../middleware/auth.js';
import { audit } from '../lib/audit.js';
import { invoicePdf, customerReport, accountsReport, salesReport, overallReport, parseItems, paymentReceiptPdf, paymentQuery } from '../reports/pdf.js';

const r = Router();
r.use(authenticate);

const rangeSchema = z.object({
  from: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  to: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  customer_id: z.coerce.number().int().positive().optional(),
});
function range(q) {
  const to = q.to ? new Date(`${q.to}T23:59:59.999Z`) : new Date();
  const from = q.from ? new Date(`${q.from}T00:00:00.000Z`) : new Date(to.getTime() - 30 * 86400000);
  return { from: from.toISOString(), to: to.toISOString() };
}

// Invoice PDF — the customer who owns it, or staff with billing.view.
r.get('/invoices/:id', async (req, res) => {
  const inv = await db().get(`SELECT i.*, u.name AS customer_name, u.email AS customer_email, c.code AS customer_code, c.address AS customer_address
    FROM invoices i JOIN customers c ON c.id = i.customer_id JOIN users u ON u.id = c.user_id WHERE i.id = ?`, [Number(req.params.id)]);
  if (!inv || (req.user.type === 'customer' ? inv.customer_id !== req.user.customer_id : !can(req.user, 'billing.view'))) throw notFound();
  await invoicePdf(res, parseItems(inv));
});

r.get('/payments/:id', async (req, res) => {
  const p = await db().get(paymentQuery, [Number(req.params.id)]);
  if (!p || p.status !== 'success' || (req.user.type === 'customer' ? p.customer_id !== req.user.customer_id : !can(req.user, 'billing.view'))) throw notFound();
  await paymentReceiptPdf(res, p);
});

// Customer statement — own statement for customers, any customer for staff with reports/customers access.
r.get('/reports/customer', validate(rangeSchema, 'query'), async (req, res) => {
  const id = req.user.type === 'customer' ? req.user.customer_id : req.query.customer_id;
  if (req.user.type !== 'customer' && !can(req.user, 'reports.view') && !can(req.user, 'customers.view')) throw forbidden();
  if (!id) throw notFound('Choose a customer');
  if (req.user.type !== 'customer') await audit(req, 'report.customer', 'customer', id);
  const ok = await customerReport(res, id, range(req.query));
  if (!ok) throw notFound();
});

const staffReport = (fn, name) => [requirePerm('reports.view'), requireModule('reports'), validate(rangeSchema, 'query'), async (req, res) => {
  await audit(req, `report.${name}`, null, null, req.query);
  await fn(res, range(req.query));
}];
r.get('/reports/accounts', ...staffReport(accountsReport, 'accounts'));
r.get('/reports/sales', ...staffReport(salesReport, 'sales'));
r.get('/reports/overall', ...staffReport(overallReport, 'overall'));

export default r;
