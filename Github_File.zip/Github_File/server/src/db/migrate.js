import { db, now, withAdvisoryLock } from './index.js';
import { migrations } from './schema.js';

/** Apply pending migrations, each in its own transaction. Cluster-safe: only one process migrates at a time. */
export async function migrate(log = console.log) {
  for (let attempt = 0; attempt < 30; attempt++) {
    const out = await withAdvisoryLock('aura:migrate', async () => {
      const d = db();
      await d.exec('CREATE TABLE IF NOT EXISTS schema_migrations (id INTEGER PRIMARY KEY, name VARCHAR(255), applied_at VARCHAR(32))');
      const done = new Set((await d.all('SELECT id FROM schema_migrations')).map((r) => Number(r.id)));
      for (const m of migrations) {
        if (done.has(m.id)) continue;
        log(`[migrate] applying ${m.id}_${m.name}`);
        await d.transaction(async (t) => {
          for (const stmt of m.up(d.dialect)) await t.exec(stmt);
          await t.run('INSERT INTO schema_migrations (id, name, applied_at) VALUES (?, ?, ?)', [m.id, m.name, now()]);
        });
      }
    });
    if (!out.busy) return;
    await new Promise((r) => setTimeout(r, 1000)); // another worker is migrating — wait for it
  }
  throw new Error('Timed out waiting for another process to finish migrations');
}
