// Multi-database data layer: MySQL / MariaDB (mysql2), PostgreSQL (pg) or SQLite (node:sqlite).
// Application SQL uses `?` placeholders (translated to $n for PostgreSQL) and portable syntax; the few dialect
// differences (case-insensitive LIKE, GREATEST, upserts, locks, cross-process events) are handled here.
// Every value is a bound parameter; table/column names are never taken from user input.
import fs from 'node:fs';
import path from 'node:path';
import config from '../config.js';

let api = null;
const IDENT = /^[a-z_][a-z0-9_]*$/;
const NO_ID_TABLES = new Set(['settings', 'schema_migrations', 'rate_limits', 'kv_cache']);

export function ident(name) {
  if (!IDENT.test(name)) throw new Error(`Invalid identifier: ${name}`);
  return name;
}

function normalize(params = []) {
  return params.map((v) => {
    if (v === undefined) return null;
    if (typeof v === 'boolean') return v ? 1 : 0; // flags are INT columns (0/1)
    if (v instanceof Date) return v.toISOString();
    if (v !== null && typeof v === 'object' && !Buffer.isBuffer(v)) return JSON.stringify(v);
    return v;
  });
}
const insertTable = (sql) => /^\s*insert\s+into\s+([a-z_][a-z0-9_]*)/i.exec(sql)?.[1]?.toLowerCase();

/** TLS options shared by MySQL and PostgreSQL. 'disable' only for a database on the same machine. */
export function tlsOptions(c = config.db) {
  if (c.ssl === 'disable') return undefined;
  // verify-full: encrypted AND the server certificate + hostname are verified (no MITM).
  return { rejectUnauthorized: true, ...(c.sslCa ? { ca: fs.readFileSync(c.sslCa, 'utf8') } : {}) };
}

// =================================================================================== PostgreSQL
async function initPostgres(c) {
  const pg = (await import('pg')).default;
  pg.types.setTypeParser(20, (v) => (v === null ? null : Number(v)));   // BIGINT / COUNT(*)
  pg.types.setTypeParser(1700, (v) => (v === null ? null : Number(v))); // NUMERIC
  const opts = pgOptions(c);
  const pool = new pg.Pool({ ...opts, max: c.poolMax, idleTimeoutMillis: 30_000 });
  pool.on('error', (e) => console.error('[db] idle client error', e.message));
  await pool.query('SELECT 1');
  const toPg = (sql) => {
    let out = ''; let n = 0; let q = null;
    for (const ch of sql) {
      if (q) { out += ch; if (ch === q) q = null; continue; }
      if (ch === "'" || ch === '"') { q = ch; out += ch; continue; }
      out += ch === '?' ? `$${++n}` : ch;
    }
    return out;
  };
  const wrap = (q) => ({
    async all(sql, p) { return (await q.query(toPg(sql), normalize(p))).rows; },
    async get(sql, p) { return (await q.query(toPg(sql), normalize(p))).rows[0]; },
    async run(sql, p) {
      const t = insertTable(sql);
      const s = t && !NO_ID_TABLES.has(t) && !/\breturning\b/i.test(sql) ? `${sql} RETURNING id` : sql;
      const r = await q.query(toPg(s), normalize(p));
      return { id: r.rows?.[0]?.id ?? null, changes: r.rowCount ?? 0 };
    },
    async exec(sql) { await q.query(sql); },
  });
  return {
    dialect: 'postgres', ...wrap(pool),
    async transaction(fn) {
      const client = await pool.connect();
      try { await client.query('BEGIN'); const out = await fn(wrap(client)); await client.query('COMMIT'); return out; }
      catch (e) { await client.query('ROLLBACK').catch(() => {}); throw e; }
      finally { client.release(); }
    },
    async tryLock(name, fn) {
      const client = await pool.connect();
      const key = hashKey(name);
      try {
        if (!(await client.query('SELECT pg_try_advisory_lock($1) AS ok', [key])).rows[0].ok) return { busy: true };
        try { return { result: await fn() }; } finally { await client.query('SELECT pg_advisory_unlock($1)', [key]).catch(() => {}); }
      } finally { client.release(); }
    },
    async leaderLock(name, onLost) {
      const client = new pg.Client(opts); await client.connect();
      const ok = (await client.query('SELECT pg_try_advisory_lock($1) AS ok', [hashKey(name)])).rows[0].ok;
      if (!ok) { await client.end(); return null; }
      client.once('error', onLost); client.once('end', onLost);
      return { release: () => client.end().catch(() => {}) };
    },
    async listen(channel, onMessage, onLost) {
      const client = new pg.Client(opts); await client.connect();
      client.on('notification', (n) => onMessage(n.payload));
      client.once('error', onLost); client.once('end', onLost);
      await client.query(`LISTEN ${ident(channel)}`);
      return { stop: () => { client.removeAllListeners(); return client.end().catch(() => {}); } };
    },
    async notify(channel, payload) { await pool.query('SELECT pg_notify($1, $2)', [channel, payload]); },
    async close() { await pool.end(); },
  };
}
export function pgOptions(c = config.db) {
  return {
    host: c.host, port: c.port, database: c.database, user: c.user, password: c.password, ssl: tlsOptions(c) || false,
    application_name: 'aura-isp', statement_timeout: 30_000, idle_in_transaction_session_timeout: 60_000, connectionTimeoutMillis: 10_000,
    options: c.schema && c.schema !== 'public' ? `-c search_path=${ident(c.schema)}` : undefined,
  };
}

// =================================================================================== MySQL / MariaDB
export function mysqlOptions(c = config.db) {
  return {
    host: c.host, port: c.port, database: c.database, user: c.user, password: c.password, ssl: tlsOptions(c),
    charset: 'utf8mb4', dateStrings: true, supportBigNumbers: true, bigNumberStrings: false, decimalNumbers: true,
    multipleStatements: false, // defence in depth against stacked-query injection
    connectTimeout: 10_000, timezone: 'Z',
  };
}
async function initMysql(c) {
  const mysql = await import('mysql2/promise');
  const pool = mysql.createPool({ ...mysqlOptions(c), waitForConnections: true, connectionLimit: c.poolMax, enableKeepAlive: true });
  // Per-connection hardening: strict SQL mode + 30 s statement timeout (MySQL: max_execution_time, MariaDB: max_statement_time).
  pool.pool.on('connection', (cn) => {
    const ignore = () => {};
    cn.query("SET SESSION sql_mode = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'", ignore);
    cn.query('SET SESSION max_execution_time = 30000', ignore);
    cn.query('SET SESSION max_statement_time = 30', ignore);
  });
  await pool.query('SELECT 1'); // fail fast on bad credentials / TLS
  const wrap = (q) => ({
    async all(sql, p) { const [rows] = await q.query(sql, normalize(p)); return rows; },
    async get(sql, p) { const [rows] = await q.query(sql, normalize(p)); return rows[0]; },
    async run(sql, p) { const [r] = await q.query(sql, normalize(p)); return { id: r.insertId || null, changes: r.affectedRows ?? 0 }; },
    async exec(sql) { await q.query(sql); },
  });
  const lockName = (n) => `aura:${hashKey(n)}`.slice(0, 64);
  return {
    dialect: 'mysql', ...wrap(pool),
    async transaction(fn) {
      const cn = await pool.getConnection();
      try { await cn.beginTransaction(); const out = await fn(wrap(cn)); await cn.commit(); return out; }
      catch (e) { await cn.rollback().catch(() => {}); throw e; }
      finally { cn.release(); }
    },
    async tryLock(name, fn) {
      const cn = await pool.getConnection();
      try {
        const [[row]] = await cn.query('SELECT GET_LOCK(?, 0) AS ok', [lockName(name)]);
        if (Number(row.ok) !== 1) return { busy: true };
        try { return { result: await fn() }; } finally { await cn.query('SELECT RELEASE_LOCK(?)', [lockName(name)]).catch(() => {}); }
      } finally { cn.release(); }
    },
    async leaderLock(name, onLost) {
      const cn = await mysql.createConnection(mysqlOptions(c));
      const [[row]] = await cn.query('SELECT GET_LOCK(?, 0) AS ok', [lockName(name)]);
      if (Number(row.ok) !== 1) { await cn.end(); return null; }
      cn.once('error', onLost); cn.once('end', onLost);
      const ping = setInterval(() => cn.query('SELECT 1').catch(() => { clearInterval(ping); onLost(); }), 15_000);
      ping.unref();
      return { release: () => { clearInterval(ping); return cn.end().catch(() => {}); } };
    },
    // MySQL has no LISTEN/NOTIFY: events go through a small table that every process polls.
    async listen(_channel, onMessage) {
      let last = Number((await this.get('SELECT COALESCE(MAX(id), 0) AS m FROM cluster_events'))?.m || 0);
      let stopped = false;
      const tick = async () => {
        if (stopped) return;
        try {
          const rows = await this.all('SELECT id, payload FROM cluster_events WHERE id > ? ORDER BY id LIMIT 500', [last]);
          for (const r of rows) { last = Number(r.id); onMessage(r.payload); }
          if (Math.random() < 0.02) await this.run('DELETE FROM cluster_events WHERE created_ms < ?', [Date.now() - 120_000]);
        } catch { /* transient */ }
        setTimeout(tick, 700).unref();
      };
      tick();
      return { stop: () => { stopped = true; } };
    },
    async notify(_channel, payload) { await pool.query('INSERT INTO cluster_events (created_ms, payload) VALUES (?, ?)', [Date.now(), payload]); },
    async close() { await pool.end(); },
  };
}

// =================================================================================== SQLite
async function initSqlite(c) {
  let DatabaseSync;
  try { ({ DatabaseSync } = await import('node:sqlite')); }
  catch { throw new Error('SQLite needs Node.js 22.13 or newer (built-in node:sqlite). Choose MySQL/MariaDB or PostgreSQL instead.'); }
  fs.mkdirSync(path.dirname(c.sqliteFile), { recursive: true });
  const sq = new DatabaseSync(c.sqliteFile);
  sq.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000; PRAGMA secure_delete = ON;');
  try { fs.chmodSync(c.sqliteFile, 0o600); } catch { /* windows */ }
  let txLock = Promise.resolve();
  const locks = new Map();
  const self = {
    dialect: 'sqlite',
    async all(sql, p) { return sq.prepare(sql).all(...normalize(p)); },
    async get(sql, p) { return sq.prepare(sql).get(...normalize(p)); },
    async run(sql, p) { const r = sq.prepare(sql).run(...normalize(p)); return { id: Number(r.lastInsertRowid) || null, changes: Number(r.changes) }; },
    async exec(sql) { sq.exec(sql); },
    // One connection: serialise transactions so awaits inside fn cannot interleave.
    transaction(fn) {
      const next = txLock.then(async () => {
        sq.exec('BEGIN IMMEDIATE');
        try { const out = await fn(self); sq.exec('COMMIT'); return out; } catch (e) { sq.exec('ROLLBACK'); throw e; }
      });
      txLock = next.catch(() => {});
      return next;
    },
    async tryLock(name, fn) {
      if (locks.get(name)) return { busy: true };
      locks.set(name, true);
      try { return { result: await fn() }; } finally { locks.delete(name); }
    },
    async leaderLock() { return { release: () => {} }; }, // SQLite always runs as a single process
    async listen() { return { stop: () => {} }; },
    async notify() { throw new Error('local'); },
    async close() { sq.close(); },
  };
  return self;
}

// =================================================================================== public API
export async function initDb() {
  if (api) return api;
  const c = config.db;
  api = c.client === 'postgres' ? await initPostgres(c) : c.client === 'sqlite' ? await initSqlite(c) : await initMysql(c);
  return api;
}

export function db() {
  if (!api) throw new Error('Database not initialised');
  return api;
}

export async function closeDb() { if (api) { const a = api; api = null; await a.close(); } }

export const dialect = () => db().dialect;
/** Case-insensitive LIKE operator for the active database. */
export const ciLike = () => (dialect() === 'postgres' ? 'ILIKE' : 'LIKE');
/** GREATEST(a, b) — SQLite spells it MAX(a, b). */
export const greatest = (a, b) => (dialect() === 'sqlite' ? `MAX(${a}, ${b})` : `GREATEST(${a}, ${b})`);

/** Insert or update a row by its primary key column (portable upsert). */
export async function upsert(table, keyCol, row, conn = db()) {
  const cols = Object.keys(row).map(ident); ident(table); ident(keyCol);
  const vals = cols.map((k) => row[k]);
  const ph = cols.map(() => '?').join(', ');
  const sets = cols.filter((k) => k !== keyCol);
  if (dialect() === 'mysql') {
    return conn.run(`INSERT INTO ${table} (${cols.join(', ')}) VALUES (${ph}) ON DUPLICATE KEY UPDATE ${sets.map((k) => `${k} = VALUES(${k})`).join(', ')}`, vals);
  }
  return conn.run(`INSERT INTO ${table} (${cols.join(', ')}) VALUES (${ph}) ON CONFLICT (${keyCol}) DO UPDATE SET ${sets.map((k) => `${k} = EXCLUDED.${k}`).join(', ')}`, vals);
}

/** Run fn only if no other process/worker holds the named lock (cluster-safe). Returns { busy } or { result }. */
export const withAdvisoryLock = (name, fn) => db().tryLock(name, fn);

export function hashKey(name) {
  let h = 0n;
  for (const ch of String(name)) h = (h * 31n + BigInt(ch.charCodeAt(0))) & 0x7fffffffffffffffn;
  return h.toString();
}

export const now = () => new Date().toISOString();

export async function insert(table, data, conn = db()) {
  const keys = Object.keys(data).filter((k) => data[k] !== undefined).map(ident);
  const sql = `INSERT INTO ${ident(table)} (${keys.join(', ')}) VALUES (${keys.map(() => '?').join(', ')})`;
  return conn.run(sql, keys.map((k) => data[k]));
}

export async function update(table, id, data, conn = db()) {
  const keys = Object.keys(data).filter((k) => data[k] !== undefined).map(ident);
  if (!keys.length) return { changes: 0 };
  const sql = `UPDATE ${ident(table)} SET ${keys.map((k) => `${k} = ?`).join(', ')} WHERE id = ?`;
  return conn.run(sql, [...keys.map((k) => data[k]), id]);
}

export async function findById(table, id, conn = db()) {
  return conn.get(`SELECT * FROM ${ident(table)} WHERE id = ?`, [id]);
}

export async function remove(table, id, conn = db()) {
  return conn.run(`DELETE FROM ${ident(table)} WHERE id = ?`, [id]);
}

export function parseJson(v, fallback = null) {
  if (v === null || v === undefined || v === '') return fallback;
  if (typeof v === 'object') return v;
  try { return JSON.parse(v); } catch { return fallback; }
}

// Paginated listing with whitelisted sort columns.
export async function paginate({ base, params = [], countBase, page = 1, pageSize = 25, sort, sortable = [], defaultSort = 'id DESC' }) {
  page = Math.max(1, Number(page) || 1);
  pageSize = Math.min(200, Math.max(1, Number(pageSize) || 25));
  let order = defaultSort;
  if (sort) {
    const desc = sort.startsWith('-');
    const col = desc ? sort.slice(1) : sort;
    // sortable: ['col', ...] or { publicName: 'qualified.column' }
    const map = Array.isArray(sortable) ? Object.fromEntries(sortable.map((s) => [s, s])) : sortable;
    if (Object.hasOwn(map, col)) order = `${map[col]} ${desc ? 'DESC' : 'ASC'}`;
  }
  const rows = await db().all(`${base} ORDER BY ${order} LIMIT ${pageSize} OFFSET ${(page - 1) * pageSize}`, params);
  const total = (await db().get(countBase, params))?.n ?? 0;
  return { rows, total: Number(total), page, pageSize };
}

// ---------------------------------------------------------------- portable ON DELETE behaviour
// The schema declares foreign keys inline (`col INTEGER REFERENCES t(id) ON DELETE CASCADE`). SQLite, PostgreSQL and
// MariaDB enforce those, but MySQL 8 silently ignores inline REFERENCES — deleting a parent would leave orphans
// (an IP still "assigned" to a deleted customer, a deleted customer's invoices still counted as outstanding).
// cascadeDelete applies the same rules explicitly, so deletes behave identically on every database.
const FK_RULES = {
  users: [['customers', 'user_id', 'cascade'], ['sessions', 'user_id', 'cascade'], ['verification_codes', 'user_id', 'cascade'], ['jobs', 'assigned_to', 'null'], ['inv_items', 'staff_id', 'null'], ['zones', 'manager_id', 'null'],
    ['notifications', 'user_id', 'cascade'], ['push_subscriptions', 'user_id', 'cascade'], ['tickets', 'assigned_to', 'null'],
    ['chat_conversations', 'user_id', 'null'], ['chat_conversations', 'assigned_to', 'null']],
  customers: [['invoices', 'customer_id', 'cascade'], ['payments', 'customer_id', 'cascade'], ['plan_changes', 'customer_id', 'cascade'],
    ['tickets', 'customer_id', 'cascade'], ['usage_samples', 'customer_id', 'cascade'], ['traffic_daily', 'customer_id', 'cascade'],
    ['site_rules', 'customer_id', 'cascade'], ['devices', 'customer_id', 'cascade'], ['remote_sessions', 'customer_id', 'cascade'],
    ['ip_addresses', 'customer_id', 'release'], ['sales', 'customer_id', 'null'], ['chat_conversations', 'customer_id', 'null'],
    ['customer_documents', 'customer_id', 'cascade'], ['inv_items', 'customer_id', 'null'], ['jobs', 'customer_id', 'null']],
    // session_logs are intentionally kept: the BTRC IP log must outlive the customer record.
  invoices: [['payments', 'invoice_id', 'null']],
  tickets: [['ticket_messages', 'ticket_id', 'cascade']],
  devices: [['device_tests', 'device_id', 'cascade']],
  chat_conversations: [['chat_messages', 'conversation_id', 'cascade']],
  ip_pools: [['ip_addresses', 'pool_id', 'cascade']],
  inv_products: [['inv_items', 'product_id', 'cascade']],
  inv_warehouses: [['inv_items', 'warehouse_id', 'null']],
  plans: [['customers', 'plan_id', 'null']],
  roles: [['users', 'role_id', 'null']],
  routers: [['customers', 'router_id', 'null'], ['ip_pools', 'router_id', 'null'], ['upstream_links', 'router_id', 'null']],
  expense_categories: [['expenses', 'category_id', 'null']],
};

/** Delete rows of `table` matching `col = value` and apply the schema's ON DELETE rules to their children. */
async function cascadeWhere(conn, table, col, value) {
  const rules = FK_RULES[table];
  if (rules) {
    const ids = (await conn.all(`SELECT id FROM ${ident(table)} WHERE ${ident(col)} = ?`, [value])).map((r) => r.id);
    for (const id of ids) {
      for (const [child, fk, action] of rules) {
        if (action === 'cascade') await cascadeWhere(conn, child, fk, id);
        else if (action === 'release') await conn.run(`UPDATE ${ident(child)} SET ${ident(fk)} = NULL, status = 'free', released_at = ? WHERE ${ident(fk)} = ?`, [now(), id]);
        else await conn.run(`UPDATE ${ident(child)} SET ${ident(fk)} = NULL WHERE ${ident(fk)} = ?`, [id]);
      }
    }
  }
  return conn.run(`DELETE FROM ${ident(table)} WHERE ${ident(col)} = ?`, [value]);
}

/** Delete one row by id with portable cascading (see FK_RULES), inside a transaction. */
export const cascadeDelete = (table, id) => db().transaction((t) => cascadeWhere(t, table, 'id', id));
