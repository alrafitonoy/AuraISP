// Idempotent default data: system roles, default plans, notification templates, reminder rules and FAQs.
import { db, insert, now } from './index.js';

const ROLES = [
  { slug: 'admin', name: 'Administrator', description: 'Full access to everything', permissions: ['*'], dashboard: [], is_system: 1 },
  { slug: 'customer', name: 'Customer', description: 'Self-service portal', permissions: [], dashboard: [], is_system: 1 },
  {
    slug: 'manager', name: 'Manager', description: 'Operations manager', is_system: 0,
    permissions: ['dashboard.view', 'customers.view', 'customers.create', 'customers.edit', 'plans.view', 'plans.manage', 'billing.view', 'billing.manage', 'billing.collect', 'tickets.view', 'tickets.manage', 'network.view', 'crm.view', 'crm.manage', 'notifications.send', 'audit.view', 'reports.view'],
    dashboard: ['kpi_customers', 'kpi_revenue', 'kpi_due', 'kpi_tickets', 'revenue_chart', 'plan_distribution', 'sales_funnel', 'recent_payments'],
  },
  {
    slug: 'billing', name: 'Billing Officer', description: 'Invoices and collections', is_system: 0,
    permissions: ['dashboard.view', 'customers.view', 'plans.view', 'billing.view', 'billing.manage', 'billing.collect', 'reports.view'],
    dashboard: ['kpi_revenue', 'kpi_due', 'revenue_chart', 'recent_payments'],
  },
  {
    slug: 'support', name: 'Support Agent', description: 'Customer support desk', is_system: 0,
    permissions: ['dashboard.view', 'customers.view', 'plans.view', 'tickets.view', 'tickets.manage', 'network.view', 'network.diagnostics', 'chat.handle'],
    dashboard: ['kpi_tickets', 'recent_tickets', 'live_bandwidth'],
  },
  {
    slug: 'network', name: 'Network Engineer', description: 'Routers, bandwidth and access control', is_system: 0,
    permissions: ['dashboard.view', 'customers.view', 'customers.edit', 'plans.view', 'network.view', 'network.manage', 'network.diagnostics', 'tickets.view'],
    dashboard: ['live_bandwidth', 'top_users', 'network_status', 'kpi_tickets'],
  },
  {
    slug: 'sales', name: 'Sales Executive', description: 'Leads, campaigns and new connections', is_system: 0,
    permissions: ['dashboard.view', 'customers.view', 'customers.create', 'plans.view', 'crm.view', 'crm.manage', 'notifications.send', 'chat.handle'],
    dashboard: ['sales_funnel', 'kpi_customers', 'plan_distribution'],
  },
];

const PLANS = [
  { slug: 'starter', name: 'Starter', download_kbps: 10000, upload_kbps: 10000, price_cents: 50000, features: ['10 Mbps symmetric', 'Unlimited data', 'Free router setup', 'Email support'], sort: 1 },
  { slug: 'home', name: 'Home', download_kbps: 25000, upload_kbps: 25000, price_cents: 80000, features: ['25 Mbps symmetric', 'Unlimited data', 'Parental controls', '24/7 chat support'], sort: 2, is_default: 1 },
  { slug: 'family', name: 'Family', download_kbps: 50000, upload_kbps: 50000, price_cents: 120000, features: ['50 Mbps symmetric', 'Unlimited data', 'Parental controls', 'Priority support', 'Real IP on request'], sort: 3, is_featured: 1 },
  { slug: 'pro', name: 'Pro', download_kbps: 100000, upload_kbps: 100000, price_cents: 200000, features: ['100 Mbps symmetric', 'Gaming-optimised routing', 'Static IP', 'Priority support'], sort: 4 },
  { slug: 'ultra', name: 'Ultra', download_kbps: 300000, upload_kbps: 300000, price_cents: 400000, features: ['300 Mbps symmetric', 'Static IP', 'Dedicated account manager', '4-hour on-site SLA'], sort: 5 },
];

const TEMPLATES = [
  ['welcome', 'Welcome', 'Welcome to {{company}}!', 'Hi {{user.name}},\n\nYour {{company}} account is ready. Sign in with {{email}} — temporary password: {{password}}\nPlease change it after your first login.', 'Welcome to {{company}}! Login: {{email}}', ['email']],
  ['invoice_created', 'Invoice created', 'New invoice {{invoice}}', 'Hi {{user.name}},\n\nInvoice {{invoice}} for {{amount}} has been issued and is due on {{due_date}}. You can pay online from your portal.', '{{company}}: invoice {{invoice}} for {{amount}} due {{due_date}}.', ['email', 'inapp', 'push']],
  ['invoice_due', 'Payment reminder', 'Reminder: {{invoice}} is due on {{due_date}}', 'Hi {{user.name}},\n\nA friendly reminder that invoice {{invoice}} ({{amount}}) is due on {{due_date}}. Pay online to avoid interruption.', '{{company}}: {{amount}} due on {{due_date}} ({{invoice}}). Pay online now.', ['email', 'sms', 'inapp', 'push']],
  ['invoice_overdue', 'Overdue notice', 'Invoice {{invoice}} is overdue', 'Hi {{user.name}},\n\nInvoice {{invoice}} ({{amount}}) is {{days}} day(s) overdue. Please pay now to keep your connection active.', '{{company}}: {{invoice}} is overdue ({{amount}}). Pay now to avoid suspension.', ['email', 'sms', 'whatsapp', 'inapp', 'push']],
  ['plan_expiry', 'Plan renewal', 'Your {{plan}} plan renews on {{date}}', 'Hi {{user.name}},\n\nYour {{plan}} plan renews on {{date}}. Want more speed? Upgrade anytime from the app.', '{{company}}: {{plan}} renews {{date}}.', ['inapp', 'push']],
  ['payment_received', 'Payment received', 'Payment received — thank you!', 'Hi {{user.name}},\n\nWe received {{amount}} via {{method}} for invoice {{invoice}}. Thank you!', '{{company}}: payment of {{amount}} received. Thank you!', ['email', 'inapp', 'push']],
  ['service_suspended', 'Service suspended', 'Your service has been suspended', 'Hi {{user.name}},\n\nYour internet service has been suspended {{reason}}. Pay outstanding invoices in the portal and service resumes automatically.', '{{company}}: service suspended. Pay dues to restore instantly.', ['email', 'sms', 'inapp', 'push']],
  ['service_activated', 'Service activated', 'Your connection is active', 'Hi {{user.name}},\n\nGreat news — your internet service is active. Enjoy!', '{{company}}: your connection is active. Enjoy!', ['email', 'sms', 'inapp', 'push']],
  ['plan_changed', 'Plan changed', 'You are now on {{plan}}', 'Hi {{user.name}},\n\nYour plan has been changed to {{plan}}. New speeds apply immediately.', '{{company}}: plan changed to {{plan}}.', ['email', 'inapp', 'push']],
  ['ticket_reply', 'Support reply', 'New reply on ticket {{ticket}}', 'Hi {{user.name}},\n\nOur support team replied to your ticket {{ticket}} ("{{subject}}"). Open the app to read it.', '{{company}}: new reply on {{ticket}}.', ['email', 'inapp', 'push']],
];

const REMINDERS = [
  ['3 days before due', 'invoice_due', 3, 'invoice_due', ['email', 'inapp', 'push']],
  ['On due date', 'invoice_due', 0, 'invoice_due', ['email', 'sms', 'inapp', 'push']],
  ['2 days overdue', 'invoice_overdue', 2, 'invoice_overdue', ['email', 'sms', 'whatsapp', 'inapp']],
  ['Renewal in 5 days', 'plan_expiry', 5, 'plan_expiry', ['inapp', 'push']],
];

const FAQS = [
  ['How do I pay my bill?', 'Sign in to the portal or app, open Billing and press "Pay now". We accept bKash, SSLCommerz (cards, mobile banking) and Stripe. You can also pay cash at our office.', 'billing', 'pay payment bill bkash card invoice'],
  ['My internet is slow. What should I do?', 'First restart your router (unplug for 30 seconds). Then run the speed test under Devices in the app. If speeds are still low, open a support ticket — we can run remote diagnostics on your line with your permission.', 'technical', 'slow speed lag buffering restart router'],
  ['How do I upgrade my plan?', 'Open Plans in the portal and choose a new plan. Upgrades are prorated — you only pay the difference for the remaining days of your cycle — and the new speed applies as soon as payment completes.', 'plans', 'upgrade plan package speed change downgrade'],
  ['How do parental controls work?', 'Under Parental controls you can block categories (social, gaming, adult…), specific websites, enable safe search and set internet pause schedules such as bedtime. Rules apply to your whole connection within a minute.', 'features', 'parental kids block site schedule safe search'],
  ['What happens if I miss a payment?', 'You will get reminders before and after the due date. After the grace period the connection is suspended, and it is restored automatically as soon as you pay.', 'billing', 'late overdue suspend disconnect grace'],
  ['How do I enable two-factor authentication?', 'Go to Profile → Security, choose "Enable 2FA", scan the QR code with Google Authenticator or Authy and enter the 6-digit code. Save your backup codes somewhere safe.', 'account', '2fa two factor authenticator security otp backup codes'],
  ['Do you have data caps?', 'No. All home plans are unlimited with no fair-usage throttling.', 'plans', 'data cap limit unlimited fup'],
  ['How long does a new connection take?', 'Usually within 24 hours in our coverage areas after your first payment. Check coverage on our website.', 'sales', 'new connection install setup time coverage'],
];

export async function seedDefaults() {
  const ts = now();
  for (const r of ROLES) {
    if (await db().get('SELECT id FROM roles WHERE slug = ?', [r.slug])) continue;
    await insert('roles', { ...r, permissions: JSON.stringify(r.permissions), dashboard: JSON.stringify(r.dashboard), created_at: ts });
  }
  const anyPlan = await db().get('SELECT id FROM plans LIMIT 1');
  if (!anyPlan) {
    for (const p of PLANS) await insert('plans', { billing_cycle: 'monthly', is_public: 1, active: 1, is_default: 0, is_featured: 0, ...p, description: `${p.name} fiber plan`, features: JSON.stringify(p.features), created_at: ts, updated_at: ts });
  }
  for (const [key, name, subject, body, sms, channels] of TEMPLATES) {
    if (await db().get('SELECT id FROM notification_templates WHERE template_key = ?', [key])) continue;
    await insert('notification_templates', { template_key: key, name, subject, body, sms_body: sms, channels: JSON.stringify(channels), active: 1, updated_at: ts });
  }
  if (!(await db().get('SELECT id FROM reminder_rules LIMIT 1'))) {
    for (const [name, trig, off, tpl, ch] of REMINDERS) await insert('reminder_rules', { name, trigger_event: trig, offset_days: off, template_key: tpl, channels: JSON.stringify(ch), active: 1, created_at: ts });
  }
  if (!(await db().get('SELECT id FROM faqs LIMIT 1'))) {
    let i = 0;
    for (const [q, a, cat, kw] of FAQS) await insert('faqs', { question: q, answer: a, category: cat, keywords: kw, sort: i++, active: 1, created_at: ts });
  }
}
