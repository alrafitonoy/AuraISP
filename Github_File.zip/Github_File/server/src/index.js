// Entry point.
//  * Not installed yet  -> starts the browser-based installer (http://your-server/install)
//  * Installed          -> starts the app; with WEB_CONCURRENCY > 1 (or "max") the built-in load balancer forks one
//                          worker per CPU core (Node cluster). Workers share PostgreSQL for sessions, rate limits,
//                          realtime events (LISTEN/NOTIFY) and scheduler leadership, so you can also run several
//                          servers behind Nginx/HAProxy (see deploy/nginx-loadbalancer.conf).
import cluster from 'node:cluster';
import os from 'node:os';
import config, { isInstalled } from './config.js';

const log = (...a) => console.log(`[${cluster.isPrimary ? 'primary' : `worker ${cluster.worker?.id}`}]`, ...a);

// Hosting panels (Hostinger, Plesk, Render...) that set APP_KEY + DB_* as environment variables skip the browser installer.
// For those, ADMIN_EMAIL + ADMIN_PASSWORD create the first administrator, once, only while no administrator exists.
async function bootstrapAdmin() {
  const email = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD || '';
  if (!email || !password) return;
  const { db, insert, now, withAdvisoryLock } = await import('./db/index.js');
  const { hashPassword } = await import('./lib/crypto.js');
  await withAdvisoryLock('aura:bootstrap-admin', async () => {
    if (await db().get("SELECT id FROM users WHERE type = 'admin' LIMIT 1")) return;
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return log('ADMIN_EMAIL is not a valid email; first administrator not created');
    if (password.length < 10 || !/[a-z]/.test(password) || !/[A-Z]/.test(password) || !/\d/.test(password)) {
      return log('ADMIN_PASSWORD needs 10+ characters with upper case, lower case and a digit; first administrator not created');
    }
    if (await db().get('SELECT id FROM users WHERE email = ?', [email])) return log('ADMIN_EMAIL already belongs to another account; first administrator not created');
    const role = await db().get("SELECT id FROM roles WHERE slug = 'admin'");
    await insert('users', { type: 'admin', role_id: role.id, name: process.env.ADMIN_NAME || 'Administrator', email, password_hash: await hashPassword(password), status: 'active', email_verified_at: now(), created_at: now(), updated_at: now() });
    log(`First administrator created (${email}). Remove ADMIN_PASSWORD from the environment now.`);
  });
}

async function bootApp(existingServer) {
  const { initDb, db } = await import('./db/index.js');
  const { migrate } = await import('./db/migrate.js');
  const { seedDefaults } = await import('./db/seed.js');
  const { createApp } = await import('./app.js');
  const { startEventBus, stopEventBus } = await import('./lib/events.js');
  const { loadLiveSnapshot } = await import('./network/service.js');
  const { startLeaderElection, stopLeaderElection } = await import('./jobs/scheduler.js');
  const { VERSION } = await import('./updater.js');

  await initDb();
  await migrate(log);
  await seedDefaults();
  await bootstrapAdmin();
  await startEventBus();
  await loadLiveSnapshot();
  const app = createApp();

  let server = existingServer;
  if (server) {
    server.removeAllListeners('request');
    server.on('request', app);
  } else {
    const dbDesc = config.db.client === 'sqlite' ? `SQLite ${config.db.sqliteFile}` : `${config.db.client === 'mysql' ? 'MySQL/MariaDB' : 'PostgreSQL'} ${config.db.host}/${config.db.database}, ssl=${config.db.ssl}`;
    server = app.listen(config.port, config.host, () => log(`AuraISP v${VERSION} listening on http://${config.host}:${config.port} (${dbDesc}, env=${config.env}, data=${config.dataDir})`));
  }
  server.requestTimeout = 120_000;
  server.headersTimeout = 30_000;
  server.keepAliveTimeout = 65_000; // longer than typical load-balancer idle timeouts (avoids 502s)
  if (!config.disableScheduler) await startLeaderElection();

  let closing = false;
  const shutdown = (sig) => {
    if (closing) return; closing = true;
    log(`${sig}: shutting down gracefully`);
    stopLeaderElection().catch(() => {});
    server.close(async () => {
      await stopEventBus().catch(() => {});
      await db().close().catch(() => {});
      process.exit(0);
    });
    setTimeout(() => process.exit(1), 10_000).unref();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('message', (m) => { if (m === 'shutdown') shutdown('cluster'); });
}

function startPrimary(count) {
  log(`built-in load balancer: starting ${count} workers`);
  let stopping = false;
  const fork = () => cluster.fork();
  for (let i = 0; i < count; i++) fork();
  const crashes = [];
  cluster.on('exit', (w, code, signal) => {
    if (stopping || w.exitedAfterDisconnect || w.aura_replaced) return;
    crashes.push(Date.now());
    while (crashes.length && crashes[0] < Date.now() - 60_000) crashes.shift();
    log(`worker ${w.id} died (${signal || code}) — restarting`);
    setTimeout(fork, crashes.length > 5 ? 10_000 : 500); // back off if workers crash-loop
  });
  // Rolling restart (after an update/restore): replace workers one by one so the site stays up.
  const rolling = async () => {
    for (const w of Object.values(cluster.workers)) {
      const fresh = fork();
      await new Promise((r) => { fresh.once('listening', r); setTimeout(r, 30_000); });
      w.aura_replaced = true; w.send('shutdown'); w.disconnect();
    }
    log('rolling restart complete');
  };
  cluster.on('message', (_w, m) => { if (m?.cmd === 'aura:restart-all') rolling().catch((e) => log('rolling restart failed', e.message)); });
  const stop = () => {
    stopping = true;
    for (const w of Object.values(cluster.workers)) { w.send('shutdown'); w.disconnect(); }
    setTimeout(() => process.exit(0), 12_000).unref();
  };
  process.on('SIGTERM', stop);
  process.on('SIGINT', stop);
}

async function main() {
  if (!isInstalled()) {
    const { startInstaller } = await import('./installer.js');
    return startInstaller((server) => bootApp(server));
  }
  let workers = config.workers === 'max' ? os.availableParallelism() : Math.max(1, config.workers);
  if (config.db.client === 'sqlite' && workers > 1) {
    log('SQLite is single-process: load balancing needs MySQL/MariaDB or PostgreSQL — running 1 worker.');
    workers = 1;
  }
  if (cluster.isPrimary && workers > 1) return startPrimary(workers);
  return bootApp();
}

main().catch((e) => {
  console.error('Fatal:', e.message);
  process.exit(1);
});
