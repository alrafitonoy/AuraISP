import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import compression from 'compression';
import config from './config.js';
import { errorHandler, notFound } from './lib/http.js';
import { helmetMw, globalLimiter, sanitizeBody } from './middleware/security.js';

import authRoutes from './routes/auth.js';
import publicRoutes from './routes/public.js';
import customerRoutes from './routes/customers.js';
import planRoutes from './routes/plans.js';
import billingRoutes from './routes/billing.js';
import portalRoutes from './routes/portal.js';
import ticketRoutes from './routes/tickets.js';
import notificationRoutes from './routes/notifications.js';
import networkRoutes from './routes/network.js';
import crmRoutes from './routes/crm.js';
import userRoutes from './routes/users.js';
import settingsRoutes from './routes/settings.js';
import systemRoutes from './routes/system.js';
import ipamRoutes from './routes/ipam.js';
import reportRoutes from './routes/reports.js';
import backupRoutes from './routes/backups.js';
import chatRoutes from './routes/chat.js';
import inventoryRoutes from './routes/inventory.js';
import jobRoutes from './routes/jobs.js';
import financeRoutes from './routes/finance.js';
import zoneRoutes from './routes/zones.js';
import opsRoutes from './routes/ops.js';

export function createApp() {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', config.trustProxy === 'true' ? true : config.trustProxy === 'false' ? false : config.trustProxy);

  app.use(helmetMw);
  app.use(compression({ filter: (req, res) => !String(res.getHeader('Content-Type') || '').includes('text/event-stream') && !req.path.startsWith('/api/speedtest') && compression.filter(req, res) }));

  // CORS only for explicitly allowed origins (mobile app: capacitor://localhost, https://localhost; desktop uses same origin).
  const allowed = new Set([...config.corsOrigins, 'capacitor://localhost', 'https://localhost']);
  app.use('/api', cors({
    origin: (origin, cb) => cb(null, !origin || allowed.has(origin)),
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'X-Chat-Token'],
    exposedHeaders: ['Content-Disposition'],
    maxAge: 600,
  }));

  app.use('/api', globalLimiter);
  app.use(cookieParser());

  // Stripe webhook & speed-test upload need the raw body, so skip the JSON parser for them.
  app.use((req, res, next) => (req.originalUrl.startsWith('/api/billing/webhooks/stripe') || req.originalUrl.startsWith('/api/speedtest/upload') ? next() : express.json({ limit: '1mb' })(req, res, next)));
  app.use(sanitizeBody);

  app.use('/api/auth', authRoutes);
  app.use('/api/public', publicRoutes);
  app.use('/api/customers', customerRoutes);
  app.use('/api/plans', planRoutes);
  app.use('/api/billing', billingRoutes);
  app.use('/api/portal', portalRoutes);
  app.use('/api/tickets', ticketRoutes);
  app.use('/api/notifications', notificationRoutes);
  app.use('/api/network', networkRoutes);
  app.use('/api/network', ipamRoutes); // IP management, capacity, core-router discovery/import
  app.use('/api/pdf', reportRoutes);
  app.use('/api/backups', backupRoutes);
  app.use('/api/chat', chatRoutes);
  app.use('/api/inventory', inventoryRoutes);
  app.use('/api/jobs', jobRoutes);
  app.use('/api/finance', financeRoutes);
  app.use('/api/zones', zoneRoutes);
  app.use('/api/ops', opsRoutes); // network map, KYC documents, session/IP log
  app.use('/api/crm', crmRoutes);
  app.use('/api/staff', userRoutes);
  app.use('/api/settings', settingsRoutes);
  app.use('/api', systemRoutes);
  app.use('/api', (_req, _res, next) => next(notFound('API route not found')));

  // Uploaded branding assets — served as inert files.
  app.use('/uploads', express.static(config.uploadsDir, {
    maxAge: '7d', index: false, dotfiles: 'deny',
    // Inert images: nosniff + CSP none; cross-origin allowed so the mobile app (capacitor://localhost) can show avatars/logos.
    setHeaders: (res) => { res.set('X-Content-Type-Options', 'nosniff'); res.set('Content-Security-Policy', "default-src 'none'"); res.set('Cross-Origin-Resource-Policy', 'cross-origin'); },
  }));

  // Web app (SPA) — the same build is used for website, customer portal, staff panel and the desktop app.
  if (fs.existsSync(config.webDist)) {
    app.use(express.static(config.webDist, { index: false, maxAge: '1h', setHeaders: (res, p) => { if (p.includes(`${path.sep}assets${path.sep}`)) res.set('Cache-Control', 'public, max-age=31536000, immutable'); } }));
    app.get('/{*splat}', (_req, res) => res.sendFile(path.join(config.webDist, 'index.html')));
  } else {
    app.get('/', (_req, res) => res.type('text').send('AuraISP API is running. Build the web app (cd web && npm run build) to serve the UI.'));
  }

  app.use(errorHandler);
  return app;
}
