import { db, insert, now, parseJson, upsert } from '../db/index.js';
import { getDriver } from './drivers.js';
import { broadcast, sendToUser, emitInternal, onInternal } from '../lib/events.js';

const routerCache = new Map();

export async function routerFor(customer) {
  if (!customer?.router_id) return null;
  return db().get('SELECT * FROM routers WHERE id = ?', [customer.router_id]);
}

export async function customerWithPlan(id) {
  return db().get(
    `SELECT c.*, p.name AS plan_name, p.download_kbps, p.upload_kbps, p.data_cap_mb, u.name, u.email, u.phone
       FROM customers c JOIN users u ON u.id = c.user_id LEFT JOIN plans p ON p.id = c.plan_id WHERE c.id = ?`, [id]);
}

export function effectiveBandwidth(c) {
  return {
    downKbps: c.custom_download_kbps || c.download_kbps || 0,
    upKbps: c.custom_upload_kbps || c.upload_kbps || 0,
  };
}

/** Push speed limits + enabled state for one customer to its router. Never throws — returns {ok, error}. */
export async function syncCustomer(customerId) {
  const c = await customerWithPlan(customerId);
  if (!c) return { ok: false, error: 'Customer not found' };
  const driver = getDriver(await routerFor(c));
  try {
    const { allowedSpeed } = await import('./enforcement.js');
    const bw = await allowedSpeed(c); // plan/custom speed, or the throttle speed once a data cap is used up
    if (bw.downKbps) await driver.applyBandwidth(c, bw);
    await driver.setEnabled(c, c.status === 'active');
    const parental = parseJson(c.parental, null);
    if (parental) await driver.applyParental(c, parental).catch(() => {});
    return { ok: true, bandwidth: bw };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

export async function syncSiteRules() {
  const rules = (await db().all('SELECT * FROM site_rules WHERE active = 1')).map((r) => ({ ...r, schedule: parseJson(r.schedule, null) }));
  const customers = await db().all('SELECT id, code, ip_address, router_id FROM customers');
  const byId = new Map(customers.map((c) => [c.id, c]));
  const routers = await db().all('SELECT * FROM routers');
  const results = [];
  for (const r of routers.length ? routers : [null]) {
    const relevant = rules.filter((x) => x.scope === 'global' || byId.get(x.customer_id)?.router_id === r?.id);
    try { await getDriver(r).syncSiteRules(relevant, byId); results.push({ router: r?.name || 'virtual', ok: true, rules: relevant.length }); }
    catch (e) { results.push({ router: r?.name || 'virtual', ok: false, error: e.message }); }
  }
  return results;
}

// Latest live rates, kept in memory for dashboards.
export const live = { at: null, totals: { rx_bps: 0, tx_bps: 0, online: 0 }, perCustomer: new Map() };

/** Poll routers, store samples, push live data. Called every minute by the scheduler. */
export async function pollUsage() {
  const customers = await db().all(
    `SELECT c.id, c.code, c.user_id, c.ip_address, c.pppoe_username, c.router_id, c.status, p.download_kbps, p.upload_kbps
       FROM customers c LEFT JOIN plans p ON p.id = c.plan_id WHERE c.status IN ('active','suspended')`);
  const groups = new Map();
  for (const c of customers) {
    const k = c.router_id || 0;
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push(c);
  }
  const ts = now();
  let rx = 0, tx = 0, online = 0;
  for (const [routerId, list] of groups) {
    let router = null;
    if (routerId) {
      router = routerCache.get(routerId) || (await db().get('SELECT * FROM routers WHERE id = ?', [routerId]));
    }
    try {
      const stats = await getDriver(router).stats(list);
      if (router) await db().run('UPDATE routers SET status = ?, last_seen_at = ? WHERE id = ?', ['online', ts, router.id]);
      for (const s of stats) {
        live.perCustomer.set(s.customer_id, s);
        rx += s.rx_bps; tx += s.tx_bps; if (s.online) online++;
        await insert('usage_samples', { customer_id: s.customer_id, ts, rx_bytes: s.rx_bytes, tx_bytes: s.tx_bytes, rx_bps: s.rx_bps, tx_bps: s.tx_bps });
        const c = list.find((x) => x.id === s.customer_id);
        if (c) sendToUser(c.user_id, 'bandwidth', { rx_bps: s.rx_bps, tx_bps: s.tx_bps, online: s.online, at: ts });
      }
    } catch (e) {
      // Keep what discovery stored (e.g. wanInterface for capacity sampling); only record the latest error.
      if (router) await db().run('UPDATE routers SET status = ?, info = ? WHERE id = ?', ['offline', JSON.stringify({ ...parseJson(router.info, {}), error: e.message, errorAt: ts }), router.id]);
    }
  }
  live.at = ts;
  live.totals = { rx_bps: rx, tx_bps: tx, online };
  await saveLiveSnapshot();
  broadcast('network', { at: ts, ...live.totals });
  return live.totals;
}

// ---- live stats are computed by the scheduler leader and shared with every worker/server via PostgreSQL ----
async function saveLiveSnapshot() {
  const value = JSON.stringify({ at: live.at, totals: live.totals, perCustomer: [...live.perCustomer.values()] });
  await upsert('kv_cache', 'ckey', { ckey: 'live', value, updated_at: now() });
  await emitInternal('live', null);
}

export async function loadLiveSnapshot() {
  const row = await db().get("SELECT value FROM kv_cache WHERE ckey = 'live'").catch(() => null);
  const snap = parseJson(row?.value, null);
  if (!snap) return;
  live.at = snap.at; live.totals = snap.totals || live.totals;
  live.perCustomer = new Map((snap.perCustomer || []).map((s) => [s.customer_id, s]));
}
onInternal('live', loadLiveSnapshot);

/** Remove raw samples older than N days (daily aggregates stay). */
export async function pruneSamples(days = 35) {
  const cutoff = new Date(Date.now() - days * 86400000).toISOString();
  await db().run('DELETE FROM usage_samples WHERE ts < ?', [cutoff]);
}

/** Aggregate today's usage per customer into traffic_daily ('total') + simulated category split. */
export async function aggregateDaily(day = new Date().toISOString().slice(0, 10)) {
  // Sum the growth between consecutive samples. Router counters are cumulative and reset to 0 on a reboot or queue
  // re-creation; MAX-MIN would then count the whole pre-reset counter as today's usage (false data-cap throttling).
  // A negative step means "counter reset", so the new reading itself is the traffic since the reset.
  const rows = await db().all(
    `SELECT customer_id, SUM(CASE WHEN step >= 0 THEN step ELSE cur END) AS total FROM (
       SELECT customer_id, rx_bytes + tx_bytes AS cur,
              (rx_bytes + tx_bytes) - LAG(rx_bytes + tx_bytes) OVER (PARTITION BY customer_id ORDER BY ts, id) AS step
         FROM usage_samples WHERE ts >= ? AND ts < ?) s
     WHERE step IS NOT NULL GROUP BY customer_id`,
    [`${day}T00:00:00`, `${day}T23:59:59.999Z`]);
  const split = { streaming: 0.46, social: 0.18, gaming: 0.12, web: 0.14, updates: 0.06, other: 0.04 };
  for (const r of rows) {
    const total = Math.max(0, Number(r.total) || 0);
    const entries = [['total', total], ...Object.entries(split).map(([k, f]) => [k, Math.round(total * f)])];
    for (const [category, bytes] of entries) {
      const ex = await db().get('SELECT id FROM traffic_daily WHERE customer_id = ? AND day = ? AND category = ?', [r.customer_id, day, category]);
      if (ex) await db().run('UPDATE traffic_daily SET bytes = ? WHERE id = ?', [bytes, ex.id]);
      else await insert('traffic_daily', { customer_id: r.customer_id, day, category, bytes });
    }
  }
}
