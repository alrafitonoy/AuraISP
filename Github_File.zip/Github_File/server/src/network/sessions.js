// Session & IP log (BTRC compliance): "which subscriber had IP address X at time T".
//
// recordSessions() runs every minute (after the usage poll) and turns the live online/offline state into session rows:
//   * customer comes online (no open session)        → open a row (started_at, ip, username, mac, router)
//   * still online with the same IP / username / MAC → bump last_seen_at and add the traffic since the last run
//   * IP (or username / MAC) changed while online    → close the old row, open a new one
//   * customer went offline / was removed            → close the row (ended_at)
// Everything is done with a handful of batched statements, so it stays cheap with thousands of subscribers, and it is
// idempotent: running it twice in the same minute changes nothing but last_seen_at.
import { db, now, withAdvisoryLock } from '../db/index.js';
import { live } from './service.js';

const CHUNK = 200;
const chunks = (arr, n = CHUNK) => { const out = []; for (let i = 0; i < arr.length; i += n) out.push(arr.slice(i, i + n)); return out; };
const marks = (n) => Array(n).fill('?').join(', ');
const norm = (v) => { const s = v === null || v === undefined ? '' : String(v).trim(); return s ? s.slice(0, 64) : null; };

// Last router byte counters seen per customer (in memory): traffic per session = sum of counter increases.
// A counter that goes down means the router queue was reset, so the new value itself is the increase.
const lastCounters = new Map();
function trafficDelta(customerId, s) {
  const prev = lastCounters.get(customerId);
  const rx = Math.max(0, Number(s?.rx_bytes) || 0); const tx = Math.max(0, Number(s?.tx_bytes) || 0);
  lastCounters.set(customerId, { rx, tx });
  if (!prev) return { rx: 0, tx: 0 }; // first observation after a restart: no baseline yet
  return { rx: rx >= prev.rx ? rx - prev.rx : rx, tx: tx >= prev.tx ? tx - prev.tx : tx };
}

async function customersByIds(ids) {
  const out = new Map();
  for (const part of chunks(ids)) {
    const rows = await db().all(`SELECT id, ip_address, pppoe_username, mac_address, router_id FROM customers WHERE id IN (${marks(part.length)})`, part);
    for (const c of rows) out.set(Number(c.id), c);
  }
  return out;
}

async function run() {
  // No poll since boot: we know nothing about who is online, so never close sessions on an empty picture.
  if (!live.at) return { opened: 0, closed: 0, touched: 0, skipped: true };
  const ts = now();
  const open = await db().all('SELECT id, customer_id, ip, mac, username, started_at FROM session_logs WHERE ended_at IS NULL ORDER BY id ASC');
  const openBy = new Map(); const toClose = [];
  for (const s of open) {
    const cid = Number(s.customer_id);
    if (!s.customer_id) { toClose.push(s.id); continue; }
    if (openBy.has(cid)) toClose.push(openBy.get(cid).id); // duplicate open rows (e.g. a crash mid-run): keep the newest
    openBy.set(cid, s);
  }

  const liveIds = [...live.perCustomer.keys()].map(Number).filter(Boolean);
  const ids = [...new Set([...liveIds, ...openBy.keys()])];
  const customers = await customersByIds(ids);

  const inserts = []; const touch = [];
  for (const cid of ids) {
    const c = customers.get(cid);
    const s = live.perCustomer.get(cid) ?? live.perCustomer.get(String(cid));
    const cur = openBy.get(cid);
    const online = !!(c && s?.online);
    if (!online) {
      if (cur) toClose.push(cur.id);
      lastCounters.delete(cid);
      continue;
    }
    const want = { ip: norm(c.ip_address), username: norm(c.pppoe_username), mac: norm(c.mac_address) };
    const delta = trafficDelta(cid, s);
    if (cur && norm(cur.ip) === want.ip && norm(cur.username) === want.username && norm(cur.mac) === want.mac) {
      touch.push({ id: cur.id, ...delta });
      continue;
    }
    if (cur) toClose.push(cur.id);
    inserts.push([cid, want.username, want.ip, want.mac, c.router_id || null, ts, ts]);
  }

  // Close first so a customer never has two open rows at once.
  for (const part of chunks([...new Set(toClose)])) {
    await db().run(`UPDATE session_logs SET ended_at = ? WHERE ended_at IS NULL AND id IN (${marks(part.length)})`, [ts, ...part]);
  }
  for (const part of chunks(inserts, 100)) {
    await db().run(`INSERT INTO session_logs (customer_id, username, ip, mac, router_id, started_at, last_seen_at) VALUES ${part.map(() => '(?, ?, ?, ?, ?, ?, ?)').join(', ')}`, part.flat());
  }
  for (const part of chunks(touch)) {
    const withTraffic = part.filter((t) => t.rx > 0 || t.tx > 0);
    if (!withTraffic.length) {
      await db().run(`UPDATE session_logs SET last_seen_at = ? WHERE id IN (${marks(part.length)})`, [ts, ...part.map((t) => t.id)]);
      continue;
    }
    // One statement per chunk: CASE adds each session's own traffic (bytes_in = download to the customer).
    const rxCase = withTraffic.map(() => 'WHEN ? THEN bytes_in + ?').join(' ');
    const txCase = withTraffic.map(() => 'WHEN ? THEN bytes_out + ?').join(' ');
    await db().run(
      `UPDATE session_logs SET last_seen_at = ?, bytes_in = CASE id ${rxCase} ELSE bytes_in END, bytes_out = CASE id ${txCase} ELSE bytes_out END WHERE id IN (${marks(part.length)})`,
      [ts, ...withTraffic.flatMap((t) => [t.id, t.rx]), ...withTraffic.flatMap((t) => [t.id, t.tx]), ...part.map((t) => t.id)]);
  }
  return { opened: inserts.length, closed: new Set(toClose).size, touched: touch.length };
}

/** Called every minute by the scheduler (after pollUsage). Never runs twice at the same time. */
export async function recordSessions() {
  const out = await withAdvisoryLock('session_log', run);
  return out.busy ? { busy: true } : out.result;
}

/** Test hook: forget the in-memory byte-counter baselines. */
export const _resetCounters = () => lastCounters.clear();
