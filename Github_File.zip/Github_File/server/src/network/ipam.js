// IP Address Management: pools of Real (public), Dedicated (public, static, single customer) and
// Shared (private / CGNAT behind a NAT address) IPs, allocation to customers and router provisioning.
import { db, insert, now } from '../db/index.js';
import { getDriver } from './drivers.js';
import { HttpError, badRequest, notFound } from '../lib/http.js';

export const IP_KINDS = ['real', 'dedicated', 'shared'];
const MAX_POOL_HOSTS = 4096; // /20 — larger blocks should be split into several pools

export function ipToInt(ip) {
  const p = String(ip).split('.').map(Number);
  if (p.length !== 4 || p.some((n) => !Number.isInteger(n) || n < 0 || n > 255)) throw badRequest(`Invalid IPv4 address: ${ip}`);
  return ((p[0] << 24) >>> 0) + (p[1] << 16) + (p[2] << 8) + p[3];
}
export const intToIp = (n) => [n >>> 24, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join('.');

export function parseCidr(cidr) {
  const m = String(cidr).trim().match(/^(\d{1,3}(?:\.\d{1,3}){3})\/(\d{1,2})$/);
  if (!m) throw badRequest('Use CIDR notation, e.g. 203.0.113.0/27');
  const prefix = Number(m[2]);
  if (prefix < 20 || prefix > 32) throw badRequest(`Pool size must be between /20 (${MAX_POOL_HOSTS} addresses) and /32`);
  const size = 2 ** (32 - prefix);
  const network = (ipToInt(m[1]) & (prefix === 0 ? 0 : (~0 << (32 - prefix)) >>> 0)) >>> 0;
  const first = prefix >= 31 ? network : network + 1; // skip network address
  const last = prefix >= 31 ? network + size - 1 : network + size - 2; // skip broadcast
  return { network, prefix, size, first, last, cidr: `${intToIp(network)}/${prefix}` };
}

export const isPrivate = (ip) => {
  const n = ipToInt(ip);
  const inRange = (base, bits) => (n >>> (32 - bits)) === (ipToInt(base) >>> (32 - bits));
  return inRange('10.0.0.0', 8) || inRange('172.16.0.0', 12) || inRange('192.168.0.0', 16) || inRange('100.64.0.0', 10);
};

/** Create a pool and materialise its usable host addresses. */
export async function createPool(data) {
  const net = parseCidr(data.cidr);
  if (data.kind !== 'shared' && isPrivate(intToIp(net.network))) throw badRequest('Real and dedicated pools must use public addresses');
  if (data.kind === 'shared' && data.nat_address && isPrivate(data.nat_address)) throw badRequest('The NAT address of a shared pool must be public');
  const overlap = await db().get('SELECT address FROM ip_addresses WHERE ip_int BETWEEN ? AND ? LIMIT 1', [net.first, net.last]);
  if (overlap) throw new HttpError(409, `This range overlaps an existing pool (${overlap.address})`);
  const gatewayInt = data.gateway ? ipToInt(data.gateway) : null;
  return db().transaction(async (t) => {
    const pool = await insert('ip_pools', { ...data, cidr: net.cidr, active: data.active ?? true, created_at: now() }, t);
    for (let n = net.first; n <= net.last; n++) {
      const status = n === gatewayInt ? 'reserved' : 'free';
      await insert('ip_addresses', { pool_id: pool.id, address: intToIp(n), ip_int: n, status, notes: n === gatewayInt ? 'Gateway' : null }, t);
    }
    return { id: pool.id, hosts: net.last - net.first + 1 };
  });
}

async function customerRow(id) {
  const c = await db().get('SELECT c.*, r.id AS rid FROM customers c LEFT JOIN routers r ON r.id = c.router_id WHERE c.id = ?', [id]);
  if (!c) throw notFound('Customer not found');
  return c;
}
const routerOf = (c) => (c.router_id ? db().get('SELECT * FROM routers WHERE id = ?', [c.router_id]) : null);

/** Assign an address to a customer. Picks the next free address of the requested kind/pool unless one is given. */
export async function assignIp(customerId, { kind, poolId, address } = {}) {
  const c = await customerRow(customerId);
  const chosen = await db().transaction(async (t) => {
    let row;
    if (address) {
      row = await t.get('SELECT a.*, p.kind, p.monthly_price_cents FROM ip_addresses a JOIN ip_pools p ON p.id = a.pool_id WHERE a.address = ?', [address]);
      if (!row) throw notFound('That address is not in any pool');
      if (row.status !== 'free' && row.customer_id !== c.id) throw new HttpError(409, `Address is ${row.status}`);
    } else {
      const where = ['a.status = ?', 'p.active = 1']; const params = ['free'];
      if (poolId) { where.push('p.id = ?'); params.push(poolId); }
      if (kind) { where.push('p.kind = ?'); params.push(kind); }
      // Prefer pools attached to the customer's router.
      row = await t.get(`SELECT a.*, p.kind, p.monthly_price_cents FROM ip_addresses a JOIN ip_pools p ON p.id = a.pool_id
        WHERE ${where.join(' AND ')} ORDER BY CASE WHEN p.router_id = ? THEN 0 ELSE 1 END, a.ip_int LIMIT 1`, [...params, c.router_id ?? -1]);
      if (!row) throw new HttpError(409, `No free ${kind || ''} addresses left — add a pool or release unused IPs`);
    }
    // Release the customer's previous address (one IP per customer).
    await t.run("UPDATE ip_addresses SET status = 'free', customer_id = NULL, released_at = ? WHERE customer_id = ? AND id != ?", [now(), c.id, row.id]);
    const claimed = await t.run("UPDATE ip_addresses SET status = 'assigned', customer_id = ?, assigned_at = ? WHERE id = ? AND (status = 'free' OR customer_id = ?)", [c.id, now(), row.id, c.id]);
    if (!claimed.changes) throw new HttpError(409, 'Address was just taken — try again');
    await t.run('UPDATE customers SET ip_address = ?, ip_type = ?, ip_addon_cents = ?, connection_type = CASE WHEN pppoe_username IS NULL OR pppoe_username = \'\' THEN \'static\' ELSE connection_type END, updated_at = ? WHERE id = ?',
      [row.address, row.kind, row.kind === 'shared' ? 0 : Number(row.monthly_price_cents || 0), now(), c.id]);
    return row;
  });
  const pool = await db().get('SELECT * FROM ip_pools WHERE id = ?', [chosen.pool_id]);
  let sync = { ok: true };
  try { await getDriver(await routerOf(c)).assignIp({ ...c, ip_address: chosen.address }, chosen.address, pool); }
  catch (e) { sync = { ok: false, error: e.message }; }
  return { address: chosen.address, kind: chosen.kind, monthlyCents: chosen.kind === 'shared' ? 0 : Number(chosen.monthly_price_cents || 0), sync };
}

export async function releaseIp(customerId) {
  const c = await customerRow(customerId);
  await db().run("UPDATE ip_addresses SET status = 'free', customer_id = NULL, released_at = ? WHERE customer_id = ?", [now(), c.id]);
  await db().run('UPDATE customers SET ip_address = NULL, ip_type = NULL, ip_addon_cents = 0, updated_at = ? WHERE id = ?', [now(), c.id]);
  let sync = { ok: true };
  try { await getDriver(await routerOf(c)).releaseIp(c); } catch (e) { sync = { ok: false, error: e.message }; }
  return { ok: true, sync };
}

/** Mark addresses that already appear on customers (e.g. imported or typed manually) as assigned. */
export async function reconcileAssignments() {
  const rows = await db().all("SELECT c.id, c.ip_address FROM customers c WHERE c.ip_address IS NOT NULL AND c.ip_address != ''");
  let fixed = 0;
  for (const r of rows) {
    const a = await db().get('SELECT a.id, a.status, a.customer_id, p.kind FROM ip_addresses a JOIN ip_pools p ON p.id = a.pool_id WHERE a.address = ?', [r.ip_address]);
    if (a && (a.status !== 'assigned' || a.customer_id !== r.id)) {
      await db().run("UPDATE ip_addresses SET status = 'assigned', customer_id = ?, assigned_at = COALESCE(assigned_at, ?) WHERE id = ?", [r.id, now(), a.id]);
      await db().run('UPDATE customers SET ip_type = ? WHERE id = ?', [a.kind, r.id]);
      fixed++;
    }
  }
  return fixed;
}
