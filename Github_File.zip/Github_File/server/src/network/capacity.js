// Core bandwidth transparency: how much upstream capacity the ISP has (configured by the admin, or
// auto-detected from the core router when nothing is configured), how much is sold to customers,
// and how much is actually used — overall and per customer.
import { db, insert, now, parseJson } from '../db/index.js';
import { getDriver } from './drivers.js';
import { live, effectiveBandwidth } from './service.js';

const TIERS_MBPS = [10, 20, 50, 100, 200, 300, 500, 1000, 2000, 2500, 5000, 10000, 20000, 25000, 40000, 50000, 100000];
const tierFor = (mbps) => TIERS_MBPS.find((t) => t >= mbps) || Math.ceil(mbps / 10000) * 10000;

async function coreRouters() {
  const rows = await db().all("SELECT * FROM routers WHERE role = 'core'");
  return rows.length ? rows : db().all('SELECT * FROM routers');
}

/** Every minute: sample configured upstream links, or the auto-detected WAN of each core router. */
export async function sampleLinks() {
  const ts = now();
  // A link whose router was deleted (router_id NULL) must not be sampled: the simulator would invent traffic for it.
  const links = await db().all('SELECT * FROM upstream_links WHERE active = 1 AND interface IS NOT NULL AND router_id IS NOT NULL');
  const byRouter = new Map();
  for (const l of links) { if (!byRouter.has(l.router_id)) byRouter.set(l.router_id, []); byRouter.get(l.router_id).push({ key: `link:${l.id}`, iface: l.interface }); }
  if (!links.length) {
    for (const r of await coreRouters()) {
      const wan = parseJson(r.info, {})?.wanInterface || (r.driver === 'simulator' ? 'ether1-wan' : null);
      if (wan) byRouter.set(r.id, [{ key: `auto:${r.id}`, iface: wan }]);
    }
  }
  for (const [routerId, items] of byRouter) {
    const router = await db().get('SELECT * FROM routers WHERE id = ?', [routerId]);
    if (!router) continue;
    try {
      const rates = await getDriver(router).interfaceRates(items.map((i) => i.iface));
      for (const i of items) {
        const r = rates[i.iface];
        if (r) await insert('link_samples', { link_key: i.key, ts, rx_bps: r.rxBps, tx_bps: r.txBps });
      }
    } catch { /* router offline — skip this minute */ }
  }
  await db().run('DELETE FROM link_samples WHERE ts < ?', [new Date(Date.now() - 35 * 86400000).toISOString()]);
}

async function peak(sql, params) {
  const row = await db().get(sql, params);
  return { rx: Number(row?.rx || 0), tx: Number(row?.tx || 0) };
}

export async function analyse({ days = 7 } = {}) {
  const since = new Date(Date.now() - days * 86400000).toISOString();
  const links = await db().all('SELECT * FROM upstream_links WHERE active = 1');
  let capacity; let source;
  if (links.length) {
    source = 'configured';
    capacity = { downKbps: links.reduce((s, l) => s + Number(l.capacity_down_kbps), 0), upKbps: links.reduce((s, l) => s + Number(l.capacity_up_kbps), 0) };
  } else {
    // Not configured: infer from what the core actually carried (WAN peak), rounded up to a standard circuit size.
    source = 'detected';
    const p = await peak(`SELECT MAX(rx_bps) AS rx, MAX(tx_bps) AS tx FROM link_samples WHERE link_key LIKE 'auto:%' AND ts >= ?`, [since]);
    const custPeak = await peak('SELECT MAX(s.rx) AS rx, MAX(s.tx) AS tx FROM (SELECT ts, SUM(rx_bps) AS rx, SUM(tx_bps) AS tx FROM usage_samples WHERE ts >= ? GROUP BY ts) s', [since]);
    const rxPeak = Math.max(p.rx, custPeak.rx); const txPeak = Math.max(p.tx, custPeak.tx);
    capacity = {
      downKbps: rxPeak ? tierFor((rxPeak * 1.2) / 1e6) * 1000 : 0,
      upKbps: txPeak ? tierFor((txPeak * 1.2) / 1e6) * 1000 : 0,
      observedPeakRxBps: rxPeak, observedPeakTxBps: txPeak,
    };
  }

  const customers = await db().all(`SELECT c.id, c.code, c.status, c.ip_address, c.ip_type, c.custom_download_kbps, c.custom_upload_kbps, c.router_id, u.name, p.name AS plan_name, p.download_kbps, p.upload_kbps
    FROM customers c JOIN users u ON u.id = c.user_id LEFT JOIN plans p ON p.id = c.plan_id WHERE c.status = 'active'`);
  const stats = await db().all('SELECT customer_id, AVG(rx_bps) AS avg_rx, MAX(rx_bps) AS peak_rx, AVG(tx_bps) AS avg_tx, MAX(tx_bps) AS peak_tx, COUNT(*) AS n FROM usage_samples WHERE ts >= ? GROUP BY customer_id', [since]);
  const byId = new Map(stats.map((s) => [s.customer_id, s]));

  let provDown = 0; let provUp = 0;
  const rows = customers.map((c) => {
    const bw = effectiveBandwidth(c);
    provDown += bw.downKbps; provUp += bw.upKbps;
    const s = byId.get(c.id) || {};
    const peakRx = Number(s.peak_rx || 0); const avgRx = Number(s.avg_rx || 0);
    const flags = [];
    if (!bw.downKbps) flags.push('no_plan_speed');
    if (bw.downKbps && peakRx > bw.downKbps * 1000 * 1.1) flags.push('over_limit'); // router limit not enforced
    if (!Number(s.n)) flags.push('no_data');
    else if (peakRx === 0) flags.push('idle');
    if (!c.ip_address) flags.push('no_ip');
    return {
      id: c.id, code: c.code, name: c.name, plan: c.plan_name, ipType: c.ip_type, ip: c.ip_address,
      provisionedDownKbps: bw.downKbps, provisionedUpKbps: bw.upKbps, avgRxBps: Math.round(avgRx), peakRxBps: peakRx,
      utilization: bw.downKbps ? +(peakRx / (bw.downKbps * 1000) * 100).toFixed(1) : null,
      live: live.perCustomer.get(c.id) || null, flags,
    };
  }).sort((a, b) => b.peakRxBps - a.peakRxBps);

  const series = await db().all('SELECT ts, SUM(rx_bps) AS rx, SUM(tx_bps) AS tx FROM usage_samples WHERE ts >= ? GROUP BY ts ORDER BY ts', [since]);
  const linkSeries = await db().all('SELECT ts, SUM(rx_bps) AS rx, SUM(tx_bps) AS tx FROM link_samples WHERE ts >= ? GROUP BY ts ORDER BY ts', [since]);
  const usagePeak = series.reduce((m, s) => Math.max(m, Number(s.rx)), 0);
  const step = Math.max(1, Math.ceil(series.length / 300));
  const capBps = capacity.downKbps * 1000;

  return {
    source, capacity, links,
    provisioned: { downKbps: provDown, upKbps: provUp, customers: customers.length },
    oversubscription: capacity.downKbps ? +(provDown / capacity.downKbps).toFixed(2) : null,
    usage: {
      liveRxBps: live.totals.rx_bps, liveTxBps: live.totals.tx_bps, online: live.totals.online,
      peakRxBps: usagePeak, peakUtilization: capBps ? +(usagePeak / capBps * 100).toFixed(1) : null,
      liveUtilization: capBps ? +(live.totals.rx_bps / capBps * 100).toFixed(1) : null,
      headroomBps: capBps ? Math.max(0, capBps - usagePeak) : null,
    },
    series: series.filter((_, i) => i % step === 0).map((s) => ({ ts: s.ts, rx: Number(s.rx), tx: Number(s.tx) })),
    linkSeries: linkSeries.filter((_, i) => i % Math.max(1, Math.ceil(linkSeries.length / 300)) === 0).map((s) => ({ ts: s.ts, rx: Number(s.rx), tx: Number(s.tx) })),
    customers: rows,
    summary: {
      overLimit: rows.filter((r) => r.flags.includes('over_limit')).length,
      idle: rows.filter((r) => r.flags.includes('idle')).length,
      noIp: rows.filter((r) => r.flags.includes('no_ip')).length,
    },
    recommendations: recommendations({ capacity, provDown, usagePeak, rows, source }),
  };
}

function recommendations({ capacity, provDown, usagePeak, rows, source }) {
  const out = [];
  const capBps = capacity.downKbps * 1000;
  if (source === 'detected') out.push({ level: 'info', text: 'Upstream capacity is estimated from observed peak traffic. Add your upstream links (bandwidth purchased from your provider) for exact figures.' });
  if (capBps && usagePeak > capBps * 0.85) out.push({ level: 'bad', text: `Peak usage reached ${Math.round(usagePeak / capBps * 100)}% of upstream capacity — customers will feel congestion. Buy more upstream bandwidth or rebalance.` });
  else if (capBps && usagePeak > capBps * 0.7) out.push({ level: 'warn', text: 'Peak usage is above 70% of capacity — plan an upstream upgrade.' });
  const ratio = capacity.downKbps ? provDown / capacity.downKbps : 0;
  if (ratio > 20) out.push({ level: 'warn', text: `Contention ratio is 1:${ratio.toFixed(0)} — high for residential service (typical 1:8 to 1:20).` });
  const over = rows.filter((r) => r.flags.includes('over_limit'));
  if (over.length) out.push({ level: 'bad', text: `${over.length} customer(s) used more than their plan speed — their limits are not enforced on the router. Use "Sync all" on the router.` });
  const noIp = rows.filter((r) => r.flags.includes('no_ip')).length;
  if (noIp) out.push({ level: 'info', text: `${noIp} active customer(s) have no IP recorded — assign one from IP management.` });
  return out;
}
