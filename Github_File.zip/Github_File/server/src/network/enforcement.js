// Strict usage enforcement — no customer may use more bandwidth or data than their package / admin-set limit.
//  * Speed: every customer has a hard router queue (max-limit, no burst). The watchdog compares live rates with the
//    allowed speed every minute; anyone above it (beyond measurement tolerance) gets the limit re-applied at once and
//    the violation is logged.
//  * Data: when a plan has a monthly data cap and it is used up, the customer is throttled (or suspended, per
//    Settings → Enforcement) until the next calendar month.
import { db, now } from '../db/index.js';
import { getSetting } from '../lib/settings.js';
import { audit } from '../lib/audit.js';
import { queueNotify } from '../lib/notify.js';
import { live, syncCustomer } from './service.js';

const period = () => new Date().toISOString().slice(0, 7); // YYYY-MM

/** Speed watchdog — runs after every usage poll. */
export async function enforceSpeed() {
  const enf = await getSetting('enforcement');
  if (!enf.strictSpeed || !live.perCustomer.size) return 0;
  const ids = [...live.perCustomer.keys()];
  const rows = await db().all(`SELECT c.id, c.custom_download_kbps, c.custom_upload_kbps, c.cap_exceeded, p.download_kbps, p.upload_kbps
    FROM customers c LEFT JOIN plans p ON p.id = c.plan_id WHERE c.status = 'active' AND c.id IN (${ids.map(() => '?').join(',')})`, ids);
  const tol = 1 + (Number(enf.speedTolerancePct) || 0) / 100;
  let fixed = 0;
  for (const c of rows) {
    const throttled = c.cap_exceeded && enf.dataCapAction === 'throttle';
    const down = throttled ? Number(enf.throttleKbps) : Number(c.custom_download_kbps || c.download_kbps || 0);
    const up = throttled ? Number(enf.throttleKbps) : Number(c.custom_upload_kbps || c.upload_kbps || 0);
    const s = live.perCustomer.get(c.id);
    if (!s || !down) continue;
    if (s.rx_bps > down * 1000 * tol || (up && s.tx_bps > up * 1000 * tol)) {
      await db().run('UPDATE customers SET speed_violations = speed_violations + 1 WHERE id = ?', [c.id]);
      await syncCustomer(c.id); // re-apply the hard limit on the router
      await audit(null, 'enforcement.speed_violation', 'customer', c.id, { rx_bps: s.rx_bps, tx_bps: s.tx_bps, allowed_down_kbps: down, allowed_up_kbps: up });
      fixed++;
    }
  }
  return fixed;
}

/** Monthly data-cap enforcement + month rollover. */
export async function enforceDataCaps() {
  const enf = await getSetting('enforcement');
  const p = period();
  // 1) New month: lift last month's caps.
  const expired = await db().all(`SELECT c.id, c.user_id, c.status, c.suspended_reason, p.data_cap_mb FROM customers c LEFT JOIN plans p ON p.id = c.plan_id
    WHERE c.cap_exceeded = 1 AND (c.cap_period IS NULL OR c.cap_period != ?)`, [p]);
  let renewed = 0;
  for (const c of expired) {
    // Still over the allowance in the NEW period (or plan lost its cap)? Carry the flag forward instead of flapping.
    const used = await db().get("SELECT COALESCE(SUM(bytes), 0) AS v FROM traffic_daily WHERE customer_id = ? AND category = 'total' AND day >= ?", [c.id, `${p}-01`]);
    if (Number(c.data_cap_mb) > 0 && Number(used.v) >= Number(c.data_cap_mb) * 1024 * 1024) {
      await db().run('UPDATE customers SET cap_period = ? WHERE id = ?', [p, c.id]);
      continue;
    }
    renewed++;
    const reactivate = c.status === 'suspended' && c.suspended_reason === 'data_cap';
    await db().run(`UPDATE customers SET cap_exceeded = 0, cap_period = NULL${reactivate ? ", status = 'active', suspended_reason = NULL" : ''}, updated_at = ? WHERE id = ?`, [now(), c.id]);
    await syncCustomer(c.id);
    queueNotify({ userId: c.user_id, channels: ['inapp', 'push'], subject: 'Data allowance renewed', body: 'Your monthly data allowance has been reset — full speed restored.', kind: 'success' });
  }
  // 2) Customers who used up this month's allowance.
  const capped = await db().all(`SELECT c.id, c.user_id, p.data_cap_mb FROM customers c JOIN plans p ON p.id = c.plan_id
    WHERE c.status = 'active' AND p.data_cap_mb > 0 AND (c.cap_exceeded = 0 OR c.cap_exceeded IS NULL)`);
  let hit = 0;
  for (const c of capped) {
    const used = await db().get("SELECT COALESCE(SUM(bytes), 0) AS v FROM traffic_daily WHERE customer_id = ? AND category = 'total' AND day >= ?", [c.id, `${p}-01`]);
    if (Number(used.v) < Number(c.data_cap_mb) * 1024 * 1024) continue;
    const suspend = enf.dataCapAction === 'suspend';
    await db().run(`UPDATE customers SET cap_exceeded = 1, cap_period = ?${suspend ? ", status = 'suspended', suspended_reason = 'data_cap'" : ''}, updated_at = ? WHERE id = ?`, [p, now(), c.id]);
    await syncCustomer(c.id);
    await audit(null, 'enforcement.data_cap', 'customer', c.id, { used: Number(used.v), cap_mb: c.data_cap_mb, action: enf.dataCapAction });
    queueNotify({
      userId: c.user_id, channels: ['inapp', 'push', 'email'], kind: 'warning',
      subject: 'Monthly data allowance used up',
      body: suspend ? 'You have used your monthly data allowance, so your service is paused until next month. Upgrade your plan to continue now.'
        : `You have used your monthly data allowance. Speed is limited to ${enf.throttleKbps} Kbps until next month — upgrade your plan for full speed.`,
      link: '/portal/plans',
    });
    hit++;
  }
  return { renewed, capped: hit };
}

/** Speed the router should enforce for a customer right now (plan/custom, or throttle when the cap is used up). */
export async function allowedSpeed(c) {
  const enf = await getSetting('enforcement');
  if (c.cap_exceeded && enf.dataCapAction === 'throttle') return { downKbps: Number(enf.throttleKbps), upKbps: Number(enf.throttleKbps), throttled: true };
  return { downKbps: c.custom_download_kbps || c.download_kbps || 0, upKbps: c.custom_upload_kbps || c.upload_kbps || 0, throttled: false };
}
