// Router drivers. Every driver implements the same interface so the rest of the app is vendor-neutral:
//   test(), applyBandwidth(c, kbps), setEnabled(c, bool), kick(c), stats(customers), ping(t), traceroute(t),
//   syncSiteRules(rules, customersById), applyParental(c, cfg)
// Add new vendors (Cisco, Huawei, Juniper, OLT/TR-069, RADIUS CoA...) by implementing this interface.
import https from 'node:https';
import tls from 'node:tls';
import { decrypt } from '../lib/crypto.js';

export const normalizeFingerprint = (fp) => (fp ? String(fp).replace(/[^a-fA-F0-9]/g, '').toUpperCase() : null);

/** Opens a TLS connection and resolves only if the peer certificate matches the pinned SHA-256 fingerprint. */
export function pinnedTlsSocket(host, port, pin, { timeout = 15000 } = {}) {
  return new Promise((resolve, reject) => {
    const s = tls.connect({ host, port, servername: /^[\d.]+$/.test(host) ? undefined : host, rejectUnauthorized: false });
    s.setTimeout(timeout, () => s.destroy(new Error('Router timeout')));
    s.once('error', reject);
    s.once('secureConnect', () => {
      const fp = normalizeFingerprint(s.getPeerCertificate()?.fingerprint256);
      if (!pin || fp !== pin) { s.destroy(); return reject(new Error('Router certificate does not match the pinned fingerprint (possible interception)')); }
      s.setTimeout(0);
      resolve(s);
    });
  });
}

/** Reads a server's certificate fingerprint so an admin can confirm and pin it (trust on first use, explicitly). */
export function fetchCertificateFingerprint(host, port) {
  return new Promise((resolve, reject) => {
    const s = tls.connect({ host, port, servername: /^[\d.]+$/.test(host) ? undefined : host, rejectUnauthorized: false });
    s.setTimeout(8000, () => s.destroy(new Error('Timeout')));
    s.once('error', reject);
    s.once('secureConnect', () => {
      const c = s.getPeerCertificate();
      s.end();
      resolve({ fingerprint256: c.fingerprint256, subject: c.subject?.CN || '', issuer: c.issuer?.CN || '', validTo: c.valid_to, selfSigned: c.subject?.CN === c.issuer?.CN });
    });
  });
}

export const CATEGORY_DOMAINS = {
  social: ['facebook.com', 'instagram.com', 'tiktok.com', 'twitter.com', 'x.com', 'snapchat.com', 'messenger.com'],
  gaming: ['steampowered.com', 'epicgames.com', 'roblox.com', 'xboxlive.com', 'playstation.net', 'pubgmobile.com', 'garena.com'],
  streaming: ['youtube.com', 'googlevideo.com', 'netflix.com', 'twitch.tv', 'primevideo.com', 'hotstar.com'],
  gambling: ['bet365.com', '1xbet.com', 'stake.com', 'pokerstars.com', 'betway.com'],
  adult: [], // handled by redirecting DNS to a family-safe resolver
};
export const FAMILY_DNS = '185.228.168.168'; // CleanBrowsing Family filter

const qname = (c) => `aura-${c.code}`;
const kbps = (n) => `${Math.max(1, Math.round(n))}k`;

// ---------------------------------------------------------------- MikroTik RouterOS v7 REST API
class MikrotikDriver {
  constructor(router) {
    this.router = router;
    const scheme = router.use_tls ? 'https' : 'http';
    const port = router.port || (router.use_tls ? 443 : 80);
    this.base = `${scheme}://${router.host}:${port}/rest`;
    this.auth = `Basic ${Buffer.from(`${router.username}:${decrypt(router.password_enc) || ''}`).toString('base64')}`;
    // Self-signed router certificates are handled by PINNING the certificate's SHA-256 fingerprint
    // (never by blindly disabling verification). Without a pin, the system CA store is used.
    this.pin = router.use_tls && !router.verify_tls ? normalizeFingerprint(router.tls_fingerprint) : null;
    if (router.use_tls && !router.verify_tls && !this.pin) this.pinMissing = true;
  }

  async req(method, path, body) {
    if (this.pinMissing) throw new Error('This router uses a self-signed certificate: fetch and confirm its fingerprint (Routers → Edit) before connecting');
    const url = `${this.base}${path}`;
    if (this.pin) {
      // 1) Complete the TLS handshake and verify the certificate fingerprint FIRST.
      const socket = await pinnedTlsSocket(this.router.host, this.router.port || 443, this.pin);
      // 2) Only then send the HTTP request (with credentials) over that verified socket.
      return new Promise((resolve, reject) => {
        const r = https.request(url, {
          method, timeout: 15000, headers: { Authorization: this.auth, 'Content-Type': 'application/json' },
          agent: false, createConnection: () => socket,
        }, (res) => {
          let data = ''; res.on('data', (d) => (data += d));
          res.on('end', () => {
            let json = null;
            try { json = data ? JSON.parse(data) : null; } catch { return reject(new Error('Router returned invalid JSON')); }
            if (res.statusCode >= 400) reject(new Error(json?.detail || json?.message || `RouterOS HTTP ${res.statusCode}`));
            else resolve(json);
          });
        });
        r.on('timeout', () => r.destroy(new Error('Router timeout')));
        r.on('error', reject);
        if (body) r.write(JSON.stringify(body));
        r.end();
      });
    }
    const res = await fetch(url, {
      method, body: body ? JSON.stringify(body) : undefined,
      headers: { Authorization: this.auth, 'Content-Type': 'application/json' },
      signal: AbortSignal.timeout(15000),
    });
    const text = await res.text();
    const json = text ? JSON.parse(text) : null;
    if (!res.ok) throw new Error(json?.detail || json?.message || `RouterOS HTTP ${res.status}`);
    return json;
  }

  async test() {
    const r = await this.req('GET', '/system/resource');
    return { ok: true, info: { version: r.version, board: r['board-name'], uptime: r.uptime, cpuLoad: r['cpu-load'] } };
  }

  async findQueue(c) {
    const list = await this.req('GET', `/queue/simple?name=${encodeURIComponent(qname(c))}`);
    return list?.[0];
  }

  async applyBandwidth(c, { downKbps, upKbps }) {
    const maxLimit = `${kbps(upKbps)}/${kbps(downKbps)}`;
    const existing = await this.findQueue(c);
    const target = c.ip_address || (c.pppoe_username ? `<pppoe-${c.pppoe_username}>` : null);
    if (!target) throw new Error('Customer has no IP address or PPPoE username');
    // Hard cap: max-limit only — burst disabled so nobody can exceed the package speed even briefly.
    const body = { 'max-limit': maxLimit, 'burst-limit': '0/0', 'burst-threshold': '0/0', 'burst-time': '0s/0s', target, disabled: 'false' };
    if (existing) await this.req('PATCH', `/queue/simple/${existing['.id']}`, body);
    else await this.req('PUT', '/queue/simple', { name: qname(c), ...body, comment: 'aura:managed' });
    return { maxLimit };
  }

  async setEnabled(c, enabled) {
    if (c.pppoe_username) {
      const [sec] = await this.req('GET', `/ppp/secret?name=${encodeURIComponent(c.pppoe_username)}`) || [];
      if (sec) await this.req('PATCH', `/ppp/secret/${sec['.id']}`, { disabled: enabled ? 'false' : 'true' });
      if (!enabled) await this.kick(c).catch(() => {});
    }
    if (c.ip_address) {
      const list = await this.req('GET', `/ip/firewall/address-list?list=aura-suspended&address=${encodeURIComponent(c.ip_address)}`);
      if (!enabled && !list?.length) await this.req('PUT', '/ip/firewall/address-list', { list: 'aura-suspended', address: c.ip_address, comment: qname(c) });
      if (enabled) for (const e of list || []) await this.req('DELETE', `/ip/firewall/address-list/${e['.id']}`);
    }
  }

  async kick(c) {
    if (!c.pppoe_username) throw new Error('Only PPPoE sessions can be reconnected');
    const active = await this.req('GET', `/ppp/active?name=${encodeURIComponent(c.pppoe_username)}`);
    for (const a of active || []) await this.req('DELETE', `/ppp/active/${a['.id']}`);
    return { disconnected: active?.length || 0 };
  }

  async stats(customers) {
    const queues = await this.req('GET', '/queue/simple');
    const byName = new Map((queues || []).map((q) => [q.name, q]));
    return customers.map((c) => {
      const q = byName.get(qname(c));
      if (!q) return { customer_id: c.id, online: false, rx_bytes: 0, tx_bytes: 0, rx_bps: 0, tx_bps: 0 };
      // simple queue: "upload/download" from the customer's point of view
      const [upB, downB] = String(q.bytes || '0/0').split('/').map(Number);
      const [upR, downR] = String(q.rate || '0/0').split('/').map(Number);
      return { customer_id: c.id, online: downR + upR > 0, rx_bytes: downB, tx_bytes: upB, rx_bps: downR, tx_bps: upR };
    });
  }

  async ping(target) {
    const r = await this.req('POST', '/ping', { address: target, count: '4' });
    const times = (r || []).map((x) => parseFloat(String(x.time || '').replace(/ms.*/, ''))).filter((n) => !Number.isNaN(n));
    return { sent: 4, received: times.length, loss: Math.round((1 - times.length / 4) * 100), avgMs: times.length ? +(times.reduce((a, b) => a + b, 0) / times.length).toFixed(1) : null, samples: times };
  }

  async traceroute(target) {
    const r = await this.req('POST', '/tool/traceroute', { address: target, count: '1' });
    return { hops: (r || []).map((h, i) => ({ hop: i + 1, address: h.address || '*', ms: parseFloat(h.last) || null, loss: h.loss })) };
  }

  async removeByComment(path, prefix) {
    const items = await this.req('GET', path);
    for (const it of items || []) if (String(it.comment || '').startsWith(prefix)) await this.req('DELETE', `${path}/${it['.id']}`);
  }

  async syncSiteRules(rules, customersById) {
    await this.removeByComment('/ip/dns/static', 'aura:rule');
    await this.removeByComment('/ip/firewall/filter', 'aura:rule');
    for (const r of rules) {
      const domains = r.domain ? [r.domain] : CATEGORY_DOMAINS[r.category] || [];
      for (const d of domains) {
        if (r.scope === 'global' && r.action === 'block' && !r.schedule?.time) {
          await this.req('PUT', '/ip/dns/static', { regexp: `(^|\\.)${d.replace(/\./g, '\\.')}$`, address: '0.0.0.0', comment: `aura:rule:${r.id}` });
        } else {
          const c = customersById.get(r.customer_id);
          const body = { chain: 'forward', protocol: 'tcp', 'dst-port': '443', 'tls-host': `*${d}`, action: r.action === 'allow' ? 'accept' : 'drop', comment: `aura:rule:${r.id}` };
          if (c?.ip_address) body['src-address'] = c.ip_address;
          if (r.schedule?.time) body.time = r.schedule.time;
          await this.req('PUT', '/ip/firewall/filter', body);
        }
      }
    }
  }

  async applyParental(c, cfg) {
    if (!c.ip_address) throw new Error('Parental controls need a customer IP address (static or PPPoE remote-address)');
    const tag = `aura:parental:${c.code}`;
    await this.removeByComment('/ip/firewall/filter', tag);
    await this.removeByComment('/ip/firewall/nat', tag);
    if (!cfg?.enabled) return;
    for (const cat of cfg.blockedCategories || []) {
      for (const d of CATEGORY_DOMAINS[cat] || []) {
        await this.req('PUT', '/ip/firewall/filter', { chain: 'forward', 'src-address': c.ip_address, protocol: 'tcp', 'dst-port': '443', 'tls-host': `*${d}`, action: 'drop', comment: tag });
      }
    }
    for (const d of cfg.blockedDomains || []) {
      await this.req('PUT', '/ip/firewall/filter', { chain: 'forward', 'src-address': c.ip_address, protocol: 'tcp', 'dst-port': '443', 'tls-host': `*${d}`, action: 'drop', comment: tag });
    }
    for (const s of cfg.schedules || []) {
      // Pause internet in these windows. time format: "22h-23h59m,sun,mon,..."
      await this.req('PUT', '/ip/firewall/filter', { chain: 'forward', 'src-address': c.ip_address, action: 'drop', time: `${s.from}-${s.to},${(s.days || []).join(',')}`, comment: tag });
    }
    if (cfg.safeSearch || (cfg.blockedCategories || []).includes('adult')) {
      for (const proto of ['udp', 'tcp']) {
        await this.req('PUT', '/ip/firewall/nat', { chain: 'dstnat', 'src-address': c.ip_address, protocol: proto, 'dst-port': '53', action: 'dst-nat', 'to-addresses': FAMILY_DNS, comment: tag });
      }
    }
  }
}

// ---- core integration / IPAM (MikroTik) ------------------------------------------------------
Object.assign(MikrotikDriver.prototype, {
  /** Read what is already configured on the core router so AuraISP can adopt it (no changes are made). */
  async discover() {
    const [res, ifaces, routes, secrets, active, queues, pools] = await Promise.all([
      this.req('GET', '/system/resource'), this.req('GET', '/interface'), this.req('GET', '/ip/route').catch(() => []),
      this.req('GET', '/ppp/secret').catch(() => []), this.req('GET', '/ppp/active').catch(() => []),
      this.req('GET', '/queue/simple').catch(() => []), this.req('GET', '/ip/pool').catch(() => []),
    ]);
    const def = (routes || []).find((r) => r['dst-address'] === '0.0.0.0/0' && r.active !== 'false');
    const wan = def ? String(def['immediate-gw'] || '').split('%')[1] || null : null;
    const names = (ifaces || []).filter((i) => i.running === 'true' && ['ether', 'sfp', 'sfp-sfpplus', 'vlan', 'bonding', 'pppoe-out'].some((t) => String(i.type || '').startsWith(t))).map((i) => i.name);
    const rates = await this.interfaceRates(names).catch(() => ({}));
    return {
      router: { version: res.version, board: res['board-name'], uptime: res.uptime, cpuLoad: Number(res['cpu-load']) },
      wanInterface: wan,
      interfaces: (ifaces || []).map((i) => ({ name: i.name, type: i.type, running: i.running === 'true', rxBytes: Number(i['rx-byte'] || 0), txBytes: Number(i['tx-byte'] || 0), ...(rates[i.name] || {}) })),
      pppSecrets: (secrets || []).map((s) => ({ name: s.name, profile: s.profile, remoteAddress: s['remote-address'] || null, disabled: s.disabled === 'true', comment: s.comment || '' })),
      activeSessions: (active || []).map((a) => ({ name: a.name, address: a.address, uptime: a.uptime, callerId: a['caller-id'] })),
      queues: (queues || []).map((q) => ({ name: q.name, target: q.target, maxLimit: q['max-limit'], managed: String(q.comment || '').startsWith('aura:') })),
      ipPools: (pools || []).map((p) => ({ name: p.name, ranges: p.ranges })),
    };
  },

  /** Current bits-per-second on interfaces (one-shot monitor-traffic). */
  async interfaceRates(names) {
    if (!names.length) return {};
    const out = await this.req('POST', '/interface/monitor-traffic', { interface: names.join(','), once: '' });
    return Object.fromEntries((out || []).map((r) => [r.name, { rxBps: Number(r['rx-bits-per-second'] || 0), txBps: Number(r['tx-bits-per-second'] || 0) }]));
  },

  /** Create/refresh the pool on the router; shared pools also get a source-NAT rule to their public NAT address. */
  async ensurePool(pool) {
    const tag = `aura:pool:${pool.id}`;
    await this.removeByComment('/ip/pool', tag);
    await this.req('PUT', '/ip/pool', { name: `aura-${pool.kind}-${pool.id}`, ranges: pool.cidr, comment: tag });
    await this.removeByComment('/ip/firewall/nat', tag);
    if (pool.kind === 'shared' && pool.nat_address) {
      await this.req('PUT', '/ip/firewall/nat', { chain: 'srcnat', 'src-address': pool.cidr, action: 'src-nat', 'to-addresses': pool.nat_address, comment: tag });
    }
    return { ok: true };
  },

  /** Give a customer a specific address: PPPoE remote-address, or a static ARP/queue target for static users. */
  async assignIp(c, address, pool) {
    if (c.pppoe_username) {
      const [sec] = await this.req('GET', `/ppp/secret?name=${encodeURIComponent(c.pppoe_username)}`) || [];
      if (sec) await this.req('PATCH', `/ppp/secret/${sec['.id']}`, { 'remote-address': address });
      await this.kick(c).catch(() => {}); // reconnect so the new address takes effect
    }
    await this.removeByComment('/ip/firewall/address-list', `aura:ip:${c.code}`);
    await this.req('PUT', '/ip/firewall/address-list', { list: `aura-${pool.kind}`, address, comment: `aura:ip:${c.code}` });
    return { ok: true };
  },

  async releaseIp(c) {
    if (c.pppoe_username) {
      const [sec] = await this.req('GET', `/ppp/secret?name=${encodeURIComponent(c.pppoe_username)}`) || [];
      if (sec) await this.req('PATCH', `/ppp/secret/${sec['.id']}`, { 'remote-address': '' });
    }
    await this.removeByComment('/ip/firewall/address-list', `aura:ip:${c.code}`);
    return { ok: true };
  },
});

// ---------------------------------------------------------------- Simulator (demo / development)
const simState = new Map();
class SimulatorDriver {
  constructor(router) { this.router = router; }
  async test() { return { ok: true, info: { version: 'simulator', board: 'Virtual CCR', uptime: `${Math.floor(process.uptime())}s`, cpuLoad: Math.floor(Math.random() * 30) } }; }
  async applyBandwidth(c, { downKbps, upKbps }) {
    const s = simState.get(c.id) || { rx: 0, tx: 0 };
    simState.set(c.id, { ...s, downKbps, upKbps });
    return { maxLimit: `${kbps(upKbps)}/${kbps(downKbps)}` };
  }
  async setEnabled(c, enabled) { const s = simState.get(c.id) || { rx: 0, tx: 0 }; simState.set(c.id, { ...s, disabled: !enabled }); }
  async kick() { return { disconnected: 1 }; }
  async stats(customers) {
    const t = Date.now() / 1000;
    return customers.map((c) => {
      const s = simState.get(c.id) || { rx: Math.random() * 5e9, tx: Math.random() * 1e9 };
      const down = (s.downKbps || c.download_kbps || 20000) * 1000;
      const up = (s.upKbps || c.upload_kbps || 10000) * 1000;
      const online = c.status === 'active' && !s.disabled;
      const wave = (Math.sin(t / 60 + c.id) + 1) / 2;
      const rx_bps = online ? Math.round(down * (0.08 + 0.75 * wave * Math.random())) : 0;
      const tx_bps = online ? Math.round(up * (0.04 + 0.4 * wave * Math.random())) : 0;
      s.rx += (rx_bps / 8) * 60; s.tx += (tx_bps / 8) * 60;
      simState.set(c.id, s);
      return { customer_id: c.id, online, rx_bytes: Math.round(s.rx), tx_bytes: Math.round(s.tx), rx_bps, tx_bps };
    });
  }
  async ping(target) {
    const samples = Array.from({ length: 4 }, () => +(4 + Math.random() * 18).toFixed(1));
    return { target, sent: 4, received: 4, loss: 0, avgMs: +(samples.reduce((a, b) => a + b) / 4).toFixed(1), samples };
  }
  async traceroute(target) {
    const hops = ['10.0.0.1', '103.4.144.1', '103.4.144.65', '72.14.217.1', target];
    return { hops: hops.map((a, i) => ({ hop: i + 1, address: a, ms: +(2 + i * 4 + Math.random() * 3).toFixed(1), loss: '0%' })) };
  }
  async syncSiteRules(rules) { return { applied: rules.length }; }
  async applyParental(_c, cfg) { return { applied: !!cfg?.enabled }; }
  async interfaceRates(names) {
    const t = Date.now() / 1000; const wave = (Math.sin(t / 300) + 1) / 2;
    return Object.fromEntries(names.map((n, i) => [n, { rxBps: Math.round((i ? 0.2 : 1) * 1e9 * (0.25 + 0.5 * wave)), txBps: Math.round((i ? 0.1 : 0.3) * 1e9 * (0.25 + 0.5 * wave)) }]));
  }
  async discover() {
    const rates = await this.interfaceRates(['ether1-wan', 'sfp1-core', 'ether2-lan']);
    return {
      router: { version: 'simulator', board: 'Virtual CCR2004', uptime: `${Math.floor(process.uptime())}s`, cpuLoad: 12 },
      wanInterface: 'ether1-wan',
      interfaces: ['ether1-wan', 'sfp1-core', 'ether2-lan'].map((name) => ({ name, type: 'ether', running: true, ...rates[name] })),
      pppSecrets: [
        { name: 'sim-import-01', profile: '20M', remoteAddress: null, disabled: false, comment: 'Imported demo user' },
        { name: 'sim-import-02', profile: '50M', remoteAddress: '203.0.113.20', disabled: false, comment: '' },
      ],
      activeSessions: [{ name: 'sim-import-01', address: '100.64.0.10', uptime: '3h12m', callerId: 'AA:BB:CC:00:00:01' }],
      queues: [], ipPools: [{ name: 'pppoe-pool', ranges: '100.64.0.2-100.64.3.254' }],
    };
  }
  async ensurePool() { return { ok: true }; }
  async assignIp() { return { ok: true }; }
  async releaseIp() { return { ok: true }; }
}

export function getDriver(router) {
  if (!router) return new SimulatorDriver({ id: 0, name: 'virtual' });
  if (router.driver === 'mikrotik') return new MikrotikDriver(router);
  return new SimulatorDriver(router);
}
