import cron from 'node-cron';
import { db, now, parseJson } from '../db/index.js';
import { pruneRateLimits } from '../lib/rate-store.js';
import { enforceSpeed, enforceDataCaps } from '../network/enforcement.js';
import { pollUsage, aggregateDaily, pruneSamples } from '../network/service.js';
import { generateRecurringInvoices, enforceOverdue } from '../billing/service.js';
import { notify } from '../lib/notify.js';
import { formatMoney, moduleEnabled } from '../lib/settings.js';
import { sendCampaign } from '../routes/crm.js';
import { autoUpdateTick } from '../updater.js';
import { sampleLinks } from '../network/capacity.js';
import { scheduledBackupTick } from '../backup.js';
import { recordSessions } from '../network/sessions.js';

const jobs = [];
const running = new Set();

function every(expr, name, fn) {
  jobs.push(cron.schedule(expr, async () => {
    if (running.has(name)) return; // never overlap
    running.add(name);
    try { await fn(); } catch (e) { console.error(`[job:${name}]`, e.message); } finally { running.delete(name); }
  }));
}

const dayIso = (d) => new Date(d).toISOString().slice(0, 10);

/** Run reminder rules: invoice_due (offset days before due), invoice_overdue (days after), plan_expiry. */
export async function runReminders() {
  if (!(await moduleEnabled('reminders'))) return 0;
  const rules = await db().all('SELECT * FROM reminder_rules WHERE active = 1');
  let sent = 0;
  for (const rule of rules) {
    const target = new Date(Date.now() + (rule.trigger_event === 'invoice_overdue' ? -1 : 1) * Math.abs(rule.offset_days) * 86400000);
    const day = dayIso(target);
    const channels = parseJson(rule.channels, ['inapp']);
    if (rule.trigger_event === 'plan_expiry') {
      const rows = await db().all("SELECT c.id, c.user_id, c.next_due_date, p.name FROM customers c JOIN plans p ON p.id = c.plan_id WHERE c.status = 'active' AND SUBSTR(c.next_due_date,1,10) = ?", [day]);
      for (const c of rows) {
        await notify({ userId: c.user_id, channels, templateKey: rule.template_key, vars: { plan: c.name, date: day }, ref: `rr:${rule.id}:c:${c.id}:${day}`, link: '/portal/plans' });
        sent++;
      }
      continue;
    }
    const status = rule.trigger_event === 'invoice_overdue' ? "('overdue')" : "('unpaid','partial')";
    const rows = await db().all(`SELECT i.id, i.number, i.total_cents, i.paid_cents, i.due_date, c.user_id FROM invoices i JOIN customers c ON c.id = i.customer_id
      WHERE i.status IN ${status} AND SUBSTR(i.due_date,1,10) = ?`, [day]);
    for (const i of rows) {
      await notify({
        userId: i.user_id, channels, templateKey: rule.template_key,
        vars: { invoice: i.number, amount: await formatMoney(Number(i.total_cents) - Number(i.paid_cents)), due_date: dayIso(i.due_date), days: Math.abs(rule.offset_days) },
        ref: `rr:${rule.id}:i:${i.id}`, link: '/portal/billing', kind: 'warning',
      });
      sent++;
    }
  }
  return sent;
}

async function runScheduledCampaigns() {
  const due = await db().all("SELECT id FROM campaigns WHERE status = 'scheduled' AND scheduled_at <= ?", [now()]);
  for (const c of due) await sendCampaign(c.id);
}

export function startScheduler() {
  every('* * * * *', 'poll-usage', async () => { await pollUsage(); await enforceSpeed(); await recordSessions(); }); // speed watchdog + session/IP log (BTRC) after each poll
  every('*/5 * * * *', 'enforce-data-caps', enforceDataCaps);
  every('* * * * *', 'sample-links', sampleLinks);
  every('5 * * * *', 'scheduled-backup', scheduledBackupTick);
  every('*/5 * * * *', 'campaigns', runScheduledCampaigns);
  every('*/15 * * * *', 'aggregate-traffic', () => aggregateDaily());
  every('5 0 * * *', 'aggregate-yesterday', () => aggregateDaily(dayIso(Date.now() - 86400000)));
  every('15 1 * * *', 'billing-generate', generateRecurringInvoices);
  every('30 1 * * *', 'billing-overdue', enforceOverdue);
  every('0 10 * * *', 'reminders', runReminders);
  every('45 2 * * *', 'prune-samples', () => pruneSamples(35));
  every('20 3 * * *', 'auto-update', autoUpdateTick);
  every('10 * * * *', 'prune-rate-limits', pruneRateLimits);
  // initial poll so dashboards have data right after boot
  setTimeout(() => pollUsage().catch(() => {}), 3000).unref();
  console.log(`[scheduler] ${jobs.length} jobs scheduled`);
}

export function stopScheduler() { for (const j of jobs) j.stop(); jobs.length = 0; }

// ---- leader election: exactly ONE process in the whole cluster runs the jobs --------------------------------
// The leader holds a PostgreSQL session advisory lock on a dedicated connection. If that process dies or loses
// its connection, the lock is released automatically and another worker/server takes over within ~20 s.
let leaderClient = null; let leaderTimer = null; let isLeader = false;
export const schedulerIsLeader = () => isLeader;

export async function startLeaderElection() {
  const attempt = async () => {
    if (isLeader) return;
    try {
      leaderClient = await db().leaderLock('aura:scheduler-leader', lost);
      if (leaderClient) {
        isLeader = true;
        console.log(`[scheduler] process ${process.pid} is the scheduler leader`);
        startScheduler();
      }
    } catch { lost(); }
  };
  const lost = () => {
    if (isLeader) console.warn('[scheduler] lost leadership — stopping jobs');
    isLeader = false; stopScheduler();
    try { leaderClient?.release(); } catch { /* ignore */ }
    leaderClient = null;
  };
  await attempt();
  leaderTimer = setInterval(attempt, 20_000);
  leaderTimer.unref();
}

export async function stopLeaderElection() {
  clearInterval(leaderTimer); stopScheduler(); isLeader = false;
  try { await leaderClient?.release(); } catch { /* ignore */ }
  leaderClient = null;
}
