// Backups: 'database' (portable logical NDJSON dump — restores into MySQL/MariaDB, PostgreSQL or SQLite),
// 'ui_db' (database + web app + uploads)
// and 'full' (entire system: code, web app, uploads, database, optionally .env). Optional passphrase encryption
// (scrypt + AES-256-GCM). Archives are plain .tar.gz so they can also be inspected or restored by hand.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import readline from 'node:readline';
import { pipeline } from 'node:stream/promises';
import * as tar from 'tar';
import config from './config.js';
import { db, insert, now } from './db/index.js';
import { clearSettingsCache, getSetting } from './lib/settings.js';
import { VERSION, scheduleRestart } from './updater.js';

export const BACKUP_DIR = path.join(config.dataDir, 'backups', 'system');
const INSTALL_ROOT = path.resolve(config.root, '..');
const MAGIC = Buffer.from('AURABK1');
export const KINDS = ['database', 'ui_db', 'full'];
// schema_migrations: the running schema is authoritative. backups: the local archive registry must survive a restore.
// cluster_events: transient realtime relay rows — restoring them would replay old events to every worker.
const SKIP_TABLES = new Set(['schema_migrations', 'backups', 'rate_limits', 'kv_cache', 'cluster_events']);

const ensureDir = (d) => fs.mkdirSync(d, { recursive: true });
const stamp = () => new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
export const sha256File = (file) => new Promise((resolve, reject) => {
  const h = crypto.createHash('sha256'); fs.createReadStream(file).on('data', (d) => h.update(d)).on('end', () => resolve(h.digest('hex'))).on('error', reject);
});

const IDENT = /^[a-z_][a-z0-9_]*$/;

/** Tables in foreign-key dependency order (parents first), so restores insert without violating constraints. */
async function rawTablesAndFks() {
  const d = db().dialect;
  if (d === 'sqlite') {
    const tables = (await db().all("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'")).map((r) => r.name);
    const fks = [];
    for (const t of tables.filter((x) => IDENT.test(x))) for (const f of await db().all(`PRAGMA foreign_key_list(${t})`)) fks.push({ child: t, parent: f.table });
    return { tables, fks };
  }
  if (d === 'mysql') {
    const tables = (await db().all("SELECT table_name AS name FROM information_schema.tables WHERE table_schema = DATABASE() AND table_type = 'BASE TABLE'")).map((r) => r.name || r.NAME || r.TABLE_NAME);
    const fks = (await db().all('SELECT table_name AS child, referenced_table_name AS parent FROM information_schema.key_column_usage WHERE table_schema = DATABASE() AND referenced_table_name IS NOT NULL'))
      .map((r) => ({ child: r.child || r.TABLE_NAME, parent: r.parent || r.REFERENCED_TABLE_NAME }));
    return { tables, fks };
  }
  const tables = (await db().all("SELECT table_name AS name FROM information_schema.tables WHERE table_schema = current_schema() AND table_type = 'BASE TABLE'")).map((r) => r.name);
  const fks = await db().all(`SELECT tc.table_name AS child, ccu.table_name AS parent FROM information_schema.table_constraints tc
    JOIN information_schema.constraint_column_usage ccu ON ccu.constraint_name = tc.constraint_name AND ccu.table_schema = tc.table_schema
    WHERE tc.constraint_type = 'FOREIGN KEY' AND tc.table_schema = current_schema()`);
  return { tables, fks };
}

async function listTables() {
  const { tables, fks } = await rawTablesAndFks();
  const deps = new Map(tables.map((t) => [t, new Set()]));
  for (const f of fks) if (f.child !== f.parent && deps.has(f.child)) deps.get(f.child).add(f.parent);
  const ordered = []; const seen = new Set();
  const visit = (t, stack = new Set()) => {
    if (seen.has(t) || stack.has(t)) return;
    stack.add(t);
    for (const p of deps.get(t) || []) visit(p, stack);
    seen.add(t); ordered.push(t);
  };
  for (const t of [...tables].sort()) visit(t);
  return ordered;
}
async function columnsOf(table) {
  const d = db().dialect;
  if (d === 'sqlite') return (await db().all(`PRAGMA table_info(${table})`)).map((r) => r.name);
  if (d === 'mysql') return (await db().all('SELECT column_name AS name FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = ? ORDER BY ordinal_position', [table])).map((r) => r.name || r.COLUMN_NAME);
  return (await db().all('SELECT column_name AS name FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = ? ORDER BY ordinal_position', [table])).map((r) => r.name);
}

/** Stream every table as NDJSON (gzip). */
export async function dumpDatabase(file) {
  const gz = zlib.createGzip({ level: 6 });
  const out = fs.createWriteStream(file);
  const done = pipeline(gz, out);
  const tables = (await listTables()).filter((t) => IDENT.test(t) && !SKIP_TABLES.has(t));
  const counts = {};
  const write = (obj) => new Promise((res) => (gz.write(`${JSON.stringify(obj)}\n`) ? res() : gz.once('drain', res)));
  await write({ meta: { app: 'aura-isp', version: VERSION, dialect: db().dialect, createdAt: now(), tables } });
  for (const t of tables) {
    const cols = await columnsOf(t);
    counts[t] = 0;
    if (cols.includes('id')) {
      // Keyset pagination: each page is an index seek, so large tables (usage_samples) never hit the 30 s statement
      // timeout, and rows pruned while the dump runs cannot shift later pages.
      for (let last = -1; ;) {
        const rows = await db().all(`SELECT * FROM ${t} WHERE id > ? ORDER BY id LIMIT 2000`, [last]);
        for (const r of rows) await write({ t, r });
        counts[t] += rows.length;
        if (rows.length < 2000) break;
        last = Number(rows[rows.length - 1].id);
      }
    } else {
      for (let offset = 0; ; offset += 2000) {
        const rows = await db().all(`SELECT * FROM ${t} LIMIT 2000 OFFSET ${offset}`);
        for (const r of rows) await write({ t, r });
        counts[t] += rows.length;
        if (rows.length < 2000) break;
      }
    }
  }
  gz.end();
  await done;
  return counts;
}

/** Replace all data with the dump. Unknown tables/columns are skipped so older or newer dumps restore safely. */
export async function restoreDatabase(file) {
  const current = new Map();
  for (const t of await listTables()) if (IDENT.test(t) && !SKIP_TABLES.has(t)) current.set(t, new Set(await columnsOf(t)));
  const counts = {};
  const d = db().dialect;
  if (d === 'sqlite') await db().exec('PRAGMA foreign_keys = OFF');
  try {
    await db().transaction(async (t) => {
      if (d === 'mysql') await t.exec('SET FOREIGN_KEY_CHECKS = 0');
      // The connection goes back to the pool afterwards: FK checks must be switched back on even if the restore fails.
      try { await restoreRows(t); } finally { if (d === 'mysql') await t.exec('SET FOREIGN_KEY_CHECKS = 1').catch(() => {}); }
    });
  } finally {
    if (d === 'sqlite') await db().exec('PRAGMA foreign_keys = ON');
    clearSettingsCache();
  }
  return counts;

  async function restoreRows(t) {
      const rl = readline.createInterface({ input: fs.createReadStream(file).pipe(zlib.createGunzip()), crlfDelay: Infinity });
      let meta = null; const cleared = new Set();
      for await (const line of rl) {
        if (!line.trim()) continue;
        const obj = JSON.parse(line);
        if (obj.meta) {
          meta = obj.meta;
          if (meta.app !== 'aura-isp') throw new Error('Not an AuraISP backup');
          // Empty every table present in the dump in ONE statement (handles FK order), then refill in dependency order.
          const tbls = meta.tables.filter((tbl) => current.has(tbl) && IDENT.test(tbl));
          if (d === 'postgres') { if (tbls.length) await t.exec(`TRUNCATE ${tbls.join(', ')} CASCADE`); }
          else for (const tbl of [...tbls].reverse()) await t.run(`DELETE FROM ${tbl}`); // children first
          for (const tbl of tbls) { cleared.add(tbl); counts[tbl] = 0; }
          continue;
        }
        if (!meta) throw new Error('Backup is missing its header');
        const cols = current.get(obj.t);
        if (!cols || !cleared.has(obj.t)) continue;
        const keys = Object.keys(obj.r).filter((k) => cols.has(k) && IDENT.test(k));
        await t.run(`INSERT INTO ${obj.t} (${keys.join(', ')}) VALUES (${keys.map(() => '?').join(', ')})`, keys.map((k) => obj.r[k]));
        counts[obj.t]++;
      }
      // Sessions from the backup are invalid after a restore — everyone signs in again.
      if (current.has('sessions')) await t.run('DELETE FROM sessions');
      // Move identity sequences past the restored ids so new rows don't collide.
      // (MySQL AUTO_INCREMENT and SQLite AUTOINCREMENT advance automatically when explicit ids are inserted.)
      if (d === 'postgres') {
        for (const tbl of cleared) {
          if (current.get(tbl).has('id')) await t.get(`SELECT setval(pg_get_serial_sequence('${tbl}', 'id'), GREATEST(COALESCE((SELECT MAX(id) FROM ${tbl}), 0), 1), (SELECT COUNT(*) > 0 FROM ${tbl}))`);
        }
      }
  }
}

function copyInto(src, dest) {
  if (!fs.existsSync(src)) return false;
  fs.cpSync(src, dest, { recursive: true, filter: (p) => !/[\\/](node_modules|\.git)([\\/]|$)/.test(p) });
  return true;
}

function encryptFile(src, dest, passphrase) {
  const salt = crypto.randomBytes(16); const iv = crypto.randomBytes(12);
  const key = crypto.scryptSync(passphrase, salt, 32, { N: 2 ** 15, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
  const c = crypto.createCipheriv('aes-256-gcm', key, iv);
  const data = Buffer.concat([c.update(fs.readFileSync(src)), c.final()]);
  fs.writeFileSync(dest, Buffer.concat([MAGIC, salt, iv, c.getAuthTag(), data]), { mode: 0o600 });
}
function decryptFile(src, dest, passphrase) {
  const buf = fs.readFileSync(src);
  if (!buf.subarray(0, 7).equals(MAGIC)) throw new Error('Not an encrypted AuraISP backup');
  const salt = buf.subarray(7, 23); const iv = buf.subarray(23, 35); const tag = buf.subarray(35, 51);
  const key = crypto.scryptSync(String(passphrase || ''), salt, 32, { N: 2 ** 15, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
  const d = crypto.createDecipheriv('aes-256-gcm', key, iv); d.setAuthTag(tag);
  try { fs.writeFileSync(dest, Buffer.concat([d.update(buf.subarray(51)), d.final()])); }
  catch { throw new Error('Wrong passphrase or the backup is corrupted'); }
}

/** Create a backup archive. */
export async function createBackup({ kind = 'database', includeEnv = false, passphrase = '', trigger = 'manual' } = {}) {
  if (!KINDS.includes(kind)) throw new Error('Unknown backup type');
  if (includeEnv && !passphrase) throw new Error('A passphrase is required when the .env (master key) is included');
  ensureDir(BACKUP_DIR);
  const stage = path.join(BACKUP_DIR, `.stage-${crypto.randomBytes(6).toString('hex')}`);
  ensureDir(stage);
  try {
    const counts = await dumpDatabase(path.join(stage, 'database.ndjson.gz'));
    const contents = ['database'];
    if (kind !== 'database') {
      if (copyInto(config.webDist, path.join(stage, 'web', 'dist'))) contents.push('web');
      if (copyInto(config.uploadsDir, path.join(stage, 'uploads'))) contents.push('uploads');
    }
    if (kind === 'full') {
      for (const p of ['src', 'scripts', 'package.json', 'package-lock.json', 'app.cjs', '.env.example']) copyInto(path.join(config.root, p), path.join(stage, 'server', p));
      for (const p of ['deploy', 'docs', 'README.md', 'Dockerfile', 'docker-compose.yml']) copyInto(path.join(INSTALL_ROOT, p), path.join(stage, 'root', p));
      contents.push('code');
      if (includeEnv && fs.existsSync(path.join(config.root, '.env'))) { fs.copyFileSync(path.join(config.root, '.env'), path.join(stage, 'server', '.env')); contents.push('env'); }
    }
    const manifest = { app: 'aura-isp', version: VERSION, kind, dialect: db().dialect, createdAt: now(), contents, counts };
    fs.writeFileSync(path.join(stage, 'manifest.json'), JSON.stringify(manifest, null, 2));
    const base = `aura-${kind}-${stamp()}.tar.gz`;
    const archive = path.join(BACKUP_DIR, base);
    await tar.c({ gzip: true, file: archive, cwd: stage, portable: true }, fs.readdirSync(stage));
    let file = base;
    if (passphrase) { encryptFile(archive, `${archive}.enc`, passphrase); fs.rmSync(archive); file = `${base}.enc`; }
    const full = path.join(BACKUP_DIR, file);
    const row = { file, kind, size: fs.statSync(full).size, encrypted: !!passphrase, sha256: await sha256File(full), manifest: JSON.stringify(manifest), trigger_by: trigger, status: 'ok', created_at: now() };
    const r = await insert('backups', row);
    await applyRetention();
    return { id: r.id, ...row, manifest };
  } finally {
    fs.rmSync(stage, { recursive: true, force: true });
  }
}

export async function applyRetention() {
  const { keep } = await getSetting('backup');
  const rows = await db().all("SELECT * FROM backups WHERE trigger_by != 'uploaded' ORDER BY id DESC");
  for (const r of rows.slice(Math.max(1, Number(keep) || 14))) {
    fs.rmSync(path.join(BACKUP_DIR, r.file), { force: true });
    await db().run('DELETE FROM backups WHERE id = ?', [r.id]);
  }
}

export function backupPath(file) {
  if (!/^aura-[\w.-]+\.tar\.gz(\.enc)?$/.test(file)) throw new Error('Invalid backup file');
  const full = path.join(BACKUP_DIR, file);
  if (path.dirname(full) !== BACKUP_DIR) throw new Error('Invalid backup file');
  return full;
}

const SAFE_ENTRY = (p) => !p.includes('..') && !path.isAbsolute(p) && !p.includes('\\') && !/(^|\/)node_modules(\/|$)/.test(p);

/** Restore from a stored backup. Takes a safety backup first. */
export async function restoreBackup(row, { passphrase = '', restoreFiles = true, restoreEnv = false } = {}) {
  const full = backupPath(row.file);
  if (!fs.existsSync(full)) throw new Error('Backup file is missing');
  if (row.sha256 && (await sha256File(full)) !== row.sha256) throw new Error('Backup checksum mismatch — file was modified or corrupted');
  const stage = path.join(BACKUP_DIR, `.restore-${crypto.randomBytes(6).toString('hex')}`);
  ensureDir(stage);
  try {
    let archive = full;
    if (row.file.endsWith('.enc')) { archive = path.join(stage, 'archive.tar.gz'); decryptFile(full, archive, passphrase); }
    const extract = path.join(stage, 'x'); ensureDir(extract);
    await tar.x({ file: archive, cwd: extract, strict: true, filter: SAFE_ENTRY, preservePaths: false });
    const manifest = JSON.parse(fs.readFileSync(path.join(extract, 'manifest.json'), 'utf8'));
    if (manifest.app !== 'aura-isp') throw new Error('Not an AuraISP backup');
    const safety = await createBackup({ kind: 'database', trigger: 'pre-restore' });
    const counts = await restoreDatabase(path.join(extract, 'database.ndjson.gz'));
    const restored = ['database'];
    let restart = false;
    if (restoreFiles) {
      if (fs.existsSync(path.join(extract, 'uploads'))) { fs.cpSync(path.join(extract, 'uploads'), config.uploadsDir, { recursive: true }); restored.push('uploads'); }
      if (fs.existsSync(path.join(extract, 'web', 'dist'))) { fs.rmSync(config.webDist, { recursive: true, force: true }); fs.cpSync(path.join(extract, 'web', 'dist'), config.webDist, { recursive: true }); restored.push('web'); }
      if (fs.existsSync(path.join(extract, 'server', 'src'))) {
        for (const p of ['src', 'scripts', 'package.json', 'package-lock.json', 'app.cjs']) {
          const src = path.join(extract, 'server', p);
          if (fs.existsSync(src)) fs.cpSync(src, path.join(config.root, p), { recursive: true });
        }
        restored.push('code'); restart = true;
      }
      if (restoreEnv && fs.existsSync(path.join(extract, 'server', '.env'))) {
        fs.copyFileSync(path.join(config.root, '.env'), path.join(config.root, `.env.before-restore-${stamp()}`));
        fs.copyFileSync(path.join(extract, 'server', '.env'), path.join(config.root, '.env'));
        restored.push('env'); restart = true;
      }
    }
    if (restart) scheduleRestart();
    return { restored, counts, safetyBackup: safety.file, restarting: restart, manifest };
  } finally {
    fs.rmSync(stage, { recursive: true, force: true });
  }
}

/** Register an uploaded archive (validates format & manifest when unencrypted). */
export async function registerUpload(tmpPath, originalName) {
  ensureDir(BACKUP_DIR);
  const head = Buffer.alloc(7); const fd = fs.openSync(tmpPath, 'r'); fs.readSync(fd, head, 0, 7, 0); fs.closeSync(fd);
  const encrypted = head.equals(MAGIC);
  if (!encrypted && !(head[0] === 0x1f && head[1] === 0x8b)) { fs.rmSync(tmpPath, { force: true }); throw new Error('Not an AuraISP backup (.tar.gz or .tar.gz.enc)'); }
  let kind = 'database'; let manifest = null;
  if (!encrypted) {
    const dir = fs.mkdtempSync(path.join(BACKUP_DIR, '.check-'));
    try {
      await tar.x({ file: tmpPath, cwd: dir, strict: true, filter: (p) => p === 'manifest.json' });
      manifest = JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json'), 'utf8'));
      if (manifest.app !== 'aura-isp') throw new Error();
      kind = KINDS.includes(manifest.kind) ? manifest.kind : 'database';
    } catch { fs.rmSync(tmpPath, { force: true }); throw new Error('Archive has no valid AuraISP manifest'); }
    finally { fs.rmSync(dir, { recursive: true, force: true }); }
  }
  const file = `aura-${kind}-uploaded-${stamp()}.tar.gz${encrypted ? '.enc' : ''}`;
  fs.renameSync(tmpPath, path.join(BACKUP_DIR, file));
  const full = path.join(BACKUP_DIR, file);
  const row = { file, kind, size: fs.statSync(full).size, encrypted, sha256: await sha256File(full), manifest: manifest ? JSON.stringify(manifest) : JSON.stringify({ originalName: String(originalName).slice(0, 120) }), trigger_by: 'uploaded', status: 'ok', created_at: now() };
  const r = await insert('backups', row);
  return { id: r.id, ...row };
}

/** Hourly tick: create the scheduled automatic backup once per day at the configured hour. */
export async function scheduledBackupTick() {
  const s = await getSetting('backup');
  if (!s.auto || new Date().getHours() !== Number(s.hour)) return null;
  const today = new Date().toISOString().slice(0, 10);
  const done = await db().get("SELECT id FROM backups WHERE trigger_by = 'auto' AND created_at >= ?", [`${today}T00:00:00`]);
  if (done) return null;
  return createBackup({ kind: s.kind || 'database', trigger: 'auto' });
}
