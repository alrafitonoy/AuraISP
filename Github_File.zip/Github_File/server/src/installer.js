// Browser-based installer. Runs ONLY while the system is not installed (no .env with APP_KEY + database settings).
// Protection: every API call needs the one-time INSTALL TOKEN that is printed to the server console and written to
// server/data/install-token.txt — only someone with access to the server (SSH / cPanel File Manager) can read it.
// Supports MySQL / MariaDB, PostgreSQL and SQLite, and recommends one by analysing the hosting environment.
import fs from 'node:fs';
import os from 'node:os';
import net from 'node:net';
import path from 'node:path';
import crypto from 'node:crypto';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import config, { reloadConfig, isInstalled } from './config.js';

const TOKEN_FILE = path.join(config.dataDir, 'install-token.txt');
const ENV_FILE = path.join(config.root, '.env');
const UI_DIR = path.join(config.root, 'installer');

function ensureToken() {
  fs.mkdirSync(config.dataDir, { recursive: true });
  if (fs.existsSync(TOKEN_FILE)) return fs.readFileSync(TOKEN_FILE, 'utf8').trim();
  const token = crypto.randomBytes(18).toString('base64url');
  fs.writeFileSync(TOKEN_FILE, token, { mode: 0o600 });
  return token;
}

const ident = z.string().trim().regex(/^[a-z_][a-z0-9_]{0,62}$/, 'Use lowercase letters, digits and _ only');
const dbSchema = z.object({
  client: z.enum(['mysql', 'postgres', 'sqlite']),
  sqliteFile: z.string().trim().max(200).regex(/^[A-Za-z0-9_./-]+\.db$/, 'Use a relative path ending in .db').optional().default('data/aura.db'),
  host: z.string().trim().max(253).regex(/^[A-Za-z0-9.\-:/_]*$/, 'Invalid host').optional().default('localhost'),
  port: z.coerce.number().int().min(0).max(65535).optional().default(0),
  database: ident.optional().default('aura_isp'),
  user: ident.optional().default('aura_app'),
  password: z.string().max(200).optional().default(''),
  ssl: z.enum(['disable', 'verify-full']).optional().default('disable'),
  sslCa: z.string().max(20000).optional().default(''),
  createWithAdmin: z.boolean().optional().default(false),
  adminUser: z.string().max(63).optional().default(''),
  adminPassword: z.string().max(200).optional().default(''),
}).transform((d) => ({ ...d, port: d.port || (d.client === 'postgres' ? 5432 : 3306) }));

const installSchema = z.object({
  db: dbSchema,
  site: z.object({
    appUrl: z.string().trim().url().max(300).refine((u) => /^https?:\/\//.test(u), 'Must start with http(s)://'),
    companyName: z.string().trim().min(1).max(80),
    email: z.string().trim().email().max(190),
    phone: z.string().trim().max(40).optional().default(''),
    currency: z.string().trim().regex(/^[A-Z]{3}$/).default('BDT'),
    currencySymbol: z.string().trim().max(5).default('৳'),
    timezone: z.string().trim().max(60).default('Asia/Dhaka'),
    workers: z.union([z.literal('max'), z.coerce.number().int().min(1).max(64)]).default(1),
  }),
  admin: z.object({
    name: z.string().trim().min(2).max(120),
    email: z.string().trim().toLowerCase().email().max(190),
    password: z.string().min(10).max(128).refine((p) => /[a-z]/.test(p) && /[A-Z]/.test(p) && /\d/.test(p), 'Password needs upper-case, lower-case and a number'),
  }),
});

const tls = (d) => (d.ssl === 'disable' ? undefined : { rejectUnauthorized: true, ...(d.sslCa ? { ca: d.sslCa } : {}) });
const sqliteAvailable = async () => { try { await import('node:sqlite'); return true; } catch { return false; } };
const portOpen = (port, host = '127.0.0.1') => new Promise((resolve) => {
  const s = net.connect({ host, port, timeout: 800 });
  s.once('connect', () => { s.destroy(); resolve(true); });
  s.once('timeout', () => { s.destroy(); resolve(false); });
  s.once('error', () => resolve(false));
});

/** Look at the server and recommend a database. */
async function analyseEnvironment() {
  const cpus = os.availableParallelism();
  const memGb = +(os.totalmem() / 1024 ** 3).toFixed(1);
  const e = process.env;
  const passenger = !!(e.PASSENGER_APP_ENV || e.PASSENGER_BASE_URI || e.PASSENGER_INSTANCE_REGISTRY_DIR);
  const cpanel = passenger || fs.existsSync('/usr/local/cpanel') || /\/home\d*\/[^/]+\//.test(config.root);
  const docker = fs.existsSync('/.dockerenv');
  const [mysqlLocal, pgLocal, sqliteOk] = await Promise.all([portOpen(3306), portOpen(5432), sqliteAvailable()]);
  const hosting = cpanel ? 'shared' : docker ? 'container' : cpus >= 2 && memGb >= 1.5 ? 'vps' : 'small';
  let recommended; let reason;
  if (hosting === 'shared') { recommended = 'mysql'; reason = 'Shared hosting (cPanel/Passenger) detected — MySQL/MariaDB is included with virtually every hosting plan and is managed for you.'; }
  else if (pgLocal && !mysqlLocal) { recommended = 'postgres'; reason = 'A PostgreSQL server is running on this machine.'; }
  else if (mysqlLocal) { recommended = 'mysql'; reason = 'A MySQL/MariaDB server is running on this machine — the best all-round choice for AuraISP.'; }
  else if (hosting === 'vps' && cpus >= 4 && memGb >= 7.5) { recommended = 'postgres'; reason = `Powerful server (${cpus} cores, ${memGb} GB RAM) — PostgreSQL scales best under heavy, concurrent load. MySQL/MariaDB is equally supported.`; }
  else if (hosting === 'vps' || hosting === 'container') { recommended = 'mysql'; reason = `VPS/cloud server (${cpus} cores, ${memGb} GB RAM) — MySQL/MariaDB is easy to install (apt install mariadb-server), fast and supports load balancing.`; }
  else { recommended = sqliteOk ? 'sqlite' : 'mysql'; reason = 'Small machine with no database server found — SQLite needs no setup (fine for trials and up to a few hundred customers on one server).'; }
  return { hosting, cpus, memGb, platform: `${os.type()} ${os.release()}`, mysqlLocal, pgLocal, sqliteOk, recommended, reason };
}

// ---------------------------------------------------------------- provisioning (optional, with admin credentials that are never stored)
async function provisionMysql(d, password) {
  const mysql = await import('mysql2/promise');
  const c = await mysql.createConnection({ host: d.host, port: d.port, user: d.adminUser || 'root', password: d.adminPassword, ssl: tls(d), connectTimeout: 10000, multipleStatements: false });
  try {
    await c.query(`CREATE DATABASE IF NOT EXISTS \`${d.database}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
    const local = ['localhost', '127.0.0.1', '::1'].includes(d.host);
    for (const host of local ? ['localhost', '127.0.0.1'] : ['%']) {
      await c.query('CREATE USER IF NOT EXISTS ?@? IDENTIFIED BY ?', [d.user, host, password]);
      await c.query(`ALTER USER ?@? IDENTIFIED BY ? ${d.ssl === 'disable' ? '' : 'REQUIRE SSL'} WITH MAX_USER_CONNECTIONS 300`, [d.user, host, password]);
      // Only the privileges the app needs, only on its own database.
      await c.query(`GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, REFERENCES, CREATE TEMPORARY TABLES, LOCK TABLES ON \`${d.database}\`.* TO ?@?`, [d.user, host]);
    }
    await c.query('FLUSH PRIVILEGES');
  } finally { await c.end(); }
}

async function provisionPostgres(d, password) {
  const pg = (await import('pg')).default;
  const base = { host: d.host, port: d.port, user: d.adminUser || 'postgres', password: d.adminPassword, ssl: tls(d) || false, connectionTimeoutMillis: 10000 };
  const admin = new pg.Client({ ...base, database: 'postgres' });
  await admin.connect();
  try {
    const exists = (await admin.query('SELECT 1 FROM pg_roles WHERE rolname = $1', [d.user])).rowCount;
    const esc = password.replace(/'/g, "''");
    await admin.query(`${exists ? 'ALTER' : 'CREATE'} ROLE ${d.user} LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION CONNECTION LIMIT 300 PASSWORD '${esc}'`);
    if (!(await admin.query('SELECT 1 FROM pg_database WHERE datname = $1', [d.database])).rowCount) await admin.query(`CREATE DATABASE ${d.database} OWNER ${d.user} ENCODING 'UTF8' TEMPLATE template0`);
    await admin.query(`REVOKE ALL ON DATABASE ${d.database} FROM PUBLIC`);
    await admin.query(`GRANT CONNECT, TEMPORARY ON DATABASE ${d.database} TO ${d.user}`);
    await admin.query(`ALTER ROLE ${d.user} SET statement_timeout = '30s'`);
  } finally { await admin.end(); }
  const own = new pg.Client({ ...base, database: d.database });
  await own.connect();
  try { await own.query('REVOKE ALL ON SCHEMA public FROM PUBLIC'); await own.query(`ALTER SCHEMA public OWNER TO ${d.user}`); } finally { await own.end(); }
}

async function provision(d) {
  if (d.client === 'sqlite' || !d.createWithAdmin) return { created: false, password: d.password };
  const password = d.password || crypto.randomBytes(24).toString('base64url');
  if (d.client === 'mysql') await provisionMysql(d, password); else await provisionPostgres(d, password);
  return { created: true, password };
}

async function checkApp(d, password) {
  if (d.client === 'sqlite') {
    if (!(await sqliteAvailable())) throw new Error('SQLite needs Node.js 22.13 or newer on this server. Choose MySQL/MariaDB or PostgreSQL.');
    const file = path.resolve(config.root, d.sqliteFile);
    if (!file.startsWith(path.resolve(config.root))) throw new Error('SQLite file must be inside the server folder');
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.accessSync(path.dirname(file), fs.constants.W_OK);
    return { version: `SQLite (built into Node ${process.version})`, superuser: false, existingTables: 0, ssl: false };
  }
  if (d.client === 'mysql') {
    const mysql = await import('mysql2/promise');
    const c = await mysql.createConnection({ host: d.host, port: d.port, user: d.user, password, database: d.database, ssl: tls(d), connectTimeout: 10000 });
    try {
      const [[v]] = await c.query('SELECT VERSION() AS v');
      const [grants] = await c.query('SHOW GRANTS FOR CURRENT_USER()');
      const g = grants.map((r) => Object.values(r)[0]).join(' ');
      const superuser = /ALL PRIVILEGES ON \*\.\*|SUPER|GRANT OPTION ON \*\.\*/i.test(g);
      // The app needs to create/alter its own tables (migrations). Least-privilege users have no DROP, so check
      // grants instead of creating & dropping a real probe table; a TEMPORARY table proves we can write.
      const dbGrant = grants.map((r) => Object.values(r)[0]).filter((x) => new RegExp(`ON \`?(${d.database}|\\*)\`?\\.\\*`, 'i').test(x)).join(' ');
      const missing = /ALL PRIVILEGES/i.test(dbGrant) ? [] : ['CREATE', 'ALTER', 'INDEX', 'INSERT', 'UPDATE', 'DELETE', 'SELECT'].filter((p) => !new RegExp(`\\b${p}\\b`, 'i').test(dbGrant));
      if (missing.length) throw new Error(`The database user is missing privileges on ${d.database}: ${missing.join(', ')}`);
      await c.query('CREATE TEMPORARY TABLE aura_install_probe (id INT)');
      const [[t]] = await c.query('SELECT COUNT(*) AS n FROM information_schema.tables WHERE table_schema = DATABASE()');
      const major = parseFloat(v.v);
      if (/mariadb/i.test(v.v) ? major < 10.4 : major < 8) throw new Error('MySQL 8.0+ or MariaDB 10.4+ is required');
      return { version: v.v, superuser, existingTables: Number(t.n), ssl: d.ssl !== 'disable' };
    } finally { await c.end(); }
  }
  const pg = (await import('pg')).default;
  const c = new pg.Client({ host: d.host, port: d.port, user: d.user, password, database: d.database, ssl: tls(d) || false, connectionTimeoutMillis: 10000 });
  await c.connect();
  try {
    const v = (await c.query('SHOW server_version_num')).rows[0].server_version_num;
    if (Number(v) < 120000) throw new Error('PostgreSQL 12 or newer is required');
    const su = (await c.query('SELECT rolsuper FROM pg_roles WHERE rolname = current_user')).rows[0]?.rolsuper;
    await c.query('CREATE TABLE IF NOT EXISTS aura_install_probe (id INT)');
    await c.query('DROP TABLE aura_install_probe');
    const tables = (await c.query("SELECT COUNT(*)::int AS n FROM information_schema.tables WHERE table_schema = 'public'")).rows[0].n;
    return { version: (await c.query('SHOW server_version')).rows[0].server_version, superuser: !!su, existingTables: tables, ssl: d.ssl !== 'disable' };
  } finally { await c.end(); }
}

const q = (s) => (/^[A-Za-z0-9_.:/@+-]*$/.test(String(s)) ? String(s) : JSON.stringify(String(s)));

async function writeEnv(input, dbPassword) {
  const webpush = (await import('web-push')).default;
  const vapid = webpush.generateVAPIDKeys();
  const d = input.db;
  let caPath = '';
  if (d.client !== 'sqlite' && d.ssl !== 'disable' && d.sslCa) {
    caPath = 'data/db-ca.pem';
    fs.writeFileSync(path.join(config.root, caPath), d.sslCa, { mode: 0o600 });
  }
  const https = input.site.appUrl.startsWith('https://');
  const workers = d.client === 'sqlite' ? 1 : input.site.workers;
  const dbLines = d.client === 'sqlite'
    ? ['DB_CLIENT=sqlite', `SQLITE_FILE=${q(d.sqliteFile)}`]
    : [`DB_CLIENT=${d.client}`, `DB_HOST=${q(d.host)}`, `DB_PORT=${d.port}`, `DB_NAME=${d.database}`, `DB_USER=${d.user}`, `DB_PASSWORD=${q(dbPassword)}`, `DB_SSL=${d.ssl}`, `DB_SSL_CA=${caPath}`, 'DB_POOL_MAX=15'];
  const lines = [
    '# Generated by the AuraISP web installer. Keep this file private and BACK IT UP (APP_KEY decrypts stored secrets).',
    'NODE_ENV=production', `PORT=${config.port}`, `HOST=${config.host}`,
    `APP_URL=${q(input.site.appUrl.replace(/\/$/, ''))}`, 'CORS_ORIGINS=', `TRUST_PROXY=${https ? '1' : 'loopback'}`,
    `APP_KEY=${crypto.randomBytes(32).toString('base64')}`,
    ...dbLines,
    `WEB_CONCURRENCY=${workers}`, 'RATE_LIMIT_GLOBAL=600',
    `VAPID_PUBLIC_KEY=${vapid.publicKey}`, `VAPID_PRIVATE_KEY=${vapid.privateKey}`,
    'UPDATE_REPO=', 'UPDATE_PUBLIC_KEY=', 'WEB_DIST=../web/dist', 'DISABLE_SCHEDULER=false', '',
  ];
  fs.writeFileSync(ENV_FILE, lines.join('\n'), { mode: 0o600 });
}

export function startInstaller(onInstalled) {
  const token = ensureToken();
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', 'loopback');
  app.use(helmet({ contentSecurityPolicy: { useDefaults: true, directives: { 'script-src': ["'self'"], 'style-src': ["'self'", "'unsafe-inline'"], 'connect-src': ["'self'"], 'frame-ancestors': ["'none'"] } } }));
  app.use(express.json({ limit: '64kb' }));
  const limiter = rateLimit({ windowMs: 15 * 60_000, limit: 80, standardHeaders: 'draft-7', legacyHeaders: false });
  const guard = (req, res, next) => {
    if (isInstalled()) return res.status(410).json({ error: 'Already installed' });
    const t = String(req.get('x-install-token') || '');
    const ok = t.length === token.length && crypto.timingSafeEqual(Buffer.from(t), Buffer.from(token));
    if (!ok) return res.status(401).json({ error: 'Invalid install token' });
    next();
  };

  app.get('/', (_req, res) => res.redirect('/install/'));
  app.use('/install', express.static(UI_DIR, { index: 'index.html', maxAge: 0 }));
  app.get('/api/health', (_req, res) => res.json({ ok: true, installer: true }));

  app.post('/install/api/status', limiter, guard, async (_req, res) => {
    const major = Number(process.versions.node.split('.')[0]);
    const writable = (p) => { try { fs.mkdirSync(p, { recursive: true }); fs.accessSync(p, fs.constants.W_OK); return true; } catch { return false; } };
    res.json({
      node: process.version, nodeOk: major >= 20,
      dataWritable: writable(config.dataDir), envWritable: writable(config.root),
      webBuilt: fs.existsSync(path.join(config.webDist, 'index.html')),
      depsInstalled: fs.existsSync(path.join(config.root, 'node_modules', 'express')),
      environment: await analyseEnvironment(),
    });
  });

  app.post('/install/api/test-db', limiter, guard, async (req, res) => {
    const parsed = dbSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
    try {
      const { created, password } = await provision(parsed.data);
      const info = await checkApp(parsed.data, password);
      res.json({ ok: true, created, generatedPassword: created && !parsed.data.password, ...info });
    } catch (e) { res.status(400).json({ error: `Database check failed: ${e.message}` }); }
  });

  let installing = false;
  app.post('/install/api/install', limiter, guard, async (req, res) => {
    if (installing) return res.status(409).json({ error: 'Installation already running' });
    const parsed = installSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: `${parsed.error.issues[0].path.join('.')}: ${parsed.error.issues[0].message}` });
    installing = true;
    const steps = [];
    try {
      const input = parsed.data;
      const { password } = await provision(input.db); steps.push('database ready');
      const info = await checkApp(input.db, password); steps.push(`connected to ${info.version}`);
      if (info.superuser) throw new Error('Refusing to run the application as a database superuser — use a dedicated user (tick "create for me")');
      await writeEnv(input, password); steps.push('configuration written (server/.env)');
      reloadConfig();
      const { initDb, db, insert, now } = await import('./db/index.js');
      const { migrate } = await import('./db/migrate.js');
      const { seedDefaults } = await import('./db/seed.js');
      const { setSetting } = await import('./lib/settings.js');
      const { hashPassword } = await import('./lib/crypto.js');
      await initDb();
      await migrate(() => {}); steps.push('database tables created');
      await seedDefaults(); steps.push('default plans, roles and templates added');
      await setSetting('branding', { companyName: input.site.companyName });
      await setSetting('company', { legalName: input.site.companyName, email: input.site.email, phone: input.site.phone, currency: input.site.currency, currencySymbol: input.site.currencySymbol, timezone: input.site.timezone });
      const role = await db().get("SELECT id FROM roles WHERE slug = 'admin'");
      const existing = await db().get('SELECT id FROM users WHERE email = ?', [input.admin.email]);
      if (existing) await db().run("UPDATE users SET password_hash = ?, type = 'admin', role_id = ?, status = 'active' WHERE id = ?", [await hashPassword(input.admin.password), role.id, existing.id]);
      else await insert('users', { type: 'admin', role_id: role.id, name: input.admin.name, email: input.admin.email, password_hash: await hashPassword(input.admin.password), status: 'active', email_verified_at: now(), created_at: now(), updated_at: now() });
      steps.push('administrator account created');
      fs.writeFileSync(path.join(config.dataDir, 'installed.lock'), now());
      fs.rmSync(TOKEN_FILE, { force: true });
      res.json({ ok: true, steps, loginUrl: '/login', restartForWorkers: input.db.client !== 'sqlite' && input.site.workers !== 1 });
      // Switch this same process from installer to the full application (no manual restart needed).
      setImmediate(() => onInstalled(server).catch((e) => { console.error('[installer] app start failed:', e.message); process.exit(1); }));
    } catch (e) {
      // Roll back the written .env (and in-memory settings/pool) so the installer can be retried cleanly.
      if (!fs.existsSync(path.join(config.dataDir, 'installed.lock'))) {
        fs.rmSync(ENV_FILE, { force: true });
        for (const k of ['APP_KEY', 'DB_CLIENT', 'DB_PASSWORD', 'DB_HOST', 'DB_NAME', 'DB_USER', 'DB_SSL', 'DB_SSL_CA', 'SQLITE_FILE']) delete process.env[k];
        const { closeDb } = await import('./db/index.js');
        await closeDb().catch(() => {});
      }
      reloadConfig();
      installing = false;
      res.status(400).json({ error: e.message, steps });
    }
  });

  app.use((_req, res) => res.redirect('/install/'));
  const server = app.listen(config.port, config.host, () => {
    console.log('\n============================================================');
    console.log(' AuraISP is not installed yet. Open the web installer:');
    console.log(`   http://<this-server>:${config.port}/install/`);
    console.log(` Install token: ${token}`);
    console.log(` (also saved in ${TOKEN_FILE})`);
    console.log('============================================================\n');
  });
  return server;
}
