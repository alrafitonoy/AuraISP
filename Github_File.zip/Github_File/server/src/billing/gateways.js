// Online payment gateways. Each gateway: init(payment, ctx) -> { redirectUrl }, and a verification path
// that confirms the payment server-to-server with the gateway before we mark anything as paid.
import crypto from 'node:crypto';
import config from '../config.js';
import { getSetting } from '../lib/settings.js';
import { safeEqual } from '../lib/crypto.js';

const fetchT = (url, opts = {}) => fetch(url, { ...opts, signal: AbortSignal.timeout(20000) });
const money = (cents) => (Number(cents) / 100).toFixed(2);

async function cfg(name) {
  const { payments } = await getSetting('integrations');
  const c = payments?.[name];
  if (!c?.enabled) throw new Error(`${name} is not enabled`);
  return c;
}

export async function enabledGateways() {
  const { payments } = await getSetting('integrations');
  return Object.entries(payments || {}).filter(([, v]) => v?.enabled).map(([k, v]) => ({
    id: k, ...(k === 'manual' ? { instructions: v.instructions } : {}), ...(k === 'stripe' ? { publishableKey: v.publishableKey } : {}),
  }));
}

// ---------------------------------------------------------------- Stripe Checkout
export const stripe = {
  async init(payment, { invoice, customer, currency }) {
    const c = await cfg('stripe');
    const body = new URLSearchParams({
      mode: 'payment',
      'line_items[0][price_data][currency]': currency.toLowerCase(),
      'line_items[0][price_data][unit_amount]': String(payment.amount_cents),
      'line_items[0][price_data][product_data][name]': `Invoice ${invoice?.number || payment.id}`,
      'line_items[0][quantity]': '1',
      success_url: `${config.appUrl}/api/billing/return/stripe?pid=${payment.id}&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${config.appUrl}/portal/billing?payment=cancelled`,
      client_reference_id: String(payment.id),
      'metadata[payment_id]': String(payment.id),
      'metadata[ref]': payment.gateway_ref,
      customer_email: customer.email,
    });
    const res = await fetchT('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${c.secretKey}`, 'Content-Type': 'application/x-www-form-urlencoded', 'Idempotency-Key': payment.gateway_ref },
      body,
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json?.error?.message || 'Stripe error');
    return { redirectUrl: json.url, sessionId: json.id };
  },
  async retrieve(sessionId) {
    const c = await cfg('stripe');
    if (!/^cs_[A-Za-z0-9_]+$/.test(sessionId)) throw new Error('Invalid session');
    const res = await fetchT(`https://api.stripe.com/v1/checkout/sessions/${sessionId}`, { headers: { Authorization: `Bearer ${c.secretKey}` } });
    const json = await res.json();
    if (!res.ok) throw new Error(json?.error?.message || 'Stripe error');
    return json;
  },
  /** Verify Stripe-Signature header (HMAC-SHA256, 5 min tolerance). */
  async verifyWebhook(rawBody, header) {
    const c = await cfg('stripe');
    const parts = Object.fromEntries(String(header || '').split(',').map((p) => p.split('=')).filter((x) => x.length === 2).map(([k, v]) => [k.trim(), v]));
    const sigs = String(header || '').split(',').filter((p) => p.startsWith('v1=')).map((p) => p.slice(3));
    if (!parts.t || !sigs.length) throw new Error('Bad signature header');
    if (Math.abs(Date.now() / 1000 - Number(parts.t)) > 300) throw new Error('Signature too old');
    const expected = crypto.createHmac('sha256', c.webhookSecret).update(`${parts.t}.${rawBody}`).digest('hex');
    if (!sigs.some((s) => safeEqual(s, expected))) throw new Error('Invalid signature');
    return JSON.parse(rawBody);
  },
};

// ---------------------------------------------------------------- SSLCommerz (Bangladesh)
const sslBase = (c) => (c.sandbox ? 'https://sandbox.sslcommerz.com' : 'https://securepay.sslcommerz.com');
export const sslcommerz = {
  async init(payment, { invoice, customer, currency }) {
    const c = await cfg('sslcommerz');
    const cb = `${config.appUrl}/api/billing/return/sslcommerz`;
    const body = new URLSearchParams({
      store_id: c.storeId, store_passwd: c.storePassword, total_amount: money(payment.amount_cents), currency,
      tran_id: payment.gateway_ref, success_url: cb, fail_url: cb, cancel_url: cb,
      ipn_url: `${config.appUrl}/api/billing/webhooks/sslcommerz`,
      cus_name: customer.name, cus_email: customer.email, cus_phone: customer.phone || 'N/A',
      cus_add1: customer.address || 'N/A', cus_city: customer.area || 'N/A', cus_country: 'Bangladesh',
      shipping_method: 'NO', product_name: `Invoice ${invoice?.number || payment.id}`,
      product_category: 'Internet', product_profile: 'non-physical-goods',
    });
    const res = await fetchT(`${sslBase(c)}/gwprocess/v4/api.php`, { method: 'POST', body });
    const json = await res.json();
    if (json.status !== 'SUCCESS' || !json.GatewayPageURL) throw new Error(json.failedreason || 'SSLCommerz error');
    return { redirectUrl: json.GatewayPageURL };
  },
  /** Server-to-server validation — never trust the browser POST alone. */
  async validate(valId) {
    const c = await cfg('sslcommerz');
    const q = new URLSearchParams({ val_id: valId, store_id: c.storeId, store_passwd: c.storePassword, format: 'json' });
    const res = await fetchT(`${sslBase(c)}/validator/api/validationserverAPI.php?${q}`);
    const json = await res.json();
    if (!['VALID', 'VALIDATED'].includes(json.status)) throw new Error('Payment not valid');
    return { tranId: json.tran_id, amountCents: Math.round(Number(json.amount) * 100), currency: json.currency, bankTranId: json.bank_tran_id, raw: json };
  },
};

// ---------------------------------------------------------------- bKash Tokenized Checkout (Bangladesh)
const bkBase = (c) => (c.sandbox ? 'https://tokenized.sandbox.bka.sh/v1.2.0-beta/tokenized/checkout' : 'https://tokenized.pay.bka.sh/v1.2.0-beta/tokenized/checkout');
let bkToken = { v: null, exp: 0 };
async function bkashToken(c) {
  if (bkToken.v && bkToken.exp > Date.now()) return bkToken.v;
  const res = await fetchT(`${bkBase(c)}/token/grant`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json', username: c.username, password: c.password },
    body: JSON.stringify({ app_key: c.appKey, app_secret: c.appSecret }),
  });
  const json = await res.json();
  if (!json.id_token) throw new Error(json.statusMessage || 'bKash auth failed');
  bkToken = { v: json.id_token, exp: Date.now() + (Number(json.expires_in || 3600) - 120) * 1000 };
  return bkToken.v;
}
export const bkash = {
  async init(payment, { invoice }) {
    const c = await cfg('bkash');
    const token = await bkashToken(c);
    const res = await fetchT(`${bkBase(c)}/create`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json', Authorization: token, 'X-APP-Key': c.appKey },
      body: JSON.stringify({
        mode: '0011', payerReference: String(payment.customer_id), callbackURL: `${config.appUrl}/api/billing/return/bkash`,
        amount: money(payment.amount_cents), currency: 'BDT', intent: 'sale', merchantInvoiceNumber: payment.gateway_ref,
      }),
    });
    const json = await res.json();
    if (!json.bkashURL) throw new Error(json.statusMessage || 'bKash error');
    return { redirectUrl: json.bkashURL, paymentID: json.paymentID };
  },
  async execute(paymentID) {
    const c = await cfg('bkash');
    const token = await bkashToken(c);
    const res = await fetchT(`${bkBase(c)}/execute`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json', Authorization: token, 'X-APP-Key': c.appKey },
      body: JSON.stringify({ paymentID }),
    });
    const json = await res.json();
    if (json.transactionStatus !== 'Completed') throw new Error(json.statusMessage || 'bKash payment not completed');
    return { ref: json.merchantInvoiceNumber, amountCents: Math.round(Number(json.amount) * 100), trxID: json.trxID, raw: json };
  },
};

export const GATEWAYS = { stripe, sslcommerz, bkash };
