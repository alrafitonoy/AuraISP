import { db, insert, update, now, parseJson } from '../db/index.js';
import { getSetting, formatMoney } from '../lib/settings.js';
import { queueNotify } from '../lib/notify.js';
import { audit } from '../lib/audit.js';
import { syncCustomer } from '../network/service.js';

const pad = (n, w = 5) => String(n).padStart(w, '0');
const dayIso = (d) => new Date(d).toISOString().slice(0, 10);

/** Next renewal date. anchorDay (the customer's billing day) keeps renewals on the same day every month; without it
 *  the input's day is used, and a period ending on the 31st would be clamped to the 28th and then drift there for good. */
export function addCycle(date, cycle, anchorDay = null) {
  const d = new Date(date);
  const months = cycle === 'yearly' ? 12 : cycle === 'quarterly' ? 3 : 1;
  const day = Number(anchorDay) >= 1 && Number(anchorDay) <= 31 ? Number(anchorDay) : d.getUTCDate();
  d.setUTCDate(1);
  d.setUTCMonth(d.getUTCMonth() + months);
  const last = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate();
  d.setUTCDate(Math.min(day, last));
  return d;
}

export async function nextInvoiceNumber(conn = db()) {
  const { invoicePrefix } = await getSetting('company');
  const year = new Date().getUTCFullYear();
  const prefix = `${invoicePrefix || 'INV'}-${year}-`;
  const row = await conn.get('SELECT number FROM invoices WHERE number LIKE ? ORDER BY id DESC LIMIT 1', [`${prefix}%`]);
  const n = row ? Number(row.number.slice(prefix.length)) + 1 : 1;
  return `${prefix}${pad(n)}`;
}

/** items: [{description, quantity, unit_cents}] */
export async function createInvoice({ customerId, items, periodStart, periodEnd, dueDate, notes, discountCents = 0 }, conn = db()) {
  const company = await getSetting('company');
  const billing = await getSetting('billing');
  const clean = items.map((i) => ({
    description: String(i.description).slice(0, 200),
    quantity: Math.max(1, Math.floor(Number(i.quantity) || 1)),
    unit_cents: Math.round(Number(i.unit_cents) || 0),
  }));
  const subtotal = clean.reduce((s, i) => s + i.quantity * i.unit_cents, 0);
  const discount = Math.min(Math.max(0, Math.round(discountCents)), subtotal);
  const tax = Math.round(((subtotal - discount) * (Number(company.taxPercent) || 0)) / 100);
  const total = subtotal - discount + tax;
  const issued = now();
  const due = dueDate || new Date(Date.now() + (billing.dueDays || 7) * 86400000).toISOString();
  // Concurrent invoice creation can race for the same number; the UNIQUE index catches it and we retry.
  let number; let r;
  for (let attempt = 0; ; attempt++) {
    number = await nextInvoiceNumber(conn);
    try {
      r = await insert('invoices', invoiceRow(number), conn);
      break;
    } catch (e) {
      if (attempt >= 4 || !/unique|duplicate/i.test(e.message)) throw e;
    }
  }
  return { id: r.id, number, total_cents: total };

  function invoiceRow(num) { return {
    number: num, customer_id: customerId, period_start: periodStart || null, period_end: periodEnd || null,
    items: JSON.stringify(clean), subtotal_cents: subtotal, tax_cents: tax, discount_cents: discount, total_cents: total,
    paid_cents: 0, currency: company.currency, status: total === 0 ? 'paid' : 'unpaid', due_date: due, issued_at: issued,
    paid_at: total === 0 ? issued : null, notes: notes || null, created_at: issued,
  }; }
}

/** Tell the customer about a new invoice (email gets the PDF). */
export async function notifyInvoice(invoiceId) {
  const i = await db().get('SELECT i.id, i.number, i.total_cents, i.paid_cents, i.due_date, i.status, c.user_id FROM invoices i JOIN customers c ON c.id = i.customer_id WHERE i.id = ?', [invoiceId]);
  if (!i || i.status === 'paid' || i.status === 'void') return;
  queueNotify({ userId: i.user_id, templateKey: 'invoice_created', vars: { invoice: i.number, amount: await formatMoney(Number(i.total_cents) - Number(i.paid_cents)), due_date: dayIso(i.due_date) }, link: '/portal/billing', attach: { invoiceId: i.id } });
}

/** Credit for the unused part of the current plan when upgrading mid-cycle. */
export async function prorationQuote(customer, fromPlan, toPlan) {
  const billing = await getSetting('billing');
  if (!fromPlan || !billing.prorate || !customer.next_due_date) {
    return { creditCents: 0, chargeCents: toPlan.price_cents, ratio: 1 };
  }
  const end = new Date(customer.next_due_date).getTime();
  const months = fromPlan.billing_cycle === 'yearly' ? 12 : fromPlan.billing_cycle === 'quarterly' ? 3 : 1;
  const startD = new Date(end);
  startD.setUTCMonth(startD.getUTCMonth() - months);
  const periodMs = Math.max(1, end - startD.getTime());
  const ratio = Math.min(1, Math.max(0, (end - Date.now()) / periodMs));
  const credit = Math.round(fromPlan.price_cents * ratio);
  const charge = Math.max(0, Math.round(toPlan.price_cents * ratio) - credit);
  return { creditCents: credit, chargeCents: charge, ratio: +ratio.toFixed(3) };
}

/**
 * Apply a completed payment. Idempotent: a payment already marked success is ignored.
 * Validates amount, updates invoice, reactivates suspended customers, applies pending plan changes.
 */
export async function completePayment(paymentId, { gatewayAmountCents, gatewayRef, meta } = {}) {
  const effects = await db().transaction(async (t) => {
    const p = await t.get('SELECT * FROM payments WHERE id = ?', [paymentId]);
    if (!p) throw new Error('Payment not found');
    if (p.status === 'success') return null;
    if (p.status !== 'pending') throw new Error(`Payment is ${p.status}`);
    if (gatewayAmountCents != null && Math.abs(Number(gatewayAmountCents) - Number(p.amount_cents)) > 1) {
      await t.run('UPDATE payments SET status = ?, meta = ? WHERE id = ?', ['failed', JSON.stringify({ reason: 'amount_mismatch', gatewayAmountCents, meta }), p.id]);
      throw new Error('Paid amount does not match the expected amount');
    }
    // Guarded transition: a Stripe webhook and the browser return can complete the same payment at the same time.
    // Only the request that actually flips pending → success may credit the invoice/balance.
    const flipped = await t.run("UPDATE payments SET status = ?, completed_at = ?, meta = ?, gateway_ref = COALESCE(?, gateway_ref) WHERE id = ? AND status = 'pending'",
      ['success', now(), JSON.stringify(meta || parseJson(p.meta, {})), gatewayRef || null, p.id]);
    if (!flipped.changes) return null;
    let invoice = null;
    if (p.invoice_id) {
      invoice = await t.get('SELECT * FROM invoices WHERE id = ?', [p.invoice_id]);
      const paid = Number(invoice.paid_cents) + Number(p.amount_cents);
      const full = paid >= Number(invoice.total_cents);
      await t.run('UPDATE invoices SET paid_cents = ?, status = ?, paid_at = ? WHERE id = ?',
        [paid, full ? 'paid' : 'partial', full ? now() : null, invoice.id]);
      invoice = { ...invoice, paid_cents: paid, status: full ? 'paid' : 'partial' };
    } else {
      await t.run('UPDATE customers SET balance_cents = balance_cents + ? WHERE id = ?', [p.amount_cents, p.customer_id]);
    }
    return { payment: p, invoice };
  });
  if (!effects) return { alreadyProcessed: true };
  await afterPayment(effects.payment, effects.invoice);
  return { ok: true };
}

async function afterPayment(payment, invoice) {
  const customer = await db().get('SELECT c.*, u.id AS uid FROM customers c JOIN users u ON u.id = c.user_id WHERE c.id = ?', [payment.customer_id]);
  if (!customer) return;
  if (invoice?.status === 'paid') {
    // Apply plan change linked to this invoice
    const change = await db().get('SELECT * FROM plan_changes WHERE invoice_id = ? AND status = ?', [invoice.id, 'awaiting_payment']);
    if (change) await applyPlanChange(change.id);
    // Advance due date for recurring invoices and reactivate.
    if (invoice.period_end && (!customer.next_due_date || invoice.period_end > customer.next_due_date)) {
      await db().run('UPDATE customers SET next_due_date = ? WHERE id = ?', [invoice.period_end, customer.id]);
    }
    // Only service stopped for NON-PAYMENT is restored automatically (manual or data-cap suspensions stay).
    const autoRestore = customer.status === 'pending' || (customer.status === 'suspended' && (!customer.suspended_reason || customer.suspended_reason === 'overdue'));
    if (autoRestore) {
      const unpaid = await db().get("SELECT COUNT(*) AS n FROM invoices WHERE customer_id = ? AND status IN ('overdue')", [customer.id]);
      if (!Number(unpaid?.n)) {
        await db().run('UPDATE customers SET status = ?, suspended_reason = NULL, updated_at = ? WHERE id = ?', ['active', now(), customer.id]);
        await syncCustomer(customer.id);
      }
    }
  }
  queueNotify({
    userId: customer.uid, templateKey: 'payment_received',
    vars: { amount: await formatMoney(payment.amount_cents), invoice: invoice?.number || '—', method: payment.method },
    link: '/portal/billing', kind: 'success', attach: { paymentId: payment.id },
  });
}

export async function applyPlanChange(changeId) {
  const ch = await db().get('SELECT * FROM plan_changes WHERE id = ?', [changeId]);
  if (!ch || ch.status === 'applied') return;
  const plan = await db().get('SELECT * FROM plans WHERE id = ?', [ch.to_plan_id]);
  const c = await db().get('SELECT * FROM customers WHERE id = ?', [ch.customer_id]);
  const patch = { plan_id: ch.to_plan_id, custom_download_kbps: null, custom_upload_kbps: null, updated_at: now() };
  if (!c.next_due_date) patch.next_due_date = addCycle(new Date(), plan.billing_cycle).toISOString();
  if (c.status === 'pending') patch.status = 'active';
  await update('customers', c.id, patch);
  await db().run('UPDATE plan_changes SET status = ?, applied_at = ? WHERE id = ?', ['applied', now(), ch.id]);
  await insert('sales', { customer_id: c.id, plan_id: plan.id, staff_id: ch.requested_by, kind: ch.kind === 'new' ? 'new' : ch.kind, amount_cents: ch.prorated_cents, created_at: now() });
  await syncCustomer(c.id);
  queueNotify({ userId: c.user_id, templateKey: 'plan_changed', vars: { plan: plan.name }, link: '/portal', kind: 'success' });
}

/** Daily job: create invoices for customers whose cycle renews within N days. */
export async function generateRecurringInvoices() {
  const billing = await getSetting('billing');
  const horizon = new Date(Date.now() + (billing.generateDaysBefore || 3) * 86400000).toISOString();
  const due = await db().all(
    `SELECT c.*, p.name AS plan_name, p.price_cents, p.billing_cycle FROM customers c JOIN plans p ON p.id = c.plan_id
      WHERE c.status IN ('active','suspended') AND c.next_due_date IS NOT NULL AND c.next_due_date <= ?`, [horizon]);
  let created = 0;
  for (const c of due) {
    const periodStart = c.next_due_date;
    const periodEnd = addCycle(periodStart, c.billing_cycle, c.billing_day).toISOString();
    const exists = await db().get('SELECT id FROM invoices WHERE customer_id = ? AND period_start = ? AND status != ?', [c.id, periodStart, 'void']);
    if (exists) continue;
    const items = [{ description: `${c.plan_name} — ${dayIso(periodStart)} to ${dayIso(periodEnd)}`, quantity: 1, unit_cents: c.price_cents }];
    if (Number(c.ip_addon_cents) > 0) {
      const months = c.billing_cycle === 'yearly' ? 12 : c.billing_cycle === 'quarterly' ? 3 : 1;
      items.push({ description: `${c.ip_type === 'dedicated' ? 'Dedicated' : 'Real'} IP ${c.ip_address || ''}`.trim(), quantity: months, unit_cents: Number(c.ip_addon_cents) });
    }
    const inv = await createInvoice({
      customerId: c.id,
      items,
      periodStart, periodEnd, dueDate: periodStart,
    });
    // Use any prepaid balance
    if (Number(c.balance_cents) > 0 && inv.total_cents > 0) {
      const use = Math.min(Number(c.balance_cents), inv.total_cents);
      const pay = await insert('payments', { invoice_id: inv.id, customer_id: c.id, amount_cents: use, currency: (await getSetting('company')).currency, method: 'balance', status: 'pending', created_at: now() });
      await db().run('UPDATE customers SET balance_cents = balance_cents - ? WHERE id = ?', [use, c.id]);
      await completePayment(pay.id);
    }
    queueNotify({ userId: c.user_id, templateKey: 'invoice_created', vars: { invoice: inv.number, amount: await formatMoney(inv.total_cents), due_date: dayIso(periodStart) }, link: '/portal/billing', attach: { invoiceId: inv.id } });
    created++;
  }
  return created;
}

/** Is a per-customer "never auto-suspend" override currently in force? */
export const overrideActive = (c) => c.billing_override === 'never_suspend' && (!c.override_until || c.override_until > now());

/**
 * Daily job: mark overdue invoices, warn, then stop service according to the admin's invoicing rules
 * (Settings → Billing): minimum overdue invoices, minimum overdue amount, grace days, optional auto-terminate.
 * Customers with an active manual override are skipped.
 */
export async function enforceOverdue() {
  const billing = await getSetting('billing');
  await db().run("UPDATE invoices SET status = 'overdue' WHERE status IN ('unpaid','partial') AND due_date < ?", [now()]);
  if (!billing.autoSuspend) return 0;
  const DAY = 86400000;
  const grace = Number(billing.graceDays || 0);
  const rows = await db().all(`SELECT c.id, c.user_id, c.status, c.suspended_reason, c.billing_override, c.override_until,
      COUNT(i.id) AS n, SUM(i.total_cents - i.paid_cents) AS due, MIN(i.due_date) AS oldest
    FROM customers c JOIN invoices i ON i.customer_id = c.id AND i.status = 'overdue'
      -- an unpaid upgrade quote is not a debt: the customer simply stays on their current plan
      AND NOT EXISTS (SELECT 1 FROM plan_changes pc WHERE pc.invoice_id = i.id AND pc.status = 'awaiting_payment' AND pc.from_plan_id IS NOT NULL)
    WHERE c.status IN ('active', 'suspended') GROUP BY c.id, c.user_id, c.status, c.suspended_reason, c.billing_override, c.override_until`);
  let suspended = 0;
  for (const r of rows) {
    if (overrideActive(r)) continue;
    const daysLate = Math.floor((Date.now() - new Date(r.oldest).getTime()) / DAY);
    const meets = Number(r.n) >= Number(billing.suspendMinOverdueInvoices || 1) && Number(r.due) >= Number(billing.suspendMinOverdueCents || 0);
    if (r.status === 'active' && meets) {
      if (daysLate > grace) {
        await db().run("UPDATE customers SET status = 'suspended', suspended_reason = 'overdue', updated_at = ? WHERE id = ?", [now(), r.id]);
        await syncCustomer(r.id);
        await audit(null, 'billing.auto_suspend', 'customer', r.id, { overdue_invoices: Number(r.n), due_cents: Number(r.due), days_late: daysLate });
        queueNotify({ userId: r.user_id, templateKey: 'service_suspended', vars: { reason: 'for overdue invoices' }, link: '/portal/billing', kind: 'warning' });
        suspended++;
      } else if (billing.warnBeforeSuspendDays && grace - daysLate === Number(billing.warnBeforeSuspendDays)) {
        queueNotify({ userId: r.user_id, channels: ['inapp', 'push', 'email', 'sms'], subject: 'Service will be paused soon', ref: `suspend-warn:${r.id}:${String(r.oldest).slice(0, 10)}`,
          body: `You have ${r.n} overdue invoice(s). Please pay within ${billing.warnBeforeSuspendDays} day(s) to keep your internet running.`, link: '/portal/billing', kind: 'warning' });
      }
    } else if (r.status === 'suspended' && r.suspended_reason === 'overdue' && Number(billing.terminateAfterDays) > 0 && daysLate > Number(billing.terminateAfterDays)) {
      await db().run("UPDATE customers SET status = 'terminated', updated_at = ? WHERE id = ?", [now(), r.id]);
      await syncCustomer(r.id);
      await audit(null, 'billing.auto_terminate', 'customer', r.id, { days_late: daysLate });
    }
  }
  return suspended;
}
