import { getSetting } from '../lib/settings.js';

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/** Printable invoice (browser "Save as PDF" produces the PDF on every platform). */
export async function renderInvoiceHtml(inv) {
  const b = await getSetting('branding');
  const c = await getSetting('company');
  const m = (cents) => `${esc(c.currencySymbol)}${(Number(cents) / 100).toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
  const d = (iso) => (iso ? new Date(iso).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—');
  const logo = /^https:\/\//.test(b.logoUrl || '') ? `<img src="${esc(b.logoUrl)}" alt="" style="height:44px">` : `<div class="brand">${esc(b.companyName)}</div>`;
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(inv.number)}</title>
<style>
  body{font-family:'Segoe UI',Arial,sans-serif;color:#1c1c33;margin:0;padding:40px;background:#fff}
  .top{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:4px solid ${esc(b.primary)};padding-bottom:20px}
  .brand{font-size:26px;font-weight:800;color:${esc(b.primary)}}
  h1{margin:0;font-size:30px;letter-spacing:2px;color:${esc(b.primary)}}
  .muted{color:#6b6b85;font-size:13px}
  .grid{display:flex;justify-content:space-between;margin:28px 0}
  table{width:100%;border-collapse:collapse}
  th{background:#f3f1ff;text-align:left;padding:10px;font-size:13px}
  td{padding:10px;border-bottom:1px solid #eee;font-size:14px}
  .r{text-align:right}
  .tot td{border:none;padding:6px 10px}
  .big{font-size:18px;font-weight:700}
  .stamp{display:inline-block;padding:6px 14px;border-radius:999px;font-weight:700;text-transform:uppercase;font-size:12px;
         background:${inv.status === 'paid' ? '#d6f8e5' : '#ffe6e6'};color:${inv.status === 'paid' ? '#0a8a4a' : '#c0262d'}}
  @media print{body{padding:0}.noprint{display:none}}
</style></head><body>
<div class="top"><div>${logo}<div class="muted">${esc(c.legalName)}<br>${esc(c.address)}<br>${esc(c.phone)} · ${esc(c.email)}${c.taxId ? `<br>Tax ID: ${esc(c.taxId)}` : ''}</div></div>
<div style="text-align:right"><h1>INVOICE</h1><div class="muted"># ${esc(inv.number)}</div><div style="margin-top:8px"><span class="stamp">${esc(inv.status)}</span></div></div></div>
<div class="grid"><div><div class="muted">Billed to</div><strong>${esc(inv.customer_name)}</strong><br><span class="muted">${esc(inv.customer_code)}<br>${esc(inv.customer_address || '')}<br>${esc(inv.customer_email || '')}</span></div>
<div style="text-align:right"><div class="muted">Issued</div>${d(inv.issued_at)}<div class="muted" style="margin-top:6px">Due</div>${d(inv.due_date)}</div></div>
<table><thead><tr><th>Description</th><th class="r">Qty</th><th class="r">Unit</th><th class="r">Amount</th></tr></thead><tbody>
${inv.items.map((i) => `<tr><td>${esc(i.description)}</td><td class="r">${i.quantity}</td><td class="r">${m(i.unit_cents)}</td><td class="r">${m(i.quantity * i.unit_cents)}</td></tr>`).join('')}
</tbody></table>
<table style="width:320px;margin-left:auto;margin-top:16px" class="tot">
<tr><td>Subtotal</td><td class="r">${m(inv.subtotal_cents)}</td></tr>
${Number(inv.discount_cents) ? `<tr><td>Discount</td><td class="r">-${m(inv.discount_cents)}</td></tr>` : ''}
${Number(inv.tax_cents) ? `<tr><td>Tax (${esc(c.taxPercent)}%)</td><td class="r">${m(inv.tax_cents)}</td></tr>` : ''}
<tr class="big"><td>Total</td><td class="r">${m(inv.total_cents)}</td></tr>
<tr><td>Paid</td><td class="r">${m(inv.paid_cents)}</td></tr>
<tr class="big"><td>Balance due</td><td class="r">${m(Number(inv.total_cents) - Number(inv.paid_cents))}</td></tr></table>
${inv.notes ? `<p class="muted">${esc(inv.notes)}</p>` : ''}
<p class="muted" style="margin-top:40px">Thank you for choosing ${esc(b.companyName)}.</p>
</body></html>`;
}
